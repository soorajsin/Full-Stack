processGoogleToken({
    "newToken": "ChAIgNynnwYQ8se30fXL1plaEjkAxziOsTejE-qiU-a9MRzaRgT7TxUa3UJTa1EKOIxZbMkFs1VeX-IviPS33wewUHEW4f0zwN8ZaFE",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2023-02-05-21",
    "pucrd": ""
});