(function(sttc) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    'use strict';
    var ca = {},
        k = this || self;

    function da(a) {
        var b = typeof a;
        b = "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null";
        return "array" == b || "object" == b && "number" == typeof a.length
    }

    function p(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function ea(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function fa(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function ha(a, b, c) {
        Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ha = ea : ha = fa;
        return ha.apply(null, arguments)
    }

    function ia(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function q(a, b) {
        a = a.split(".");
        var c = k || k;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function ja(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.U = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.Pa = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    }

    function ka(a) {
        return a
    };
    var la;
    var ma = /&/g,
        na = /</g,
        oa = />/g,
        pa = /"/g,
        qa = /'/g,
        ra = /\x00/g,
        sa = /[\x00&<>"']/;

    function ta() {
        var a = k.navigator;
        return a && (a = a.userAgent) ? a : ""
    }

    function r(a) {
        return -1 != ta().indexOf(a)
    };

    function va(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function wa(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function xa(a) {
        const b = a.length;
        if (0 < b) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function ya(a) {
        ya[" "](a);
        return a
    }
    ya[" "] = function() {};

    function za(a, b) {
        try {
            return ya(a[b]), !0
        } catch (c) {}
        return !1
    };
    var Aa = r("Trident") || r("MSIE"),
        Ba = r("Gecko") && !(-1 != ta().toLowerCase().indexOf("webkit") && !r("Edge")) && !(r("Trident") || r("MSIE")) && !r("Edge"),
        Ca = -1 != ta().toLowerCase().indexOf("webkit") && !r("Edge");
    var Da = {},
        Ea = null;
    var Fa = "undefined" !== typeof Uint8Array;
    const Ga = !Aa && "function" === typeof k.btoa;
    const t = Symbol();

    function Ha(a) {
        let b;
        t ? b = a[t] : b = a.M;
        return null == b ? 0 : b
    }

    function Ia(a, b) {
        t ? a[t] = b : void 0 !== a.M ? a.M = b : Object.defineProperties(a, {
            M: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    };
    var Ja = {};

    function Ka(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    var La;
    const Ma = [];
    Ia(Ma, 23);
    La = Object.freeze(Ma);

    function Na(a) {
        if (Ha(a.i) & 2) throw Error("Cannot mutate an immutable Message");
    }

    function Oa(a) {
        var b = a.length;
        (b = b ? a[b - 1] : void 0) && Ka(b) ? b.g = 1 : a.push({
            g: 1
        })
    };

    function Pa(a) {
        const b = a.o + a.j;
        return a.h || (a.h = a.i[b] = {})
    }

    function Qa(a, b) {
        return -1 === b ? null : b >= a.o ? a.h ? a.h[b] : void 0 : a.i[b + a.j]
    }

    function Ra(a, b, c, d) {
        a.l && (a.l = void 0);
        if (b >= a.o || d) return Pa(a)[b] = c, a;
        a.i[b + a.j] = c;
        (c = a.h) && b in c && delete c[b];
        return a
    }

    function u(a, b, c, d) {
        Na(a);
        c !== d ? Ra(a, b, c) : Ra(a, b, void 0, !1);
        return a
    }

    function Sa(a, b) {
        return null == a ? b : a
    };
    let Ta;

    function Va(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "object":
                if (a)
                    if (Array.isArray(a)) {
                        if (0 !== (Ha(a) & 128)) return a = Array.prototype.slice.call(a), Oa(a), a
                    } else if (Fa && null != a && a instanceof Uint8Array) {
                    if (Ga) {
                        for (var b = ""; 10240 < a.length;) b += String.fromCharCode.apply(null, a.subarray(0, 10240)), a = a.subarray(10240);
                        b += String.fromCharCode.apply(null, a);
                        a = btoa(b)
                    } else {
                        void 0 === b && (b = 0);
                        if (!Ea) {
                            Ea = {};
                            for (var c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                                    d = ["+/=", "+/", "-_=", "-_.", "-_"], e = 0; 5 > e; e++) {
                                var f = c.concat(d[e].split(""));
                                Da[e] = f;
                                for (var g = 0; g < f.length; g++) {
                                    var h = f[g];
                                    void 0 === Ea[h] && (Ea[h] = g)
                                }
                            }
                        }
                        b = Da[b];
                        c = Array(Math.floor(a.length / 3));
                        d = b[64] || "";
                        for (e = f = 0; f < a.length - 2; f += 3) {
                            var l = a[f],
                                m = a[f + 1];
                            h = a[f + 2];
                            g = b[l >> 2];
                            l = b[(l & 3) << 4 | m >> 4];
                            m = b[(m & 15) << 2 | h >> 6];
                            h = b[h & 63];
                            c[e++] = g + l + m + h
                        }
                        g = 0;
                        h = d;
                        switch (a.length - f) {
                            case 2:
                                g = a[f + 1], h = b[(g & 15) << 2] || d;
                            case 1:
                                a = a[f], c[e] = b[a >> 2] + b[(a & 3) << 4 | g >> 4] + h + d
                        }
                        a = c.join("")
                    }
                    return a
                }
        }
        return a
    };

    function Wa(a, b, c, d) {
        if (null != a) {
            if (Array.isArray(a)) a = Xa(a, b, c, void 0 !== d);
            else if (Ka(a)) {
                const e = {};
                for (let f in a) Object.prototype.hasOwnProperty.call(a, f) && (e[f] = Wa(a[f], b, c, d));
                a = e
            } else a = b(a, d);
            return a
        }
    }

    function Xa(a, b, c, d) {
        const e = Ha(a);
        d = d ? !!(e & 16) : void 0;
        a = Array.prototype.slice.call(a);
        for (let f = 0; f < a.length; f++) a[f] = Wa(a[f], b, c, d);
        c(e, a);
        return a
    }

    function Ya(a) {
        return a.Ha === Ja ? a.toJSON() : Va(a)
    }

    function Za(a, b) {
        a & 128 && Oa(b)
    };
    var ab = class {
        constructor(a, b, c) {
            null == a && (a = Ta);
            Ta = void 0;
            var d = this.constructor.h || 0,
                e = 0 < d,
                f = this.constructor.messageId,
                g = !1;
            if (null == a) {
                a = f ? [f] : [];
                var h = 48;
                var l = !0;
                e && (d = 0, h |= 128);
                Ia(a, h)
            } else {
                if (!Array.isArray(a)) throw Error();
                if (f && f !== a[0]) throw Error();
                l = a;
                t ? l = l[t] |= 0 : void 0 !== l.M ? l = l.M |= 0 : (Object.defineProperties(l, {
                    M: {
                        value: 0,
                        configurable: !0,
                        writable: !0,
                        enumerable: !1
                    }
                }), l = 0);
                const m = l;
                let n = m;
                if (l = 0 !== (16 & n))(g = 0 !== (32 & n)) || (n |= 32);
                if (e)
                    if (128 & n) d = 0;
                    else {
                        if (0 < a.length) {
                            const v = a[a.length -
                                1];
                            if (Ka(v) && "g" in v) {
                                d = 0;
                                n |= 128;
                                delete v.g;
                                let y = !0;
                                for (h in v) {
                                    y = !1;
                                    break
                                }
                                y && a.pop()
                            }
                        }
                    }
                else if (128 & n) throw Error();
                m !== n && Ia(a, n)
            }
            this.j = (f ? 0 : -1) - d;
            this.i = a;
            a: {
                f = this.i.length;d = f - 1;
                if (f && (f = this.i[d], Ka(f))) {
                    this.h = f;
                    this.o = d - this.j;
                    break a
                }
                void 0 !== b && -1 < b ? (this.o = Math.max(b, d + 1 - this.j), this.h = void 0) : this.o = Number.MAX_VALUE
            }
            if (!e && this.h && "g" in this.h) throw Error('Unexpected "g" flag in sparse object of message that is not a group type.');
            if (c) {
                b = l && !g && !0;
                e = this.o;
                let m;
                for (g = 0; g < c.length; g++) l =
                    c[g], l < e ? (l += this.j, (d = a[l]) ? $a(d, b) : a[l] = La) : (m || (m = Pa(this)), (d = m[l]) ? $a(d, b) : m[l] = La)
            }
        }
        toJSON() {
            return Xa(this.i, Ya, Za)
        }
    };

    function $a(a, b) {
        if (Array.isArray(a)) {
            var c = Ha(a),
                d = 1;
            !b || c & 2 || (d |= 16);
            (c & d) !== d && Ia(a, c | d)
        }
    }
    ab.prototype.Ha = Ja;
    let bb = void 0;

    function cb(a, b) {
        const c = bb;
        bb = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    };

    function w(a, b) {
        this.i = a === db && b || "";
        this.j = eb
    }
    w.prototype.V = !0;
    w.prototype.h = function() {
        return this.i
    };
    var eb = {},
        db = {};

    function fb(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function gb(a) {
        let b = 0;
        return function(c) {
            k.clearTimeout(b);
            const d = arguments;
            b = k.setTimeout(function() {
                a.apply(void 0, d)
            }, 100)
        }
    };

    function x(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    }

    function hb(a, b, c) {
        return a.removeEventListener ? (a.removeEventListener(b, c, !1), !0) : !1
    };

    function ib(a, b, c) {
        for (const d in a) b.call(c, a[d], d, a)
    }

    function jb(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    }
    const kb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function lb(a, b) {
        let c, d;
        for (let e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (let f = 0; f < kb.length; f++) c = kb[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    var mb;

    function nb() {
        if (void 0 === mb) {
            var a = null,
                b = k.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: ka,
                        createScript: ka,
                        createScriptURL: ka
                    })
                } catch (c) {
                    k.console && k.console.error(c.message)
                }
                mb = a
            } else mb = a
        }
        return mb
    };
    var pb = class {
        constructor(a, b) {
            this.i = b === ob ? a : ""
        }
        toString() {
            return this.i + ""
        }
    };
    pb.prototype.V = !0;
    pb.prototype.h = function() {
        return this.i.toString()
    };

    function qb(a) {
        return a instanceof pb && a.constructor === pb ? a.i : "type_error:TrustedResourceUrl"
    }

    function rb(a) {
        sb(a instanceof w && a.constructor === w && a.j === eb ? a.i : "type_error:Const")
    }
    var ob = {};

    function sb(a) {
        const b = nb();
        a = b ? b.createScriptURL(a) : a;
        return new pb(a, ob)
    };
    const tb = {};

    function ub(a) {
        return a instanceof vb && a.constructor === vb ? a.i : "type_error:SafeStyle"
    }
    class vb {
        constructor(a, b) {
            this.i = b === tb ? a : "";
            this.V = !0
        }
        h() {
            return this.i
        }
        toString() {
            return this.i.toString()
        }
    };
    const zb = {};

    function Ab(a) {
        return a instanceof Bb && a.constructor === Bb ? a.i : "type_error:SafeStyleSheet"
    }
    class Bb {
        constructor(a, b) {
            this.i = b === zb ? a : "";
            this.V = !0
        }
        toString() {
            return this.i.toString()
        }
        h() {
            return this.i
        }
    };
    const Cb = {};

    function Db(a) {
        return a instanceof z && a.constructor === z ? a.i : "type_error:SafeHtml"
    }

    function Eb(a) {
        a instanceof z || (a = "object" == typeof a && a.V ? a.h() : String(a), sa.test(a) && (-1 != a.indexOf("&") && (a = a.replace(ma, "&amp;")), -1 != a.indexOf("<") && (a = a.replace(na, "&lt;")), -1 != a.indexOf(">") && (a = a.replace(oa, "&gt;")), -1 != a.indexOf('"') && (a = a.replace(pa, "&quot;")), -1 != a.indexOf("'") && (a = a.replace(qa, "&#39;")), -1 != a.indexOf("\x00") && (a = a.replace(ra, "&#0;"))), a = Fb(a));
        return a
    }

    function Fb(a) {
        const b = nb();
        a = b ? b.createHTML(a) : a;
        return new z(a, Cb)
    }
    class z {
        constructor(a, b) {
            this.i = b === Cb ? a : "";
            this.V = !0
        }
        h() {
            return this.i.toString()
        }
        toString() {
            return this.i.toString()
        }
    }
    var Gb = new z(k.trustedTypes && k.trustedTypes.emptyHTML || "", Cb);
    var Hb = fb(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = Db(Gb);
        return !b.parentElement
    });

    function A(a, b) {
        this.width = a;
        this.height = b
    }
    A.prototype.aspectRatio = function() {
        return this.width / this.height
    };
    A.prototype.isEmpty = function() {
        return !(this.width * this.height)
    };
    A.prototype.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    A.prototype.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    A.prototype.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };

    function Ib(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function Jb(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };

    function Kb(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!da(f) || p(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (p(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                wa(g ? xa(f) : f, d)
            }
        }
    }

    function Lb(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function Mb(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    }

    function Nb() {
        this.h = k.document || document
    }
    Nb.prototype.getElementsByTagName = function(a, b) {
        return (b || this.h).getElementsByTagName(String(a))
    };
    Nb.prototype.createElement = function(a) {
        return Lb(this.h, a)
    };
    Nb.prototype.createTextNode = function(a) {
        return this.h.createTextNode(String(a))
    };
    Nb.prototype.append = function(a, b) {
        Kb(9 == a.nodeType ? a : a.ownerDocument || a.document, a, arguments)
    };
    var Ob = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function Pb(a, b) {
        a.src = qb(b);
        (b = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };

    function Qb(a) {
        try {
            return !!a && null != a.location.href && za(a, "foo")
        } catch {
            return !1
        }
    }

    function Rb() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function Sb(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Tb(a) {
        const b = [];
        Sb(a, function(c) {
            b.push(c)
        });
        return b
    }
    var B = (a, b) => {
            Sb(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        },
        Vb = (a, b) => {
            if ("length" in a.style) {
                a = a.style;
                const c = a.length;
                for (let d = 0; d < c; d++) {
                    const e = a[d];
                    b(a[e], e, a)
                }
            } else a = Ub(a.style.cssText), Sb(a, b)
        },
        Ub = a => {
            const b = {};
            if (a) {
                const c = /\s*:\s*/;
                wa((a || "").split(/\s*;\s*/), d => {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d && e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        Wb = a => {
            const b = /!\s*important/i;
            Vb(a, (c, d) => {
                b.test(c) ? b.test(c) : a.style.setProperty(d, c, "important")
            })
        };
    const Xb = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        Yb = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        Zb = /.*domain\.test$/,
        $b = /\.prod\.google\.com(:\d+)?$/;
    var ac = a => Xb[a] || Yb.test(a) || Zb.test(a) || $b.test(a);
    let bc = [];
    const cc = () => {
        const a = bc;
        bc = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var dc = a => {
            bc.push(a);
            1 == bc.length && (window.Promise ? Promise.resolve().then(cc) : window.setImmediate ? setImmediate(cc) : setTimeout(cc, 0))
        },
        ec = (a, b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        });

    function fc(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function gc(a) {
        k.google_image_requests || (k.google_image_requests = []);
        const b = fc("IMG", k.document);
        b.src = a;
        k.google_image_requests.push(b)
    };
    var hc = window;

    function ic() {
        var a = k.context || k.AMP_CONTEXT_DATA;
        if (!a) try {
            a = k.parent.context || k.parent.AMP_CONTEXT_DATA
        } catch {}
        return (a = a ? .pageViewId && a ? .canonicalUrl ? a : null) ? Qb(a.master) ? a.master : null : null
    };

    function jc(a, ...b) {
        if (0 === b.length) return sb(a[0]);
        const c = [a[0]];
        for (let d = 0; d < b.length; d++) c.push(encodeURIComponent(b[d])), c.push(a[d + 1]);
        return sb(c.join(""))
    }

    function kc(a, b) {
        let c = qb(a).toString();
        if (/#/.test(c)) throw Error("");
        let d = /\?/.test(c) ? "&" : "?";
        b.forEach((e, f) => {
            e = e instanceof Array ? e : [e];
            for (let g = 0; g < e.length; g++) {
                const h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return sb(c)
    };

    function C(a, b, c) {
        if ("string" === typeof b)(b = lc(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = lc(c, d);
                f && (c.style[f] = e)
            }
    }
    var mc = {};

    function lc(a, b) {
        var c = mc[b];
        if (!c) {
            var d = Ib(b);
            c = d;
            void 0 === a.style[d] && (d = (Ca ? "Webkit" : Ba ? "Moz" : Aa ? "ms" : null) + Jb(d), void 0 !== a.style[d] && (c = d));
            mc[b] = c
        }
        return c
    };
    var nc = () => {
        if (!hc) return !1;
        try {
            return !(!hc.navigator.standalone && !hc.top.navigator.standalone)
        } catch (a) {
            return !1
        }
    };
    class oc {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };
    const pc = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var qc = class {
            constructor(a, b) {
                this.h = a;
                this.i = b
            }
        },
        rc = class {
            constructor(a, b, c) {
                this.url = a;
                this.B = b;
                this.Ca = !!c;
                this.depth = null
            }
        };

    function sc(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function tc(a, b, c, d, e) {
        const f = [];
        Sb(a, function(g, h) {
            (g = uc(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function uc(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(uc(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(tc(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function vc(a) {
        let b = 1;
        for (const c in a.i) b = c.length > b ? c.length : b;
        return 3997 - b - a.j.length - 1
    }

    function wc(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = vc(a) - b.length;
        if (0 > d) return "";
        a.h.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.h.length; f++) {
            const g = a.h[f],
                h = a.i[g];
            for (let l = 0; l < h.length; l++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let m = tc(h[l], a.j, ",$");
                if (m) {
                    m = e + m;
                    if (d >= m.length) {
                        d -= m.length;
                        c += m;
                        e = a.j;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class xc {
        constructor() {
            this.j = "&";
            this.i = {};
            this.o = 0;
            this.h = []
        }
    };

    function yc(a, b) {
        0 <= b && 1 >= b && (a.h = b)
    }

    function zc(a, b, c, d = !1, e) {
        if ((d ? a.h : Math.random()) < (e || .01)) try {
            let f;
            c instanceof xc ? f = c : (f = new xc, Sb(c, (h, l) => {
                var m = f;
                const n = m.o++;
                h = sc(l, h);
                m.h.push(n);
                m.i[n] = h
            }));
            const g = wc(f, "/pagead/gen_204?id=" + b + "&");
            g && gc(g)
        } catch (f) {}
    }
    class Ac {
        constructor() {
            this.h = Math.random()
        }
    };
    let Bc = null;

    function Cc() {
        const a = k.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Dc() {
        const a = k.performance;
        return a && a.now ? a.now() : null
    };
    class Ec {
        constructor(a, b) {
            var c = Dc() || Cc();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.uniqueId = Math.random();
            this.taskId = this.slotId = void 0
        }
    };
    const D = k.performance,
        Fc = !!(D && D.mark && D.measure && D.clearMarks),
        Gc = fb(() => {
            var a;
            if (a = Fc) {
                var b;
                if (null === Bc) {
                    Bc = "";
                    try {
                        a = "";
                        try {
                            a = k.top.location.hash
                        } catch (c) {
                            a = k.location.hash
                        }
                        a && (Bc = (b = a.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = Bc;
                a = !!b.indexOf && 0 <= b.indexOf("1337")
            }
            return a
        });

    function Hc(a) {
        a && D && Gc() && (D.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), D.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Ic(a) {
        a.h = !1;
        a.i != a.j.google_js_reporting_queue && (Gc() && wa(a.i, Hc), a.i.length = 0)
    }
    class Jc {
        constructor(a) {
            this.i = [];
            this.j = a || k;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.h = Gc() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.h) return null;
            a = new Ec(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            D && Gc() && D.mark(b);
            return a
        }
        end(a) {
            if (this.h && "number" === typeof a.value) {
                a.duration = (Dc() || Cc()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                D && Gc() && D.mark(b);
                !this.h || 2048 < this.i.length ||
                    this.i.push(a)
            }
        }
    };

    function Kc(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        if (a.stack) {
            a = a.stack;
            var c = b;
            try {
                -1 == a.indexOf(c) && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n")
            } catch (d) {
                b = c
            }
        }
        return b
    }

    function Lc(a, b) {
        a.i = b
    }

    function Mc(a, b, c) {
        let d, e;
        try {
            a.h && a.h.h ? (e = a.h.start(b.toString(), 3), d = c(), a.h.end(e)) : d = c()
        } catch (f) {
            c = !0;
            try {
                Hc(e), c = a.l(b, new oc(f, {
                    message: Kc(f)
                }), void 0, void 0)
            } catch (g) {
                a.ea(217, g)
            }
            if (c) window.console ? .error ? .(f);
            else throw f;
        }
        return d
    }

    function Nc(a, b, c) {
        return (...d) => Mc(a, b, () => c.apply(void 0, d))
    }

    function Oc(a, b) {
        var c = E;
        b.catch(d => {
            d = d ? d : "unknown rejection";
            c.ea(a, d instanceof Error ? d : Error(d), void 0, c.i || void 0)
        })
    }
    class Pc {
        constructor(a, b = null) {
            this.o = a;
            this.i = null;
            this.l = this.ea;
            this.h = b;
            this.j = !1
        }
        ea(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const Q = new xc;
                var g = Q;
                g.h.push(1);
                g.i[1] = sc("context", a);
                b.error && b.meta && b.id || (b = new oc(b, {
                    message: Kc(b)
                }));
                if (b.msg) {
                    g = Q;
                    var h = b.msg.substring(0, 512);
                    g.h.push(2);
                    g.i[2] = sc("msg", h)
                }
                var l = b.meta || {};
                b = l;
                if (this.i) try {
                    this.i(b)
                } catch (aa) {}
                if (d) try {
                    d(b)
                } catch (aa) {}
                d = Q;
                l = [l];
                d.h.push(3);
                d.i[3] = l;
                d = k;
                l = [];
                b = null;
                do {
                    var m = d;
                    if (Qb(m)) {
                        var n = m.location.href;
                        b = m.document && m.document.referrer ||
                            null
                    } else n = b, b = null;
                    l.push(new rc(n || "", m));
                    try {
                        d = m.parent
                    } catch (aa) {
                        d = null
                    }
                } while (d && m != d);
                for (let aa = 0, Uc = l.length - 1; aa <= Uc; ++aa) l[aa].depth = Uc - aa;
                m = k;
                if (m.location && m.location.ancestorOrigins && m.location.ancestorOrigins.length == l.length - 1)
                    for (n = 1; n < l.length; ++n) {
                        var v = l[n];
                        v.url || (v.url = m.location.ancestorOrigins[n - 1] || "", v.Ca = !0)
                    }
                var y = l;
                let Ua = new rc(k.location.href, k, !1);
                m = null;
                const wb = y.length - 1;
                for (v = wb; 0 <= v; --v) {
                    var R = y[v];
                    !m && pc.test(R.url) && (m = R);
                    if (R.url && !R.Ca) {
                        Ua = R;
                        break
                    }
                }
                R = null;
                const Ze =
                    y.length && y[wb].url;
                0 != Ua.depth && Ze && (R = y[wb]);
                f = new qc(Ua, R);
                if (f.i) {
                    y = Q;
                    var ba = f.i.url || "";
                    y.h.push(4);
                    y.i[4] = sc("top", ba)
                }
                var xb = {
                    url: f.h.url || ""
                };
                if (f.h.url) {
                    var yb = f.h.url.match(Ob),
                        ua = yb[1],
                        Vc = yb[3],
                        Wc = yb[4];
                    ba = "";
                    ua && (ba += ua + ":");
                    Vc && (ba += "//", ba += Vc, Wc && (ba += ":" + Wc));
                    var Xc = ba
                } else Xc = "";
                ua = Q;
                xb = [xb, {
                    url: Xc
                }];
                ua.h.push(5);
                ua.i[5] = xb;
                zc(this.o, e, Q, this.j, c)
            } catch (Q) {
                try {
                    zc(this.o, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Kc(Q),
                        url: f && f.h.url
                    }, this.j, c)
                } catch (Ua) {}
            }
            return !0
        }
    };
    var Qc = a => "string" === typeof a,
        Rc = a => void 0 === a;
    var Sc = class extends ab {
        constructor() {
            super()
        }
        J(a) {
            return u(this, 2, a, 0)
        }
    };
    var Tc = class extends ab {
            constructor() {
                super()
            }
        },
        Yc = [4, 5, 6, 8, 9, 10];

    function Zc(a, ...b) {
        $c(a, ...b.map(c => ({
            Oa: 7,
            message: c
        })))
    };

    function ad(a) {
        return JSON.stringify([a.map(b => [{
            [b.Oa]: b.message.toJSON()
        }])])
    };
    var bd = (a, b) => {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function cd(a) {
        a && "function" == typeof a.D && a.D()
    };

    function F() {
        this.o = this.o;
        this.L = this.L
    }
    F.prototype.o = !1;
    F.prototype.D = function() {
        this.o || (this.o = !0, this.i())
    };

    function G(a, b) {
        a.o ? b() : (a.L || (a.L = []), a.L.push(b))
    }
    F.prototype.i = function() {
        if (this.L)
            for (; this.L.length;) this.L.shift()()
    };

    function $c(a, ...b) {
        65536 <= ad(a.h.concat(b)).length && dd(a);
        a.h.push(...b);
        100 <= a.h.length && dd(a);
        a.h.length && null === a.i && (a.i = setTimeout(() => {
            dd(a)
        }, 100))
    }

    function dd(a) {
        null !== a.i && (clearTimeout(a.i), a.i = null);
        if (a.h.length) {
            var b = ad(a.h);
            a.j("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.h = []
        }
    }
    var ed = class {
            constructor() {
                this.j = bd;
                this.h = [];
                this.i = null
            }
        },
        fd = class extends ed {};
    var H = a => {
        var b = "oa";
        if (a.oa && a.hasOwnProperty(b)) return a.oa;
        b = new a;
        return a.oa = b
    };

    function gd(a, b, c) {
        return b[a] || c
    };

    function hd(a, b) {
        a.h = () => gd(3, b, () => [])(1)
    }
    class id {
        h() {
            return []
        }
    };
    let jd, kd;
    const ld = new Jc(window);
    (a => {
        jd = a ? ? new Ac;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        yc(jd, window.google_srt);
        kd = new Pc(jd, ld);
        Lc(kd, () => {});
        kd.j = !0;
        "complete" == window.document.readyState ? window.google_measure_js_timing || Ic(ld) : ld.h && x(window, "load", () => {
            window.google_measure_js_timing || Ic(ld)
        })
    })();
    let md, E;
    const nd = new Jc(k);
    (a => {
        md = a || new Ac;
        "number" !== typeof k.google_srt && (k.google_srt = Math.random());
        yc(md, k.google_srt);
        E = new Pc(md, nd);
        E.j = !0;
        "complete" == k.document.readyState ? k.google_measure_js_timing || Ic(nd) : nd.h && x(k, "load", () => {
            k.google_measure_js_timing || Ic(nd)
        })
    })();
    var I = (a, b) => Nc(E, a, b),
        od = (a, b, c) => {
            const d = H(id).h();
            !b.eid && d.length && (b.eid = d.toString());
            zc(md, a, b, !0, c)
        };

    function pd() {
        if (qd) return qd;
        const a = ic() || window,
            b = a.google_persistent_state_async;
        return null != b && "object" == typeof b && null != b.S && "object" == typeof b.S ? qd = b : a.google_persistent_state_async = qd = new rd
    }

    function sd(a, b, c) {
        b = td[b] || "google_ps_" + b;
        a = a.S;
        const d = a[b];
        return void 0 === d ? (a[b] = c(), a[b]) : d
    }

    function ud(a, b) {
        return sd(a, 30, () => b)
    }

    function vd(a) {
        return !!ud(pd(), a)
    }
    class rd {
        constructor() {
            this.S = {}
        }
    }
    var qd = null;
    const td = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };
    var J = class {
            constructor(a, b = !1) {
                this.h = a;
                this.defaultValue = b
            }
        },
        K = class {
            constructor(a, b = 0) {
                this.h = a;
                this.defaultValue = b
            }
        };
    var wd = new J(1214, !0),
        xd = new K(1130, 100),
        yd = new J(1233),
        zd = new K(1085, 5),
        Ad = new K(63, 30),
        Bd = new K(1080, 5),
        Cd = new class {
            constructor(a, b = []) {
                this.h = a;
                this.defaultValue = b
            }
        }(10003, ["2"]),
        Dd = new J(63682),
        Ed = new K(1027, 10),
        Fd = new J(10004),
        Gd = new K(57, 120),
        Hd = new J(1134),
        Id = new K(1050, 30),
        Jd = new K(58, 120),
        Kd = new J(10005),
        Ld = new J(1200),
        Md = new J(1033, !0),
        Nd = new J(10002, !0),
        Od = new J(1185);
    var Pd = (a, b, c, d = null) => {
        const e = g => {
            let h;
            try {
                h = JSON.parse(g.data)
            } catch (l) {
                return
            }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
        };
        x(a, "message", e);
        let f = !1;
        return () => {
            let g = !1;
            f || (f = !0, g = hb(a, "message", e));
            return g
        }
    };

    function Qd(a, b, c, d) {
        return Pd(a, "fullscreen", Nc(d, 952, (e, f) => {
            if (f.source === b) {
                if (!("eventType" in e)) throw Error(`bad message ${JSON.stringify(e)}`);
                delete e.googMsgType;
                c(e)
            }
        }))
    };
    class L {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.h = b
            })
        }
    };
    async function Rd(a) {
        return a.m.promise
    }
    async function Sd(a) {
        return a.j.promise
    }
    async function Td(a) {
        return a.l.promise
    }

    function Ud(a, b) {
        b.type = "err_st";
        b.slot = a.slotType;
        zc(a.A, "fullscreen_tag", b, !1, .25)
    }
    class Vd extends F {
        constructor(a, b, c) {
            var d = E,
                e = md;
            super();
            this.slotType = a;
            this.pubWin = b;
            this.h = c;
            this.s = d;
            this.A = e;
            this.state = 1;
            this.m = new L;
            this.j = new L;
            this.l = new L
        }
        Ia() {
            k.IntersectionObserver || this.h.postMessage(JSON.stringify({
                eventType: "visible",
                googMsgType: "fullscreen"
            }), "*")
        }
        ra() {
            this.h.postMessage(JSON.stringify({
                eventType: "backButton",
                googMsgType: "fullscreen"
            }), "*")
        }
        init() {
            const a = Qd(this.pubWin, this.h, b => {
                if ("adError" === b.eventType) this.l.resolve(), this.state = 0;
                else if ("adReady" === b.eventType &&
                    1 === this.state) b.slotType !== this.slotType && (Ud(this, {
                    cur_st: this.state,
                    evt: b.eventType,
                    adp_tp: b.slotType
                }), this.state = 0), this.m.resolve(), this.state = 2;
                else if ("adClosed" === b.eventType && 2 === this.state) this.j.resolve(b.result), this.state = 3;
                else if ("adClosed" !== b.eventType || 3 !== this.state) Ud(this, {
                    cur_st: this.state,
                    evt: b.eventType
                }), this.state = 0
            }, this.s);
            G(this, a)
        }
    }

    function Wd(a, b, c) {
        a = new Vd(a, b, c);
        a.init();
        return a
    };
    /* 
     
    Math.uuid.js (v1.4) 
    http://www.broofa.com 
    mailto:robert@broofa.com 
    Copyright (c) 2010 Robert Kieffer 
    Dual licensed under the MIT and GPL licenses. 
    */
    var Xd = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
    class Yd {
        constructor(a) {
            for (var b = Array(36), c = 0, d, e = 0; 36 > e; e++) 8 == e || 13 == e || 18 == e || 23 == e ? b[e] = "-" : 14 == e ? b[e] = "4" : (2 >= c && (c = 33554432 + 16777216 * Math.random() | 0), d = c & 15, c >>= 4, b[e] = Xd[19 == e ? d & 3 | 8 : d]);
            this.uuid = b.join("");
            this.callback = a
        }
    }

    function Zd(a) {
        const b = k.imalib_globalCallbacks || new Map,
            c = b.get("AFMA_updateActiveView") || [];
        if (0 === c.length && k.AFMA_updateActiveView) {
            const d = new Yd(k.AFMA_updateActiveView);
            c.push(d);
            k.AFMA_updateActiveView = void 0
        }
        k.AFMA_updateActiveView || (k.AFMA_updateActiveView = function() {
            const d = b.get("AFMA_updateActiveView");
            for (const e of d) e.callback.apply(null, arguments)
        });
        a = new Yd(a);
        c.push(a);
        b.set("AFMA_updateActiveView", c);
        k.imalib_globalCallbacks = b;
        return a.uuid
    }

    function $d(a) {
        if (k.AFMA_updateActiveView) {
            var b = k.imalib_globalCallbacks;
            if (b) {
                var c = b.get("AFMA_updateActiveView");
                if (c) {
                    var d = c.findIndex(e => e.uuid === a); - 1 !== d && (c.splice(d, 1), 0 === c.length && (k.AFMA_updateActiveView = void 0), b.set("AFMA_updateActiveView", c), k.imalib_globalCallbacks = b)
                }
            }
        }
    };
    var google = {};
    var ae = -1 != (k.navigator ? k.navigator.userAgent : "").indexOf("Android");

    function M(a, b) {
        this.type = a;
        this.currentTarget = this.target = b;
        this.defaultPrevented = this.i = !1
    }
    M.prototype.stopPropagation = function() {
        this.i = !0
    };
    M.prototype.preventDefault = function() {
        this.defaultPrevented = !0
    };
    var N = class {
            constructor(a, b) {
                this.messageName = a;
                this.parameters = b || {}
            }
        },
        be = class extends M {
            constructor(a, b) {
                super(a.messageName, b);
                this.params = a.parameters || {}
            }
        };

    function ce(a) {
        var b = sb("gmsg://mobileads.google.com/" + a.messageName);
        return kc(b, new Map(Object.entries(a.parameters)))
    };
    var de = function() {
        if (!k.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            k.addEventListener("test", () => {}, b), k.removeEventListener("test", () => {}, b)
        } catch (c) {}
        return a
    }();

    function O(a, b) {
        M.call(this, a ? a.type : "");
        this.relatedTarget = this.currentTarget = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
        this.key = "";
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.h = null;
        a && this.init(a, b)
    }
    ja(O, M);
    var ee = {
        2: "touch",
        3: "pen",
        4: "mouse"
    };
    O.prototype.init = function(a, b) {
        var c = this.type = a.type,
            d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
        this.target = a.target || a.srcElement;
        this.currentTarget = b;
        (b = a.relatedTarget) ? Ba && (za(b, "nodeName") || (b = null)): "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
        this.relatedTarget = b;
        d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX, this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.clientX = void 0 !== a.clientX ?
            a.clientX : a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
        this.button = a.button;
        this.key = a.key || "";
        this.ctrlKey = a.ctrlKey;
        this.altKey = a.altKey;
        this.shiftKey = a.shiftKey;
        this.metaKey = a.metaKey;
        this.pointerId = a.pointerId || 0;
        this.pointerType = "string" === typeof a.pointerType ? a.pointerType : ee[a.pointerType] || "";
        this.state = a.state;
        this.h = a;
        a.defaultPrevented && O.U.preventDefault.call(this)
    };
    O.prototype.stopPropagation = function() {
        O.U.stopPropagation.call(this);
        this.h.stopPropagation ? this.h.stopPropagation() : this.h.cancelBubble = !0
    };
    O.prototype.preventDefault = function() {
        O.U.preventDefault.call(this);
        var a = this.h;
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };
    var fe = "closure_listenable_" + (1E6 * Math.random() | 0);
    var ge = 0;

    function he(a, b, c, d, e) {
        this.listener = a;
        this.proxy = null;
        this.src = b;
        this.type = c;
        this.capture = !!d;
        this.da = e;
        this.key = ++ge;
        this.W = this.ba = !1
    }

    function ie(a) {
        a.W = !0;
        a.listener = null;
        a.proxy = null;
        a.src = null;
        a.da = null
    };

    function je(a) {
        this.src = a;
        this.h = {};
        this.i = 0
    }
    je.prototype.add = function(a, b, c, d, e) {
        var f = a.toString();
        a = this.h[f];
        a || (a = this.h[f] = [], this.i++);
        var g = ke(a, b, d, e); - 1 < g ? (b = a[g], c || (b.ba = !1)) : (b = new he(b, this.src, f, !!d, e), b.ba = c, a.push(b));
        return b
    };

    function le(a, b, c, d, e) {
        b = b.toString();
        if (b in a.h) {
            var f = a.h[b];
            c = ke(f, c, d, e); - 1 < c && (ie(f[c]), Array.prototype.splice.call(f, c, 1), 0 == f.length && (delete a.h[b], a.i--))
        }
    }

    function me(a, b) {
        var c = b.type,
            d;
        if (d = c in a.h) {
            d = a.h[c];
            const e = va(d, b);
            let f;
            (f = 0 <= e) && Array.prototype.splice.call(d, e, 1);
            d = f
        }
        d && (ie(b), 0 == a.h[c].length && (delete a.h[c], a.i--))
    }

    function ke(a, b, c, d) {
        for (var e = 0; e < a.length; ++e) {
            var f = a[e];
            if (!f.W && f.listener == b && f.capture == !!c && f.da == d) return e
        }
        return -1
    };
    var ne = "closure_lm_" + (1E6 * Math.random() | 0),
        oe = {},
        pe = 0;

    function qe(a, b, c, d, e) {
        if (d && d.once) return re(a, b, c, d, e);
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++) qe(a, b[f], c, d, e);
            return null
        }
        c = se(c);
        return a && a[fe] ? a.h.add(String(b), c, !1, p(d) ? !!d.capture : !!d, e) : te(a, b, c, !1, d, e)
    }

    function te(a, b, c, d, e, f) {
        if (!b) throw Error("Invalid event type");
        var g = p(e) ? !!e.capture : !!e,
            h = ue(a);
        h || (a[ne] = h = new je(a));
        c = h.add(b, c, d, g, f);
        if (c.proxy) return c;
        d = ve();
        c.proxy = d;
        d.src = a;
        d.listener = c;
        if (a.addEventListener) de || (e = g), void 0 === e && (e = !1), a.addEventListener(b.toString(), d, e);
        else if (a.attachEvent) a.attachEvent(we(b.toString()), d);
        else if (a.addListener && a.removeListener) a.addListener(d);
        else throw Error("addEventListener and attachEvent are unavailable.");
        pe++;
        return c
    }

    function ve() {
        function a(c) {
            return b.call(a.src, a.listener, c)
        }
        const b = xe;
        return a
    }

    function re(a, b, c, d, e) {
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++) re(a, b[f], c, d, e);
            return null
        }
        c = se(c);
        return a && a[fe] ? a.h.add(String(b), c, !0, p(d) ? !!d.capture : !!d, e) : te(a, b, c, !0, d, e)
    }

    function ye(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) ye(a, b[f], c, d, e);
        else(d = p(d) ? !!d.capture : !!d, c = se(c), a && a[fe]) ? le(a.h, String(b), c, d, e) : a && (a = ue(a)) && (b = a.h[b.toString()], a = -1, b && (a = ke(b, c, d, e)), (c = -1 < a ? b[a] : null) && ze(c))
    }

    function ze(a) {
        if ("number" !== typeof a && a && !a.W) {
            var b = a.src;
            if (b && b[fe]) me(b.h, a);
            else {
                var c = a.type,
                    d = a.proxy;
                b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(we(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                pe--;
                (c = ue(b)) ? (me(c, a), 0 == c.i && (c.src = null, b[ne] = null)) : ie(a)
            }
        }
    }

    function we(a) {
        return a in oe ? oe[a] : oe[a] = "on" + a
    }

    function xe(a, b) {
        if (a.W) a = !0;
        else {
            b = new O(b, this);
            var c = a.listener,
                d = a.da || a.src;
            a.ba && ze(a);
            a = c.call(d, b)
        }
        return a
    }

    function ue(a) {
        a = a[ne];
        return a instanceof je ? a : null
    }
    var Ae = "__closure_events_fn_" + (1E9 * Math.random() >>> 0);

    function se(a) {
        if ("function" === typeof a) return a;
        a[Ae] || (a[Ae] = function(b) {
            return a.handleEvent(b)
        });
        return a[Ae]
    };

    function Be(a) {
        F.call(this);
        this.j = a;
        this.h = {}
    }
    ja(Be, F);
    var Ce = [];

    function De(a) {
        ib(a.h, function(b, c) {
            this.h.hasOwnProperty(c) && ze(b)
        }, a);
        a.h = {}
    }
    Be.prototype.i = function() {
        Be.U.i.call(this);
        De(this)
    };
    Be.prototype.handleEvent = function() {
        throw Error("EventHandler.handleEvent not implemented");
    };

    function P() {
        F.call(this);
        this.h = new je(this);
        this.G = this;
        this.A = null
    }
    ja(P, F);
    P.prototype[fe] = !0;
    P.prototype.addEventListener = function(a, b, c, d) {
        qe(this, a, b, c, d)
    };
    P.prototype.removeEventListener = function(a, b, c, d) {
        ye(this, a, b, c, d)
    };

    function Ee(a, b) {
        var c, d = a.A;
        if (d)
            for (c = []; d; d = d.A) c.push(d);
        a = a.G;
        d = b.type || b;
        if ("string" === typeof b) b = new M(b, a);
        else if (b instanceof M) b.target = b.target || a;
        else {
            var e = b;
            b = new M(d, a);
            lb(b, e)
        }
        e = !0;
        if (c)
            for (var f = c.length - 1; !b.i && 0 <= f; f--) {
                var g = b.currentTarget = c[f];
                e = Fe(g, d, !0, b) && e
            }
        b.i || (g = b.currentTarget = a, e = Fe(g, d, !0, b) && e, b.i || (e = Fe(g, d, !1, b) && e));
        if (c)
            for (f = 0; !b.i && f < c.length; f++) g = b.currentTarget = c[f], e = Fe(g, d, !1, b) && e
    }
    P.prototype.i = function() {
        P.U.i.call(this);
        if (this.h) {
            var a = this.h,
                b = 0,
                c;
            for (c in a.h) {
                for (var d = a.h[c], e = 0; e < d.length; e++) ++b, ie(d[e]);
                delete a.h[c];
                a.i--
            }
        }
        this.A = null
    };

    function Fe(a, b, c, d) {
        b = a.h.h[String(b)];
        if (!b) return !0;
        b = b.concat();
        for (var e = !0, f = 0; f < b.length; ++f) {
            var g = b[f];
            if (g && !g.W && g.capture == c) {
                var h = g.listener,
                    l = g.da || g.src;
                g.ba && me(a.h, g);
                e = !1 !== h.call(l, d) && e
            }
        }
        return e && !d.defaultPrevented
    };

    function S(a, b) {
        P.call(this);
        this.s = a || 1;
        this.m = b || k;
        this.C = ha(this.K, this);
        this.F = Date.now()
    }
    ja(S, P);
    S.prototype.l = !1;
    S.prototype.j = null;
    S.prototype.K = function() {
        if (this.l) {
            var a = Date.now() - this.F;
            0 < a && a < .8 * this.s ? this.j = this.m.setTimeout(this.C, this.s - a) : (this.j && (this.m.clearTimeout(this.j), this.j = null), Ee(this, "tick"), this.l && (this.stop(), this.start()))
        }
    };
    S.prototype.start = function() {
        this.l = !0;
        this.j || (this.j = this.m.setTimeout(this.C, this.s), this.F = Date.now())
    };
    S.prototype.stop = function() {
        this.l = !1;
        this.j && (this.m.clearTimeout(this.j), this.j = null)
    };
    S.prototype.i = function() {
        S.U.i.call(this);
        this.stop();
        delete this.m
    };

    function Ge() {
        if (window.googleJsEnvironment && ("rhino" == window.googleJsEnvironment.environment || "jscore" == window.googleJsEnvironment.environment)) return new He;
        if (ae && window.googleAdsJsInterface && "notify" in window.googleAdsJsInterface) try {
            return window.googleAdsJsInterface.notify("gmsg://mobileads.google.com/noop"), new He
        } catch (a) {} else if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.gadGMSGHandler) return new Ie;
        return new Je
    }

    function Ke() {
        Le || (Le = Ge());
        return Le
    }
    var Le = null,
        Me = class extends F {};

    function Ne(a) {
        const b = jb(a.parameters);
        b["google.afma.Notify_dt"] = (new Date).getTime();
        return ce(new N(a.messageName, b)).toString()
    }
    var Oe = class extends Me {
            constructor(a) {
                super();
                this.s = a;
                this.m = [];
                this.l = new S(1);
                a = this.A = new Be(this);
                var b = this.l,
                    c = this.C,
                    d = "tick";
                Array.isArray(d) || (d && (Ce[0] = d.toString()), d = Ce);
                for (var e = 0; e < d.length; e++) {
                    var f = qe(b, d[e], c || a.handleEvent, !1, a.j || a);
                    if (!f) break;
                    a.h[f.key] = f
                }
            }
            sendMessage(a) {
                this.m.push(a);
                this.l.l || (a = this.m.shift(), this.s(a), this.l.start())
            }
            C() {
                const a = this.m.shift();
                a ? this.s(a) : this.l.stop()
            }
        },
        Je = class extends Oe {
            constructor() {
                super(a => {
                    var b = this.h[this.j];
                    b || (b = Lb(document,
                        "IFRAME"), b.id = "afma-notify-" + (new Date).getTime(), b.style.display = "none", this.h[this.j] = b);
                    this.j = (this.j + 1) % 25;
                    const c = jb(a.parameters);
                    c["google.afma.Notify_dt"] = (new Date).getTime();
                    a = ce(new N(a.messageName, c));
                    b.src = qb(a).toString();
                    b.parentNode || document.body.appendChild(b)
                });
                this.h = [];
                this.j = 0
            }
            i() {
                this.h.forEach(Mb);
                this.h = [];
                super.i()
            }
        },
        He = class extends Me {
            sendMessage(a) {
                a = Ne(a);
                window.googleAdsJsInterface && window.googleAdsJsInterface.notify && (window.googleAdsJsInterface.notify(a), window.googleAdsJsInterface.DEBUG &&
                    console.log(a))
            }
        },
        Ie = class extends Me {
            sendMessage(a) {
                a = Ne(a);
                window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.gadGMSGHandler && window.webkit.messageHandlers.gadGMSGHandler.postMessage(a)
            }
        };

    function Pe(a, {
        data: b,
        source: c
    }) {
        if (c && b) {
            var d = a.o;
            if ("arwebview_iframe_loaded" === b && a.j) q("JavascriptWebViewBridge.incoming.postMessage", a.m.bind(a)), -1 === d.indexOf(c) && d.push(c);
            else {
                var e = b.messageName;
                b = b.parameters;
                if (a.j) switch (e) {
                    case "mraid_loaded":
                        !1 === b.is_top_win && (a.l = !0, a.i = Zd(f => {
                            a.j && Qe(a, new N("update_activeview_action", f))
                        }), -1 === d.indexOf(c) && (d.push(c), "undefined" !== typeof c.postMessage && c.postMessage(new N("mraid_env_obj", window.MRAID_ENV), "*")));
                        break;
                    case "start_tracking_action":
                        0 ==
                            a.h && window.AFMA_SendMessage("trackActiveViewUnit");
                        a.h += 1;
                        break;
                    case "stop_tracking_action":
                        --a.h, 0 == a.h && (window.AFMA_SendMessage("untrackActiveViewUnit", {
                            hashCode: b.hashCode
                        }), a.i && ($d(a.i), a.i = null))
                } else switch (e) {
                    case "mraid_env_obj":
                        window.MRAID_ENV = b;
                        break;
                    case "update_activeview_action":
                        window.AFMA_updateActiveView && window.AFMA_updateActiveView(b);
                        break;
                    case "receive_message_action":
                        window.AFMA_ReceiveMessage(b.messageName, b.parameters)
                }
            }
        }
    }

    function Qe(a, b) {
        a.o.forEach(c => c.postMessage(b, "*"))
    }
    class Re {
        constructor() {
            this.o = [];
            this.j = window === window.top;
            this.l = !1;
            this.h = 0;
            this.i = null;
            "undefined" !== typeof window.addEventListener && window.addEventListener("message", a => Pe(this, a))
        }
        m(a) {
            this.j && Qe(this, {
                name: "arwebview_message_forwarded",
                message: a
            })
        }
    };
    var Te = class extends P {
        constructor() {
            super();
            this.l = Ke();
            this.l = Ke();
            G(this, ia(cd, this.l));
            this.j = {};
            this.m = new Re
        }
        sendMessage(a, b) {
            let c;
            "string" === typeof a ? c = new N(a, b) : a instanceof N && (c = a);
            "loading" == document.readyState ? re(k, "DOMContentLoaded", () => this.l.sendMessage(c), !1, this) : this.l.sendMessage(c)
        }
        receiveMessage(a, b) {
            if (this.shouldForwardMessageToIframe()) this.forwardMessage(new N("receive_message_action", new N(a, b)));
            else {
                const c = document.getElementById("ad_iframe");
                void 0 != c && void 0 != c.contentWindow &&
                    void 0 != c.contentWindow.AFMA_ReceiveMessage && c.contentWindow.AFMA_ReceiveMessage(a, b)
            }
            "onshow" == a && "loading" == document.readyState ? re(k, "DOMContentLoaded", () => Se(a, b ? ? void 0)) : Ee(this, new be(new N(a, b), this))
        }
        addObserver(a, b, c) {
            const d = e => void c.call(b, e.type, e.params);
            this.h.add(String(a), d, !1, void 0, void 0);
            this.j[a] || (this.j[a] = {});
            this.j[a][b] = d
        }
        removeObserver(a, b) {
            this.j[a] && this.j[a][b] && (le(this.h, String(a), this.j[a][b]), delete this.j[a][b])
        }
        shouldForwardMessageToIframe() {
            return this.m.l
        }
        forwardMessage(a) {
            Qe(this.m,
                a)
        }
    };

    function T(a, b) {
        k.AFMA_Communicator ? k.AFMA_Communicator.sendMessage(a, b) : Ue(a, b)
    }

    function Ue(a, b) {
        "loading" == document.readyState ? (a = ha(Ue, null, a, b), re(k, "DOMContentLoaded", a, !1)) : (a = new N(a, b), Ke().sendMessage(a))
    }

    function Se(a, b) {
        k.AFMA_Communicator.receiveMessage(a, b)
    }

    function Ve(a, b, c, d) {
        k.AFMA_Communicator.removeEventListener(a, b, c, d)
    }

    function We(a, b, c, d) {
        k.AFMA_Communicator.addEventListener(a, b, c, d)
    }

    function Xe(a, b, c) {
        k.AFMA_Communicator.addObserver(a, b, c)
    }

    function Ye(a, b) {
        k.AFMA_Communicator.removeObserver(a, b)
    }
    k.AFMA_Communicator || (q("AFMA_AddEventListener", We), q("AFMA_RemoveEventListener", Ve), q("AFMA_AddObserver", Xe), q("AFMA_RemoveObserver", Ye), q("AFMA_ReceiveMessage", Se), q("AFMA_SendMessage", T), k.AFMA_Communicator = new Te);
    var $e = class {
        constructor(a) {
            this.h = a;
            We("h5adsEvent", b => void this.h(b))
        }
        ma(a, b) {
            T("h5ads", {
                obj_id: a,
                action: "create_interstitial_ad",
                ad_unit: b
            })
        }
        na(a, b) {
            T("h5ads", {
                obj_id: a,
                ad_unit: b,
                action: "create_rewarded_ad"
            })
        }
        D(a) {
            T("h5ads", {
                obj_id: a,
                action: "dispose"
            })
        }
    };

    function af(a) {
        void 0 === a.extras && (a.extras = {});
        a.extras.highfive = "1";
        return encodeURIComponent(JSON.stringify(a))
    }
    class bf extends F {
        constructor(a, b) {
            super();
            this.id = a;
            this.h = b
        }
        load(a, b) {
            this.o || (this.listener = b, a = af(a), T("h5ads", {
                obj_id: this.id,
                action: "load_interstitial_ad",
                ad_request: a
            }))
        }
        show() {
            if (!this.o) {
                if (null == this.listener) throw Error("load must be called before show");
                T("h5ads", {
                    obj_id: this.id,
                    action: "show_interstitial_ad"
                })
            }
        }
        i() {
            this.h.l.D(this.id);
            super.i()
        }
    }
    class cf extends F {
        constructor(a, b) {
            super();
            this.id = a;
            this.h = b
        }
        load(a, b) {
            this.o || (this.listener = b, a = af(a), T("h5ads", {
                obj_id: this.id,
                action: "load_rewarded_ad",
                ad_request: a
            }))
        }
        show() {
            if (!this.o) {
                if (null == this.listener) throw Error("load must be called before show");
                T("h5ads", {
                    obj_id: this.id,
                    action: "show_rewarded_ad"
                })
            }
        }
        i() {
            this.h.l.D(this.id);
            super.i()
        }
    }

    function df(a) {
        const b = a.m;
        a.m += 1;
        return b
    }
    var ef = class {
        constructor() {
            this.m = 0;
            this.o = new Map;
            this.h = new Map;
            this.j = new L;
            this.i = 0;
            this.l = new $e(a => {
                a = a.params;
                switch (a.eventCategory) {
                    case "initialize":
                        this.o.clear();
                        this.h.clear();
                        this.i = 3;
                        this.j.resolve(this);
                        break;
                    case "creation":
                        var b = a.objectId;
                        switch (a.event) {
                            case "nativeObjectCreated":
                                a = b;
                                if (b = this.h.get(a)) this.h.delete(a), this.o.set(a, b.ad), b.T.resolve(b.ad);
                                return;
                            case "nativeObjectNotCreated":
                                a = b;
                                if (b = this.h.get(a)) this.h.delete(a), b.ad.D(), b.T.h(Error("Native object not created"));
                                return;
                            default:
                                return
                        }
                    case "interstitial":
                        if ((b = this.o.get(a.objectId)) && b instanceof bf && b.listener) switch (a.event) {
                            case "onAdLoaded":
                                b.listener.P ? .(b);
                                break;
                            case "onAdFailedToLoad":
                                b.listener.O ? .(b, a.errorCode);
                                break;
                            case "onAdOpened":
                                b.listener.Ka ? .(b);
                                break;
                            case "onAdClicked":
                                b.listener.Ra ? .(b);
                                break;
                            case "onAdClosed":
                                b.listener.I ? .(b);
                                break;
                            case "onNativeAdObjectNotAvailable":
                                b.listener.R ? .(b)
                        }
                        break;
                    case "rewarded":
                        if ((b = this.o.get(a.objectId)) && b instanceof cf && b.listener) switch (a.event) {
                            case "onRewardedAdLoaded":
                                b.listener.P ? .(b);
                                break;
                            case "onRewardedAdFailedToLoad":
                                b.listener.O ? .(b, a.errorCode);
                                break;
                            case "onRewardedAdOpened":
                                b.listener.Ka ? .(b);
                                break;
                            case "onRewardedAdFailedToShow":
                                b.listener.Ja ? .(b, a.errorCode);
                                break;
                            case "onUserEarnedReward":
                                b.listener.La ? .(b);
                                break;
                            case "onRewardedAdClosed":
                                b.listener.I ? .(b);
                                break;
                            case "onNativeAdObjectNotAvailable":
                                b.listener.R ? .(b)
                        }
                }
            })
        }
        connect() {
            switch (this.i) {
                case 3:
                    return Promise.resolve(this);
                case 1:
                    return this.j.promise;
                default:
                    return this.i = 1, this.j = new L, T("h5ads", {
                            action: "initialize"
                        }),
                        setTimeout(() => {
                            3 !== this.i && (this.i = 2, this.j.h(Error("GmaBridge could not connect to SDK after 10000 ms.")))
                        }, 1E4), this.j.promise
            }
        }
        ma(a) {
            if (3 !== this.i) return Promise.reject(Error("GmaBridge is not connected"));
            const b = df(this),
                c = new L;
            this.h.set(b, {
                T: c,
                ad: new bf(b, this)
            });
            this.l.ma(b, a);
            return c.promise
        }
        na(a) {
            if (3 !== this.i) return Promise.reject(Error("GmaBridge is not connected"));
            const b = df(this),
                c = new L;
            this.h.set(b, {
                T: c,
                ad: new cf(b, this)
            });
            this.l.na(b, a);
            return c.promise
        }
    };
    let ff = null;
    var gf = {},
        hf = {};

    function jf() {
        throw Error("Do not instantiate directly");
    }
    jf.prototype.za = null;
    jf.prototype.getContent = function() {
        return this.content
    };
    jf.prototype.toString = function() {
        return this.content
    };
    jf.prototype.sa = function() {
        if (this.ca !== gf) throw Error("Sanitized content was not of kind HTML.");
        return Fb(this.toString())
    };

    function kf() {
        jf.call(this)
    }
    ja(kf, jf);
    kf.prototype.ca = gf;

    function lf(a) {
        if (null != a) switch (a.za) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function mf(a) {
        return null != a && a.ca === gf ? a : a instanceof z ? U(Db(a).toString()) : a instanceof z ? U(Db(a).toString()) : U(String(String(a)).replace(nf, of ), lf(a))
    }
    var U = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            void 0 !== d && (c.za = d);
            return c
        }
    }(kf);

    function pf(a) {
        return a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>")
    }

    function V(a) {
        return null != a && a.ca === gf ? String(String(a.getContent()).replace(qf, "").replace(rf, "&lt;")).replace(sf, of ) : String(a).replace(nf, of )
    }

    function W(a) {
        null != a && a.ca === hf ? a = pf(a.getContent()) : null == a ? a = "" : a instanceof vb ? a = pf(ub(a)) : a instanceof vb ? a = pf(ub(a)) : a instanceof Bb ? a = pf(Ab(a)) : a instanceof Bb ? a = pf(Ab(a)) : (a = String(a), a = tf.test(a) ? a : "zSoyz");
        return a
    }
    const uf = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\v": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    };

    function of (a) {
        return uf[a]
    }
    const nf = /[\x00\x22\x26\x27\x3c\x3e]/g,
        sf = /[\x00\x22\x27\x3c\x3e]/g,
        tf = /^(?!-*(?:expression|(?:moz-)?binding))(?:(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|(?:rgb|rgba|hsl|hsla|calc|max|min|cubic-bezier)\([-\u0020\t,+.!#%_0-9a-zA-Z]+\)|[-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:e-?[0-9]+)?(?:[a-z]{1,4}|%)?|!important)(?:\s*[,\u0020]\s*|$))*$/i,
        vf = /^[a-zA-Z0-9+\/_-]+={0,2}$/,
        qf = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
        rf = /</g;
    var xf = class extends ab {
            constructor(a) {
                super(a, -1, wf)
            }
        },
        wf = [19];
    let yf = void 0;
    var zf = class {
        constructor() {
            const a = {};
            this.h = (b, c) => null != a[b] ? a[b] : c;
            this.i = (b, c) => null != a[b] ? a[b] : c;
            this.l = (b, c) => null != a[b] ? a[b] : c;
            this.j = (b, c) => null != a[b] ? a[b] : c;
            this.o = () => {}
        }
    };

    function X(a) {
        return H(zf).h(a.h, a.defaultValue)
    }

    function Y(a) {
        return H(zf).i(a.h, a.defaultValue)
    };
    class Af {
        constructor() {
            this.wasPlaTagProcessed = !1;
            this.wasReactiveAdConfigReceived = {};
            this.adCount = {};
            this.wasReactiveAdVisible = {};
            this.stateForType = {};
            this.reactiveTypeEnabledInAsfe = {};
            this.wasReactiveTagRequestSent = !1;
            this.reactiveTypeDisabledByPublisher = {};
            this.tagSpecificState = {};
            this.messageValidationEnabled = !1;
            this.floatingAdsStacking = new Bf;
            this.sideRailProcessedFixedElements = new Set;
            this.sideRailAvailableSpace = new Map
        }
    }
    var Bf = class {
        constructor() {
            this.maxZIndexRestrictions = {};
            this.nextRestrictionId = 0;
            this.maxZIndexListeners = []
        }
    };
    var Cf = (a, b) => a && a.source ? a.source === b || a.source.parent === b : !1,
        Df = a => {
            const b = {
                bottom: "auto",
                clear: "none",
                display: "inline",
                "float": "none",
                height: "auto",
                left: "auto",
                margin: 0,
                "margin-bottom": 0,
                "margin-left": 0,
                "margin-right": "0",
                "margin-top": 0,
                "max-height": "none",
                "max-width": "none",
                opacity: 1,
                overflow: "visible",
                padding: 0,
                "padding-bottom": 0,
                "padding-left": 0,
                "padding-right": 0,
                "padding-top": 0,
                position: "static",
                right: "auto",
                top: "auto",
                "vertical-align": "baseline",
                visibility: "visible",
                width: "auto",
                "z-index": "auto"
            };
            wa(Object.keys(b), c => {
                var d = a.style[Ib(c)];
                ("undefined" !== typeof d ? d : a.style[lc(a, c)]) || C(a, c, b[c])
            });
            Wb(a)
        };

    function Ef(a) {
        const b = Ff(a);
        wa(a.h.maxZIndexListeners, c => c(b))
    }

    function Ff(a) {
        a = Tb(a.h.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }
    class Gf {
        constructor(a) {
            a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map)) : a.google_reactive_ads_global_state = new Af;
            this.h = a.google_reactive_ads_global_state.floatingAdsStacking
        }
        addListener(a) {
            this.h.maxZIndexListeners.push(a);
            a(Ff(this))
        }
    }
    class Hf {
        constructor(a) {
            this.i = a;
            this.h = null
        }
    };
    var Jf = (a, b) => {
        if (!a.body) return null;
        const c = new If;
        c.apply(a, b);
        return () => {
            C(a.body, {
                filter: c.h,
                webkitFilter: c.h,
                overflow: c.j,
                position: c.o,
                top: c.l
            });
            b.scrollTo(0, c.i)
        }
    };
    class If {
        constructor() {
            this.h = this.l = this.o = this.j = null;
            this.i = 0
        }
        apply(a, b) {
            this.j = a.body.style.overflow;
            this.o = a.body.style.position;
            this.l = a.body.style.top;
            this.h = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
            this.i = void 0 === b.pageYOffset ? (b.document.documentElement || b.document.body.parentNode || b.document.body).scrollTop : b.pageYOffset;
            C(a.body, "top", -this.i + "px")
        }
    };

    function Kf(a, b) {
        var c;
        if (!a.l)
            for (a.l = [], c = a.h.parentElement; c;) {
                a.l.push(c);
                if (a.F(c)) break;
                c = c.parentNode && 1 === c.parentNode.nodeType ? c.parentNode : null
            }
        c = a.l.slice();
        let d, e;
        for (d = 0; d < c.length; ++d)(e = c[d]) && b.call(a, e, d, c)
    }
    var Lf = class extends F {
        constructor(a, b, c) {
            super();
            this.h = a;
            this.G = b;
            this.A = c;
            this.l = null;
            G(this, () => this.l = null)
        }
        F(a) {
            return this.A === a
        }
    };

    function Mf(a, b) {
        const c = a.A;
        if (c)
            if (b) {
                b = a.C;
                if (null == b.h) {
                    var d = b.i;
                    const e = d.h.nextRestrictionId++;
                    d.h.maxZIndexRestrictions[e] = 2147483646;
                    Ef(d);
                    b.h = e
                }
                B(c, {
                    display: "block"
                });
                a.s.body && !a.m && (a.m = Jf(a.s, a.G));
                c.setAttribute("tabindex", "0");
                c.setAttribute("aria-hidden", "false");
                a.s.body.setAttribute("aria-hidden", "true")
            } else b = a.C, null != b.h && (d = b.i, delete d.h.maxZIndexRestrictions[b.h], Ef(d), b.h = null), B(c, {
                display: "none"
            }), a.m && (a.m(), a.m = null), a.s.body.setAttribute("aria-hidden", "false"), c.setAttribute("aria-hidden",
                "true")
    }

    function Nf(a) {
        Mf(a, !1);
        const b = a.A;
        b && (Kf(a, c => {
            B(c, Of);
            Df(c)
        }), a.h.setAttribute("width", ""), a.h.setAttribute("height", ""), C(a.h, Of), C(a.h, Pf), C(b, Qf), C(b, {
            background: "transparent"
        }), B(b, {
            display: "none",
            position: "fixed"
        }), Df(b), Df(a.h))
    }
    class Rf extends Lf {
        constructor(a, b, c) {
            super(a, b, c);
            this.m = null;
            this.s = b.document;
            a = new Gf(b);
            this.C = new Hf(a)
        }
        j() {
            Mf(this, !1)
        }
    }
    var Qf = {
            backgroundColor: "white",
            opacity: "1",
            position: "fixed",
            left: "0px",
            top: "0px",
            margin: "0px",
            padding: "0px",
            display: "none",
            zIndex: "2147483647"
        },
        Of = {
            width: "100vw",
            height: "100vh"
        },
        Pf = {
            left: "0",
            position: "absolute",
            top: "0"
        };
    class Sf extends Rf {
        constructor(a, b, c) {
            super(b, a, c);
            Nf(this)
        }
        F(a) {
            a.classList ? a = a.classList.contains("adsbygoogle") : (a = a.classList ? a.classList : ("string" == typeof a.className ? a.className : a.getAttribute && a.getAttribute("class") || "").match(/\S+/g) || [], a = 0 <= va(a, "adsbygoogle"));
            return a
        }
    };
    var Tf = a => {
        try {
            var b = (a || window).document,
                c = "CSS1Compat" == b.compatMode ? b.documentElement : b.body;
            return (new A(c.clientWidth, c.clientHeight)).round()
        } catch (d) {
            return new A(-12245933, -12245933)
        }
    };

    function Uf(a) {
        a.google_ad_modifications || (a.google_ad_modifications = {});
        return a.google_ad_modifications
    }

    function Vf() {
        const a = Uf(window);
        a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
        return a.afg_slotcar_vars
    };
    var Wf = a => (a = a.innerText || a.innerHTML) && (a = a.replace(/^\s+/, "").split(/\r?\n/, 1)[0].match(/^\x3c!--+(.*?)(?:--+>)?\s*$/)) && RegExp("google_ad_client").test(a[1]) ? a[1] : null,
        Xf = a => {
            if (a = a.innerText || a.innerHTML)
                if (a = a.replace(/^\s+|\s+$/g, "").replace(/\s*(\r?\n)+\s*/g, ";"), (a = a.match(/^\x3c!--+(.*?)(?:--+>)?$/) || a.match(/^\/*\s*<!\[CDATA\[(.*?)(?:\/*\s*\]\]>)?$/i)) && RegExp("google_ad_client").test(a[1])) return a[1];
            return null
        },
        Yf = a => {
            switch (a) {
                case "true":
                    return !0;
                case "false":
                    return !1;
                case "null":
                    return null;
                case "undefined":
                    break;
                default:
                    try {
                        const b = a.match(/^(?:'(.*)'|"(.*)")$/);
                        if (b) return b[1] || b[2] || "";
                        if (/^[-+]?\d*(\.\d+)?$/.test(a)) {
                            const c = parseFloat(a);
                            return c === c ? c : void 0
                        }
                    } catch (b) {}
            }
        };
    async function Zf(a, b) {
        var c = 10;
        return 0 >= c ? Promise.reject() : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e())
            }, 200)
        })
    };

    function $f(a) {
        var b = a.state.pc;
        if (null !== b && 0 !== b) a = b;
        else {
            b = a.state;
            a = a.B;
            if ("number" !== typeof a.goog_pvsid) try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: Math.floor(Math.random() * 2 ** 52),
                    configurable: !1
                })
            } catch (c) {}
            a = b.pc = Number(a.goog_pvsid) || -1
        }
        return a
    }

    function ag(a) {
        var b = a.state.wpc;
        if (null === b || "" === b) {
            b = a.state;
            var c = a.B;
            if (c.google_ad_client) a = String(c.google_ad_client);
            else {
                if (null == (a = Uf(c).head_tag_slot_vars ? .google_ad_client ? ? c.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client"))) {
                    b: {
                        a = c.document.getElementsByTagName("script");c = c.navigator && c.navigator.userAgent || "";c = RegExp("appbankapppuzdradb|daumapps|fban|fbios|fbav|fb_iab|gsa/|messengerforios|naver|niftyappmobile|nonavigation|pinterest|twitter|ucbrowser|yjnewsapp|youtube",
                            "i").test(c) || /i(phone|pad|pod)/i.test(c) && /applewebkit/i.test(c) && !/version|safari/i.test(c) && !nc() ? Wf : Xf;
                        for (var d = a.length - 1; 0 <= d; d--) {
                            var e = a[d];
                            if (!e.google_parsed_script_for_pub_code && (e.google_parsed_script_for_pub_code = !0, e = c(e))) {
                                a = e;
                                break b
                            }
                        }
                        a = null
                    }
                    if (a) {
                        c = /(google_\w+) *= *(['"]?[\w.-]+['"]?) *(?:;|$)/gm;
                        for (d = {}; e = c.exec(a);) d[e[1]] = Yf(e[2]);
                        a = d;
                        a = a.google_ad_client ? a.google_ad_client : ""
                    } else a = ""
                }
                a = a ? ? ""
            }
            b = b.wpc = a
        }
        return b
    }
    async function bg(a) {
        await Zf(a.B, () => !(!$f(a) || !ag(a)))
    }
    async function cg(a, b) {
        if (a.i) {
            await bg(a);
            var c = a.h;
            var d = new Tc;
            var e = $f(a);
            d = u(d, 1, e, 0);
            e = ag(a);
            d = u(d, 2, e, "");
            d = u(d, 3, a.state.sd, 0);
            a = u(d, 7, Math.round(a.B.performance.now()), 0);
            Na(a);
            null == b && (b = void 0);
            Na(a);
            d = 0;
            for (e = 0; e < Yc.length; e++) {
                const f = Yc[e];
                null != Qa(a, f) && (0 !== d && Ra(a, d, void 0, !1), d = f)
            }
            d && 10 !== d && null != b && Ra(a, d, void 0, !1);
            b = Ra(a, 10, b);
            Zc(c, b)
        }
    }
    var dg = class {
        constructor(a) {
            this.B = ic() || window;
            this.h = a ? ? new fd;
            if (X(wd)) this.state = sd(pd(), 33, () => {
                const b = Y(xd);
                return {
                    sd: b,
                    ssp: 0 < b && Rb() < 1 / b,
                    pc: null,
                    wpc: null,
                    le: [],
                    lgdp: []
                }
            });
            else {
                a = Y(xd);
                const b = vd(0 < a && Rb() < 1 / a);
                this.state = {
                    sd: a,
                    ssp: b,
                    pc: null,
                    wpc: null,
                    le: [],
                    lgdp: []
                }
            }
        }
        get i() {
            return this.state.ssp
        }
    };
    class eg {};

    function fg() {
        var a = k.ggeac || (k.ggeac = {});
        hd(H(id), a);
        gg(a);
        H(eg);
        H(zf).o()
    }

    function gg(a) {
        const b = H(zf);
        b.h = (c, d) => gd(5, a, () => !1)(c, d, 1);
        b.i = (c, d) => gd(6, a, () => 0)(c, d, 1);
        b.l = (c, d) => gd(7, a, () => "")(c, d, 1);
        b.j = (c, d) => gd(8, a, () => [])(c, d, 1);
        b.o = () => {
            gd(15, a, () => {})(1)
        }
    };

    function hg(a) {
        Lc(E, b => {
            b.shv = String(a);
            b.mjsv = "m202302060101";
            const c = H(id).h(),
                d = Uf(k);
            d.eids || (d.eids = []);
            b.eid = c.concat(d.eids).join(",")
        })
    }

    function ig(a) {
        hg(Sa(Qa(a, 2), ""));
        a = Qa(a, 6);
        a = Sa(null == a ? a : !!a, !1);
        cb(yf, Rc);
        yf = a
    };

    function jg(a) {
        {
            k.google_llp || (k.google_llp = {});
            var b = k.google_llp;
            let c = b[7];
            if (!c) {
                const {
                    promise: d,
                    resolve: e
                } = new L;
                c = {
                    promise: d,
                    resolve: e
                };
                b[7] = c
            }
            b = c
        }
        b.resolve(a)
    };
    var kg = (a, b, c) => {
        a.dataset.adsbygoogleStatus = "reserved";
        a.className += " adsbygoogle-noablate";
        if (!c.adsbygoogle) {
            c.adsbygoogle = [];
            var d = c.document,
                e = jc `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`;
            const f = fc("SCRIPT", d);
            Pb(f, e);
            (d = d.getElementsByTagName("script")[0]) && d.parentNode && d.parentNode.insertBefore(f, d)
        }
        c.adsbygoogle.push({
            element: a,
            params: b
        })
    };
    var lg = "undefined" === typeof sttc ? void 0 : sttc;

    function mg() {
        var a = E;
        try {
            return cb(lg, Qc), new xf(JSON.parse(lg))
        } catch (b) {
            a.ea(838, b instanceof Error ? b : Error(String(b)), void 0, c => {
                c.jspb = String(lg)
            })
        }
        return new xf
    };
    var ng = class extends F {
            i() {
                this.A();
                super.i()
            }
        },
        og = class extends F {
            constructor(a) {
                super();
                this.callback = a
            }
        },
        pg = class extends F {
            constructor(a) {
                super();
                this.j = a;
                this.h = new Set
            }
            fetch(a) {
                const b = new og(a.callback);
                this.h.add(b);
                this.j.fetch({ ...a,
                    callback: c => {
                        b.o ? c && c.D() : b.callback(c);
                        this.h.delete(b)
                    }
                })
            }
            i() {
                for (const a of this.h.values()) a.D();
                this.h.clear();
                super.i()
            }
        };
    var qg = class {
        constructor(a) {
            this.l = a;
            this.m = "m202302060101";
            this.j = "unset"
        }
        fa(a) {
            this.j = a
        }
        X(a) {
            this.h = a.Ba;
            this.i = a.Da
        }
        J(a) {
            this.o = a
        }
        v(a, b = {}) {
            b.event = a;
            b.client = this.j;
            b.bow_v = this.l;
            b.js_v = this.m;
            b.fetcher = this.o ? .toString() ? ? "unset";
            this.h && (b.admb_iid = this.h);
            this.i && (b.admb_rid = this.i);
            od("slotcar", b, 1)
        }
    };
    var rg = class extends ng {
        constructor(a, b, c, d) {
            super();
            this.ad = a;
            this.l = b;
            this.m = c;
            this.j = d;
            this.h = null;
            this.C = this.F = !1;
            this.G = !0
        }
        show(a) {
            this.h = a;
            if (this.G && this.C) this.ad.show();
            else if (this.C) this.I();
            else throw Error("Tried to show AdMobAd before it finished loading.");
        }
        A() {
            this.ad.D()
        }
        P() {
            this.C = !0;
            this.m(this)
        }
        O() {
            this.m(null);
            this.D()
        }
        R() {
            this.j.v("admb_na");
            this.h ? this.I() : this.G = !1
        }
    };

    function sg(a) {
        return {
            P: I(849, () => {
                a.P()
            }),
            O: I(850, () => {
                a.O()
            }),
            I: I(851, () => {
                a.I()
            }),
            R: I(854, () => {
                a.R()
            })
        }
    }
    var tg = class extends rg {
        constructor(a, b, c, d) {
            super(a, b, c, d);
            this.ad = a;
            this.l = b;
            this.m = c;
            this.j = d
        }
        s() {
            this.ad.load(this.l, sg(this))
        }
        I() {
            (0, this.h)(1)
        }
    };

    function ug(a) {
        return {
            P: I(849, () => {
                a.P()
            }),
            O: I(850, () => {
                a.O()
            }),
            Ja: I(855, () => {
                a.j.v("admb_rfs");
                (0, a.h)(2)
            }),
            La: I(852, () => {
                a.F = !0
            }),
            I: I(853, () => {
                a.I()
            }),
            R: I(854, () => {
                a.R()
            })
        }
    }
    var vg = class extends rg {
        constructor(a, b, c, d) {
            super(a, b, c, d);
            this.ad = a;
            this.l = b;
            this.m = c;
            this.j = d
        }
        s() {
            this.ad.load(this.l, ug(this))
        }
        I() {
            this.F ? (0, this.h)(3) : (0, this.h)(2)
        }
    };

    function wg(a, b) {
        const c = "on" === a.H.google_adbreak_test;
        switch (b) {
            case 1:
                return c ? "ca-app-pub-3940256099942544/1033173712" : a.H.google_admob_interstitial_slot;
            case 2:
                return c ? "ca-app-pub-3940256099942544/5224354917" : a.H.google_admob_rewarded_slot;
            default:
                throw Error(`Unknown ad type ${b}`);
        }
    }

    function xg(a, b, c) {
        a.j.error(`Unable to fetch ad: '${b}' is missing from tag.`);
        c(null)
    }

    function yg(a) {
        Mc(E, 850, () => {
            a(null)
        })
    }
    var zg = class {
        constructor(a, b, c, d) {
            this.i = a;
            this.H = b;
            this.j = c;
            this.h = d
        }
        fetch(a) {
            const b = {
                isTestDevice: !1,
                httpTimeoutMillis: 1E3 * Y(Ad)
            };
            var c = this.H.google_tag_for_child_directed_treatment;
            if ("0" === c || "1" === c) b.tagForChildDirectedTreatment = "1" === c;
            c = this.H.google_tag_for_under_age_of_consent;
            if ("0" === c || "1" === c) b.tagForUnderAgeOfConsent = "1" === c;
            c = this.H.google_max_ad_content_rating;
            "string" === typeof c && (b.maxAdContentRating = c);
            a.Aa ? .length && (void 0 === b.extras && (b.extras = {}), b.extras.slotcar_eids = a.Aa.join(","));
            X(Md) && (void 0 === b.extras && (b.extras = {}), b.extras.muted = a.pa || 2 === a.type ? "0" : "1");
            c = wg(this, a.type);
            1 === a.type ? "string" !== typeof c ? xg(this, "data-admob-interstitial-slot", a.callback) : this.i.ma(c).then(d => {
                (new tg(d, b, a.callback, this.h)).s()
            }).catch(() => {
                yg(a.callback)
            }) : "string" !== typeof c ? xg(this, "data-admob-rewarded-slot", a.callback) : this.i.na(c).then(d => {
                (new vg(d, b, a.callback, this.h)).s()
            }).catch(() => {
                yg(a.callback)
            })
        }
    };

    function Ag(a, b, c) {
        try {
            if (!ac(c.origin) || a.s && !Cf(c, a.s.contentWindow)) return
        } catch (f) {
            return
        }
        const d = b.msg_type;
        let e;
        "string" === typeof d && (e = a.A[d]) && Mc(a.h, 168, () => {
            e.call(a, b, c)
        })
    }
    class Bg extends F {
        constructor(a, b) {
            var c = E,
                d = md;
            super();
            this.l = a;
            this.s = b;
            this.h = c;
            this.C = d;
            this.A = {};
            this.F = Nc(this.h, 168, (e, f) => void Ag(this, e, f));
            this.N = Nc(this.h, 169, (e, f) => {
                zc(this.C, "ras::xsf", {
                    c: f.data.substring(0, 500),
                    u: this.l.location.href.substring(0, 500)
                }, !0, .1);
                return !0
            });
            this.j = [];
            Cg(this, this.A);
            this.j.push(Pd(this.l, "sth", this.F, this.N))
        }
        i() {
            for (const a of this.j) a();
            this.j.length = 0;
            super.i()
        }
    };

    function Cg(a, b) {
        b["i-adframe-load"] = I(792, () => {
            a.G()
        });
        b["i-dismiss"] = I(793, () => {
            a.adDismissed(1)
        });
        b["r-dismiss-before-reward"] = I(794, () => {
            a.adDismissed(2)
        });
        b["r-dismiss-after-reward"] = I(795, () => {
            a.adDismissed(3)
        })
    }
    var Dg = class extends Bg {
        constructor(a, b, c, d) {
            super(d, c);
            this.G = a;
            this.adDismissed = b;
            this.m = c
        }
        K() {
            this.m.contentWindow.postMessage(JSON.stringify({
                msg_type: "i-view"
            }), "*")
        }
        ra() {
            this.m.contentWindow.postMessage(JSON.stringify({
                msg_type: "r-back-button"
            }), "*")
        }
    };

    function Eg(a, b) {
        a.dataset["slotcar" + (1 === b ? "Interstitial" : "Rewarded")] = "true"
    };

    function Fg(a, b) {
        return setTimeout(I(728, () => {
            b(null);
            a.D()
        }), 1E3 * Y(Ad))
    }

    function Gg(a, b, c, d, e, f) {
        b = Wd(2 === e ? 2 : 1, b, c.contentWindow);
        c = Rd(b).then(() => {
            clearTimeout(f);
            d(a)
        });
        Oc(1005, c);
        c = Sd(b).then(g => {
            switch (g.status) {
                case 1:
                    g = 1;
                    break;
                case 2:
                    g = 3;
                    break;
                case 3:
                    g = 2;
                    break;
                default:
                    throw Error(`Unexpected CloseResult: ${g.status}`);
            }
            Hg(a, g)
        });
        Oc(1006, c);
        c = Td(b).then(() => {
            a.D()
        });
        Oc(1004, c);
        return b
    }

    function Hg(a, b) {
        if (null != a.h) {
            a.s.j();
            "goog_slotcar_ad" === a.B.location.hash && a.B.history.back();
            var c = a.h;
            a.h = null;
            c(b)
        }
    }

    function Ig(a) {
        if (X(Hd)) {
            "" !== a.B.location.hash && od("pub_hash", {
                o_url: a.B.location.href
            }, .1);
            a.B.location.hash = "goog_slotcar_ad";
            var b = I(950, c => {
                c.oldURL.endsWith("#goog_slotcar_ad") && (1 === a.j ? Hg(a, 1) : (a.l ? .ra(), a.m ? .ra()), a.B.removeEventListener("hashchange", b))
            });
            a.B.addEventListener("hashchange", b);
            G(a, () => {
                a.B.removeEventListener("hashchange", b);
                "#goog_slotcar_ad" === a.B.location.hash && a.B.history.back()
            })
        }
    }
    var Jg = class extends ng {
        constructor(a, b, c, d, e) {
            super();
            this.B = a;
            this.C = b;
            this.j = e;
            this.m = this.l = this.h = null;
            this.s = new Sf(a, c, b);
            const f = Fg(this, d);
            X(Od) && !X(yd) ? this.m = Gg(this, a, c, d, e, f) : this.l = new Dg(() => {
                clearTimeout(f);
                d(this)
            }, g => {
                1 === g && 2 === e && (g = 3);
                Hg(this, g)
            }, c, a);
            G(this, () => {
                this.l ? .D();
                this.m ? .D();
                clearTimeout(f)
            });
            Eg(b, e)
        }
        show(a) {
            this.h = a;
            Mf(this.s, !0);
            this.l ? .K();
            this.m ? .Ia();
            Ig(this)
        }
        A() {
            Hg(this, 4);
            Mb(this.C)
        }
    };

    function Kg(a, b, c, d) {
        const e = Tf(a.B);
        b = X(Md) ? {
            google_ad_width: e.width,
            google_ad_height: e.height,
            google_reactive_ad_format: 1 === b ? 10 : 11,
            google_acr: d,
            google_video_play_muted: 2 !== b && !c
        } : {
            google_ad_width: e.width,
            google_ad_height: e.height,
            google_reactive_ad_format: 1 === b ? 10 : 11,
            google_acr: d
        };
        X(Od) && (b.fsapi = !0);
        return { ...a.H,
            ...b
        }
    }
    var Lg = class {
        constructor(a) {
            this.B = window;
            this.H = a
        }
        fetch(a) {
            const b = this.B.document.createElement("ins");
            b.classList.add("adsbygoogle");
            B(b, {
                display: "none"
            });
            this.B.document.documentElement.appendChild(b);
            const c = Kg(this, a.type, a.pa, d => {
                new Jg(this.B, b, d, a.callback, a.type)
            });
            kg(b, c, this.B)
        }
    };
    /* 
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    const Mg = {};

    function Ng() {
        return U('<ins class="adsbygoogle" style="width:100% !important;height:100% !important;" id="fake-interstitial-ins"><iframe style="overflow:hidden;" width="100%" height="100%" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" scrolling="no" src="about:blank" id="aswift-fake"></iframe></ins>')
    }

    function Og() {
        return U('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path style="fill:#f5f5f5" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/><path fill="none" d="M0 0h24v24H0V0z"/></svg>')
    }

    function Pg(a) {
        const b = a.Ga;
        a = a.Na;
        return U('<div class="dialog-wrapper" style="width: 100%; height: 100%; position: absolute; top: 0;"><div class="close-confirmation-dialog" id="close-confirmation-dialog" style="width: ' + V(W(Math.floor(.78 * a))) + 'px"><div class="confirmation-title" style="font-size: ' + V(W(Math.floor(.031 * b))) + "px; margin-top: " + V(W(Math.floor(.0375 * b))) + "px; margin-left: " + V(W(Math.floor(.066 * a))) + "px; margin-right: " + V(W(Math.floor(.066 * a))) + 'px;">Close Ad?</div><div class="confirmation-message" style="font-size: ' +
            V(W(Math.floor(.025 * b))) + "px; margin-bottom: " + V(W(Math.floor(.0375 * b))) + "px; margin-top: " + V(W(Math.floor(.0375 * b))) + "px; margin-left: " + V(W(Math.floor(.066 * a))) + "px; margin-right: " + V(W(Math.floor(.066 * a))) + 'px;">You will lose your reward</div><div class="confirmation-buttons" style="font-size: ' + V(W(Math.floor(.0218 * b))) + "px; line-height: " + V(W(Math.floor(.05625 * b))) + "px; margin-right: " + V(W(Math.floor(.0125 * b))) + "px; margin-bottom: " + V(W(Math.floor(.0125 * b))) + 'px;"><div class="close-ad-button" id="close-ad-button" style="padding-left: ' +
            V(W(Math.floor(.044 * a))) + "px; padding-right: " + V(W(Math.floor(.044 * a))) + 'px;">CLOSE</div><div class="resume-ad-button" id="resume-ad-button" style="padding-left: ' + V(W(Math.floor(.044 * a))) + "px; padding-right: " + V(W(Math.floor(.044 * a))) + 'px;">RESUME</div></div></div></div>')
    };
    Aa ? rb(new w(db, 'javascript:""')) : rb(new w(db, "about:blank"));
    Aa ? rb(new w(db, 'javascript:""')) : rb(new w(db, "javascript:undefined"));

    function Qg(a, b, c) {
        a = a.h;
        c = b(c || Mg, {});
        b = a || la || (la = new Nb);
        if (c && c.h) b = c.h();
        else {
            b = b.createElement("DIV");
            b: if (p(c)) {
                if (c.sa && (c = c.sa(), c instanceof z)) {
                    a = c;
                    break b
                }
                a = Eb("zSoyz")
            } else a = Eb(String(c));
            c = b;
            if (Hb())
                for (; c.lastChild;) c.removeChild(c.lastChild);
            c.innerHTML = Db(a)
        }
        1 == b.childNodes.length && (c = b.firstChild, 1 == c.nodeType && (b = c));
        return b
    }
    class Rg {
        constructor() {
            this.h = la || (la = new Nb)
        }
    };

    function Sg(a, b) {
        if (a.contentDocument || a.contentWindow) b(a);
        else {
            const c = () => {
                b(a);
                hb(a, "load", c)
            };
            x(a, "load", c)
        }
    }
    async function Tg(a) {
        if (null == a.h) throw Error("Tried to show ad before initialized.");
        const b = new L;
        var c = a.h.h,
            d = Math.min(Number(c.clientWidth), Number(c.clientHeight));
        let e = Math.max(Number(c.clientWidth), Number(c.clientHeight));
        Ug(a) && (d *= .5, e *= .5);
        c = c.contentDocument;
        a = c.body.appendChild(Qg(a.C, Pg, {
            Na: d,
            Ga: e
        }));
        d = a.querySelector(".resume-ad-button");
        x(a.querySelector(".close-ad-button"), "click", () => {
            b.resolve(0)
        });
        x(d, "click", () => {
            b.resolve(1)
        });
        d = await b.promise;
        c.body.removeChild(a);
        return 0 ===
            d
    }

    function Ug(a) {
        if (null == a.h) throw Error("Tried to show ad before initialized.");
        a = a.h.h;
        return 1E3 < Number(a.clientWidth) || 1E3 < Number(a.clientHeight)
    }
    var Vg = class extends ng {
            constructor(a, b) {
                super();
                this.j = b;
                this.C = new Rg;
                this.l = 10;
                this.s = !1;
                this.m = Qg(this.C, Ng);
                Eg(this.m, b);
                document.documentElement.appendChild(this.m);
                Sg(this.m.firstChild, c => {
                    var d = {};
                    var e = 2 === this.j ? "Rewarded ad example" : "Interstitial ad example";
                    var f = this.j,
                        g = d && d.Qa;
                    d = U;
                    g ? (g = String(g), g = vf.test(g) ? g : "zSoyz", g = ' nonce="' + V(g) + '"') : g = "";
                    d = "<!DOCTYPE html><html><head>" + d("\n  <style" + g + '>\n    body {\n      padding: 0;\n      margin: 0;\n      background-color: #262626;\n    }\n    .container {\n      width: 100vw;\n      height: 92vh;\n      display: flex;\n      flex-direction: column;\n    }\n    .container .creative {\n      background-color: white;\n      border-style: solid;\n      border-width: thin;\n      border-color:#bdc1c6;\n      height: 250px;\n      margin: 20vh auto auto auto;\n      overflow: hidden;\n      padding: 0;\n      width: 300px;\n    }\n    .header-panel {\n      display: flex;\n      justify-content: center;\n      margin-bottom: 20px;\n      background-color: #424242;\n      border: 1px solid transparent;\n      border-radius: 4px;\n      height: 8vh;\n      color: #f5f5f5;\n      font-family: "Google Sans",Roboto,Arial,sans-serif;\n      font-size: 20px;\n      line-height: 8vh;\n    }\n    .dismiss-button {\n      display: flex;\n      flex-direction: row;\n      height: inherit;\n      align-items: center;\n      padding-right: 4%;\n      cursor: pointer;\n      position: absolute;\n      right: 0;\n    }\n    .count-down-container {\n      display: inline-flex;\n      flex: auto;\n    }\n    .adContainer {\n      display: flex;\n      flex-direction: row;\n      width: 100%;\n      height: 100%;\n      text-align: left;\n      margin: 0;\n    }\n    .adContainer .logo {\n      align-self: center;\n      width: 40px;\n      margin: 0 24px;\n      height: 40px;\n    }\n    .adContainer .logo IMG {\n      height: 40px;\n      width: 40px;\n    }\n    .adContainer .text {\n      margin: auto auto auto 0;\n    }\n    .adContainer .button {\n      align-self: center;\n      height: 100%;\n      max-height: 48px;\n      /* This gives a perceived margin of 32px, due to the margins within the button SVGs. */\n      margin-right: 30px;\n    }\n    .adContainer .button-inner {\n      max-height: 48px;\n      height: 100%;\n    }\n    .adContainer .button-inner SVG {\n      height: 100%;\n      width: auto;\n    }\n    .adText {\n      font-family: "Google Sans",Roboto,Arial,sans-serif;\n      font-size: 18px;\n      font-weight: normal;\n      line-height: 18px;\n      color: #202124;\n      margin-bottom: 4px;\n    }\n    .areaText {\n      font-family: Roboto,Arial,sans-serif;\n      font-size: 14px;\n      font-weight: medium;\n      line-height: 14px;\n      color: #5f6368;\n    }\n    .nativeIframeMessage .text {\n      padding: 0 10px;\n    }\n    .creative a {\n      text-decoration: none;\n    }\n\n    @media (max-height: 44px),\n        (max-height: 150px) and (max-width: 210px) {\n      .adContainer .logo {\n        display: none;\n      }\n      .adContainer .text {\n        margin-left: 5px;\n      }\n    }\n    @media (max-height: 110px) and (max-width: 330px) {\n      .adText {\n        font-size: 13px;\n        line-height: 13px;\n        margin-bottom: 2px;\n      }\n      .areaText {\n        font-size: 11px;\n        line-height: 11px;\n      }\n    }\n    @media (max-height: 38px) {\n      .adText {\n        font-size: 17px;\n        line-height: 17px;\n        margin-bottom: 0;\n      }\n      .areaText {\n        display: none;\n      }\n    }\n    @media (max-height: 20px) {\n      .adText {\n        font-size: 12px;\n        line-height: 12px;\n        margin-bottom: 0;\n      }\n    }\n\n    /* Vertically stacked assets in cases where creative is not a distictly\n       horizontal rectangle shape */\n    @media (min-height: 240px),\n        (max-width: 65px) and (min-height: 50px),\n        (max-width: 130px) and (min-height: 100px),\n        (max-width: 195px) and (min-height: 150px),\n        (max-width: 260px) and (min-height: 200px) {\n      .adContainer .logo {\n        display: initial;\n      }\n      .areaText {\n        display: initial;\n      }\n      .adContainer .text {\n        margin-left: 0;\n      }\n      .adContainer {\n        text-align: center;\n        display: flex;\n        flex-direction: column;\n      }\n      .adContainer .logo {\n        margin: 40px auto 24px auto;\n      }\n      .adContainer .text {\n        margin: 0 auto auto auto;\n      }\n      .adContainer .text .adText{\n        margin-bottom: 8px;\n      }\n      .adContainer .button {\n        margin: auto auto 32px auto;\n      }\n      @media (max-height: 200px) {\n        .adContainer .logo {\n          display: none;\n        }\n        .adContainer .text {\n          margin: 10px auto auto auto;\n        }\n      }\n    }\n\n    .x-button {\n      display: flex;\n      align-items: center;\n    }\n\n    .dialog-wrapper {\n      background: rgba(0, 0, 0, .4);\n      height: 100%;\n      left: 0;\n      opacity: 1;\n      pointer-events: auto;\n      position: fixed;\n      top: 0;\n      transition: opacity .15s ease-out;\n      -webkit-transition: opacity .15s ease-out;\n      width: 100%;\n      will-change: opacity;\n      z-index: 2147483647;\n    }\n\n    .close-confirmation-dialog {\n      background: #fff;\n      box-shadow: 0 16px 24px 2px rgba(0, 0, 0, .14),\n        0 6px 30px 5px rgba(0, 0, 0, .12), 0 8px 10px -5px rgba(0, 0, 0, .2);\n      font-family: Roboto, sans-serif;\n      left: 50%;\n      position: fixed;\n      top: 50%;\n      transform: translate(-50%, -50%);\n      -webkit-transform: translate(-50%, -50%);\n    }\n\n    .confirmation-title {\n      color: #000;\n    }\n\n    .confirmation-message {\n      color: #757575;\n    }\n\n    .confirmation-buttons {\n      display: -webkit-box;\n      display: -webkit-flex;\n      display: flex;\n\n      -webkit-box-align: center;\n      -webkit-align-items: center;\n      align-items: center;\n\n      -webkit-box-pack: flex-end;\n      -webkit-justify-content: flex-end;\n      justify-content: flex-end;\n    }\n\n    .close-ad-button,\n    .resume-ad-button {\n      color: #fff;\n      cursor: pointer;\n      font-weight: 500;\n      text-align: center;\n\n      display: -webkit-box;\n      display: -webkit-flex;\n      display: flex;\n    }\n\n    .close-ad-button {\n      color: #3e82f7;\n    }\n\n    .resume-ad-button {\n      background: #3e82f7;\n      border-radius: 2px;\n      box-shadow: 0 2px 2px 0 rgba(0, 0, 0, .24);\n    }\n  </style>\n  ') +
                        '</head><body><div class="header-panel">';
                    2 != f && (d += "Ad");
                    d += '<div class="dismiss-button" id="dismiss-button">' + (2 == f ? '<div class="count-down-container" id="count-down-container"><div id="count-down"><div class="count-down-text" id="count-down-text"></div></div><div class="x-button" id="close-button" style="padding-left: 5px;">' + Og() + "</div></div>" : "") + '<div class="x-button" id="dismiss-button-element">' + Og() + '</div></div></div><div class="container"><div class="creative">' + U('<div style="position:relative;float:right;top:1px;right:1px;width:15px;height:15px;"><svg style="fill:#00aecd;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 15 15"><circle cx="6" cy="6" r="0.67"></circle><path d="M4.2,11.3Q3.3,11.8,3.3,10.75L3.3,4.1Q3.3,3.1,4.3,3.5L10.4,7.0Q12.0,7.5,10.4,8.0L6.65,10.0L6.65,7.75a0.65,0.65,0,1,0,-1.3,0L5.35,10.75a0.9,0.9,0,0,0,1.3,0.8L12.7,8.2Q13.7,7.5,12.7,6.7L3.3,1.6Q2.2,1.3,1.8,2.5L1.8,12.5Q2.2,13.9,3.3,13.3L4.8,12.5A0.3,0.3,0,1,0,4.2,11.3Z"></path></svg></div>') +
                        '<a target="_blank" href="https://developers.google.com/ad-placement"><div class="adContainer"><div class="logo">' + U('<img width="40" height="40" alt="" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iNTVweCIgaGVpZ2h0PSI1NnB4IiB2aWV3Qm94PSIwIDAgNTUgNTYiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDUyLjMgKDY3Mjk3KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5sb2dvX2dvb2dsZWdfNDhkcDwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxnIGlkPSJNMl92MiIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9IjAyYV9hdXRvX2FkcyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxNy4wMDAwMDAsIC03MDUuMDAwMDAwKSI+CiAgICAgICAgICAgIDxnIGlkPSJtb2JpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDM3OC4wMDAwMDAsIDE2NC4wMDAwMDApIj4KICAgICAgICAgICAgICAgIDxnIGlkPSJHcm91cC00IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxNi4wMDAwMDAsIDc0LjAwMDAwMCkiPgogICAgICAgICAgICAgICAgICAgIDxnIGlkPSJHUC1hZCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTEuMDAwMDAwLCA0NDQuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICAgICAgICAgIDxnIGlkPSJsb2dvX2dvb2dsZWdfNDhkcCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjQuMDAwMDAwLCAyMy4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik01NC44OCwyOC42MzYzNjM2IEM1NC44OCwyNi42NTA5MDkxIDU0LjcwMTgxODIsMjQuNzQxODE4MiA1NC4zNzA5MDkxLDIyLjkwOTA5MDkgTDI4LDIyLjkwOTA5MDkgTDI4LDMzLjc0IEw0My4wNjkwOTA5LDMzLjc0IEM0Mi40MiwzNy4yNCA0MC40NDcyNzI3LDQwLjIwNTQ1NDUgMzcuNDgxODE4Miw0Mi4xOTA5MDkxIEwzNy40ODE4MTgyLDQ5LjIxNjM2MzYgTDQ2LjUzMDkwOTEsNDkuMjE2MzYzNiBDNTEuODI1NDU0NSw0NC4zNDE4MTgyIDU0Ljg4LDM3LjE2MzYzNjQgNTQuODgsMjguNjM2MzYzNiBaIiBpZD0iU2hhcGUiIGZpbGw9IiM0Mjg1RjQiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTI4LDU2IEMzNS41Niw1NiA0MS44OTgxODE4LDUzLjQ5MjcyNzMgNDYuNTMwOTA5MSw0OS4yMTYzNjM2IEwzNy40ODE4MTgyLDQyLjE5MDkwOTEgQzM0Ljk3NDU0NTUsNDMuODcwOTA5MSAzMS43NjcyNzI3LDQ0Ljg2MzYzNjQgMjgsNDQuODYzNjM2NCBDMjAuNzA3MjcyNyw0NC44NjM2MzY0IDE0LjUzNDU0NTUsMzkuOTM4MTgxOCAxMi4zMzI3MjczLDMzLjMyIEwyLjk3ODE4MTgyLDMzLjMyIEwyLjk3ODE4MTgyLDQwLjU3NDU0NTUgQzcuNTg1NDU0NTUsNDkuNzI1NDU0NSAxNy4wNTQ1NDU1LDU2IDI4LDU2IFoiIGlkPSJTaGFwZSIgZmlsbD0iIzM0QTg1MyIgZmlsbC1ydWxlPSJub256ZXJvIj48L3BhdGg+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMTIuMzMyNzI3MywzMy4zMiBDMTEuNzcyNzI3MywzMS42NCAxMS40NTQ1NDU1LDI5Ljg0NTQ1NDUgMTEuNDU0NTQ1NSwyOCBDMTEuNDU0NTQ1NSwyNi4xNTQ1NDU1IDExLjc3MjcyNzMsMjQuMzYgMTIuMzMyNzI3MywyMi42OCBMMTIuMzMyNzI3MywxNS40MjU0NTQ1IEwyLjk3ODE4MTgyLDE1LjQyNTQ1NDUgQzEuMDgxODE4MTgsMTkuMjA1NDU0NSAwLDIzLjQ4MTgxODIgMCwyOCBDMCwzMi41MTgxODE4IDEuMDgxODE4MTgsMzYuNzk0NTQ1NSAyLjk3ODE4MTgyLDQwLjU3NDU0NTUgTDEyLjMzMjcyNzMsMzMuMzIgWiIgaWQ9IlNoYXBlIiBmaWxsPSIjRkJCQzA1IiBmaWxsLXJ1bGU9Im5vbnplcm8iPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0yOCwxMS4xMzYzNjM2IEMzMi4xMTA5MDkxLDExLjEzNjM2MzYgMzUuODAxODE4MiwxMi41NDkwOTA5IDM4LjcwMzYzNjQsMTUuMzIzNjM2NCBMNDYuNzM0NTQ1NSw3LjI5MjcyNzI3IEM0MS44ODU0NTQ1LDIuNzc0NTQ1NDUgMzUuNTQ3MjcyNywwIDI4LDAgQzE3LjA1NDU0NTUsMCA3LjU4NTQ1NDU1LDYuMjc0NTQ1NDUgMi45NzgxODE4MiwxNS40MjU0NTQ1IEwxMi4zMzI3MjczLDIyLjY4IEMxNC41MzQ1NDU1LDE2LjA2MTgxODIgMjAuNzA3MjcyNywxMS4xMzYzNjM2IDI4LDExLjEzNjM2MzYgWiIgaWQ9IlNoYXBlIiBmaWxsPSIjRUE0MzM1IiBmaWxsLXJ1bGU9Im5vbnplcm8iPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwb2x5Z29uIGlkPSJTaGFwZSIgcG9pbnRzPSIwIDAgNTYgMCA1NiA1NiAwIDU2Ij48L3BvbHlnb24+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg=="/>') +
                        '</div><div class="text"><div class="adText">' + mf(e) + '</div><div class="areaText">' + (mf("Disclaimer: This ad is not frequency capped.") + "</div></div></div></a></div></div></body></html>");
                    e = U(d).sa();
                    f = c.contentDocument || c.contentWindow.document;
                    f.open();
                    f.write(Db(e));
                    f.close();
                    this.h = new Sf(window, c, this.m);
                    a(this)
                })
            }
            show(a) {
                if (null == this.h) throw Error("Tried to show ad before initialized.");
                const b = this.h.h.contentDocument,
                    c = b.getElementById("dismiss-button");
                Mf(this.h, !0);
                if (2 === this.j) {
                    const d =
                        c.querySelector("#dismiss-button-element");
                    d.style.display = "none";
                    const e = async () => {
                        if (null == this.h) throw Error("Failure on rewarded example: Could not find ad frame.");
                        this.s = !0;
                        await Tg(this) ? (this.h.j(), x(c, "click", e), a(2)) : this.s = !1
                    };
                    x(c, "click", e);
                    this.l = Y(Ed);
                    const f = 0 > this.l;
                    this.s = !1;
                    const g = b.getElementById("count-down-container"),
                        h = g.querySelector("#count-down-text");
                    h.innerText = `Reward in ${this.l} seconds`;
                    f || (this.F = setInterval(() => {
                        this.s || (--this.l, h.innerText = `Reward in ${this.l} seconds`);
                        if (0 === this.l) {
                            g.style.display = "none";
                            d.style.display = "";
                            clearInterval(this.F);
                            const l = async () => {
                                if (null == this.h) throw Error("Failure on rewarded example: Could not find ad frame.");
                                this.h.j();
                                hb(c, "click", l);
                                a(3)
                            };
                            x(c, "click", l);
                            hb(c, "click", e)
                        }
                    }, 1E3))
                } else x(c, "click", () => {
                    if (null == this.h) throw Error("Failure on rewarded example: Could not find ad frame.");
                    this.h.j();
                    a(1)
                })
            }
            A() {
                this.h ? .j();
                Mb(this.m)
            }
        },
        Wg = class {
            fetch(a) {
                new Vg(a.callback, a.type)
            }
        };

    function Xg(a, b, c) {
        a.h.addEventListener(a.ima.AdErrorEvent.Type.AD_ERROR, () => {
            Yg(a, c)
        });
        a.h.addEventListener(a.ima.AdEvent.Type.SKIPPED, () => {
            Yg(a, b)
        });
        a.h.addEventListener(a.ima.AdEvent.Type.COMPLETE, () => {
            Yg(a, b)
        })
    }

    function Yg(a, b) {
        B(a.l, {
            display: "none",
            "z-index": "0"
        });
        a.callback(b)
    }
    var Zg = class extends ng {
        constructor(a, b, c, d, e) {
            super();
            this.ima = a;
            this.j = b;
            this.l = c;
            this.m = d;
            this.h = e;
            this.callback = () => {}
        }
        show(a) {
            this.callback = a;
            switch (this.j) {
                case 1:
                    Xg(this, 1, 1);
                    break;
                case 2:
                    Xg(this, 3, 2)
            }
            try {
                B(this.l, {
                    display: "block",
                    "z-index": "1000000"
                }), this.h.start()
            } catch (b) {
                this.h.discardAdBreak(), Yg(this, 2 === this.j ? 2 : 1)
            }
        }
        A() {
            this.m.destroy();
            this.h.destroy();
            this.l.remove()
        }
    };

    function $g(a) {
        const b = a.document.createElement("div");
        B(b, {
            top: "0",
            left: "0",
            width: "100%",
            height: "100%",
            position: "fixed",
            display: "none",
            "z-index": "0"
        });
        a.document.body.appendChild(b);
        return b
    }

    function ah(a, b) {
        a = new a.ima.AdDisplayContainer(b);
        a.initialize();
        return a
    }

    function bh(a, b, c, d, e, f) {
        const g = new a.ima.AdsRenderingSettings;
        g.restoreCustomPlaybackStateOnAdBreakComplete = !0;
        const h = b.getAdsManager({}, g);
        h.addEventListener(a.ima.AdEvent.Type.LOADED, () => {
            const l = new Zg(a.ima, f.type, c, d, h);
            e.destroy();
            f.callback(l)
        });
        b = Tf(a.B);
        h.init(b.width, b.height, a.ima.ViewMode.FULLSCREEN)
    }

    function ch(a) {
        a = {
            ad_type: "video_text_image",
            client: a.H.google_ad_client.replace("ca-", "ca-games-"),
            description_url: a.H.google_page_url || a.document.URL,
            overlay: "0"
        };
        const b = new URL("https://googleads.g.doubleclick.net/pagead/ads");
        b.search = (new URLSearchParams(a)).toString();
        return b.toString()
    }
    var dh = class {
        constructor(a) {
            var b = window,
                c = jc `https://imasdk.googleapis.com/js/sdkloader/ima3.js`;
            this.B = b;
            this.H = a;
            this.Fa = c;
            this.ima = google.ima;
            this.document = this.B.document;
            a = this.document.createElement("script");
            Pb(a, this.Fa);
            const d = new L;
            a.onload = () => {
                this.ima = this.B.google.ima;
                d.resolve()
            };
            this.Ma = d.promise;
            this.document.documentElement.appendChild(a)
        }
        async fetch(a) {
            await this.Ma;
            const b = $g(this),
                c = ah(this, b),
                d = new this.ima.AdsLoader(c);
            d.addEventListener(this.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
                g => {
                    bh(this, g, b, c, d, a)
                });
            d.addEventListener(this.ima.AdErrorEvent.Type.AD_ERROR, () => {
                a.callback(null)
            });
            const e = new this.ima.AdsRequest;
            e.adTagUrl = ch(this);
            e.setAdWillAutoPlay(!1);
            e.setAdWillPlayMuted(!(2 === a.type || a.pa));
            e.forceNonLinearFullSlot = !0;
            const f = Tf(this.B);
            e.linearAdSlotWidth = f.width;
            e.linearAdSlotHeight = f.height;
            e.nonLinearAdSlotWidth = f.width;
            e.nonLinearAdSlotHeight = f.height;
            d.requestAds(e)
        }
    };
    var eh = class {
            constructor() {
                this.o = H(dg);
                this.l = (new Map).set("inv_plcnf", 1).set("inv_adcnf", 2).set("adbr_cl", 3).set("adbr_noad", 4).set("adbr_nousitr", 5).set("adbr_usrint", 6).set("adbr_naf", 7).set("adbr_pgad", 8).set("adbr_pgaatd", 9).set("adbr_tepgai", 10).set("adcf_cl", 11).set("adcf_naf", 12).set("adcf_pgad", 13).set("adcf_pgaatd", 14).set("prf_suc", 15).set("prf_fail", 16).set("admb_na", 17).set("admb_rfs", 18).set("admb_fetfail", 19).set("lgc_fld", 20).set("pr_rr", 21).set("api_ld", 23).set("dbl_init", 26).set("admb_tm",
                    24).set("adbr_dn", 25).set("dbl_init", 26).set("sess_m", 27).set("ad_cls", 28);
                this.m = (new Map).set("admob", 1).set("adsense", 2).set("ima", 3)
            }
            fa() {}
            X(a) {
                this.h = a.Ba;
                this.i = a.Da
            }
            J(a) {
                this.j = this.m.get(a) ? ? 0
            }
            v(a) {
                var b = new Sc;
                a = this.l.get(a) ? ? 0;
                b = u(b, 1, a, 0).J(this.j);
                this.h && u(b, 3, this.h, "");
                this.i && u(b, 4, this.i, "");
                cg(this.o, b)
            }
        },
        fh = class {
            constructor(a, b) {
                this.i = a;
                this.h = b
            }
            fa(a) {
                this.h.fa(a)
            }
            X(a) {
                this.i.X(a);
                this.h.X(a)
            }
            J(a) {
                this.i.J(a);
                this.h.J(a)
            }
            v(a, b = {}) {
                this.i.v(a, b);
                this.h.v(a, b)
            }
        };
    const gh = "click mousedown mouseup touchstart touchend pointerdown pointerup keydown keyup scroll".split(" ");
    var hh = class extends F {
        constructor() {
            var a = window;
            super();
            this.h = 0;
            const b = () => {
                this.h = Date.now()
            };
            for (const c of gh) a.document.documentElement.addEventListener(c, b, {
                capture: !0
            });
            G(this, () => {
                for (const c of gh) a.document.documentElement.removeEventListener(c, b, {
                    capture: !0
                })
            })
        }
    };
    const ih = new Set(["auto", "on"]),
        jh = new Set(["on", "off"]),
        kh = new Set("start pause next browse reward preroll".split(" ")),
        lh = new Map([
            ["start", "interstitial"],
            ["pause", "interstitial"],
            ["next", "interstitial"],
            ["browse", "interstitial"],
            ["reward", "reward"],
            ["preroll", "preroll"]
        ]),
        mh = new Map([
            ["interstitial", ["type"]],
            ["reward", ["type", "beforeReward", "adDismissed", "adViewed"]],
            ["preroll", ["type", "adBreakDone"]]
        ]),
        nh = new Map([
            ["interstitial", ["beforeReward", "adDismissed", "adViewed"]],
            ["reward", []],
            ["preroll", ["beforeAd", "afterAd", "beforeReward", "adDismissed", "adViewed"]]
        ]),
        oh = "beforeAd afterAd beforeReward adDismissed adViewed adBreakDone".split(" "),
        ph = new Map([
            ["beforeBreak", "beforeAd"],
            ["afterBreak", "afterAd"],
            ["adComplete", "adViewed"]
        ]);

    function qh(a, b) {
        let c = !1;
        const d = f => {
            c = !0;
            b.error(`Invalid ad config: ${f}.`)
        };
        if (null != a.preloadAdBreaks && !ih.has(a.preloadAdBreaks)) {
            var e = Array.from(ih).map(f => `'${f}'`).join(", ");
            d(`'preloadAdBreaks' must be one of [${e}]`)
        }
        null == a.sound || jh.has(a.sound) || (e = Array.from(jh).map(f => `'${f}'`).join(", "), d(`'sound' must be one of [${e}]`));
        null != a.onReady && "function" !== typeof a.onReady && d("'onReady' must be a function");
        return !c
    }

    function rh(a, b, c) {
        for (const [d, e] of ph) {
            const f = d,
                g = e;
            if (f in a) {
                c.v("lgc_fld", {
                    field: f
                });
                if (g in a) return b.error(`Invalid placement config: '${f}' has been renamed to ${g}. Cannot pass both fields. Please use ${g} only.`), !1;
                b.warn(`Placement config: '${f}' has been renamed to '${g}'. Please update your code.`);
                a[g] = a[f];
                delete a[f]
            }
        }
        return !0
    }

    function sh(a, b, c) {
        let d = !1;
        const e = h => {
            d = !0;
            b.error(`Invalid placement config: ${h}.`)
        };
        a = Object.assign({}, a);
        if (!rh(a, b, c)) return {
            qa: !1,
            ta: a
        };
        if (!kh.has(a.type)) {
            var f = Array.from(kh).map(h => `'${h}'`).join(", ");
            e(`'type' must be one of [${f}]`);
            return {
                qa: !d,
                ta: a
            }
        }
        c = lh.get(a.type);
        const g = mh.get(c).filter(h => !(h in a));
        0 < g.length && e("missing required properties " + g.map(h => `'${h}'`).join(", "));
        c = nh.get(c).filter(h => h in a);
        0 < c.length && e("the following properties are not used for the given ad type: " +
            c.map(h => `'${h}'`).join(", "));
        for (f of oh) f in a && "function" !== typeof a[f] && e(`'${f}' must be a function`);
        return {
            qa: !d,
            ta: a
        }
    };
    class th extends F {
        constructor(a, b) {
            super();
            this.T = new L;
            this.h = !1;
            this.timeout = setTimeout(I(726, () => {
                b()
            }), 1E3 * a)
        }
        get promise() {
            return this.T.promise
        }
        resolve(a) {
            this.o || (this.h = !0, this.T.resolve(a))
        }
        i() {
            clearTimeout(this.timeout)
        }
    }

    function uh(a, b) {
        const c = a.google_adbreak_test;
        if (c) switch (c) {
            case "on":
                return new Wg;
            case "adsense":
                break;
            default:
                throw b.error(`Unsupported data-adbreak-test value '${c}. Supported values: '${"on"}'.`), Error("unsupported test mode");
        }
        return new Lg(a)
    }

    function vh(a) {
        return ["google_admob_interstitial_slot", "google_admob_rewarded_slot"].some(b => "string" === typeof wh(b, a))
    }

    function wh(a, b) {
        if (b[a] && "string" === typeof b[a]) return String(b[a])
    }

    function xh(a, b, c) {
        null == ff && (ff = new ef);
        return ff.connect().then(d => new zg(d, a, b, c))
    }

    function yh(a, b) {
        window.addEventListener("onpagehide" in self ? "pagehide" : "unload", I(938, () => {
            if (b.first_slotcar_request_processing_time) {
                var c = Date.now();
                a.h.v("sess_m", {
                    igsl: c - b.first_slotcar_request_processing_time,
                    afh: String(b.ad_frequency_hint),
                    niab: Number(b.number_of_interstitial_ad_breaks),
                    nias: Number(b.number_of_interstitial_ads_shown),
                    opsl: c - b.adsbygoogle_execution_start_time
                })
            }
        }))
    }

    function zh(a, b) {
        const c = b.google_admob_ads_only;
        "string" === typeof c && ("on" === c ? vh(b) ? a.Y = !0 : a.m.error("Cannot set data-admob-ads-only without providing at least one AdMob ad slot id.") : a.m.error(`Unsupported data-admob-ads-only value '${c}'. Supported value: 'on'.`))
    }

    function Ah(a) {
        return a.K ? "adbreaktest" : a.C ? "admob" : "adsense"
    }

    function Bh(a) {
        for (const b of [1, 2]) {
            const c = a.j.get(b);
            if (c || Ch(a, b)) c ? (c.D(), a.j.delete(b)) : (a.A.get(b).D(), a.A.delete(b)), Dh(a, b, 0, 7)
        }
    }

    function Eh(a) {
        if (!a.Z || a.ya) {
            if (!a.va && a.s.preloadAdBreaks)
                for (var b of [1, 2])
                    if (!a.j.has(b) && !a.G.has(b)) return;
            for (a.va = !0; 0 < a.ja.length;) b = a.ja.pop(), Fh(a, "onReady", b)
        }
    }

    function Gh(a, b) {
        b = b.google_ad_frequency_hint;
        const c = Y(Gd);
        if ("string" !== typeof b) return c;
        const d = /^(\d+)s$/.exec(b);
        return null == d ? (a.m.error(`Invalid data-ad-frequency-hint value: '${b}'. It must be in format 'Xs' where X is a number.`), c) : Math.max(Y(Id), Number(d[1]))
    }

    function Hh(a) {
        return "ca-pub-1725310704471587" === a.F
    }

    function Ih(a, b) {
        a.Y && !a.C && X(Fd) ? a.h.v("adcf_afni") : b()
    }

    function Jh(a, b, c, d = !0) {
        const e = a.j.get(b);
        e && (e.D(), Dh(a, b, 10, c), d && a.j.delete(b))
    }

    function Ch(a, b) {
        return a.A.has(b) && !a.A.get(b).h
    }

    function Kh(a) {
        return H(zf).j(Cd.h, Cd.defaultValue).includes(a.toString())
    }

    function Dh(a, b, c, d) {
        if (Ch(a, b)) throw Error("already scheduled");
        c = new th(c, () => Lh(a, b, d));
        a.A.set(b, c);
        return c
    }

    function Fh(a, b, c) {
        dc(() => {
            Mh(a, b, c)
        })
    }

    function Z(a, b, c, d) {
        const e = {
            breakType: b.type,
            breakFormat: 2 === c ? "reward" : "preroll" === b.type ? "preroll" : "interstitial",
            breakStatus: d
        };
        b.name && (e.breakName = b.name);
        a.h.v("adbr_dn", {
            breakType: e.breakType,
            breakFormat: e.breakFormat,
            breakStatus: e.breakStatus,
            breakName: e.breakName ? ? ""
        });
        const f = b.adBreakDone;
        null != f && Fh(a, "adBreakDone", () => {
            f(e)
        })
    }
    async function Nh(a, b, c) {
        if (a.ia) return a.h.v("pr_rr"), Z(a, b, c, "frequencyCapped"), !1;
        a.ia = !0;
        a.Z && await a.ga;
        var d = Ch(a, c) ? a.A.get(c) : Dh(a, c, 0, 2);
        d = await Promise.race([d.promise, ec(1E3 * Y(Bd), 2)]);
        return 1 === d ? (a.h.v("adbr_noad"), Z(a, b, c, "noAdPreloaded"), !1) : 2 === d ? (a.h.v("pr_to", {
            source: "slotcar"
        }), Z(a, b, c, "timeout"), !1) : !0
    }
    async function Oh(a, b) {
        const c = new L;
        a.ua = c;
        Mh(a, "beforeReward", () => {
            b.beforeReward(() => {
                c.resolve(0)
            })
        });
        return 0 === await c.promise
    }

    function Mh(a, b, c) {
        if (c) try {
            c()
        } catch (d) {
            return a.m.error(`'${b}' callback threw an error:`, d), !1
        }
        return !0
    }

    function Ph(a, b, c, d, e) {
        const f = a.Ea.get(c),
            g = b ? 1 : -1,
            h = 0 < f.length ? f[f.length - 1] : 0;
        Math.sign(h) === g ? f[f.length - 1] = h + g : f.push(g);
        a.h.v(b ? "prf_suc" : "prf_fail", {
            type: c,
            src: d,
            stats: f.join(","),
            timing: Date.now() - e
        })
    }
    async function Lh(a, b, c) {
        const d = Date.now();
        a.l.fetch({
            type: b,
            pa: "on" === a.s.sound,
            Aa: X(Nd) ? H(id).h() : void 0,
            callback: e => {
                a.G.delete(b);
                const f = a.A.get(b);
                e ? (f.resolve(0), a.j.set(b, e), G(e, () => {
                    a.j.delete(b)
                })) : (f.resolve(1), a.G.add(b), Dh(a, b, Y(Jd), 5));
                Ph(a, null != e, b, c, d);
                1 !== c && 7 !== c || Eh(a)
            }
        })
    }
    var Qh = class extends F {
        constructor(a, b) {
            super();
            this.m = a;
            this.h = b;
            this.l = null;
            this.F = "";
            this.ia = this.Z = this.va = this.K = !1;
            this.ha = 0;
            this.N = !1;
            this.ua = null;
            this.ja = [];
            this.aa = window.innerWidth;
            this.la = window.innerHeight;
            this.Y = this.ya = this.C = !1;
            this.ga = Promise.resolve();
            this.wa = 0;
            this.s = {
                sound: "on"
            };
            this.j = new Map;
            this.ka = new Set;
            this.A = new Map;
            this.xa = new hh;
            this.G = new Set;
            this.Ea = new Map([
                [1, []],
                [2, []]
            ]);
            G(this, ia(cd, this.xa))
        }
        init(a) {
            this.F = String(a.google_ad_client);
            if (null != this.l) this.h.v("dbl_init", {
                ad_client: this.F
            });
            else {
                var b = Vf();
                b.in_game_session_length = 0;
                b.number_of_interstitial_ad_breaks = 0;
                b.number_of_interstitial_ads_shown = 0;
                b.ad_frequency_hint = a.google_ad_frequency_hint ? String(a.google_ad_frequency_hint) : "";
                yh(this, b);
                b = navigator.userAgent;
                var c = RegExp("\\bwv\\b");
                this.Z = b.includes("Android") && c.test(b);
                "on" === a.google_adbreak_test && (this.K = !0);
                zh(this, a);
                this.h.fa(this.F);
                this.l = new pg(uh(a, this.m));
                this.h.J(Ah(this));
                if (vh(a)) {
                    this.h.X({
                        Ba: wh("google_admob_interstitial_slot", a),
                        Da: wh("google_admob_rewarded_slot",
                            a)
                    });
                    const e = Date.now();
                    b = xh(a, this.m, this.h).then(f => {
                        null != this.l && this.l.D();
                        this.l = new pg(f);
                        this.C = !0;
                        this.h.J(Ah(this));
                        Bh(this)
                    }).catch(f => {
                        this.h.v("admb_fetfail", {
                            error: f
                        })
                    }).finally(() => {
                        this.h.v("admb_tm", {
                            timing: Date.now() - e
                        })
                    });
                    this.Z && (this.ga = Promise.race([b, ec(1E3 * Y(zd))]), this.ga.finally(() => {
                        this.ya = !0;
                        Eh(this)
                    }))
                } else X(Ld) && (this.l.D(), this.l = new pg(new dh(a)), this.h.J("ima"), Bh(this));
                this.ha = Gh(this, a);
                this.aa = window.innerWidth;
                this.la = window.innerHeight;
                var d = gb(I(791, () => {
                    if (this.aa !==
                        window.innerWidth || this.la !== window.innerHeight)
                        if (!this.C || this.aa !== window.innerWidth) {
                            for (const e of this.j.keys()) Jh(this, e, 4, !1);
                            this.j.clear();
                            this.aa = window.innerWidth;
                            this.la = window.innerHeight
                        }
                }));
                window.addEventListener("resize", d);
                G(this, () => {
                    window.removeEventListener("resize", d)
                });
                this.wa = Date.now()
            }
        }
        handleAdConfig(a) {
            Hh(this) && !X(Dd) ? this.h.v("adcf_pgad") : !this.Y || this.C || X(Fd) ? qh(a, this.m) ? (this.h.v("adcf_cl", {
                preloadAdBreaks: a.preloadAdBreaks || "",
                sound: a.sound || "",
                onReady: a.onReady ?
                    "true" : "false"
            }), a.sound && this.s.sound !== a.sound && (this.s.sound = a.sound, Ih(this, () => {
                Jh(this, 1, 6)
            })), a.preloadAdBreaks && !this.s.preloadAdBreaks ? Ih(this, () => {
                this.s.preloadAdBreaks = a.preloadAdBreaks;
                if ("on" === this.s.preloadAdBreaks)
                    for (const b of [1, 2]) this.j.has(b) || Ch(this, b) || (Hh(this) && !Kh(b) ? this.h.v("adcf_pgaatd", {
                        ad_type: 1 === b ? "interstitial" : "rewarded"
                    }) : Dh(this, b, 0, 1))
            }) : a.preloadAdBreaks && this.s.preloadAdBreaks && this.m.error("'adConfig' was already called to set 'preloadAdBreaks' with value " +
                `'${this.s.preloadAdBreaks}'`), a.onReady && (this.ja.push(a.onReady), Eh(this))) : this.h.v("inv_adcnf") : this.h.v("adcf_naf")
        }
        async handleAdBreak(a, b) {
            if (Hh(this) && !X(Dd)) this.h.v("adbr_pgad");
            else if (!this.Y || this.C)
                if (a = sh(a, this.m, this.h), a.qa) {
                    var c = a.ta,
                        d = "reward" === c.type ? 2 : 1;
                    if (Hh(this) && !Kh(d)) this.h.v("adbr_pgaatd", {
                        ad_type: 1 === d ? "interstitial" : "rewarded"
                    });
                    else if ("ca-pub-1725310704471587" === this.F && 1 === d ? 6E4 < Date.now() - this.wa : 1) {
                        a = Vf();
                        1 === d && a.number_of_interstitial_ad_breaks++;
                        var e = "preroll" ===
                            c.type;
                        this.h.v("adbr_cl", {
                            type: c.type,
                            name: c.name || "",
                            frequency_cap: 2 === d ? 0 : this.ha,
                            last_intr: Date.now() - this.xa.h
                        });
                        if (b && !e) Z(this, c, d, "notReady");
                        else if (2 === d && this.ua ? .resolve(1), this.j.get(d) || !e || await Nh(this, c, d)) {
                            var f = this.j.get(d);
                            if (f)
                                if (this.ka.has(d) && this.K) this.ka.delete(d), Z(this, c, d, "frequencyCapped");
                                else if (this.ka.add(d), 2 !== d || await Oh(this, c))
                                if (this.N) this.m.error("Cannot show ad while another ad is already visible."), Z(this, c, d, "frequencyCapped");
                                else if (Mh(this, "beforeAd",
                                    c.beforeAd)) {
                                this.N = !0;
                                1 === d && a.number_of_interstitial_ads_shown++;
                                this.ia = !0;
                                var g = Date.now(),
                                    h = l => {
                                        this.N = !1;
                                        2 === l || 2 === d && 4 === l ? Fh(this, "adDismissed", c.adDismissed) : 3 === l && Fh(this, "adViewed", c.adViewed);
                                        Fh(this, "afterAd", c.afterAd);
                                        1 === d ? Z(this, c, d, "viewed") : Z(this, c, d, 4 === l ? "other" : 2 === l ? "dismissed" : "viewed");
                                        4 !== l && (f.D(), Dh(this, d, this.K || 2 === d ? 0 : this.ha, 3));
                                        this.h.v("ad_cls", {
                                            result: l,
                                            adType: d,
                                            dur: Date.now() - g
                                        })
                                    };
                                G(f, () => {
                                    this.N && h(4)
                                });
                                f.show(h)
                            } else Fh(this, "afterAd", c.afterAd), Z(this, c,
                                d, "error");
                            else Z(this, c, d, "ignored");
                            else Ch(this, d) ? (this.h.v("adbr_noad"), Z(this, c, d, this.G.has(d) ? "other" : "frequencyCapped")) : (Dh(this, d, 0, 2), Z(this, c, d, "noAdPreloaded"))
                        }
                    } else this.h.v("adbr_tepgai")
                } else this.h.v("inv_plcnf");
            else this.h.v("adbr_naf")
        }
        handleAdBreakBeforeReady(a) {
            return this.handleAdBreak(a, !0)
        }
        i() {
            for (const a of this.A.values()) a.D();
            this.A.clear();
            for (const a of this.j.values()) a.D();
            this.j.clear();
            this.l && this.l.D();
            super.i()
        }
    };
    Mc(E, 723, () => {
        var a = mg();
        ig(a);
        fg();
        a = new qg(Sa(Qa(a, 2), ""));
        a = Kd ? new fh(new eh, a) : a;
        const b = {
            error(...c) {
                console.error("[Ad Placement API]", ...c)
            },
            warn(...c) {
                console.warn("[Ad Placement API]", ...c)
            }
        };
        r("Trident") || r("MSIE") ? b.warn("Internet Explorer is not supported.") : jg(new Qh(b, a))
    });
}).call(this, "[2021,\"r20230207\",\"r20110914\",null,null,null,null,\".google.co.in\",null,null,null,null,[null,[]],null,null,null,null,-1,[44759876,44759927,44759842]]");