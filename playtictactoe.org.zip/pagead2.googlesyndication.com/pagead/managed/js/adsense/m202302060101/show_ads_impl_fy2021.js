(function(sttc) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    'use strict';
    var p, aa = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function ba(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var ca = ba(this),
        da = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        fa = {},
        ha = {};

    function ia(a, b) {
        var c = ha[b];
        if (null == c) return a[b];
        c = a[c];
        return void 0 !== c ? c : a[b]
    }

    function ka(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in fa ? f = fa : f = ca;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = da && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? aa(fa, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === ha[d] && (a = 1E9 * Math.random() >>> 0, ha[d] = da ? ca.Symbol(d) : "$jscp$" + a + "$" + d), aa(f, ha[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    var la = "function" == typeof Object.create ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ma;
    if (da && "function" == typeof Object.setPrototypeOf) ma = Object.setPrototypeOf;
    else {
        var na;
        a: {
            var oa = {
                    a: !0
                },
                pa = {};
            try {
                pa.__proto__ = oa;
                na = pa.a;
                break a
            } catch (a) {}
            na = !1
        }
        ma = na ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var qa = ma;

    function ra(a, b) {
        a.prototype = la(b.prototype);
        a.prototype.constructor = a;
        if (qa) qa(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.hg = b.prototype
    }
    ka("AggregateError", function(a) {
        function b(c, d) {
            d = Error(d);
            "stack" in d && (this.stack = d.stack);
            this.errors = c;
            this.message = d.message
        }
        if (a) return a;
        ra(b, Error);
        b.prototype.name = "AggregateError";
        return b
    }, "es_2021");
    ka("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : Array.from(b);
            return Promise.all(b.map(function(c) {
                return Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new fa.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    var u = this || self;

    function sa(a) {
        var b = typeof a;
        b = "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null";
        return "array" == b || "object" == b && "number" == typeof a.length
    }

    function ta(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function ua(a) {
        return Object.prototype.hasOwnProperty.call(a, wa) && a[wa] || (a[wa] = ++xa)
    }
    var wa = "closure_uid_" + (1E9 * Math.random() >>> 0),
        xa = 0;

    function ya(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function Aa(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function Ba(a, b, c) {
        Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Ba = ya : Ba = Aa;
        return Ba.apply(null, arguments)
    }

    function Ca(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function Da() {
        return Date.now()
    }

    function Ea(a, b) {
        a = a.split(".");
        var c = u;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function Fa(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.hg = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.jk = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    }

    function Ga(a) {
        return a
    };
    var Ja = {
        lj: 0,
        kj: 1,
        jj: 2
    };

    function La(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, La);
        else {
            const c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        void 0 !== b && (this.cause = b)
    }
    Fa(La, Error);
    La.prototype.name = "CustomError";
    var Ma;

    function Na(a, b) {
        a = a.split("%s");
        let c = "";
        const d = a.length - 1;
        for (let e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        La.call(this, c + a[d])
    }
    Fa(Na, La);
    Na.prototype.name = "AssertionError";

    function Oa(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function Qa(a) {
        if (!Ra.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(Sa, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(Ta, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Ua, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Wa, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Xa, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Ya, "&#0;"));
        return a
    }
    var Sa = /&/g,
        Ta = /</g,
        Ua = />/g,
        Wa = /"/g,
        Xa = /'/g,
        Ya = /\x00/g,
        Ra = /[\x00&<>"']/;

    function Za(a, b) {
        return -1 != a.indexOf(b)
    }

    function $a(a) {
        var b = ab();
        let c = 0;
        b = Oa(String(b)).split(".");
        a = Oa(String(a)).split(".");
        const d = Math.max(b.length, a.length);
        for (let g = 0; 0 == c && g < d; g++) {
            var e = b[g] || "",
                f = a[g] || "";
            do {
                e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                if (0 == e[0].length && 0 == f[0].length) break;
                c = bb(0 == e[1].length ? 0 : parseInt(e[1], 10), 0 == f[1].length ? 0 : parseInt(f[1], 10)) || bb(0 == e[2].length, 0 == f[2].length) || bb(e[2], f[2]);
                e = e[3];
                f = f[3]
            } while (0 == c)
        }
        return c
    }

    function bb(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };

    function cb() {
        var a = u.navigator;
        return a && (a = a.userAgent) ? a : ""
    }

    function v(a) {
        return Za(cb(), a)
    };

    function db() {
        return v("Opera")
    }

    function eb() {
        return v("Trident") || v("MSIE")
    }

    function fb() {
        return v("Firefox") || v("FxiOS")
    }

    function gb() {
        return v("Safari") && !(hb() || v("Coast") || db() || v("Edge") || v("Edg/") || v("OPR") || fb() || v("Silk") || v("Android"))
    }

    function hb() {
        return (v("Chrome") || v("CriOS")) && !v("Edge") || v("Silk")
    }

    function ib() {
        return v("Android") && !(hb() || fb() || db() || v("Silk"))
    }

    function jb(a) {
        const b = {};
        a.forEach(c => {
            b[c[0]] = c[1]
        });
        return c => b[c.find(d => d in b)] || ""
    }

    function ab() {
        var a = cb();
        if (eb()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        let d;
        for (; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
        a = jb(b);
        return db() ? a(["Version", "Opera"]) :
            v("Edge") ? a(["Edge"]) : v("Edg/") ? a(["Edg"]) : v("Silk") ? a(["Silk"]) : hb() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    };

    function kb(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function lb(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function mb(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = "string" === typeof a ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function nb(a, b) {
        const c = a.length,
            d = Array(c),
            e = "string" === typeof a ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function ob(a, b, c) {
        let d = c;
        lb(a, function(e, f) {
            d = b.call(void 0, d, e, f, a)
        });
        return d
    }

    function pb(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function rb(a, b) {
        return 0 <= kb(a, b)
    }

    function sb(a, b) {
        b = kb(a, b);
        let c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function tb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function ub(a) {
        const b = a.length;
        if (0 < b) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function vb(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    }

    function wb(a, b, c) {
        c = c || xb;
        let d = 0,
            e = a.length,
            f;
        for (; d < e;) {
            const g = d + (e - d >>> 1);
            let h;
            h = c(b, a[g]);
            0 < h ? d = g + 1 : (e = g, f = !h)
        }
        return f ? d : -d - 1
    }

    function yb(a, b) {
        if (!sa(a) || !sa(b) || a.length != b.length) return !1;
        const c = a.length,
            d = zb;
        for (let e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    }

    function xb(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function zb(a, b) {
        return a === b
    }

    function Ab(a) {
        const b = [];
        for (let c = 0; c < arguments.length; c++) {
            const d = arguments[c];
            if (Array.isArray(d))
                for (let e = 0; e < d.length; e += 8192) {
                    const f = Ab.apply(null, vb(d, e, e + 8192));
                    for (let g = 0; g < f.length; g++) b.push(f[g])
                } else b.push(d)
        }
        return b
    }

    function Bb(a, b) {
        b = b || Math.random;
        for (let c = a.length - 1; 0 < c; c--) {
            const d = Math.floor(b() * (c + 1)),
                e = a[c];
            a[c] = a[d];
            a[d] = e
        }
    };

    function Cb(a) {
        Cb[" "](a);
        return a
    }
    Cb[" "] = function() {};

    function Db(a, b) {
        try {
            return Cb(a[b]), !0
        } catch (c) {}
        return !1
    };
    var Eb = db(),
        Fb = eb(),
        Hb = v("Edge"),
        Ib = Hb || Fb,
        Jb = v("Gecko") && !(Za(cb().toLowerCase(), "webkit") && !v("Edge")) && !(v("Trident") || v("MSIE")) && !v("Edge"),
        Kb = Za(cb().toLowerCase(), "webkit") && !v("Edge");

    function Lb() {
        var a = u.document;
        return a ? a.documentMode : void 0
    }
    var Mb;
    a: {
        var Nb = "",
            Ob = function() {
                var a = cb();
                if (Jb) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Hb) return /Edge\/([\d\.]+)/.exec(a);
                if (Fb) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (Kb) return /WebKit\/(\S+)/.exec(a);
                if (Eb) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();Ob && (Nb = Ob ? Ob[1] : "");
        if (Fb) {
            var Pb = Lb();
            if (null != Pb && Pb > parseFloat(Nb)) {
                Mb = String(Pb);
                break a
            }
        }
        Mb = Nb
    }
    var Qb = Mb,
        Rb;
    if (u.document && Fb) {
        var Sb = Lb();
        Rb = Sb ? Sb : parseInt(Qb, 10) || void 0
    } else Rb = void 0;
    var Tb = Rb;
    ib();
    hb();
    gb();
    var Ub = {},
        Vb = null;

    function Wb(a, b) {
        void 0 === b && (b = 0);
        Xb();
        b = Ub[b];
        const c = Array(Math.floor(a.length / 3)),
            d = b[64] || "";
        let e = 0,
            f = 0;
        for (; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function Yb(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            255 < e && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        return Wb(b, 3)
    }

    function Zb(a) {
        var b = [];
        $b(a, function(c) {
            b.push(c)
        });
        return b
    }

    function ac(a) {
        var b = a.length,
            c = 3 * b / 4;
        c % 3 ? c = Math.floor(c) : Za("=.", a[b - 1]) && (c = Za("=.", a[b - 2]) ? c - 2 : c - 1);
        var d = new Uint8Array(c),
            e = 0;
        $b(a, function(f) {
            d[e++] = f
        });
        return e !== c ? d.subarray(0, e) : d
    }

    function $b(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    m = Vb[l];
                if (null != m) return m;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
            }
            return k
        }
        Xb();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (64 === h && -1 === e) break;
            b(e << 2 | f >> 4);
            64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
        }
    }

    function Xb() {
        if (!Vb) {
            Vb = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                var d = a.concat(b[c].split(""));
                Ub[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e];
                    void 0 === Vb[f] && (Vb[f] = e)
                }
            }
        }
    };
    var bc = "undefined" !== typeof Uint8Array;
    const cc = !Fb && "function" === typeof u.btoa;

    function dc(a) {
        if (!cc) return Wb(a);
        let b = "";
        for (; 10240 < a.length;) b += String.fromCharCode.apply(null, a.subarray(0, 10240)), a = a.subarray(10240);
        b += String.fromCharCode.apply(null, a);
        return btoa(b)
    }
    const ec = RegExp("[-_.]", "g");

    function fc(a) {
        switch (a) {
            case "-":
                return "+";
            case "_":
                return "/";
            case ".":
                return "=";
            default:
                return ""
        }
    }

    function gc(a) {
        return bc && null != a && a instanceof Uint8Array
    }
    let hc;
    var ic = {};
    let jc;

    function kc(a) {
        if (a !== ic) throw Error("illegal external caller");
    }

    function lc() {
        return jc || (jc = new mc(null, ic))
    }
    var mc = class {
        constructor(a, b) {
            kc(b);
            this.M = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        }
        isEmpty() {
            return null == this.M
        }
    };
    const nc = Symbol();

    function oc(a, b) {
        if (nc) return a[nc] |= b;
        if (void 0 !== a.za) return a.za |= b;
        Object.defineProperties(a, {
            za: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        });
        return b
    }

    function pc(a, b) {
        const c = qc(a);
        (c & b) !== b && (Object.isFrozen(a) && (a = Array.prototype.slice.call(a)), rc(a, c | b));
        return a
    }

    function sc(a, b) {
        nc ? a[nc] && (a[nc] &= ~b) : void 0 !== a.za && (a.za &= ~b)
    }

    function qc(a) {
        let b;
        nc ? b = a[nc] : b = a.za;
        return null == b ? 0 : b
    }

    function rc(a, b) {
        nc ? a[nc] = b : void 0 !== a.za ? a.za = b : Object.defineProperties(a, {
            za: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    }

    function tc(a) {
        oc(a, 1);
        return a
    }

    function uc(a) {
        return !!(qc(a) & 2)
    }

    function vc(a) {
        oc(a, 16);
        return a
    }

    function wc(a, b) {
        rc(b, (a | 0) & -51)
    }

    function xc(a, b) {
        rc(b, (a | 18) & -41)
    };
    var yc = {};

    function zc(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let Ac;

    function Bc(a, b) {
        if (null != a)
            if ("string" === typeof a) a = a ? new mc(a, ic) : lc();
            else if (a.constructor !== mc)
            if (gc(a)) a = a.length ? new mc(new Uint8Array(a), ic) : lc();
            else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    }
    var Cc;
    const Dc = [];
    rc(Dc, 23);
    Cc = Object.freeze(Dc);

    function Ec(a) {
        if (uc(a.P)) throw Error("Cannot mutate an immutable Message");
    }

    function Fc(a) {
        var b = a.length;
        (b = b ? a[b - 1] : void 0) && zc(b) ? b.g = 1 : a.push({
            g: 1
        })
    };

    function Gc(a) {
        if (null != a && "number" !== typeof a) throw Error(`Value of float/double field must be a number|null|undefined, found ${typeof a}: ${a}`);
        return a
    }

    function Hc(a) {
        return a
    }

    function Ic(a) {
        return a
    }

    function Jc(a) {
        return a
    }

    function Kc(a) {
        return a
    }

    function Lc(a) {
        return a
    };

    function Mc(a) {
        const b = a.m + a.Ga;
        return a.ra || (a.ra = a.P[b] = {})
    }

    function w(a, b, c) {
        return -1 === b ? null : b >= a.m ? a.ra ? a.ra[b] : void 0 : c && a.ra && (c = a.ra[b], null != c) ? c : a.P[b + a.Ga]
    }

    function x(a, b, c, d) {
        Ec(a);
        return Nc(a, b, c, d)
    }

    function Nc(a, b, c, d) {
        a.C && (a.C = void 0);
        if (b >= a.m || d) return Mc(a)[b] = c, a;
        a.P[b + a.Ga] = c;
        (c = a.ra) && b in c && delete c[b];
        return a
    }

    function Oc(a, b, c) {
        return void 0 !== Pc(a, b, c, !1)
    }

    function Qc(a, b, c, d, e) {
        let f = w(a, b, d);
        Array.isArray(f) || (f = Cc);
        const g = qc(f);
        g & 1 || tc(f);
        if (e) g & 2 || oc(f, 2), c & 1 || Object.freeze(f);
        else {
            e = !(c & 2);
            const h = g & 2;
            c & 1 || !h ? e && g & 16 && !h && sc(f, 16) : (f = tc(Array.prototype.slice.call(f)), Nc(a, b, f, d))
        }
        return f
    }

    function Rc(a, b) {
        return Qc(a, b, 0, !1, uc(a.P))
    }

    function Sc(a, b) {
        const c = w(a, b);
        var d = null == c ? c : "number" === typeof c || "NaN" === c || "Infinity" === c || "-Infinity" === c ? Number(c) : void 0;
        null != d && d !== c && Nc(a, b, d);
        return d
    }

    function y(a, b) {
        a = w(a, b);
        return null == a ? a : !!a
    }

    function Tc(a, b, c, d) {
        const e = uc(a.P);
        let f = Qc(a, b, 1, d, e);
        const g = qc(f);
        if (!(g & 4)) {
            Object.isFrozen(f) && (f = tc(f.slice()), Nc(a, b, f, d));
            let h = 0,
                k = 0;
            for (; h < f.length; h++) {
                const l = c(f[h]);
                null != l && (f[k++] = l)
            }
            k < h && (f.length = k);
            oc(f, 5);
            e && (oc(f, 2), Object.freeze(f))
        }!e && (g & 2 || Object.isFrozen(f)) && (f = Array.prototype.slice.call(f), oc(f, 5), Uc(a, b, f, d));
        return f
    }

    function Vc(a, b, c, d) {
        if (null == c) return x(a, b, Cc);
        const e = qc(c);
        if (!(e & 4)) {
            if (e & 2 || Object.isFrozen(c)) c = Array.prototype.slice.call(c);
            for (let f = 0; f < c.length; f++) c[f] = d(c[f]);
            rc(c, e | 5)
        }
        return x(a, b, c)
    }

    function Uc(a, b, c, d) {
        c = null == c ? Cc : pc(c, 1);
        return x(a, b, c, d)
    }

    function Wc(a, b, c, d) {
        Ec(a);
        c !== d ? Nc(a, b, c) : Nc(a, b, void 0, !1);
        return a
    }

    function Xc(a, b, c, d) {
        Ec(a);
        (c = Yc(a, c)) && c !== b && null != d && Nc(a, c, void 0, !1);
        return Nc(a, b, d)
    }

    function Yc(a, b) {
        let c = 0;
        for (let d = 0; d < b.length; d++) {
            const e = b[d];
            null != w(a, e) && (0 !== c && Nc(a, c, void 0, !1), c = e)
        }
        return c
    }

    function Pc(a, b, c, d) {
        const e = w(a, c, d); {
            let g = !1;
            var f = null == e || "object" !== typeof e || (g = Array.isArray(e)) || e.Sc !== yc ? g ? new b(e) : void 0 : e
        }
        f !== e && null != f && (Nc(a, c, f, d), oc(f.P, qc(a.P) & 18));
        return f
    }

    function C(a, b, c) {
        b = Pc(a, b, c, !1);
        if (null == b) return b;
        if (!uc(a.P)) {
            const d = Zc(b);
            d !== b && (b = d, Nc(a, c, b, !1))
        }
        return b
    }

    function $c(a, b, c, d, e) {
        a.l || (a.l = {});
        var f = a.l[c],
            g = Qc(a, c, 3, void 0, e);
        if (!f) {
            var h = g;
            f = [];
            var k = !!(qc(a.P) & 16);
            g = uc(h);
            const q = h;
            !e && g && (h = Array.prototype.slice.call(h));
            var l = g;
            let r = 0;
            for (; r < h.length; r++) {
                var m = h[r];
                m = Array.isArray(m) ? new b(m) : void 0;
                if (void 0 === m) continue;
                var n = m.P;
                const t = qc(n);
                let B = t;
                g && (B |= 2);
                k && (B |= 16);
                B != t && rc(n, B);
                n = B;
                l = l || !!(2 & n);
                f.push(m)
            }
            a.l[c] = f;
            k = qc(h);
            b = k | 33;
            b = l ? b & -9 : b | 8;
            k != b && (l = h, Object.isFrozen(l) && (l = Array.prototype.slice.call(l)), rc(l, b), h = l);
            q !== h && Nc(a, c, h);
            (e || d && g) && oc(f, 2);
            d && Object.freeze(f);
            return f
        }
        e || (e = Object.isFrozen(f), d && !e ? Object.freeze(f) : !d && e && (f = Array.prototype.slice.call(f), a.l[c] = f));
        return f
    }

    function D(a, b, c) {
        var d = uc(a.P);
        b = $c(a, b, c, d, d);
        a = Qc(a, c, 3, void 0, d);
        if (!(d || qc(a) & 8)) {
            for (d = 0; d < b.length; d++) {
                c = b[d];
                const e = Zc(c);
                c !== e && (b[d] = e, a[d] = e.P)
            }
            oc(a, 8)
        }
        return b
    }

    function ad(a, b, c) {
        Ec(a);
        null == c && (c = void 0);
        return Nc(a, b, c)
    }

    function bd(a, b, c, d) {
        Ec(a);
        null == d && (d = void 0);
        return Xc(a, b, c, d)
    }

    function cd(a, b, c, d) {
        Ec(a);
        let e = null == c ? Cc : tc([]);
        if (null != c) {
            let f = !!c.length;
            for (let g = 0; g < c.length; g++) {
                const h = c[g];
                f = f && !uc(h.P);
                e[g] = h.P
            }
            e = pc(e, (f ? 8 : 0) | 1);
            a.l || (a.l = {});
            a.l[b] = c
        } else a.l && (a.l[b] = void 0);
        return Nc(a, b, e, d)
    }

    function dd(a, b, c, d) {
        Ec(a);
        const e = $c(a, c, b, !1, !1);
        c = null != d ? d : new c;
        b = Qc(a, b, 2, void 0, !1);
        e.push(c);
        b.push(c.P);
        uc(c.P) && sc(b, 8);
        return a
    }

    function ed(a, b) {
        a = w(a, b);
        return null == a ? 0 : a
    }

    function fd(a, b) {
        return gd(w(a, b), 0)
    }

    function hd(a, b) {
        return w(a, b)
    }

    function id(a, b, c) {
        return Wc(a, b, c, 0)
    }

    function jd(a, b, c) {
        return Wc(a, b, c, "")
    }

    function gd(a, b) {
        return null == a ? b : a
    }

    function G(a, b) {
        return gd(w(a, b), "")
    }

    function I(a, b, c = !1) {
        return gd(y(a, b), c)
    }

    function ld(a, b) {
        return gd(w(a, b), 0)
    }

    function md(a, b, c, d) {
        c = Yc(a, d) === c ? c : -1;
        return C(a, b, c)
    }

    function nd(a, b, c) {
        return Wc(a, b, c, !1)
    }

    function od(a, b, c) {
        return Wc(a, b, c, 0)
    };
    let pd;

    function qd(a, b) {
        pd = b;
        a = new a(b);
        pd = void 0;
        return a
    };

    function rd(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "object":
                if (a)
                    if (Array.isArray(a)) {
                        if (0 !== (qc(a) & 128)) return a = Array.prototype.slice.call(a), Fc(a), a
                    } else {
                        if (gc(a)) return dc(a);
                        if (a instanceof mc) {
                            const b = a.M;
                            return null == b ? "" : "string" === typeof b ? b : a.M = dc(b)
                        }
                    }
        }
        return a
    };

    function sd(a, b, c, d) {
        if (null != a) {
            if (Array.isArray(a)) a = td(a, b, c, void 0 !== d);
            else if (zc(a)) {
                const e = {};
                for (let f in a) Object.prototype.hasOwnProperty.call(a, f) && (e[f] = sd(a[f], b, c, d));
                a = e
            } else a = b(a, d);
            return a
        }
    }

    function td(a, b, c, d) {
        const e = qc(a);
        d = d ? !!(e & 16) : void 0;
        a = Array.prototype.slice.call(a);
        for (let f = 0; f < a.length; f++) a[f] = sd(a[f], b, c, d);
        c(e, a);
        return a
    }

    function ud(a) {
        return a.Sc === yc ? a.toJSON() : rd(a)
    }

    function vd(a, b) {
        a & 128 && Fc(b)
    };

    function wd(a, b, c = xc) {
        if (null != a) {
            if (bc && a instanceof Uint8Array) return a.length ? new mc(new Uint8Array(a), ic) : lc();
            if (Array.isArray(a)) {
                const d = qc(a);
                if (d & 2) return a;
                if (b && !(d & 32) && (d & 16 || 0 === d)) return rc(a, d | 2), a;
                a = td(a, wd, d & 4 ? xc : c, !0);
                b = qc(a);
                b & 4 && b & 2 && Object.freeze(a);
                return a
            }
            return a.Sc === yc ? xd(a) : a
        }
    }

    function yd(a, b, c, d, e, f, g) {
        (a = a.l && a.l[c]) ? (d = qc(a), d & 2 ? d = a : (f = nb(a, xd), xc(d, f), Object.freeze(f), d = f), cd(b, c, d, e)) : x(b, c, wd(d, f, g), e)
    }

    function xd(a) {
        if (uc(a.P)) return a;
        a = zd(a, !0);
        oc(a.P, 2);
        return a
    }

    function zd(a, b) {
        const c = a.P;
        var d = vc([]),
            e = a.constructor.messageId;
        e && d.push(e);
        e = a.ra;
        if (e) {
            d.length = c.length;
            d.fill(void 0, d.length, c.length);
            var f = {};
            d[d.length - 1] = f
        }
        0 !== (qc(c) & 128) && Fc(d);
        b = b || uc(a.P) ? xc : wc;
        d = qd(a.constructor, d);
        a.Wd && (d.Wd = a.Wd.slice());
        f = !!(qc(c) & 16);
        const g = e ? c.length - 1 : c.length;
        for (let h = 0; h < g; h++) yd(a, d, h - a.Ga, c[h], !1, f, b);
        if (e)
            for (const h in e) yd(a, d, +h, e[h], !0, f, b);
        return d
    }

    function Zc(a) {
        if (!uc(a.P)) return a;
        const b = zd(a, !1);
        b.C = a;
        return b
    };

    function Ad(a) {
        Ac = !0;
        try {
            return JSON.stringify(a.toJSON(), Bd)
        } finally {
            Ac = !1
        }
    }
    var K = class {
        constructor(a, b, c) {
            null == a && (a = pd);
            pd = void 0;
            var d = this.constructor.j || 0,
                e = 0 < d,
                f = this.constructor.messageId,
                g = !1;
            if (null == a) {
                a = f ? [f] : [];
                var h = 48;
                var k = !0;
                e && (d = 0, h |= 128);
                rc(a, h)
            } else {
                if (!Array.isArray(a)) throw Error();
                if (f && f !== a[0]) throw Error();
                let l = h = oc(a, 0);
                if (k = 0 !== (16 & l))(g = 0 !== (32 & l)) || (l |= 32);
                if (e)
                    if (128 & l) d = 0;
                    else {
                        if (0 < a.length) {
                            const m = a[a.length - 1];
                            if (zc(m) && "g" in m) {
                                d = 0;
                                l |= 128;
                                delete m.g;
                                let n = !0;
                                for (let q in m) {
                                    n = !1;
                                    break
                                }
                                n && a.pop()
                            }
                        }
                    }
                else if (128 & l) throw Error();
                h !== l && rc(a,
                    l)
            }
            this.Ga = (f ? 0 : -1) - d;
            this.l = void 0;
            this.P = a;
            a: {
                f = this.P.length;d = f - 1;
                if (f && (f = this.P[d], zc(f))) {
                    this.ra = f;
                    this.m = d - this.Ga;
                    break a
                }
                void 0 !== b && -1 < b ? (this.m = Math.max(b, d + 1 - this.Ga), this.ra = void 0) : this.m = Number.MAX_VALUE
            }
            if (!e && this.ra && "g" in this.ra) throw Error('Unexpected "g" flag in sparse object of message that is not a group type.');
            if (c) {
                b = k && !g && !0;
                e = this.m;
                let l;
                for (k = 0; k < c.length; k++) g = c[k], g < e ? (g += this.Ga, (d = a[g]) ? Cd(d, b) : a[g] = Cc) : (l || (l = Mc(this)), (d = l[g]) ? Cd(d, b) : l[g] = Cc)
            }
        }
        toJSON() {
            const a =
                this.P;
            return Ac ? a : td(a, ud, vd)
        }
    };

    function Cd(a, b) {
        if (Array.isArray(a)) {
            var c = qc(a),
                d = 1;
            !b || c & 2 || (d |= 16);
            (c & d) !== d && rc(a, c | d)
        }
    }
    K.prototype.Sc = yc;

    function Bd(a, b) {
        return rd(b)
    };
    const Dd = a => null !== a && void 0 !== a;
    let Ed = void 0;

    function Fd(a, b) {
        const c = Ed;
        Ed = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    };

    function Gd(a) {
        return b => {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = qd(a, vc(b))
            }
            return b
        }
    };

    function Hd(a, b) {
        this.j = a === Id && b || "";
        this.l = Jd
    }
    Hd.prototype.qa = !0;
    Hd.prototype.ja = function() {
        return this.j
    };

    function Kd(a) {
        return a instanceof Hd && a.constructor === Hd && a.l === Jd ? a.j : "type_error:Const"
    }

    function Ld(a) {
        return new Hd(Id, a)
    }
    var Jd = {},
        Id = {};
    var Md = Ld("https://tpc.googlesyndication.com/sodar/%{basename}.js");

    function Nd() {
        return !1
    }

    function Od() {
        return !0
    }

    function Pd(a) {
        const b = arguments,
            c = b.length;
        return function() {
            for (let d = 0; d < c; d++)
                if (!b[d].apply(this, arguments)) return !1;
            return !0
        }
    }

    function Qd(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function Rd(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function Sd(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    }

    function Td(a, b) {
        let c = 0;
        return function(d) {
            u.clearTimeout(c);
            const e = arguments;
            c = u.setTimeout(function() {
                a.apply(b, e)
            }, 63)
        }
    }

    function Ud(a, b) {
        function c() {
            e = u.setTimeout(d, 63);
            let h = g;
            g = [];
            a.apply(b, h)
        }

        function d() {
            e = 0;
            f && (f = !1, c())
        }
        let e = 0,
            f = !1,
            g = [];
        return function(h) {
            g = arguments;
            e ? f = !0 : c()
        }
    };
    var Vd = {
            passive: !0
        },
        Wd = Rd(function() {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
                u.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function Xd(a) {
        return a ? a.passive && Wd() ? a : a.capture || !1 : !1
    }

    function L(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, Xd(d)), !0) : !1
    }

    function Yd(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, Xd(d)), !0) : !1
    };

    function Zd(a, b) {
        for (const c in a) b.call(void 0, a[c], c, a)
    }

    function $d(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function ae(a) {
        var b = be;
        a: {
            for (const c in b)
                if (b[c] == a) {
                    a = !0;
                    break a
                }
            a = !1
        }
        return a
    }

    function ce(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function de(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    }
    const ee = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function fe(a, b) {
        let c, d;
        for (let e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (let f = 0; f < ee.length; f++) c = ee[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    var ge = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var he;

    function ie() {
        if (void 0 === he) {
            var a = null,
                b = u.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: Ga,
                        createScript: Ga,
                        createScriptURL: Ga
                    })
                } catch (c) {
                    u.console && u.console.error(c.message)
                }
                he = a
            } else he = a
        }
        return he
    };
    const je = {};

    function ke(a) {
        return a instanceof le && a.constructor === le ? a.j : "type_error:SafeScript"
    }
    class le {
        constructor(a, b) {
            this.j = b === je ? a : "";
            this.qa = !0
        }
        toString() {
            return this.j.toString()
        }
        ja() {
            return this.j.toString()
        }
    };
    var ne = class {
        constructor(a, b) {
            this.j = b === me ? a : ""
        }
        toString() {
            return this.j + ""
        }
    };
    ne.prototype.qa = !0;
    ne.prototype.ja = function() {
        return this.j.toString()
    };

    function oe(a, b) {
        a = pe.exec(qe(a).toString());
        var c = a[3] || "";
        return re(a[1] + se("?", a[2] || "", b) + se("#", c))
    }

    function qe(a) {
        return a instanceof ne && a.constructor === ne ? a.j : "type_error:TrustedResourceUrl"
    }

    function te(a, b) {
        var c = Kd(a);
        if (!ue.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(ve, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof Hd ? Kd(d) : encodeURIComponent(String(d))
        });
        return re(a)
    }
    var ve = /%{(\w+)}/g,
        ue = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i"),
        pe = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        me = {};

    function re(a) {
        const b = ie();
        a = b ? b.createScriptURL(a) : a;
        return new ne(a, me)
    }

    function se(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var xe = class {
        constructor(a, b) {
            this.j = b === we ? a : ""
        }
        toString() {
            return this.j.toString()
        }
    };
    xe.prototype.qa = !0;
    xe.prototype.ja = function() {
        return this.j.toString()
    };

    function ye(a) {
        return a instanceof xe && a.constructor === xe ? a.j : "type_error:SafeUrl"
    }
    var ze = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
        Ae = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;

    function Be(a) {
        if (a instanceof xe) return a;
        a = "object" == typeof a && a.qa ? a.ja() : String(a);
        Ae.test(a) ? a = new xe(a, we) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(ze) ? new xe(a, we) : null);
        return a
    }
    var we = {},
        Ce = new xe("about:invalid#zClosurez", we);
    const De = {};

    function Ee(a) {
        return a instanceof Fe && a.constructor === Fe ? a.j : "type_error:SafeStyle"
    }

    function Ge(a) {
        let b = "";
        for (let c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                if (!/^[-_a-zA-Z0-9]+$/.test(c)) throw Error(`Name allows only [-_a-zA-Z0-9], got: ${c}`);
                let d = a[c];
                null != d && (d = Array.isArray(d) ? d.map(He).join(" ") : He(d), b += `${c}:${d};`)
            }
        return b ? new Fe(b, De) : Ie
    }
    class Fe {
        constructor(a, b) {
            this.j = b === De ? a : "";
            this.qa = !0
        }
        ja() {
            return this.j
        }
        toString() {
            return this.j.toString()
        }
    }
    var Ie = new Fe("", De);

    function He(a) {
        if (a instanceof xe) return 'url("' + ye(a).replace(/</g, "%3c").replace(/[\\"]/g, "\\$&") + '")';
        if (a instanceof Hd) a = Kd(a);
        else {
            a = String(a);
            var b = a.replace(Je, "$1").replace(Je, "$1").replace(Ke, "url");
            if (Le.test(b)) {
                if (b = !Me.test(a)) {
                    let c = b = !0;
                    for (let d = 0; d < a.length; d++) {
                        const e = a.charAt(d);
                        "'" == e && c ? b = !b : '"' == e && b && (c = !c)
                    }
                    b = b && c && Ne(a)
                }
                a = b ? Oe(a) : "zClosurez"
            } else a = "zClosurez"
        }
        if (/[{;}]/.test(a)) throw new Na("Value does not allow [{;}], got: %s.", [a]);
        return a
    }

    function Ne(a) {
        let b = !0;
        const c = /^[-_a-zA-Z0-9]$/;
        for (let d = 0; d < a.length; d++) {
            const e = a.charAt(d);
            if ("]" == e) {
                if (b) return !1;
                b = !0
            } else if ("[" == e) {
                if (!b) return !1;
                b = !1
            } else if (!b && !c.test(e)) return !1
        }
        return b
    }
    const Le = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$"),
        Ke = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g"),
        Je = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g"),
        Me = /\/\*/;

    function Oe(a) {
        return a.replace(Ke, (b, c, d, e) => {
            let f = "";
            d = d.replace(/^(['"])(.*)\1$/, (g, h, k) => {
                f = h;
                return k
            });
            b = (Be(d) || Ce).ja();
            return c + f + b + f + e
        })
    };
    const Pe = {};

    function Qe(a) {
        return a instanceof Re && a.constructor === Re ? a.j : "type_error:SafeStyleSheet"
    }
    class Re {
        constructor(a, b) {
            this.j = b === Pe ? a : "";
            this.qa = !0
        }
        toString() {
            return this.j.toString()
        }
        ja() {
            return this.j
        }
    };
    const Se = {};

    function Te(a) {
        return a instanceof Ue && a.constructor === Ue ? a.j : "type_error:SafeHtml"
    }

    function Ve(a) {
        return a instanceof Ue ? a : We(Qa("object" == typeof a && a.qa ? a.ja() : String(a)))
    }

    function We(a) {
        const b = ie();
        a = b ? b.createHTML(a) : a;
        return new Ue(a, Se)
    }

    function Xe(a, b, c) {
        var d = String(a);
        if (!Ye.test(d)) throw Error("");
        if (d.toUpperCase() in Ze) throw Error("");
        return $e(String(a), b, c)
    }

    function $e(a, b, c) {
        var d = "";
        if (b)
            for (let g in b)
                if (Object.prototype.hasOwnProperty.call(b, g)) {
                    if (!Ye.test(g)) throw Error("");
                    var e = b[g];
                    if (null != e) {
                        var f = g;
                        if (e instanceof Hd) e = Kd(e);
                        else if ("style" == f.toLowerCase()) {
                            if (!ta(e)) throw Error("");
                            e instanceof Fe || (e = Ge(e));
                            e = Ee(e)
                        } else {
                            if (/^on/i.test(f)) throw Error("");
                            if (f.toLowerCase() in af)
                                if (e instanceof ne) e = qe(e).toString();
                                else if (e instanceof xe) e = ye(e);
                            else if ("string" === typeof e) e = (Be(e) || Ce).ja();
                            else throw Error("");
                        }
                        e.qa && (e = e.ja());
                        f = `${f}="` +
                            Qa(String(e)) + '"';
                        d += " " + f
                    }
                }
        b = `<${a}` + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === ge[a.toLowerCase()] ? b += ">" : (c = bf(c), b += ">" + Te(c).toString() + "</" + a + ">");
        return We(b)
    }

    function cf(a) {
        const b = Ve(df),
            c = [],
            d = e => {
                Array.isArray(e) ? e.forEach(d) : (e = Ve(e), c.push(Te(e).toString()))
            };
        a.forEach(d);
        return We(c.join(Te(b).toString()))
    }

    function bf(a) {
        return cf(Array.prototype.slice.call(arguments))
    }
    class Ue {
        constructor(a, b) {
            this.j = b === Se ? a : "";
            this.qa = !0
        }
        ja() {
            return this.j.toString()
        }
        toString() {
            return this.j.toString()
        }
    }
    const Ye = /^[a-zA-Z0-9-]+$/,
        af = {
            action: !0,
            cite: !0,
            data: !0,
            formaction: !0,
            href: !0,
            manifest: !0,
            poster: !0,
            src: !0
        },
        Ze = {
            APPLET: !0,
            BASE: !0,
            EMBED: !0,
            IFRAME: !0,
            LINK: !0,
            MATH: !0,
            META: !0,
            OBJECT: !0,
            SCRIPT: !0,
            STYLE: !0,
            SVG: !0,
            TEMPLATE: !0
        };
    var ef = We("<!DOCTYPE html>"),
        df = new Ue(u.trustedTypes && u.trustedTypes.emptyHTML || "", Se),
        ff = We("<br>");
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function gf(a) {
        a: {
            try {
                var b = new URL(a)
            } catch (c) {
                b = "https:";
                break a
            }
            b = b.protocol
        }
        if ("javascript:" !== b) return a
    };

    function hf(a) {
        var b = jf(kf) || Ce;
        b = b instanceof xe ? ye(b) : gf(b);
        void 0 !== b && (a.href = b)
    };

    function lf(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const mf = "alternate author bookmark canonical cite help icon license next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function pf(a, b, c) {
        if (b instanceof ne) a.href = qe(b).toString();
        else {
            if (-1 === mf.indexOf(c)) throw Error(`TrustedResourceUrl href attribute required with rel="${c}"`);
            b = b instanceof xe ? ye(b) : gf(b);
            if (void 0 === b) return;
            a.href = b
        }
        a.rel = c
    };

    function qf(a) {
        var b;
        (b = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    }

    function rf(a, b) {
        a.src = qe(b);
        qf(a)
    };
    class sf {
        constructor(a) {
            this.Cf = a
        }
    }

    function tf(a) {
        return new sf(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const kf = [tf("data"), tf("http"), tf("https"), tf("mailto"), tf("ftp"), new sf(a => /^[^:]*([/?#]|$)/.test(a))];

    function jf(a = kf) {
        for (let b = 0; b < a.length; ++b) {
            const c = a[b];
            if (c instanceof sf && c.Cf("#")) return new xe("#", we)
        }
    };

    function uf(a) {
        var b = window;
        new Promise((c, d) => {
            function e() {
                f.onload = null;
                f.onerror = null;
                f.parentElement ? .removeChild(f)
            }
            const f = b.document.createElement("script");
            f.onload = () => {
                e();
                c()
            };
            f.onerror = () => {
                e();
                d(void 0)
            };
            f.type = "text/javascript";
            rf(f, a);
            "complete" !== b.document.readyState ? L(b, "load", () => {
                b.document.body.appendChild(f)
            }) : b.document.body.appendChild(f)
        })
    };
    async function vf(a) {
        var b = "https://pagead2.googlesyndication.com/getconfig/sodar" + `?sv=${200}&tid=${a.j}` + `&tv=${a.l}&st=` + `${a.jb}`;
        let c = void 0;
        try {
            c = await wf(b)
        } catch (g) {}
        if (c) {
            b = a.zb || c.sodar_query_id;
            var d = void 0 !== c.rc_enable && a.m ? c.rc_enable : "n",
                e = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms,
                f = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
            if (b && c.bg_hash_basename && c.bg_binary) return {
                context: a.v,
                Ye: c.bg_hash_basename,
                Xe: c.bg_binary,
                Df: a.j + "_" + a.l,
                zb: b,
                jb: a.jb,
                cc: d,
                rc: e,
                Zb: f
            }
        }
    }
    let wf = a => new Promise((b, c) => {
        const d = new XMLHttpRequest;
        d.onreadystatechange = () => {
            d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
        };
        d.open("GET", a, !0);
        d.send()
    });
    async function xf(a) {
        var b = await vf(a);
        if (b) {
            a = window;
            let c = a.GoogleGcLKhOms;
            c && "function" === typeof c.push || (c = a.GoogleGcLKhOms = []);
            c.push({
                _ctx_: b.context,
                _bgv_: b.Ye,
                _bgp_: b.Xe,
                _li_: b.Df,
                _jk_: b.zb,
                _st_: b.jb,
                _rc_: b.cc,
                _dl_: b.rc,
                _g2_: b.Zb
            });
            if (b = a.GoogleDX5YKUSk) a.GoogleDX5YKUSk = void 0, b[1]();
            a = te(Md, {
                basename: "sodar2"
            });
            uf(a)
        }
    };

    function yf(a, b) {
        return jd(a, 1, b)
    }
    var zf = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return G(this, 1)
        }
    };

    function Af(a, b) {
        return ad(a, 5, b)
    }

    function Bf(a, b) {
        return jd(a, 3, b)
    }
    var Cf = class extends K {
        constructor() {
            super()
        }
    };

    function Df(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    }
    var Ef = class {
            constructor(a) {
                this.j = a.l;
                this.l = a.m;
                this.v = a.v;
                this.zb = a.zb;
                this.win = a.R();
                this.jb = a.jb;
                this.cc = a.cc;
                this.rc = a.rc;
                this.Zb = a.Zb;
                this.m = a.j
            }
        },
        Ff = class {
            constructor(a, b, c) {
                this.l = a;
                this.m = b;
                this.v = c;
                this.win = window;
                this.jb = "env";
                this.cc = "n";
                this.rc = "0";
                this.Zb = "1";
                this.j = !0
            }
            R() {
                return this.win
            }
            build() {
                return new Ef(this)
            }
        };
    var Hf = class extends K {
            constructor(a) {
                super(a, -1, Gf)
            }
        },
        Gf = [2, 3];

    function If(a, b) {
        return x(a, 1, b)
    }

    function Jf(a, b) {
        return x(a, 2, b)
    }

    function Kf(a, b) {
        return x(a, 3, b)
    }

    function Lf(a, b) {
        return x(a, 4, b)
    }
    var Mf = class extends K {
        constructor() {
            super()
        }
        getVersion() {
            return w(this, 5)
        }
    };
    var Of = class extends K {
            constructor(a) {
                super(a, -1, Nf)
            }
        },
        Nf = [5];
    var Qf = class extends K {
            constructor(a) {
                super(a, -1, Pf)
            }
        },
        Pf = [3];
    var Sf = class extends K {
            constructor(a) {
                super(a, -1, Rf)
            }
        },
        Rf = [2];

    function Tf(a) {
        return D(a, Sf, 2)
    }

    function Uf(a) {
        return D(a, Of, 15)
    }
    var Wf = class extends K {
            constructor(a) {
                super(a, -1, Vf)
            }
        },
        Xf = Gd(Wf),
        Vf = [2, 15];
    var Yf = window;
    var Zf = {
        tg: "google_adtest",
        xg: "google_ad_client",
        yg: "google_ad_format",
        Ag: "google_ad_height",
        Ng: "google_ad_width",
        Eg: "google_ad_layout",
        Fg: "google_ad_layout_key",
        Gg: "google_ad_output",
        Hg: "google_ad_region",
        Kg: "google_ad_slot",
        Lg: "google_ad_type",
        Mg: "google_ad_url",
        Og: "google_allow_expandable_ads",
        ih: "google_analytics_domain_name",
        jh: "google_analytics_uacct",
        Ah: "google_container_id",
        Kh: "google_gl",
        ei: "google_enable_ose",
        oi: "google_full_width_responsive",
        oj: "google_rl_filtering",
        nj: "google_rl_mode",
        pj: "google_rt",
        mj: "google_rl_dest_url",
        Ui: "google_max_radlink_len",
        Zi: "google_num_radlinks",
        aj: "google_num_radlinks_per_unit",
        wg: "google_ad_channel",
        Ti: "google_max_num_ads",
        Vi: "google_max_responsive_height",
        uh: "google_color_border",
        di: "google_enable_content_recommendations",
        Hh: "google_content_recommendation_ui_type",
        Gh: "google_source_type",
        Fh: "google_content_recommendation_rows_num",
        Eh: "google_content_recommendation_columns_num",
        Dh: "google_content_recommendation_ad_positions",
        Ih: "google_content_recommendation_use_square_imgs",
        xh: "google_color_link",
        wh: "google_color_line",
        zh: "google_color_url",
        ug: "google_ad_block",
        Jg: "google_ad_section",
        vg: "google_ad_callback",
        rh: "google_captcha_token",
        yh: "google_color_text",
        ah: "google_alternate_ad_url",
        Dg: "google_ad_host_tier_id",
        sh: "google_city",
        Bg: "google_ad_host",
        Cg: "google_ad_host_channel",
        bh: "google_alternate_color",
        th: "google_color_bg",
        fi: "google_encoding",
        mi: "google_font_face",
        Nh: "google_cust_ch",
        Qh: "google_cust_job",
        Ph: "google_cust_interests",
        Oh: "google_cust_id",
        Rh: "google_cust_u_url",
        si: "google_hints",
        Hi: "google_image_size",
        Wi: "google_mtl",
        Sj: "google_cpm",
        Ch: "google_contents",
        Yi: "google_native_settings_key",
        Jh: "google_country",
        Kj: "google_targeting",
        ni: "google_font_size",
        Uh: "google_disable_video_autoplay",
        fk: "google_video_product_type",
        ek: "google_video_doc_id",
        dk: "google_cust_gender",
        Fj: "google_cust_lh",
        Ej: "google_cust_l",
        Rj: "google_tfs",
        Xi: "google_native_ad_template",
        Mi: "google_kw",
        Hj: "google_tag_for_child_directed_treatment",
        Ij: "google_tag_for_under_age_of_consent",
        rj: "google_region",
        Mh: "google_cust_criteria",
        Ig: "google_safe",
        Lh: "google_ctr_threshold",
        sj: "google_resizing_allowed",
        uj: "google_resizing_width",
        tj: "google_resizing_height",
        ck: "google_cust_age",
        LANGUAGE: "google_language",
        Ni: "google_kw_type",
        gj: "google_pucrd",
        ej: "google_page_url",
        Jj: "google_tag_partner",
        yj: "google_restrict_data_processing",
        pg: "google_adbreak_test",
        zg: "google_ad_frequency_hint",
        rg: "google_admob_interstitial_slot",
        sg: "google_admob_rewarded_slot",
        qg: "google_admob_ads_only",
        Si: "google_max_ad_content_rating",
        ij: "google_ad_public_floor",
        hj: "google_ad_private_floor",
        bk: "google_traffic_source",
        Cj: "google_shadow_mode"
    };
    var $f = Rd(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = Te(df);
        return !b.parentElement
    });

    function ag(a, b) {
        if ($f())
            for (; a.lastChild;) a.removeChild(a.lastChild);
        a.innerHTML = Te(b)
    }
    var bg = /^[\w+/_-]+[=]{0,2}$/;

    function cg(a, b) {
        b = (b || u).document;
        return b.querySelector ? (a = b.querySelector(a)) && (a = a.nonce || a.getAttribute("nonce")) && bg.test(a) ? a : "" : ""
    };

    function dg(a, b, c) {
        return Math.min(Math.max(a, b), c)
    }

    function eg(a) {
        return Array.prototype.reduce.call(arguments, function(b, c) {
            return b + c
        }, 0)
    }

    function fg(a) {
        return eg.apply(null, arguments) / arguments.length
    };

    function gg(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    }
    gg.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    gg.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    gg.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };

    function hg(a, b) {
        this.width = a;
        this.height = b
    }

    function ig(a, b) {
        return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
    }
    p = hg.prototype;
    p.aspectRatio = function() {
        return this.width / this.height
    };
    p.isEmpty = function() {
        return !(this.width * this.height)
    };
    p.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    p.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    p.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };

    function jg(a, b) {
        const c = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        let d;
        d = b ? b.createElement("div") : u.document.createElement("div");
        return a.replace(kg, function(e, f) {
            var g = c[e];
            if (g) return g;
            "#" == f.charAt(0) && (f = Number("0" + f.slice(1)), isNaN(f) || (g = String.fromCharCode(f)));
            g || (g = We(e + " "), ag(d, g), g = d.firstChild.nodeValue.slice(0, -1));
            return c[e] = g
        })
    }
    var kg = /&([^;\s<&]+);?/g;

    function lg(a) {
        let b = 0;
        for (let c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
        return b
    }

    function mg(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function ng(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };

    function og(a) {
        return a ? new pg(qg(a)) : Ma || (Ma = new pg)
    }

    function rg(a, b) {
        Zd(b, function(c, d) {
            c && "object" == typeof c && c.qa && (c = c.ja());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : sg.hasOwnProperty(d) ? a.setAttribute(sg[d], c) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, c) : a[d] = c
        })
    }
    var sg = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };

    function tg(a) {
        a = a.document;
        a = "CSS1Compat" == a.compatMode ? a.documentElement : a.body;
        return new hg(a.clientWidth, a.clientHeight)
    }

    function ug(a) {
        var b = a.scrollingElement ? a.scrollingElement : Kb || "CSS1Compat" != a.compatMode ? a.body || a.documentElement : a.documentElement;
        a = a.parentWindow || a.defaultView;
        return Fb && a.pageYOffset != b.scrollTop ? new gg(b.scrollLeft, b.scrollTop) : new gg(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
    }

    function vg(a) {
        return a ? a.parentWindow || a.defaultView : window
    }

    function wg(a, b, c, d) {
        function e(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (; d < c.length; d++) {
            var f = c[d];
            if (!sa(f) || ta(f) && 0 < f.nodeType) e(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (ta(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                lb(g ? ub(f) : f, e)
            }
        }
    }

    function xg(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function yg(a, b) {
        var c = xg(a, "DIV");
        Fb ? (b = bf(ff, b), ag(c, b), c.removeChild(c.firstChild)) : ag(c, b);
        if (1 == c.childNodes.length) c = c.removeChild(c.firstChild);
        else {
            for (a = a.createDocumentFragment(); c.firstChild;) a.appendChild(c.firstChild);
            c = a
        }
        return c
    }

    function zg(a) {
        var b, c = arguments.length;
        if (!c) return null;
        if (1 == c) return arguments[0];
        var d = [],
            e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (var h = 1; h < c; h++)
                if (g != d[h][b]) return f;
            f = g
        }
        return f
    }

    function qg(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    }
    var Ag = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        },
        Bg = {
            IMG: " ",
            BR: "\n"
        };

    function Cg(a) {
        var b = [];
        Dg(a, b, !0);
        a = b.join("");
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g, "");
        a = a.replace(/ +/g, " ");
        " " != a && (a = a.replace(/^\s*/, ""));
        return a
    }

    function Dg(a, b, c) {
        if (!(a.nodeName in Ag))
            if (3 == a.nodeType) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in Bg) b.push(Bg[a.nodeName]);
        else
            for (a = a.firstChild; a;) Dg(a, b, c), a = a.nextSibling
    }

    function Eg(a, b, c) {
        if (!b && !c) return null;
        var d = b ? String(b).toUpperCase() : null;
        return Fg(a, function(e) {
            return (!d || e.nodeName == d) && (!c || "string" === typeof e.className && rb(e.className.split(/\s+/), c))
        })
    }

    function Fg(a, b) {
        for (var c = 0; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function pg(a) {
        this.j = a || u.document || document
    }
    p = pg.prototype;
    p.tf = function(a) {
        return "string" === typeof a ? this.j.getElementById(a) : a
    };
    p.og = pg.prototype.tf;
    p.getElementsByTagName = function(a, b) {
        return (b || this.j).getElementsByTagName(String(a))
    };
    p.ga = function(a, b, c) {
        var d = this.j,
            e = arguments,
            f = e[1],
            g = xg(d, String(e[0]));
        f && ("string" === typeof f ? g.className = f : Array.isArray(f) ? g.className = f.join(" ") : rg(g, f));
        2 < e.length && wg(d, g, e, 2);
        return g
    };
    p.createElement = function(a) {
        return xg(this.j, a)
    };
    p.createTextNode = function(a) {
        return this.j.createTextNode(String(a))
    };

    function Gg(a, b) {
        return yg(a.j, b)
    }
    p.R = function() {
        var a = this.j;
        return a.parentWindow || a.defaultView
    };
    p.appendChild = function(a, b) {
        a.appendChild(b)
    };
    p.append = function(a, b) {
        wg(qg(a), a, arguments, 1)
    };
    p.canHaveChildren = function(a) {
        if (1 != a.nodeType) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    p.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    p.qf = zg;

    function Hg() {
        return !Ig() && (v("iPod") || v("iPhone") || v("Android") || v("IEMobile"))
    }

    function Ig() {
        return v("iPad") || v("Android") && !v("Mobile") || v("Silk")
    };
    var Jg = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Kg(a) {
        try {
            return !!a && null != a.location.href && Db(a, "foo")
        } catch {
            return !1
        }
    }

    function Lg(a, b = !1, c = !1, d = u) {
        c = c ? Mg(d) : d;
        for (d = 0; c && 40 > d++ && (!b && !Kg(c) || !a(c));) c = Mg(c)
    }

    function Mg(a) {
        try {
            const b = a.parent;
            if (b && b != a) return b
        } catch {}
        return null
    }

    function Ng(a) {
        return Kg(a.top) ? a.top : null
    }

    function Og(a, b) {
        const c = Pg("SCRIPT", a);
        rf(c, b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function Qg(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function Rg() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function Sg(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Tg(a) {
        const b = [];
        Sg(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Ug(a) {
        const b = a.length;
        if (0 == b) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    }
    var Wg = Rd(() => pb(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], Vg) || 1E-4 > Math.random());
    const Vg = a => Za(cb(), a);
    var Xg = /^([0-9.]+)px$/,
        Yg = /^(-?[0-9.]{1,30})$/;

    function Zg(a) {
        if (!Yg.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function $g(a) {
        return /^true$/.test(a)
    }

    function ah(a) {
        return (a = Xg.exec(a)) ? +a[1] : null
    }

    function bh() {
        var a = u.document.URL;
        if (!a) return "";
        const b = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
            const c = b.exec(decodeURIComponent(a));
            if (c) return c[1] && 1 < c[1].length ? c[1].substring(1) : "true"
        } catch {}
        return ""
    }
    var ch = {
        Pg: "allow-forms",
        Qg: "allow-modals",
        Rg: "allow-orientation-lock",
        Sg: "allow-pointer-lock",
        Tg: "allow-popups",
        Ug: "allow-popups-to-escape-sandbox",
        Vg: "allow-presentation",
        Wg: "allow-same-origin",
        Xg: "allow-scripts",
        Yg: "allow-top-navigation",
        Zg: "allow-top-navigation-by-user-activation"
    };
    const dh = Rd(() => Tg(ch));

    function eh() {
        var a = ["allow-top-navigation", "allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"];
        const b = dh();
        return a.length ? mb(b, c => !rb(a, c)) : b
    }

    function fh() {
        const a = Pg("IFRAME"),
            b = {};
        lb(dh(), c => {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    }
    var gh = (a, b) => {
            try {
                return !(!a.frames || !a.frames[b])
            } catch {
                return !1
            }
        },
        hh = (a, b) => {
            for (let c = 0; 50 > c; ++c) {
                if (gh(a, b)) return a;
                if (!(a = Mg(a))) break
            }
            return null
        },
        ih = Rd(() => Hg() ? 2 : Ig() ? 1 : 0),
        M = (a, b) => {
            Sg(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        };
    const jh = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        kh = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        lh = /.*domain\.test$/,
        mh = /\.prod\.google\.com(:\d+)?$/;
    var nh = a => jh[a] || kh.test(a) || lh.test(a) || mh.test(a);
    let oh = [];
    const ph = () => {
        const a = oh;
        oh = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var qh = (a, b) => {
        if ("number" !== typeof a.goog_pvsid) try {
            Object.defineProperty(a, "goog_pvsid", {
                value: Math.floor(Math.random() * 2 ** 52),
                configurable: !1
            })
        } catch (c) {
            b && b.ka(784, c)
        }
        a = Number(a.goog_pvsid);
        b && (!a || 0 >= a) && b.ka(784, Error(`Invalid correlator, ${a}`));
        return a || -1
    };

    function rh(a, b, c, d = []) {
        const e = new a.MutationObserver(f => {
            for (const g of f)
                for (const h of g.removedNodes)
                    if (d && (h === b || zg(h, b))) {
                        for (const k of d) k.disconnect();
                        d.length = 0;
                        c();
                        return
                    }
        });
        d.push(e);
        e.observe(a.document.documentElement, {
            childList: !0,
            subtree: !0
        });
        Lg(f => {
            if (!f.parent || !Kg(f.parent)) return !1;
            const g = f.parent.document.getElementsByTagName("iframe");
            for (let l = 0; l < g.length; l++) try {
                a: {
                    var h = g[l];
                    try {
                        var k = h.contentWindow || (h.contentDocument ? vg(h.contentDocument) : null);
                        break a
                    } catch (m) {}
                    k =
                    null
                }
                if (k == f) {
                    rh(f.parent, g[l], c, d);
                    break
                }
            }
            catch {}
            return !1
        }, !1, !1, a)
    }
    var sh = (a, b) => {
            rh(vg(qg(a)), a, b)
        },
        th = (a, b) => {
            "complete" === a.document.readyState ? (oh.push(b), 1 == oh.length && (window.Promise ? Promise.resolve().then(ph) : window.setImmediate ? setImmediate(ph) : setTimeout(ph, 0))) : a.addEventListener("load", b)
        },
        uh = (a, b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        });

    function Pg(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    }
    var vh = a => {
        let b = a;
        for (; a && a != a.parent;) a = a.parent, Kg(a) && (b = a);
        return b
    };

    function wh(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    p = wh.prototype;
    p.getWidth = function() {
        return this.right - this.left
    };
    p.getHeight = function() {
        return this.bottom - this.top
    };

    function xh(a) {
        return new wh(a.top, a.right, a.bottom, a.left)
    }
    p.contains = function(a) {
        return this && a ? a instanceof wh ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };

    function zh(a, b) {
        return a.left <= b.right && b.left <= a.right && a.top <= b.bottom && b.top <= a.bottom
    }
    p.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    p.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    p.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };

    function Ah(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    }

    function Bh(a, b) {
        var c = Math.max(a.left, b.left),
            d = Math.min(a.left + a.width, b.left + b.width);
        if (c <= d) {
            var e = Math.max(a.top, b.top);
            a = Math.min(a.top + a.height, b.top + b.height);
            if (e <= a) return new Ah(c, e, d - c, a - e)
        }
        return null
    }

    function Ch(a, b) {
        var c = Bh(a, b);
        if (!c || !c.height || !c.width) return [new Ah(a.left, a.top, a.width, a.height)];
        c = [];
        var d = a.top,
            e = a.height,
            f = a.left + a.width,
            g = a.top + a.height,
            h = b.left + b.width,
            k = b.top + b.height;
        b.top > a.top && (c.push(new Ah(a.left, a.top, a.width, b.top - a.top)), d = b.top, e -= b.top - a.top);
        k < g && (c.push(new Ah(a.left, k, a.width, g - k)), e = k - d);
        b.left > a.left && c.push(new Ah(a.left, d, b.left - a.left, e));
        h < f && c.push(new Ah(h, d, f - h, e));
        return c
    }
    Ah.prototype.contains = function(a) {
        return a instanceof gg ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    Ah.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    Ah.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    Ah.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    const Dh = {
        "AMP-CAROUSEL": "ac",
        "AMP-FX-FLYING-CARPET": "fc",
        "AMP-LIGHTBOX": "lb",
        "AMP-STICKY-AD": "sa"
    };

    function Eh(a = u) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function Fh(a = Eh()) {
        return a && a.mode ? +a.mode.version || null : null
    }

    function Gh(a = Eh()) {
        if (a && a.container) {
            a = a.container.split(",");
            const b = [];
            for (let c = 0; c < a.length; c++) b.push(Dh[a[c]] || "x");
            return b.join()
        }
        return null
    }

    function Hh() {
        var a = Eh();
        return a && a.initialIntersection
    }

    function Ih() {
        const a = Hh();
        return a && ta(a.rootBounds) ? new hg(a.rootBounds.width, a.rootBounds.height) : null
    }

    function Jh(a = Eh()) {
        return a ? Kg(a.master) ? a.master : null : null
    }

    function Kh(a, b) {
        const c = a.ampInaboxIframes = a.ampInaboxIframes || [];
        let d = () => {},
            e = () => {};
        b && (c.push(b), e = () => {
            a.AMP && a.AMP.inaboxUnregisterIframe && a.AMP.inaboxUnregisterIframe(b);
            sb(c, b);
            d()
        });
        if (a.ampInaboxInitialized) return e;
        a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
        const f = g => {
            if (a.ampInaboxInitialized) g = !0;
            else {
                var h, k = "amp-ini-load" === g.data;
                a.ampInaboxPendingMessages && !k && (h = /^amp-(\d{15,20})?/.exec(g.data)) && (a.ampInaboxPendingMessages.push(g), g = h[1], a.ampInaboxInitialized ||
                    g && !/^\d{15,20}$/.test(g) || a.document.querySelector('script[src$="amp4ads-host-v0.js"]') || Og(a.document, g ? te(Ld("https://cdn.ampproject.org/rtv/%{ampVersion}/amp4ads-host-v0.js"), {
                        ampVersion: g
                    }) : re(Kd(Ld("https://cdn.ampproject.org/amp4ads-host-v0.js")))));
                g = !1
            }
            g && d()
        };
        c.google_amp_listener_added || (c.google_amp_listener_added = !0, L(a, "message", f), d = () => {
            Yd(a, "message", f)
        });
        return e
    };

    function N(a, ...b) {
        if (0 === b.length) return re(a[0]);
        const c = [a[0]];
        for (let d = 0; d < b.length; d++) c.push(encodeURIComponent(b[d])), c.push(a[d + 1]);
        return re(c.join(""))
    }

    function Lh(a, b) {
        let c = qe(a).toString();
        if (/#/.test(c)) throw Error("");
        let d = /\?/.test(c) ? "&" : "?";
        b.forEach((e, f) => {
            e = e instanceof Array ? e : [e];
            for (let g = 0; g < e.length; g++) {
                const h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return re(c)
    };

    function Mh(a) {
        a = a[0];
        const b = ie();
        a = b ? b.createScript(a) : a;
        return new le(a, je)
    };

    function Nh(a) {
        return new Re(a[0], Pe)
    };

    function Oh(a, b, c) {
        if ("string" === typeof b)(b = Ph(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = Ph(c, d);
                f && (c.style[f] = e)
            }
    }
    var Qh = {};

    function Ph(a, b) {
        var c = Qh[b];
        if (!c) {
            var d = mg(b);
            c = d;
            void 0 === a.style[d] && (d = (Kb ? "Webkit" : Jb ? "Moz" : Fb ? "ms" : null) + ng(d), void 0 !== a.style[d] && (c = d));
            Qh[b] = c
        }
        return c
    }

    function Rh(a, b) {
        var c = qg(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    }

    function Sh(a, b) {
        return Rh(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function Th(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function Uh(a) {
        var b = qg(a),
            c = new gg(0, 0);
        var d = b ? qg(b) : document;
        d = !Fb || 9 <= Number(Tb) || "CSS1Compat" == og(d).j.compatMode ? d.documentElement : d.body;
        if (a == d) return c;
        a = Th(a);
        b = ug(og(b).j);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function Vh(a) {
        var b = Wh;
        if ("none" != Sh(a, "display")) return b(a);
        var c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function Wh(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = Kb && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = Th(a), new hg(a.right - a.left, a.bottom - a.top)) : new hg(b, c)
    }

    function Xh(a, b) {
        if (/^\d+px?$/.test(b)) return parseInt(b, 10);
        var c = a.style.left,
            d = a.runtimeStyle.left;
        a.runtimeStyle.left = a.currentStyle.left;
        a.style.left = b;
        b = a.style.pixelLeft;
        a.style.left = c;
        a.runtimeStyle.left = d;
        return +b
    }

    function Yh(a, b) {
        return (b = a.currentStyle ? a.currentStyle[b] : null) ? Xh(a, b) : 0
    }
    var Zh = {
        thin: 2,
        medium: 4,
        thick: 6
    };

    function $h(a, b) {
        if ("none" == (a.currentStyle ? a.currentStyle[b + "Style"] : null)) return 0;
        b = a.currentStyle ? a.currentStyle[b + "Width"] : null;
        return b in Zh ? Zh[b] : Xh(a, b)
    };
    var ai = a => "number" === typeof a && 0 < a,
        ci = (a, b) => {
            a = bi(a);
            if (!a) return b;
            const c = b.slice(-1);
            return b + ("?" === c || "#" === c ? "" : "&") + a
        },
        bi = a => Object.entries(di(a)).map(([b, c]) => `${b}=${encodeURIComponent(String(c))}`).join("&"),
        di = a => {
            const b = {};
            Sg(a, (c, d) => {
                if (c || 0 === c || !1 === c) "boolean" === typeof c && (c = c ? 1 : 0), b[d] = c
            });
            return b
        },
        ei = () => {
            try {
                return Yf.history.length
            } catch (a) {
                return 0
            }
        },
        fi = a => {
            a = Jh(Eh(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1
        },
        gi = a => {
            a = a.google_unique_id;
            return "number" === typeof a ? a :
                0
        },
        hi = a => {
            a.u_tz = -(new Date).getTimezoneOffset();
            a.u_his = ei();
            a.u_h = Yf.screen ? .height;
            a.u_w = Yf.screen ? .width;
            a.u_ah = Yf.screen ? .availHeight;
            a.u_aw = Yf.screen ? .availWidth;
            a.u_cd = Yf.screen ? .colorDepth
        },
        ii = a => {
            let b;
            b = 9 !== a.nodeType && a.id;
            a: {
                if (a && a.nodeName && a.parentElement) {
                    var c = a.nodeName.toString().toLowerCase();
                    const d = a.parentElement.childNodes;
                    let e = 0;
                    for (let f = 0; f < d.length; ++f) {
                        const g = d[f];
                        if (g.nodeName && g.nodeName.toString().toLowerCase() === c) {
                            if (a === g) {
                                c = "." + e;
                                break a
                            }++e
                        }
                    }
                }
                c = ""
            }
            return (a.nodeName &&
                a.nodeName.toString().toLowerCase()) + (b ? "/" + b : "") + c
        },
        ji = a => function() {
            if (a) {
                const b = a;
                a = null;
                b.apply(null, arguments)
            }
        },
        ki = () => {
            if (!Yf) return !1;
            try {
                return !(!Yf.navigator.standalone && !Yf.top.navigator.standalone)
            } catch (a) {
                return !1
            }
        },
        li = a => (a = a.google_ad_format) ? 0 < a.indexOf("_0ads") : !1,
        mi = a => {
            let b = Number(a.google_ad_width),
                c = Number(a.google_ad_height);
            if (!(0 < b && 0 < c)) {
                a: {
                    try {
                        const e = String(a.google_ad_format);
                        if (e && e.match) {
                            const f = e.match(/(\d+)x(\d+)/i);
                            if (f) {
                                const g = parseInt(f[1], 10),
                                    h = parseInt(f[2],
                                        10);
                                if (0 < g && 0 < h) {
                                    var d = {
                                        width: g,
                                        height: h
                                    };
                                    break a
                                }
                            }
                        }
                    } catch (e) {}
                    d = null
                }
                a = d;
                if (!a) return null;b = 0 < b ? b : a.width;c = 0 < c ? c : a.height
            }
            return {
                width: b,
                height: c
            }
        };
    class ni {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };
    const oi = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var pi = class {
            constructor(a, b) {
                this.j = a;
                this.l = b
            }
        },
        qi = class {
            constructor(a, b, c) {
                this.url = a;
                this.win = b;
                this.Xd = !!c;
                this.depth = null
            }
        };

    function ri(a, b, c = null, d = !1, e = !1) {
        si(a, b, c, d, e)
    }

    function si(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = Pg("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                d && sb(a.google_image_requests, f);
                Yd(f, "load", g);
                Yd(f, "error", g)
            };
            L(f, "load", g);
            L(f, "error", g)
        }
        e && (f.attributionsrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var ui = (a, b) => {
            let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
            Sg(a, (d, e) => {
                d && (c += `&${e}=${encodeURIComponent(d)}`)
            });
            ti(c)
        },
        ti = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : ri(b, a, void 0, !1, !1)
        };

    function vi(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function wi(a, b, c, d, e) {
        const f = [];
        Sg(a, function(g, h) {
            (g = xi(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function xi(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(xi(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(wi(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function yi(a) {
        let b = 1;
        for (const c in a.l) b = c.length > b ? c.length : b;
        return 3997 - b - a.m.length - 1
    }

    function zi(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = yi(a) - b.length;
        if (0 > d) return "";
        a.j.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.j.length; f++) {
            const g = a.j[f],
                h = a.l[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let l = wi(h[k], a.m, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.m;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class Ai {
        constructor() {
            this.m = "&";
            this.l = {};
            this.v = 0;
            this.j = []
        }
    };

    function Bi(a, b) {
        0 <= b && 1 >= b && (a.j = b)
    }

    function Ci(a, b, c, d = !1, e) {
        if ((d ? a.j : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Ai ? f = c : (f = new Ai, Sg(c, (h, k) => {
                var l = f;
                const m = l.v++;
                h = vi(k, h);
                l.j.push(m);
                l.l[m] = h
            }));
            const g = zi(f, "/pagead/gen_204?id=" + b + "&");
            g && ri(u, g)
        } catch (f) {}
    }
    class Di {
        constructor() {
            this.j = Math.random()
        }
    };
    let Ei = null;

    function Fi() {
        if (null === Ei) {
            Ei = "";
            try {
                let a = "";
                try {
                    a = u.top.location.hash
                } catch (b) {
                    a = u.location.hash
                }
                if (a) {
                    const b = a.match(/\bdeid=([\d,]+)/);
                    Ei = b ? b[1] : ""
                }
            } catch (a) {}
        }
        return Ei
    };

    function Gi() {
        const a = u.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Da()
    }

    function Hi() {
        const a = u.performance;
        return a && a.now ? a.now() : null
    };
    class Ii {
        constructor(a, b) {
            var c = Hi() || Gi();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.uniqueId = Math.random();
            this.taskId = this.slotId = void 0
        }
    };
    const Ji = u.performance,
        Ki = !!(Ji && Ji.mark && Ji.measure && Ji.clearMarks),
        Li = Rd(() => {
            var a;
            if (a = Ki) a = Fi(), a = !!a.indexOf && 0 <= a.indexOf("1337");
            return a
        });

    function Mi(a) {
        a && Ji && Li() && (Ji.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Ji.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Ni(a) {
        a.j = !1;
        a.l != a.m.google_js_reporting_queue && (Li() && lb(a.l, Mi), a.l.length = 0)
    }

    function Oi(a, b) {
        if (!a.j) return b();
        const c = a.start("491", 3);
        let d;
        try {
            d = b()
        } catch (e) {
            throw Mi(c), e;
        }
        a.end(c);
        return d
    }
    class Pi {
        constructor(a) {
            this.l = [];
            this.m = a || u;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.l = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.j = Li() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.j) return null;
            a = new Ii(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Ji && Li() && Ji.mark(b);
            return a
        }
        end(a) {
            if (this.j && "number" === typeof a.value) {
                a.duration = (Hi() || Gi()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Ji && Li() && Ji.mark(b);
                !this.j || 2048 < this.l.length ||
                    this.l.push(a)
            }
        }
    };

    function Qi(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        a.stack && (b = Ri(a.stack, b));
        return b
    }

    function Ri(a, b) {
        try {
            -1 == a.indexOf(b) && (a = b + "\n" + a);
            let c;
            for (; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (c) {
            return b
        }
    }
    class Si {
        constructor(a, b = null) {
            this.v = a;
            this.j = null;
            this.B = this.ka;
            this.l = b;
            this.m = !1
        }
        sa() {
            return this.v
        }
        ed(a) {
            this.j = a
        }
        A(a) {
            this.m = a
        }
        Db(a, b, c) {
            let d, e;
            try {
                this.l && this.l.j ? (e = this.l.start(a.toString(), 3), d = b(), this.l.end(e)) : d = b()
            } catch (f) {
                b = !0;
                try {
                    Mi(e), b = this.B(a, new ni(f, {
                        message: Qi(f)
                    }), void 0, c)
                } catch (g) {
                    this.ka(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        ta(a, b, c, d) {
            return (...e) => this.Db(a, () => b.apply(c, e), d)
        }
        ka(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const H = new Ai;
                var g = H;
                g.j.push(1);
                g.l[1] = vi("context", a);
                b.error && b.meta && b.id || (b = new ni(b, {
                    message: Qi(b)
                }));
                if (b.msg) {
                    g = H;
                    var h = b.msg.substring(0, 512);
                    g.j.push(2);
                    g.l[2] = vi("msg", h)
                }
                var k = b.meta || {};
                b = k;
                if (this.j) try {
                    this.j(b)
                } catch (Z) {}
                if (d) try {
                    d(b)
                } catch (Z) {}
                d = H;
                k = [k];
                d.j.push(3);
                d.l[3] = k;
                d = u;
                k = [];
                b = null;
                do {
                    var l = d;
                    if (Kg(l)) {
                        var m = l.location.href;
                        b = l.document && l.document.referrer || null
                    } else m = b, b = null;
                    k.push(new qi(m || "", l));
                    try {
                        d = l.parent
                    } catch (Z) {
                        d = null
                    }
                } while (d && l != d);
                for (let Z = 0, va = k.length - 1; Z <= va; ++Z) k[Z].depth = va - Z;
                l = u;
                if (l.location && l.location.ancestorOrigins && l.location.ancestorOrigins.length == k.length - 1)
                    for (m = 1; m < k.length; ++m) {
                        var n = k[m];
                        n.url || (n.url = l.location.ancestorOrigins[m - 1] || "", n.Xd = !0)
                    }
                var q = k;
                let W = new qi(u.location.href, u, !1);
                l = null;
                const Va = q.length - 1;
                for (n = Va; 0 <= n; --n) {
                    var r = q[n];
                    !l && oi.test(r.url) && (l = r);
                    if (r.url && !r.Xd) {
                        W = r;
                        break
                    }
                }
                r = null;
                const ea = q.length && q[Va].url;
                0 != W.depth && ea && (r = q[Va]);
                f = new pi(W, r);
                if (f.l) {
                    q = H;
                    var t = f.l.url || "";
                    q.j.push(4);
                    q.l[4] = vi("top", t)
                }
                var B = {
                    url: f.j.url || ""
                };
                if (f.j.url) {
                    var z =
                        f.j.url.match(Jg),
                        A = z[1],
                        J = z[3],
                        E = z[4];
                    t = "";
                    A && (t += A + ":");
                    J && (t += "//", t += J, E && (t += ":" + E));
                    var F = t
                } else F = "";
                A = H;
                B = [B, {
                    url: F
                }];
                A.j.push(5);
                A.l[5] = B;
                Ci(this.v, e, H, this.m, c)
            } catch (H) {
                try {
                    Ci(this.v, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Qi(H),
                        url: f && f.j.url
                    }, this.m, c)
                } catch (W) {}
            }
            return !0
        }
        Aa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.ka(a, d instanceof Error ? d : Error(d), void 0, c || this.j || void 0)
            })
        }
    };
    var Ti = a => "string" === typeof a,
        Ui = a => void 0 === a;

    function Vi() {
        var a = Wi;
        return b => {
            for (const c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }
    };
    var Xi = class extends K {
        constructor() {
            super()
        }
    };

    function Yi(a) {
        var b = new Zi;
        return x(b, 1, a)
    }
    var Zi = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var $i = class extends K {
        constructor() {
            super()
        }
    };

    function aj(a, b) {
        return id(a, 1, b)
    }

    function bj(a, b) {
        return id(a, 2, b)
    }

    function cj(a, b) {
        return id(a, 3, b)
    }

    function dj(a, b) {
        return id(a, 4, b)
    }

    function ej(a, b) {
        return id(a, 5, b)
    }

    function fj(a, b) {
        return Wc(a, 8, Gc(b), 0)
    }

    function gj(a, b) {
        return Wc(a, 9, Gc(b), 0)
    }
    var hj = class extends K {
        constructor() {
            super()
        }
    };
    var ij = class extends K {
        constructor() {
            super()
        }
    };

    function jj(a, b) {
        return Vc(a, 1, b, Kc)
    }

    function kj(a, b) {
        return Vc(a, 12, b, Jc)
    }

    function lj() {
        var a = new mj;
        Ec(a);
        Qc(a, 2, 2, !1, !1).push("irr");
        return a
    }

    function nj(a, b) {
        return nd(a, 3, b)
    }

    function oj(a, b) {
        return nd(a, 4, b)
    }

    function pj(a, b) {
        return nd(a, 5, b)
    }

    function qj(a, b) {
        return nd(a, 7, b)
    }

    function rj(a, b) {
        return nd(a, 8, b)
    }

    function sj(a, b) {
        return id(a, 9, b)
    }

    function tj(a, b) {
        return cd(a, 10, b)
    }

    function uj(a, b) {
        return Vc(a, 11, b, Hc)
    }
    var mj = class extends K {
            constructor() {
                super(void 0, -1, vj)
            }
        },
        vj = [1, 12, 2, 10, 11];

    function wj(a) {
        var b = xj();
        ad(a, 1, b)
    }

    function yj(a, b) {
        return id(a, 2, b)
    }

    function zj(a, b) {
        return cd(a, 3, b)
    }

    function Aj(a, b) {
        return cd(a, 4, b)
    }

    function Bj(a, b) {
        return dd(a, 4, Zi, b)
    }

    function Cj(a, b) {
        return cd(a, 5, b)
    }

    function Dj(a, b) {
        return Vc(a, 6, b, Kc)
    }

    function Ej(a, b) {
        return id(a, 7, b)
    }

    function Fj(a, b) {
        ad(a, 9, b)
    }

    function Gj(a, b) {
        return nd(a, 10, b)
    }

    function Hj(a, b) {
        return nd(a, 11, b)
    }

    function Ij(a, b) {
        return nd(a, 12, b)
    }
    var Kj = class extends K {
            constructor() {
                super(void 0, -1, Jj)
            }
            D(a) {
                return id(this, 8, a)
            }
        },
        Jj = [3, 4, 5, 6];
    var Mj = class extends K {
            constructor() {
                super(void 0, -1, Lj)
            }
        },
        Lj = [2];
    var Nj = class extends K {
        constructor() {
            super()
        }
    };
    var Oj = class extends K {
        constructor() {
            super()
        }
    };
    var Pj = class extends K {
        constructor() {
            super()
        }
        getContentUrl() {
            return G(this, 1)
        }
    };
    var Rj = class extends K {
            constructor() {
                super(void 0, -1, Qj)
            }
        },
        Qj = [1];
    var Sj = class extends K {
        constructor() {
            super()
        }
    };
    var Tj = class extends K {
        constructor() {
            super()
        }
    };
    var Uj = class extends K {
            constructor(a) {
                super(a)
            }
        },
        Vj = [1, 2, 3, 5, 6, 7, 8];
    var Xj = class extends K {
            constructor() {
                super(void 0, -1, Wj)
            }
        },
        Wj = [1];
    var Zj = class extends K {
            constructor() {
                super(void 0, -1, Yj)
            }
        },
        Yj = [2];
    var ak = class extends K {
        constructor() {
            super()
        }
    };
    var bk = class extends K {
        constructor() {
            super()
        }
    };

    function ck(a) {
        var b = new dk;
        return od(b, 1, a)
    }
    var dk = class extends K {
            constructor() {
                super(void 0, -1, ek)
            }
        },
        ek = [9];
    var gk = class extends K {
            constructor() {
                super(void 0, -1, fk)
            }
        },
        fk = [2];

    function hk(a, b) {
        return x(a, 1, b)
    }

    function ik(a, b) {
        return x(a, 2, b)
    }
    var jk = class extends K {
        constructor() {
            super()
        }
    };
    var kk = class extends K {
            constructor() {
                super()
            }
        },
        lk = [4, 5];
    var mk = class extends K {
        constructor() {
            super()
        }
    };
    var nk = class extends K {
        constructor() {
            super()
        }
    };
    var ok = class extends K {
        constructor() {
            super()
        }
    };
    var pk = class extends K {
        constructor() {
            super()
        }
    };
    var qk = class extends K {
        constructor() {
            super()
        }
    };
    var rk = class extends K {
        constructor() {
            super()
        }
    };
    var sk = class extends K {
            constructor() {
                super()
            }
        },
        tk = [2, 3];
    var uk = class extends K {
            constructor() {
                super()
            }
        },
        vk = [3, 4, 5, 6, 7, 8, 9];
    var wk = class extends K {
            constructor() {
                super()
            }
            Na(a) {
                return jd(this, 2, a)
            }
        },
        xk = [4, 5, 6, 8, 9, 10];

    function yk(a, ...b) {
        zk(a, ...b.map(c => ({
            kg: 7,
            message: c
        })))
    };

    function Ak(a) {
        return JSON.stringify([a.map(b => [{
            [b.kg]: b.message.toJSON()
        }])])
    };
    var Bk = (a, b) => {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function Ck(a) {
        a && "function" == typeof a.xa && a.xa()
    };

    function Dk() {
        this.B = this.B;
        this.D = this.D
    }
    Dk.prototype.B = !1;
    Dk.prototype.xa = function() {
        this.B || (this.B = !0, this.j())
    };

    function Ek(a, b) {
        a.B ? b() : (a.D || (a.D = []), a.D.push(b))
    }
    Dk.prototype.j = function() {
        if (this.D)
            for (; this.D.length;) this.D.shift()()
    };

    function zk(a, ...b) {
        65536 <= Ak(a.j.concat(b)).length && Fk(a);
        a.j.push(...b);
        100 <= a.j.length && Fk(a);
        a.j.length && null === a.l && (a.l = setTimeout(() => {
            Fk(a)
        }, 100))
    }

    function Fk(a) {
        null !== a.l && (clearTimeout(a.l), a.l = null);
        if (a.j.length) {
            var b = Ak(a.j);
            a.m("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.j = []
        }
    }
    var Gk = class {
            constructor() {
                this.m = Bk;
                this.j = [];
                this.l = null
            }
        },
        Hk = class extends Gk {};
    var Ik = a => {
        var b = "Nc";
        if (a.Nc && a.hasOwnProperty(b)) return a.Nc;
        b = new a;
        return a.Nc = b
    };

    function Jk(a, b, c) {
        return b[a] || c
    };

    function Kk(a, b) {
        a.l = c => Jk(2, b, () => [])(c, 1);
        a.j = () => Jk(3, b, () => [])(1)
    }
    class Lk {
        l() {
            return []
        }
        j() {
            return []
        }
    };
    let Mk, Nk;
    const Ok = new Pi(u);
    (a => {
        Mk = a || new Di;
        "number" !== typeof u.google_srt && (u.google_srt = Math.random());
        Bi(Mk, u.google_srt);
        Nk = new Si(Mk, Ok);
        Nk.A(!0);
        "complete" == u.document.readyState ? u.google_measure_js_timing || Ni(Ok) : Ok.j && L(u, "load", () => {
            u.google_measure_js_timing || Ni(Ok)
        })
    })();
    var Pk = (a, b, c) => Nk.Db(a, b, c),
        Qk = (a, b) => Nk.ta(a, b),
        Rk = (a, b, c) => {
            const d = Ik(Lk).j();
            !b.eid && d.length && (b.eid = d.toString());
            Ci(Mk, a, b, !0, c)
        },
        Sk = (a, b) => Nk.ka(a, b, void 0, void 0);
    var Tk = (a, b) => {
        const c = bh();
        return a + (-1 == a.indexOf("?") ? "?" : "&") + [0 < c.length ? "google_debug" + (c ? "=" + c : "") + "&" : "", "xpc=", b, "&p=", encodeURIComponent(u.document.location.protocol), "//", encodeURIComponent(u.document.location.host)].join("")
    };
    re(Kd(Ld("https://pagead2.googlesyndication.com/pagead/expansion_embed.js")));
    var Uk = (a, b, c, d = null) => {
            const e = g => {
                let h;
                try {
                    h = JSON.parse(g.data)
                } catch (k) {
                    return
                }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
            };
            L(a, "message", e);
            let f = !1;
            return () => {
                let g = !1;
                f || (f = !0, g = Yd(a, "message", e));
                return g
            }
        },
        Vk = (a, b, c, d = null) => {
            const e = Uk(a, b, Pd(c, () => e()), d);
            return e
        },
        Wk = (a, b, c, d, e) => {
            if (!(0 >= e) && (c.googMsgType = b, a.postMessage(JSON.stringify(c), d), a = a.frames))
                for (let f = 0; f < a.length; ++f) 1 < e && Wk(a[f], b, c, d, --e)
        };

    function Xk(a, b, c, d) {
        nh(d.origin) && "expandable-xpc-ready" == c.notify && Yk(a, b)
    }

    function Yk(a, b) {
        var c = a.Mc;
        c.google_eas_queue = c.google_eas_queue || [];
        c.google_eas_queue.push({
            a: a.id,
            b: a.url,
            c: a.width,
            d: a.height,
            e: a.Sa,
            f: a.Rf,
            g: a.Oe,
            h: a.Bf,
            i: void 0
        });
        u.setTimeout(Qk(220, ji(() => {
            Og(c.document, b)
        })), 0)
    };
    var $k = class extends K {
            constructor() {
                super(void 0, -1, Zk)
            }
        },
        Zk = [15];
    var al = class extends K {
        constructor() {
            super()
        }
        getCorrelator() {
            return fd(this, 1)
        }
        setCorrelator(a) {
            return id(this, 1, a)
        }
    };
    var bl = class extends K {
        constructor() {
            super()
        }
    };
    let cl = null,
        kl = null;
    var ll = () => {
            if (null != cl) return cl;
            cl = !1;
            try {
                const a = Ng(u);
                a && -1 !== a.location.hash.indexOf("google_logging") && (cl = !0);
                u.localStorage.getItem("google_logging") && (cl = !0)
            } catch (a) {}
            return cl
        },
        ml = () => {
            if (null != kl) return kl;
            kl = !1;
            try {
                const a = Ng(u);
                if (a && -1 !== a.location.hash.indexOf("auto_ads_logging") || u.localStorage.getItem("auto_ads_logging")) kl = !0
            } catch (a) {}
            return kl
        },
        nl = (a, b = []) => {
            let c = !1;
            u.google_logging_queue || (c = !0, u.google_logging_queue = []);
            u.google_logging_queue.push([a, b]);
            c && ll() && Og(u.document,
                re(Kd(Ld("https://pagead2.googlesyndication.com/pagead/js/logging_library.js"))))
        };
    let ol, pl;
    const ql = new Pi(window);
    (a => {
        ol = a ? ? new Di;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        Bi(ol, window.google_srt);
        pl = new Si(ol, ql);
        pl.ed(() => {});
        pl.A(!0);
        "complete" == window.document.readyState ? window.google_measure_js_timing || Ni(ql) : ql.j && L(window, "load", () => {
            window.google_measure_js_timing || Ni(ql)
        })
    })();
    let rl = (new Date).getTime();
    var sl = a => {
        a = parseFloat(a);
        return isNaN(a) || 1 < a || 0 > a ? .05 : a
    };
    var tl = {
        Di: 0,
        Ci: 1,
        zi: 2,
        ui: 3,
        Ai: 4,
        vi: 5,
        Bi: 6,
        xi: 7,
        yi: 8,
        ti: 9,
        wi: 10
    };
    var ul = {
        Fi: 0,
        Gi: 1,
        Ei: 2
    };

    function vl(a, b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
    }

    function wl(a) {
        a = nb(a, b => new wh(b.top, b.right, b.bottom, b.left));
        a = xl(a);
        return {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left
        }
    }

    function xl(a) {
        if (!a.length) throw Error("pso:box:m:nb");
        return ob(a.slice(1), (b, c) => {
            b.left = Math.min(b.left, c.left);
            b.top = Math.min(b.top, c.top);
            b.right = Math.max(b.right, c.right);
            b.bottom = Math.max(b.bottom, c.bottom);
            return b
        }, xh(a[0]))
    };
    var be = {
        qj: 0,
        gi: 1,
        ji: 2,
        hi: 3,
        ii: 4,
        ri: 8,
        Bj: 9,
        Qi: 10,
        Ri: 11,
        xj: 16,
        Th: 17,
        Sh: 24,
        Oi: 25,
        lh: 26,
        kh: 27,
        Fe: 30,
        Ji: 32,
        Li: 40,
        Gj: 41,
        Dj: 42
    };
    var yl = {
            overlays: 1,
            interstitials: 2,
            vignettes: 2,
            inserts: 3,
            immersives: 4,
            list_view: 5,
            full_page: 6,
            side_rails: 7
        },
        zl = {
            [1]: 1,
            [2]: 1,
            [3]: 7,
            [4]: 7,
            [8]: 2,
            [27]: 3,
            [9]: 4,
            [30]: 5
        };

    function Al(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map)) : a.google_reactive_ads_global_state = new Bl;
        return a.google_reactive_ads_global_state
    }
    class Bl {
        constructor() {
            this.wasPlaTagProcessed = !1;
            this.wasReactiveAdConfigReceived = {};
            this.adCount = {};
            this.wasReactiveAdVisible = {};
            this.stateForType = {};
            this.reactiveTypeEnabledInAsfe = {};
            this.wasReactiveTagRequestSent = !1;
            this.reactiveTypeDisabledByPublisher = {};
            this.tagSpecificState = {};
            this.messageValidationEnabled = !1;
            this.floatingAdsStacking = new Cl;
            this.sideRailProcessedFixedElements = new Set;
            this.sideRailAvailableSpace = new Map
        }
    }
    var Cl = class {
        constructor() {
            this.maxZIndexRestrictions = {};
            this.nextRestrictionId = 0;
            this.maxZIndexListeners = []
        }
    };
    var Dl = 728 * 1.38,
        El = (a, b = 420) => (a = O(a).clientWidth) ? a > b ? 32768 : 320 > a ? 65536 : 0 : 16384,
        Fl = a => {
            var b = O(a).clientWidth;
            a = a.innerWidth;
            return (b = b && a ? b / a : 0) ? 1.05 < b ? 262144 : .95 > b ? 524288 : 0 : 131072
        },
        Hl = a => Math.max(0, Gl(a, !0) - O(a).clientHeight),
        O = a => {
            a = a.document;
            let b = {};
            a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
            return b || {}
        },
        Gl = (a, b) => {
            const c = O(a);
            return b ? c.scrollHeight == O(a).clientHeight ? c.offsetHeight : c.scrollHeight : c.offsetHeight
        },
        Jl = (a, b) => Il(b) || 10 === b || !a.adCount ? !1 : 1 == b || 2 == b ? !(!a.adCount[1] &&
            !a.adCount[2]) : (a = a.adCount[b]) ? 1 <= a : !1,
        Kl = (a, b) => a && a.source ? a.source === b || a.source.parent === b : !1,
        Ll = a => void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset,
        Ml = a => void 0 === a.pageXOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollLeft : a.pageXOffset,
        Nl = a => {
            const b = {};
            let c;
            Array.isArray(a) ? c = a : a && a.key_value && (c = a.key_value);
            if (c)
                for (a = 0; a < c.length; a++) {
                    const d = c[a];
                    if ("key" in d && "value" in d) {
                        const e =
                            d.value;
                        b[d.key] = null == e ? null : String(e)
                    }
                }
            return b
        },
        Ol = (a, b, c, d) => {
            Ci(c, b, {
                c: d.data.substring(0, 500),
                u: a.location.href.substring(0, 500)
            }, !0, .1);
            return !0
        },
        Il = a => 26 === a || 27 === a || 40 === a || 41 === a;

    function Pl(a, b) {
        Ql(a).forEach(b, void 0)
    }

    function Ql(a) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b
    };

    function Rl(a, b) {
        return void 0 !== a.j[Sl(b)]
    }

    function Tl(a) {
        const b = [];
        for (const c in a.j) void 0 !== a.j[c] && a.j.hasOwnProperty(c) && b.push(a.l[c]);
        return b
    }

    function Ul(a) {
        const b = [];
        for (const c in a.j) void 0 !== a.j[c] && a.j.hasOwnProperty(c) && b.push(a.j[c]);
        return b
    }
    const Vl = class {
        constructor() {
            this.j = {};
            this.l = {}
        }
        set(a, b) {
            const c = Sl(a);
            this.j[c] = b;
            this.l[c] = a
        }
        remove(a) {
            a = Sl(a);
            this.j[a] = void 0;
            this.l[a] = void 0
        }
        get(a, b) {
            a = Sl(a);
            return void 0 !== this.j[a] ? this.j[a] : b
        }
        xb() {
            return Tl(this).length
        }
        clear() {
            this.j = {};
            this.l = {}
        }
    };

    function Sl(a) {
        return a instanceof Object ? String(ua(a)) : a + ""
    };
    const Wl = class {
        constructor(a) {
            this.j = new Vl;
            if (a)
                for (var b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.j.set(a, !0)
        }
        remove(a) {
            this.j.remove(a)
        }
        contains(a) {
            return Rl(this.j, a)
        }
    };
    const Xl = new Wl("IMG AMP-IMG IFRAME AMP-IFRAME HR EMBED OBJECT VIDEO AMP-VIDEO INPUT BUTTON SVG".split(" "));

    function Yl(a) {
        a.l.forEach((b, c) => {
            if (b.overrides.delete(a)) {
                b = Array.from(b.overrides.values()).pop() || b.originalValue;
                var d = a.element;
                b ? d.style.setProperty(c, b.value, b.priority) : d.style.removeProperty(c)
            }
        })
    }

    function Zl(a, b, c) {
        c = {
            value: c,
            priority: "important"
        };
        var d = a.l.get(b);
        if (!d) {
            d = a.element;
            var e = d.style.getPropertyValue(b);
            d = {
                originalValue: e ? {
                    value: e,
                    priority: d.style.getPropertyPriority(b)
                } : null,
                overrides: new Map
            };
            a.l.set(b, d)
        }
        d.overrides.delete(a);
        d.overrides.set(a, c);
        a = a.element;
        c ? a.style.setProperty(b, c.value, c.priority) : a.style.removeProperty(b)
    }
    var $l = class extends Dk {
        constructor(a, b) {
            super();
            this.element = b;
            a = a.googTempStyleOverrideInfo = a.googTempStyleOverrideInfo || new Map;
            var c = a.get(b);
            c ? b = c : (c = new Map, a.set(b, c), b = c);
            this.l = b
        }
        j() {
            Yl(this);
            super.j()
        }
    };

    function am(a, b) {
        const c = new bm({
            first: a.M,
            second: b.M
        });
        a.Z(() => P(c, {
            first: a.M,
            second: b.M
        }));
        b.Z(() => P(c, {
            first: a.M,
            second: b.M
        }));
        return c
    }

    function cm(...a) {
        const b = [...a],
            c = () => b.every(f => f.M),
            d = new bm(c()),
            e = () => {
                P(d, c())
            };
        b.forEach(f => f.Z(e));
        return dm(d)
    }

    function em(...a) {
        const b = [...a],
            c = () => -1 !== b.findIndex(f => f.M),
            d = new bm(c()),
            e = () => {
                P(d, c())
            };
        b.forEach(f => f.Z(e));
        return dm(d)
    }

    function P(a, b) {
        a.M = b;
        a.j.forEach(c => {
            c(a.M)
        })
    }

    function dm(a, b = fm) {
        var c = a.M;
        const d = new bm(a.M);
        a.Z(e => {
            b(e, c) || (c = e, P(d, e))
        });
        return d
    }

    function gm(a, b) {
        return a.Z(b, !0)
    }

    function hm(a, b, c) {
        return gm(a, d => {
            d === b && c()
        })
    }

    function im(a, b) {
        if (!1 === a.M) b();
        else {
            var c = {
                Pb: null
            };
            c.Pb = hm(a, !1, () => {
                c.Pb && (c.Pb(), c.Pb = null);
                b()
            })
        }
    }

    function jm(a, b, c) {
        dm(a).Z(d => {
            d === b && c()
        })
    }

    function km(a, b) {
        a.l && a.l();
        a.l = b.Z(c => P(a, c), !0)
    }
    class bm {
        constructor(a) {
            this.M = a;
            this.j = new Map;
            this.m = 1;
            this.l = null
        }
        Z(a, b = !1) {
            const c = this.m++;
            this.j.set(c, a);
            b && a(this.M);
            return () => {
                this.j.delete(c)
            }
        }
        map(a) {
            const b = new bm(a(this.M));
            this.Z(c => P(b, a(c)));
            return b
        }
    }

    function fm(a, b) {
        return a == b
    };

    function lm(a, b) {
        lb(a.j, c => {
            c(b)
        })
    }
    var mm = class {
        constructor() {
            this.j = []
        }
    };
    class nm {
        constructor(a) {
            this.j = a
        }
        Z(a) {
            this.j.j.push(a)
        }
        map(a) {
            const b = new mm;
            this.Z(c => lm(b, a(c)));
            return new nm(b)
        }
    }

    function om(...a) {
        const b = new mm;
        a.forEach(c => {
            c.Z(d => {
                lm(b, d)
            })
        });
        return new nm(b)
    };

    function pm(a) {
        return dm(am(a.j, a.m).map(b => {
            var c = b.first;
            b = b.second;
            return null == c || null == b ? null : qm(c, b)
        }))
    }
    var sm = class {
        constructor(a) {
            this.l = a;
            this.j = new bm(null);
            this.m = new bm(null);
            this.v = new mm;
            this.C = b => {
                null == this.j.M && 1 == b.touches.length && P(this.j, b.touches[0])
            };
            this.A = b => {
                const c = this.j.M;
                null != c && (b = rm(c, b.changedTouches), null != b && (P(this.j, null), P(this.m, null), lm(this.v, qm(c, b))))
            };
            this.B = b => {
                var c = this.j.M;
                null != c && (c = rm(c, b.changedTouches), null != c && (P(this.m, c), b.preventDefault()))
            }
        }
    };

    function qm(a, b) {
        return {
            De: b.pageX - a.pageX,
            Ee: b.pageY - a.pageY
        }
    }

    function rm(a, b) {
        if (null == b) return null;
        for (let c = 0; c < b.length; ++c)
            if (b[c].identifier == a.identifier) return b[c];
        return null
    };

    function tm(a) {
        return dm(am(a.j, a.l).map(b => {
            var c = b.first;
            b = b.second;
            return null == c || null == b ? null : um(c, b)
        }))
    }
    var vm = class {
        constructor(a, b) {
            this.v = a;
            this.A = b;
            this.j = new bm(null);
            this.l = new bm(null);
            this.m = new mm;
            this.D = c => {
                P(this.j, c)
            };
            this.B = c => {
                const d = this.j.M;
                null != d && (P(this.j, null), P(this.l, null), lm(this.m, um(d, c)))
            };
            this.C = c => {
                null != this.j.M && (P(this.l, c), c.preventDefault())
            }
        }
    };

    function um(a, b) {
        return {
            De: b.screenX - a.screenX,
            Ee: b.screenY - a.screenY
        }
    };
    var ym = (a, b) => {
        const c = new wm(a, b);
        return () => xm(c)
    };

    function xm(a) {
        if (a.j) return !1;
        if (null == a.l) return zm(a), !0;
        const b = a.l + 1E3 - (new Date).getTime();
        if (1 > b) return zm(a), !0;
        Am(a, b);
        return !0
    }

    function zm(a) {
        a.l = (new Date).getTime();
        a.v()
    }

    function Am(a, b) {
        a.j = !0;
        a.m.setTimeout(() => {
            a.j = !1;
            zm(a)
        }, b)
    }
    class wm {
        constructor(a, b) {
            this.m = a;
            this.v = b;
            this.l = null;
            this.j = !1
        }
    };

    function Bm(a) {
        return Cm(tm(a.j), pm(a.l))
    }

    function Dm(a) {
        return om(new nm(a.j.m), new nm(a.l.v))
    }
    var Em = class {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
    };

    function Cm(a, b) {
        return am(a, b).map(({
            first: c,
            second: d
        }) => c || d || null)
    };

    function Fm(a, b) {
        return new Gm(a, b)
    }

    function Hm(a) {
        a.win.requestAnimationFrame(() => {
            a.B || P(a.m, new hg(a.element.offsetWidth, a.element.offsetHeight))
        })
    }

    function Im(a) {
        a.l || (a.l = !0, a.v.observe(a.element));
        return dm(a.m, ig)
    }
    var Gm = class extends Dk {
        constructor(a, b) {
            super();
            this.win = a;
            this.element = b;
            this.l = !1;
            this.m = new bm(new hg(this.element.offsetWidth, this.element.offsetHeight));
            this.v = new ResizeObserver(() => {
                Hm(this)
            })
        }
        j() {
            this.v.disconnect();
            super.j()
        }
    };

    function Jm(a, b) {
        return {
            top: a.j - b,
            right: a.m + a.l,
            bottom: a.j + b,
            left: a.m
        }
    }
    class Km {
        constructor(a, b, c) {
            this.m = a;
            this.j = b;
            this.l = c
        }
    };

    function Lm(a, b) {
        a = a.getBoundingClientRect();
        return new Mm(a.top + Ll(b), a.bottom - a.top)
    }

    function Nm(a) {
        return new Mm(Math.round(a.j), Math.round(a.l))
    }
    class Mm {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
        getHeight() {
            return this.l
        }
    };

    function Om(a, b) {
        a.B = !0;
        a.m = b;
        a.l.forEach(c => {
            c(a.m)
        });
        a.l = []
    }
    class Pm {
        constructor(a) {
            this.j = a;
            this.l = [];
            this.B = !1;
            this.A = this.m = null;
            this.C = ym(a, () => {
                if (null != this.A) {
                    var b = Gl(this.j, !0) - this.A;
                    1E3 < b && Om(this, b)
                }
            });
            this.v = null
        }
        init(a, b) {
            null == a ? (this.A = a = Gl(this.j, !0), this.j.addEventListener("scroll", this.C), null != b && b(a)) : this.v = this.j.setTimeout(() => {
                this.init(void 0, b)
            }, a)
        }
        xa() {
            null != this.v && this.j.clearTimeout(this.v);
            this.j.removeEventListener("scroll", this.C);
            this.l = [];
            this.m = null
        }
        addListener(a) {
            this.B ? a(this.m) : this.l.push(a)
        }
    };

    function Qm(a) {
        return new Rm(a, new $l(a, a.document.body), new $l(a, a.document.documentElement), new $l(a, a.document.documentElement))
    }

    function Sm(a) {
        Zl(a.m, "scroll-behavior", "auto");
        const b = Tm(a.win);
        b.activePageScrollPreventers.add(a);
        null === b.previousWindowScroll && (b.previousWindowScroll = a.win.scrollY);
        Zl(a.j, "position", "fixed");
        Zl(a.j, "top", `${-b.previousWindowScroll}px`);
        Zl(a.j, "width", "100%");
        Zl(a.j, "overflow-x", "hidden");
        Zl(a.j, "overflow-y", "hidden");
        Zl(a.l, "overflow-x", "hidden");
        Zl(a.l, "overflow-y", "hidden")
    }

    function Um(a) {
        Yl(a.j);
        Yl(a.l);
        const b = Tm(a.win);
        b.activePageScrollPreventers.delete(a);
        0 === b.activePageScrollPreventers.size && (a.win.scrollTo(0, b.previousWindowScroll || 0), b.previousWindowScroll = null);
        Yl(a.m)
    }
    var Rm = class {
        constructor(a, b, c, d) {
            this.win = a;
            this.j = b;
            this.l = c;
            this.m = d
        }
    };

    function Tm(a) {
        return a.googPageScrollPreventerInfo = a.googPageScrollPreventerInfo || {
            previousWindowScroll: null,
            activePageScrollPreventers: new Set
        }
    };
    var Vm = (a, b) => a.reduce((c, d) => c.concat(b(d)), []);
    class Wm {
        constructor(a = 1) {
            this.j = a
        }
        next() {
            var a = 48271 * this.j % 2147483647;
            this.j = 0 > 2147483647 * a ? a + 2147483647 : a;
            return this.j / 2147483647
        }
    };

    function Xm(a, b, c) {
        const d = [];
        for (const e of a.j) b(e) ? d.push(e) : c(e);
        return new Ym(d)
    }

    function Zm(a, b = 1) {
        a = a.j.slice(0);
        const c = new Wm(b);
        Bb(a, () => c.next());
        return new Ym(a)
    }
    const Ym = class {
        constructor(a) {
            this.j = a.slice(0)
        }
        forEach(a) {
            this.j.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new Ym(mb(this.j, a))
        }
        apply(a) {
            return new Ym(a(this.j.slice(0)))
        }
        sort(a) {
            return new Ym(this.j.slice(0).sort(a))
        }
        get(a) {
            return this.j[a]
        }
        add(a) {
            const b = this.j.slice(0);
            b.push(a);
            return new Ym(b)
        }
    };
    class $m {
        constructor(a) {
            this.j = new Wl(a)
        }
        contains(a) {
            return this.j.contains(a)
        }
    };

    function an(a) {
        return new bn({
            value: a
        }, null)
    }

    function cn(a) {
        return new bn(null, Error(a))
    }

    function dn(a) {
        try {
            return an(a())
        } catch (b) {
            return new bn(null, b)
        }
    }

    function en(a) {
        return null != a.j ? a.j.value : null
    }

    function fn(a, b) {
        null != a.j && b(a.j.value)
    }

    function gn(a, b) {
        null != a.j || b(a.l);
        return a
    }
    class bn {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
        map(a) {
            return null != this.j ? (a = a(this.j.value), a instanceof bn ? a : an(a)) : this
        }
    };
    class hn {
        constructor() {
            this.j = new Vl
        }
        set(a, b) {
            let c = this.j.get(a);
            c || (c = new Wl, this.j.set(a, c));
            c.add(b)
        }
    };

    function jn(a) {
        return !a
    };
    var ln = class extends K {
            constructor(a) {
                super(a, -1, kn)
            }
            getId() {
                return w(this, 3)
            }
        },
        kn = [4];
    class mn {
        constructor(a, {
            zd: b,
            Ke: c,
            zf: d,
            te: e
        }) {
            this.A = a;
            this.m = c;
            this.v = new Ym(b || []);
            this.l = e;
            this.j = d
        }
    };
    var nn = a => {
            var b = a.split("~").filter(c => 0 < c.length);
            a = new Vl;
            for (const c of b) b = c.indexOf("."), -1 == b ? a.set(c, "") : a.set(c.substring(0, b), c.substring(b + 1));
            return a
        },
        pn = a => {
            var b = on(a);
            a = [];
            for (let c of b) b = String(c.nb), a.push(c.Oa + "." + (20 >= b.length ? b : b.slice(0, 19) + "_"));
            return a.join("~")
        };
    const on = a => {
            const b = [],
                c = a.v;
            c && c.j.length && b.push({
                Oa: "a",
                nb: qn(c)
            });
            null != a.m && b.push({
                Oa: "as",
                nb: a.m
            });
            null != a.j && b.push({
                Oa: "i",
                nb: String(a.j)
            });
            null != a.l && b.push({
                Oa: "rp",
                nb: String(a.l)
            });
            b.sort(function(d, e) {
                return d.Oa.localeCompare(e.Oa)
            });
            b.unshift({
                Oa: "t",
                nb: rn(a.A)
            });
            return b
        },
        rn = a => {
            switch (a) {
                case 0:
                    return "aa";
                case 1:
                    return "ma";
                default:
                    throw Error("Invalid slot type" + a);
            }
        },
        qn = a => {
            a = a.j.slice(0).map(sn);
            a = JSON.stringify(a);
            return Ug(a)
        },
        sn = a => {
            const b = {};
            null != w(a, 7) && (b.q = w(a, 7));
            null !=
                w(a, 2) && (b.o = w(a, 2));
            null != w(a, 5) && (b.p = w(a, 5));
            return b
        };

    function tn() {
        var a = new un;
        return x(a, 2, 1)
    }
    var un = class extends K {
        constructor(a) {
            super(a)
        }
        setLocation(a) {
            return x(this, 1, a)
        }
    };

    function vn(a) {
        const b = [].slice.call(arguments).filter(Qd(e => null === e));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Dd || []);
            d = Object.assign(d, e.yb())
        });
        return new wn(c, d)
    }

    function xn(a) {
        switch (a) {
            case 1:
                return new wn(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new wn(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new wn(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new wn(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function yn(a) {
        return null == a ? null : new wn(null, {
            google_ml_rank: a
        })
    }

    function zn(a) {
        return null == a ? null : new wn(null, {
            google_placement_id: pn(a)
        })
    }

    function An({
        ff: a,
        lf: b = null
    }) {
        if (null == a) return null;
        a = {
            google_daaos_ts: a
        };
        null != b && (a.google_erank = b + 1);
        return new wn(null, a)
    }
    class wn {
        constructor(a, b) {
            this.Dd = a;
            this.j = b
        }
        yb() {
            return this.j
        }
    };
    var Bn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Cn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Dn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var En = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Gn = class extends K {
            constructor(a) {
                super(a, -1, Fn)
            }
            D() {
                return w(this, 2)
            }
            B() {
                return w(this, 5)
            }
            j() {
                return D(this, En, 3)
            }
            v() {
                return w(this, 4)
            }
            A() {
                return Sc(this, 6)
            }
            G() {
                return Oc(this, Dn, 7)
            }
        },
        Fn = [3];
    var Hn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var In = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return I(this, 18, !1)
        }
        A() {
            x(this, 18, !1)
        }
        v() {
            return I(this, 21, !1)
        }
    };
    var Jn = class extends K {
        constructor() {
            super()
        }
    };
    var Kn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Ln = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Mn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Nn = class extends K {
        constructor(a) {
            super(a)
        }
        Y() {
            return C(this, ln, 1)
        }
        j() {
            return w(this, 2)
        }
    };
    var On = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Pn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Qn = class extends K {
            constructor(a) {
                super(a)
            }
            getName() {
                return w(this, 4)
            }
        },
        Rn = [1, 2, 3];
    var Tn = class extends K {
            constructor(a) {
                super(a, -1, Sn)
            }
        },
        Sn = [2, 5, 6, 11];
    var Un = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return y(this, 2)
        }
    };
    var Vn = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return w(this, 1)
        }
    };
    var Wn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Xn = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Zn = class extends K {
            constructor(a) {
                super(a, -1, Yn)
            }
            j() {
                return C(this, Xn, 2)
            }
        },
        Yn = [1];
    var $n = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var ao = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return G(this, 2)
        }
    };

    function bo() {
        var a = new co;
        a = x(a, 1, 1);
        var b = new $n;
        b = x(b, 2, !0);
        a = ad(a, 2, b);
        b = new Zn;
        var c = new Wn;
        c = x(c, 1, 1);
        b = dd(b, 1, Wn, c);
        c = new Xn;
        c = x(c, 1, !0);
        b = ad(b, 2, c);
        return ad(a, 3, b)
    }
    var co = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var eo = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return ld(this, 1)
        }
        v() {
            return G(this, 3)
        }
        A() {
            return G(this, 4)
        }
    };
    var fo = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return fd(this, 1)
        }
    };
    var go = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return G(this, 1)
        }
        v() {
            return G(this, 2)
        }
    };
    var ho = class extends K {
        constructor(a) {
            super(a)
        }
        A() {
            return C(this, eo, 8)
        }
        B() {
            return C(this, eo, 9)
        }
        v() {
            return C(this, go, 4)
        }
        j() {
            return C(this, fo, 5)
        }
        D() {
            return G(this, 10)
        }
    };
    var io = class extends K {
        constructor(a) {
            super(a)
        }
        v() {
            return fd(this, 3)
        }
        D() {
            return I(this, 4)
        }
        G() {
            return I(this, 7)
        }
        B() {
            return C(this, go, 5)
        }
        j() {
            return C(this, fo, 6)
        }
        A() {
            return G(this, 8)
        }
        H() {
            return I(this, 10)
        }
        I() {
            return I(this, 11)
        }
    };
    var ko = class extends K {
            constructor(a) {
                super(a, -1, jo)
            }
        },
        jo = [2];
    var lo = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var no = class extends K {
            constructor(a) {
                super(a, -1, mo)
            }
        },
        mo = [1];
    var oo = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return w(this, 1)
        }
    };
    var po = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var ro = class extends K {
            constructor(a) {
                super(a, -1, qo)
            }
            j() {
                return D(this, po, 1)
            }
        },
        qo = [1];
    var so = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var uo = class extends K {
            constructor(a) {
                super(a, -1, to)
            }
        },
        to = [3, 4];
    var vo = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var xo = class extends K {
            constructor(a) {
                super(a, -1, wo)
            }
            Y() {
                return C(this, ln, 1)
            }
            j() {
                return w(this, 2)
            }
        },
        wo = [6, 7, 9, 10, 11];
    var zo = class extends K {
            constructor(a) {
                super(a, -1, yo)
            }
        },
        yo = [4];
    var Ao = class extends K {
        constructor() {
            super()
        }
    };
    var Co = class extends K {
            constructor(a) {
                super(a, -1, Bo)
            }
        },
        Bo = [6];
    var Do = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return fd(this, 1)
        }
    };
    var Eo = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Go = class extends K {
            constructor(a) {
                super(a)
            }
            j() {
                return md(this, Eo, 2, Fo)
            }
        },
        Fo = [1, 2];
    var Ho = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return C(this, Go, 3)
        }
    };
    var Io = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var Ko = class extends K {
            constructor(a) {
                super(a, -1, Jo)
            }
            j() {
                return D(this, Io, 1)
            }
        },
        Jo = [1];
    var Mo = class extends K {
            constructor(a) {
                super(a, -1, Lo)
            }
            j() {
                return Tc(this, 1, Lc, !1)
            }
            v() {
                return C(this, Ho, 3)
            }
        },
        Lo = [1, 4];

    function No(a) {
        return C(a, Cn, 13)
    }

    function Oo(a) {
        return C(a, io, 28)
    }
    var Qo = Gd(class extends K {
            constructor(a) {
                super(a, -1, Po)
            }
            j() {
                return C(this, In, 15)
            }
        }),
        Po = [1, 2, 5, 7];
    var Ro = class extends K {
            constructor(a) {
                super(a)
            }
        },
        So = Gd(Ro);

    function To(a) {
        try {
            const b = a.localStorage.getItem("google_ama_settings");
            return b ? So(b) : null
        } catch (b) {
            return null
        }
    }

    function Uo(a, b) {
        if (void 0 !== a.Gc) {
            let c = To(b);
            c || (c = new Ro);
            void 0 !== a.Gc && x(c, 2, a.Gc);
            x(c, 1, Da() + 864E5);
            a = Ad(c);
            try {
                b.localStorage.setItem("google_ama_settings", a)
            } catch (d) {}
        } else if ((a = To(b)) && w(a, 1) < Da()) try {
            b.localStorage.removeItem("google_ama_settings")
        } catch (c) {}
    };

    function Vo(a) {
        var b = [];
        Pl(a.getElementsByTagName("p"), function(c) {
            100 <= Wo(c) && b.push(c)
        });
        return b
    }

    function Wo(a) {
        if (3 == a.nodeType) return a.length;
        if (1 != a.nodeType || "SCRIPT" == a.tagName) return 0;
        var b = 0;
        Pl(a.childNodes, function(c) {
            b += Wo(c)
        });
        return b
    }

    function Xo(a) {
        return 0 == a.length || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Yo(a, b) {
        if (null == a.j) return b;
        switch (a.j) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.j);
        }
    }
    const Zo = class {
        constructor(a, b, c, d) {
            this.v = a;
            this.l = b;
            this.m = c;
            this.j = d
        }
        query(a) {
            var b = [];
            try {
                b = a.querySelectorAll(this.v)
            } catch (f) {}
            if (!b.length) return [];
            a = ub(b);
            a = Yo(this, a);
            "number" === typeof this.l && (b = this.l, 0 > b && (b += a.length), a = 0 <= b && b < a.length ? [a[b]] : []);
            if ("number" === typeof this.m) {
                b = [];
                for (var c = 0; c < a.length; c++) {
                    var d = Vo(a[c]),
                        e = this.m;
                    0 > e && (e += d.length);
                    0 <= e && e < d.length && b.push(d[e])
                }
                a = b
            }
            return a
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.v,
                occurrenceIndex: this.l,
                paragraphIndex: this.m,
                ignoreMode: this.j
            })
        }
    };

    function $o(a) {
        if (1 != a.nodeType) var b = !1;
        else if (b = "INS" == a.tagName) a: {
            b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
            for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
            for (d = 0; d < b.length; ++d)
                if (!c[b[d]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    }

    function ap(a) {
        return Ql(a.querySelectorAll("ins.adsbygoogle-ablated-ad-slot"))
    };
    var R = class {
            constructor(a, b = !1) {
                this.j = a;
                this.defaultValue = b
            }
        },
        S = class {
            constructor(a, b = 0) {
                this.j = a;
                this.defaultValue = b
            }
        },
        bp = class {
            constructor(a) {
                this.j = a;
                this.defaultValue = ""
            }
        };
    var cp = new R(1082, !0),
        dp = new R(1214, !0),
        ep = new S(1130, 100),
        fp = new S(1126, 1E4),
        gp = new S(1032, 200),
        hp = new bp(14),
        ip = new S(1224, .01),
        jp = new S(1159, 500),
        kp = new R(1122, !0),
        lp = new R(1226),
        mp = new R(1196),
        np = new R(1160),
        op = new R(316),
        pp = new R(334),
        qp = new S(54),
        rp = new R(313),
        sp = new S(66, -1),
        tp = new S(65, -1),
        up = new R(369),
        vp = new R(368),
        wp = new R(1223),
        xp = new R(1227),
        yp = new S(1169, 61440),
        zp = new R(1171, !0),
        Ap = new R(1151),
        Bp = new S(1072, .75),
        Cp = new S(1168, 61440),
        Dp = new R(290),
        Ep = new R(1222),
        Fp = new R(1225),
        Gp = new R(1147),
        Hp = new R(1210),
        Ip = new S(506864295),
        Jp = new S(506871937),
        Kp = new R(483374575),
        Lp = new bp(1166),
        Mp = new R(1E4),
        Np = new S(472785970, 500),
        Op = new R(447540096, !0),
        Pp = new R(83),
        Qp = new class {
            constructor(a, b = []) {
                this.j = a;
                this.defaultValue = b
            }
        }(472572701),
        Rp = new R(439828594),
        Sp = new R(483962503),
        Tp = new R(77),
        Up = new R(78),
        Vp = new R(309),
        Wp = new R(80),
        Xp = new R(76),
        Yp = new R(1957, !0),
        Zp = new R(380025941),
        $p = new R(84),
        aq = new R(1973),
        bq = new R(188),
        cq = new R(1975),
        dq = new R(1974),
        eq = new R(504787204),
        fq = new R(1162),
        gq = new R(1120),
        hq = new S(1142, 8),
        iq = new S(1158),
        jq = new S(501545963, 1),
        kq = new S(1157),
        lq = new R(494741144),
        mq = new S(1119, 300),
        nq = new S(1193, 100),
        oq = new R(501545960),
        pq = new S(1103),
        qq = new R(501545961),
        rq = new R(505942137, !0),
        sq = new R(45388034),
        tq = new S(501545962, 1),
        uq = new S(45388309, -1),
        vq = new S(1114, 1),
        wq = new S(1116, 300),
        xq = new S(1108, 1E3),
        yq = new R(491815314),
        zq = new R(1121),
        Aq = new R(501545959, !0),
        Bq = new R(500169372),
        Cq = new R(45388161),
        Dq = new R(471262996),
        Eq = new R(504834127),
        Fq = new R(500922887),
        Gq = new R(472491850),
        Hq =
        new S(469675170, 3E4),
        Iq = new R(506619840),
        Jq = new R(506852289),
        Kq = new R(504535903),
        Lq = new R(502896280),
        Mq = new R(50227136),
        Nq = new R(1928),
        Oq = new R(1941),
        Pq = new R(370946349),
        Qq = new R(392736476),
        Rq = new S(406149835),
        Sq = new R(432946749),
        Tq = new R(432938498),
        Uq = new S(1935),
        Vq = new R(485990406);
    var Wq = class {
        constructor() {
            const a = {};
            this.j = (b, c) => null != a[b] ? a[b] : c;
            this.l = (b, c) => null != a[b] ? a[b] : c;
            this.m = (b, c) => null != a[b] ? a[b] : c;
            this.v = (b, c) => null != a[b] ? a[b] : c;
            this.A = () => {}
        }
    };

    function T(a) {
        return Ik(Wq).j(a.j, a.defaultValue)
    }

    function V(a) {
        return Ik(Wq).l(a.j, a.defaultValue)
    }

    function Xq(a) {
        return Ik(Wq).m(a.j, a.defaultValue)
    };

    function Yq(a, b) {
        a = (new pg(a)).createElement("DIV");
        const c = a.style;
        c.width = "100%";
        c.height = "auto";
        c.clear = b ? "both" : "none";
        return a
    }

    function Zq(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && 8 == d.nodeType;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        $o(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    }

    function $q(a) {
        if (a && a.parentNode) {
            const b = a.parentNode;
            b.removeChild(a);
            $o(b) && (b.style.display = b.getAttribute("data-init-display") || "none")
        }
    };
    var br = (a, b, c, d = 0) => {
            var e = ar(b, c, d);
            if (e.init) {
                for (c = b = e.init; c = e.Tb(c);) b = c;
                e = {
                    anchor: b,
                    position: e.lc
                }
            } else e = {
                anchor: b,
                position: c
            };
            a["google-ama-order-assurance"] = d;
            Zq(a, e.anchor, e.position)
        },
        cr = (a, b, c, d = 0) => {
            T(rp) ? br(a, b, c, d) : Zq(a, b, c)
        };

    function ar(a, b, c) {
        const d = f => {
                f = dr(f);
                return null == f ? !1 : c < f
            },
            e = f => {
                f = dr(f);
                return null == f ? !1 : c > f
            };
        switch (b) {
            case 0:
                return {
                    init: er(a.previousSibling, d),
                    Tb: f => er(f.previousSibling, d),
                    lc: 0
                };
            case 2:
                return {
                    init: er(a.lastChild, d),
                    Tb: f => er(f.previousSibling, d),
                    lc: 0
                };
            case 3:
                return {
                    init: er(a.nextSibling, e),
                    Tb: f => er(f.nextSibling, e),
                    lc: 3
                };
            case 1:
                return {
                    init: er(a.firstChild, e),
                    Tb: f => er(f.nextSibling, e),
                    lc: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function dr(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function er(a, b) {
        return a && b(a) ? a : null
    };
    var fr = (a, b = !1) => {
        try {
            return b ? (new hg(a.innerWidth, a.innerHeight)).round() : tg(a || window).round()
        } catch (c) {
            return new hg(-12245933, -12245933)
        }
    };

    function gr(a = u) {
        a = a.devicePixelRatio;
        return "number" === typeof a ? +a.toFixed(3) : null
    }

    function hr(a, b = u) {
        a = a.scrollingElement || ("CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return new gg(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
    }

    function ir(a) {
        try {
            return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
        } catch (b) {
            return !1
        }
    };

    function jr(a) {
        -1 === a.l && (a.l = ob(a.j, (b, c, d) => c ? b + 2 ** d : b, 0));
        return a.l
    }
    class kr {
        constructor() {
            this.j = [];
            this.l = -1
        }
        set(a, b = !0) {
            0 <= a && 52 > a && Number.isInteger(a) && this.j[a] !== b && (this.j[a] = b, this.l = -1)
        }
        get(a) {
            return !!this.j[a]
        }
    };
    var lr = (a, b, c) => {
        b = b || a.google_ad_width;
        c = c || a.google_ad_height;
        if (a && a.top == a) return !1;
        const d = a.document,
            e = d.documentElement;
        if (b && c) {
            let f = 1,
                g = 1;
            a.innerHeight ? (f = a.innerWidth, g = a.innerHeight) : e && e.clientHeight ? (f = e.clientWidth, g = e.clientHeight) : d.body && (f = d.body.clientWidth, g = d.body.clientHeight);
            if (g > 2 * c || f > 2 * b) return !1
        }
        return !0
    };

    function mr(a, b) {
        Sg(a, (c, d) => {
            b[d] = c
        })
    }
    var nr = a => {
            let b = a.location.href;
            if (a == a.top) return {
                url: b,
                Pc: !0
            };
            let c = !1;
            const d = a.document;
            d && d.referrer && (b = d.referrer, a.parent == a.top && (c = !0));
            (a = a.location.ancestorOrigins) && (a = a[a.length - 1]) && -1 == b.indexOf(a) && (c = !1, b = a);
            return {
                url: b,
                Pc: c
            }
        },
        or = a => {
            if (a == a.top) return 0;
            for (; a && a != a.top && Kg(a); a = a.parent) {
                if (a.sf_) return 2;
                if (a.$sf) return 3;
                if (a.inGptIF) return 4;
                if (a.inDapIF) return 5
            }
            return 1
        };
    var pr = (a, b) => {
            try {
                const c = b.document.documentElement.getBoundingClientRect(),
                    d = a.getBoundingClientRect();
                return {
                    x: d.left - c.left,
                    y: d.top - c.top
                }
            } catch (c) {
                return null
            }
        },
        qr = (a, b) => {
            const c = 40 === a.google_reactive_ad_format,
                d = 16 === a.google_reactive_ad_format;
            return !!a.google_ad_resizable && (!a.google_reactive_ad_format || c) && !d && !!b.navigator && /iPhone|iPod|iPad|Android|BlackBerry/.test(b.navigator.userAgent) && b === b.top
        },
        rr = (a, b, c) => {
            a = a.style;
            "rtl" == b ? a.marginRight = c : a.marginLeft = c
        };
    const sr = (a, b, c) => {
        a = pr(b, a);
        return "rtl" == c ? -a.x : a.x
    };
    var tr = (a, b) => {
            b = b.parentElement;
            return b ? (a = Qg(b, a)) ? a.direction : "" : ""
        },
        ur = (a, b, c) => {
            if (0 === sr(a, b, c)) return !1;
            rr(b, c, "0px");
            const d = sr(a, b, c);
            rr(b, c, -1 * d + "px");
            a = sr(a, b, c);
            0 !== a && a !== d && rr(b, c, d / (a - d) * d + "px");
            return !0
        };
    const vr = RegExp("(^| )adsbygoogle($| )");

    function wr(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = mg(d.bd);
            a[e] = d.value
        }
    }

    function xr(a, b, c, d, e, f) {
        a = yr(a, e);
        a.va.setAttribute("data-ad-format", d ? d : "auto");
        zr(a, b, c, f);
        return a
    }

    function Ar(a, b, c = null) {
        a = yr(a, {});
        zr(a, b, null, c);
        return a
    }

    function zr(a, b, c, d) {
        var e = [];
        if (d = d && d.Dd) a.Ua.className = d.join(" ");
        a = a.va;
        a.className = "adsbygoogle";
        a.setAttribute("data-ad-client", b);
        c && a.setAttribute("data-ad-slot", c);
        e.length && a.setAttribute("data-ad-channel", e.join("+"))
    }

    function yr(a, b) {
        const c = Yq(a, b.clearBoth || !1);
        var d = c.style;
        d.textAlign = "center";
        b.kc && wr(d, b.kc);
        a = (new pg(a)).createElement("INS");
        d = a.style;
        d.display = "block";
        d.margin = "auto";
        d.backgroundColor = "transparent";
        b.nd && (d.marginTop = b.nd);
        b.zc && (d.marginBottom = b.zc);
        b.lb && wr(d, b.lb);
        c.appendChild(a);
        return {
            Ua: c,
            va: a
        }
    }

    function Br(a, b, c) {
        b.dataset.adsbygoogleStatus = "reserved";
        b.className += " adsbygoogle-noablate";
        const d = {
            element: b
        };
        c = c && c.yb();
        if (b.hasAttribute("data-pub-vars")) {
            try {
                c = JSON.parse(b.getAttribute("data-pub-vars"))
            } catch (e) {
                return
            }
            b.removeAttribute("data-pub-vars")
        }
        c && (d.params = c);
        (a.adsbygoogle = a.adsbygoogle || []).push(d)
    }

    function Cr(a) {
        const b = ap(a.document);
        lb(b, function(c) {
            const d = Dr(a, c);
            var e;
            if (e = d) e = pr(c, a), e = !((e ? e.y : 0) < O(a).clientHeight);
            e && (c.setAttribute("data-pub-vars", JSON.stringify(d)), c.removeAttribute("height"), c.style.removeProperty("height"), c.removeAttribute("width"), c.style.removeProperty("width"), Br(a, c))
        })
    }

    function Dr(a, b) {
        b = b.getAttribute("google_element_uid");
        a = a.google_sv_map;
        if (!b || !a || !a[b]) return null;
        a = a[b];
        b = {};
        for (let c in Zf) a[Zf[c]] && (b[Zf[c]] = a[Zf[c]]);
        return b
    };
    class Er {
        constructor() {
            var a = N `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
            this.j = null;
            this.l = !1;
            this.v = Math.random();
            this.m = this.ka;
            this.B = a
        }
        ed(a) {
            this.j = a
        }
        A(a) {
            this.l = a
        }
        ka(a, b, c = .01, d, e = "jserror") {
            if ((this.l ? this.v : Math.random()) > c) return !1;
            b.error && b.meta && b.id || (b = new ni(b, {
                context: a,
                id: e
            }));
            if (d || this.j) b.meta = {}, this.j && this.j(b.meta), d && d(b.meta);
            u.google_js_errors = u.google_js_errors || [];
            u.google_js_errors.push(b);
            u.error_rep_loaded || (Og(u.document, this.B), u.error_rep_loaded = !0);
            return !1
        }
        Db(a, b, c) {
            try {
                return b()
            } catch (d) {
                if (!this.m(a, d, .01, c, "jserror")) throw d;
            }
        }
        ta(a, b, c, d) {
            return (...e) => this.Db(a, () => b.apply(c, e), d)
        }
        Aa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.ka(a, d instanceof Error ? d : Error(d), void 0, c || this.j || void 0)
            })
        }
    };
    const Fr = (a, b) => {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    var Gr = (a, b, c, d) => {
            const e = d || window,
                f = "undefined" !== typeof queueMicrotask;
            return function() {
                f && queueMicrotask(() => {
                    e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                    e.google_rum_task_id_counter += 1
                });
                const g = Hi();
                let h, k = 3;
                try {
                    h = b.apply(this, arguments)
                } catch (l) {
                    k = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    e.google_measure_js_timing && g && Fr({
                        label: a.toString(),
                        value: g,
                        duration: (Hi() || 0) - g,
                        type: k,
                        ...(f && {
                            taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                        })
                    }, e)
                }
                return h
            }
        },
        Hr = (a, b) => Gr(754,
            a, (c, d) => {
                (new Er).ka(c, d)
            }, b);

    function Ir(a, b, c) {
        return Gr(a, b, void 0, c).apply()
    }

    function Jr(a, b) {
        return Hr(a, b).apply()
    }

    function Kr(a) {
        if (!a) return null;
        var b = w(a, 7);
        if (w(a, 1) || a.getId() || 0 < Tc(a, 4, Lc, !1).length) {
            b = Tc(a, 4, Lc, !1);
            var c = w(a, 3),
                d = w(a, 1),
                e = "";
            d && (e += d);
            c && (e += "#" + Xo(c));
            if (b)
                for (c = 0; c < b.length; c++) e += "." + Xo(b[c]);
            a = (b = e) ? new Zo(b, w(a, 2), w(a, 5), Lr(w(a, 6))) : null
        } else a = b ? new Zo(b, w(a, 2), w(a, 5), Lr(w(a, 6))) : null;
        return a
    }
    var Mr = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Lr(a) {
        return null == a ? a : Mr[a]
    }

    function Nr(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = w(a[c], 1),
                e = w(a[c], 2);
            if (d && null != e) {
                var f = {};
                f.bd = d;
                f.value = e;
                b.push(f)
            }
        }
        return b
    }

    function Or(a, b) {
        var c = {};
        a && (c.nd = w(a, 1), c.zc = w(a, 2), c.clearBoth = !!y(a, 3));
        b && (c.kc = Nr(D(b, so, 3)), c.lb = Nr(D(b, so, 4)));
        return c
    }
    var Pr = {
            1: 0,
            2: 1,
            3: 2,
            4: 3
        },
        Qr = {
            0: 1,
            1: 2,
            2: 3,
            3: 4
        };
    var Rr = {
            pa: "ama_success",
            la: .1,
            ma: !0
        },
        Sr = {
            pa: "ama_failure",
            la: .1,
            ma: !0
        },
        Tr = {
            pa: "ama_inf_scr",
            la: .1,
            ma: !0
        },
        Ur = {
            pa: "ama_inf_scr",
            la: .1,
            ma: !0
        },
        Vr = {
            pa: "ama_coverage",
            la: .1,
            ma: !0
        },
        Wr = {
            pa: "ama_inf_scr",
            la: 1,
            ma: !0
        },
        Xr = {
            pa: "ama_opt",
            la: .1,
            ma: !0
        },
        Yr = {
            pa: "ama_aud_sen",
            la: 1,
            ma: !0
        },
        Zr = {
            pa: "ama_auto_rs",
            la: 1,
            ma: !0
        },
        $r = {
            pa: "ama_auto_prose",
            la: 1,
            ma: !0
        },
        as = {
            pa: "ama_improv",
            la: .1,
            ma: !0
        };

    function bs(a, b) {
        for (var c = 0; c < b.length; c++) a.wa(b[c]);
        return a
    }

    function cs(a, b) {
        a.m = a.m ? a.m : b;
        return a
    }
    class ds {
        constructor(a) {
            this.C = {};
            this.C.c = a;
            this.A = [];
            this.m = null;
            this.B = [];
            this.G = 0
        }
        Na(a) {
            this.C.wpc = a;
            return this
        }
        wa(a) {
            for (var b = 0; b < this.A.length; b++)
                if (this.A[b] == a) return this;
            this.A.push(a);
            return this
        }
        v(a) {
            var b = de(this.C);
            0 < this.G && (b.t = this.G);
            b.err = this.A.join();
            b.warn = this.B.join();
            this.m && (b.excp_n = this.m.name, b.excp_m = this.m.message && this.m.message.substring(0, 512), b.excp_s = this.m.stack && Ri(this.m.stack, ""));
            b.w = 0 < a.innerWidth ? a.innerWidth : null;
            b.h = 0 < a.innerHeight ? a.innerHeight : null;
            return b
        }
    };

    function es(a, b, c) {
        !b.ma || "pvc" in c || (c.pvc = qh(a.j));
        Rk(b.pa, c, b.la)
    }

    function fs(a, b, c) {
        c = c.v(a.j);
        b.ma && (c.pvc = qh(a.j));
        0 < b.la && (c.r = b.la, es(a, b, c))
    }
    var gs = class {
        constructor(a) {
            this.j = a
        }
    };

    function hs(a, b, c) {
        var d = a.m,
            e = O(a.j).clientHeight,
            f = C(a.l, ao, 4) ? .j();
        a = a.j;
        a = a.google_ama_state = a.google_ama_state || {};
        es(d, Yr, { ...c,
            evt: b,
            vh: e,
            eid: f,
            psr: a.audioSenseSpaceReserved ? 1 : 0
        })
    }
    var is = class {
        constructor(a, b, c) {
            this.j = a;
            this.m = b;
            this.l = c
        }
    };
    const js = class {
        constructor(a) {
            this.j = a
        }
        l(a, b, c, d) {
            return xr(d.document, a, null, null, this.j, b)
        }
        m() {
            return null
        }
    };
    const ks = class {
        constructor(a) {
            this.j = a
        }
        l(a, b, c, d) {
            var e = 0 < D(this.j, uo, 9).length ? D(this.j, uo, 9)[0] : null,
                f = Or(C(this.j, vo, 3), e);
            if (!e) return null;
            if (e = w(e, 1)) {
                d = d.document;
                var g = c.tagName;
                c = (new pg(d)).createElement(g);
                c.style.clear = f.clearBoth ? "both" : "none";
                "A" == g && (c.style.display = "block");
                c.style.padding = "0px";
                c.style.margin = "0px";
                f.kc && wr(c.style, f.kc);
                d = (new pg(d)).createElement("INS");
                f.lb && wr(d.style, f.lb);
                c.appendChild(d);
                f = {
                    Ua: c,
                    va: d
                };
                f.va.setAttribute("data-ad-type", "text");
                f.va.setAttribute("data-native-settings-key",
                    e);
                zr(f, a, null, b);
                a = f
            } else a = null;
            return a
        }
        m() {
            var a = 0 < D(this.j, uo, 9).length ? D(this.j, uo, 9)[0] : null;
            if (!a) return null;
            a = D(a, so, 3);
            for (var b = 0; b < a.length; b++) {
                var c = a[b];
                if ("height" == w(c, 1) && 0 < parseInt(w(c, 2), 10)) return parseInt(w(c, 2), 10)
            }
            return null
        }
    };
    const ls = class {
        constructor(a) {
            this.j = a
        }
        l(a, b, c, d) {
            if (!this.j) return null;
            const e = this.j.google_ad_format || null,
                f = this.j.google_ad_slot || null;
            if (c = c.style) {
                var g = [];
                for (let h = 0; h < c.length; h++) {
                    const k = c.item(h);
                    "width" !== k && "height" !== k && g.push({
                        bd: k,
                        value: c.getPropertyValue(k)
                    })
                }
                c = {
                    lb: g
                }
            } else c = {};
            a = xr(d.document, a, f, e, c, b);
            a.va.setAttribute("data-pub-vars", JSON.stringify(this.j));
            return a
        }
        m() {
            return this.j ? parseInt(this.j.google_ad_height, 10) || null : null
        }
        yb() {
            return this.j
        }
    };
    class ms {
        constructor(a) {
            this.l = a
        }
        j() {
            return new wn([], {
                google_ad_type: this.l,
                google_reactive_ad_format: 26,
                google_ad_format: "fluid"
            })
        }
    };
    const ns = class {
        constructor(a, b) {
            this.v = a;
            this.m = b
        }
        j() {
            return this.m
        }
        l(a) {
            a = this.v.query(a.document);
            return 0 < a.length ? a[0] : null
        }
    };

    function os(a, b, c) {
        const d = [];
        for (let r = 0; r < a.length; r++) {
            var e = a[r];
            var f = r,
                g = b,
                h = c,
                k = e.Y();
            if (k) {
                var l = Kr(k);
                if (l) {
                    var m = Pr[w(e, 2)],
                        n = void 0 === m ? null : m;
                    if (null === n) e = null;
                    else {
                        m = (m = C(e, vo, 3)) ? y(m, 3) : null;
                        l = new ns(l, n);
                        n = Rc(e, 10).slice(0);
                        null != w(k, 5) && n.push(1);
                        var q = h ? h : {};
                        h = w(e, 12);
                        k = Oc(e, un, 4) ? C(e, un, 4) : null;
                        1 == w(e, 8) ? (q = q.Ve || null, e = new ps(l, new js(Or(C(e, vo, 3), null)), q, m, 0, n, k, g, f, h, e)) : e = 2 == w(e, 8) ? new ps(l, new ks(e), q.Af || new ms("text"), m, 1, n, k, g, f, h, e) : null
                    }
                } else e = null
            } else e = null;
            null !==
                e && d.push(e)
        }
        return d
    }

    function qs(a) {
        return a.A
    }

    function rs(a) {
        return a.ua
    }

    function ss(a) {
        return T(mp) ? (a.K || (a.K = a.G.l(a.m)), a.K) : a.G.l(a.m)
    }

    function ts(a) {
        var b = a.H;
        a = a.m.document.createElement("div");
        T(mp) ? a.className = "google-auto-placed-ad-placeholder" : a.className = "google-auto-placed";
        var c = a.style;
        c.textAlign = "center";
        c.width = "100%";
        c.height = "0px";
        c.clear = b ? "both" : "none";
        return a
    }

    function us(a) {
        return a.C instanceof ls ? a.C.yb() : null
    }

    function vs(a, b, c) {
        Rl(a.I, b) || a.I.set(b, []);
        a.I.get(b).push(c)
    }

    function ws(a, b) {
        a.A = !0;
        T(mp) && (a.l && $q(a.l), a.l = null);
        null != b && a.N.push(b)
    }

    function xs(a) {
        return Yq(a.m.document, a.H || !1)
    }

    function ys(a) {
        return a.C.m(a.m)
    }

    function zs(a, b = null, c = null) {
        return new ps(a.G, b || a.C, c || a.L, a.H, a.Ya, a.dc, a.qc, a.m, a.ca, a.D, a.v, a.B, a.T)
    }
    class ps {
        constructor(a, b, c, d, e, f, g, h, k, l = null, m = null, n = null, q = null) {
            this.G = a;
            this.C = b;
            this.L = c;
            this.H = d;
            this.Ya = e;
            this.dc = f;
            this.qc = g ? g : new un;
            this.m = h;
            this.ca = k;
            this.D = l;
            this.v = m;
            if (!(a = !m)) {
                if (a = m.Y()) m = m.Y(), a = null != w(m, 5);
                a = !a
            }
            this.ua = !a;
            this.B = n;
            this.T = q;
            this.N = [];
            this.A = !1;
            this.I = new Vl;
            this.K = this.l = null
        }
        R() {
            return this.m
        }
        j() {
            return this.G.j()
        }
    };
    var As = a => a ? .google_ad_slot ? an(new mn(1, {
            Ke: a.google_ad_slot
        })) : cn("Missing dimension when creating placement id"),
        Cs = a => {
            switch (a.Ya) {
                case 0:
                case 1:
                    var b = a.v;
                    null == b ? a = null : (a = b.Y(), null == a ? a = null : (b = w(b, 2), a = null == b ? null : new mn(0, {
                        zd: [a],
                        te: b
                    })));
                    return null != a ? an(a) : cn("Missing dimension when creating placement id");
                case 2:
                    return a = Bs(a), null != a ? an(a) : cn("Missing dimension when creating placement id");
                default:
                    return cn("Invalid type: " + a.Ya)
            }
        };
    const Bs = a => {
        if (null == a || null == a.B) return null;
        const b = C(a.B, ln, 1),
            c = C(a.B, ln, 2);
        if (null == b || null == c) return null;
        const d = a.T;
        if (null == d) return null;
        a = a.j();
        return null == a ? null : new mn(0, {
            zd: [b, c],
            zf: d,
            te: Qr[a]
        })
    };

    function Ds(a) {
        const b = us(a.V);
        return (b ? As(b) : Cs(a.V)).map(c => pn(c))
    }

    function Es(a) {
        a.j = a.j || Ds(a);
        return a.j
    }

    function Fs(a, b) {
        if (a.V.A) throw Error("AMA:AP:AP");
        cr(b, a.Y(), a.V.j());
        ws(a.V, b)
    }
    const Gs = class {
        constructor(a, b, c) {
            this.V = a;
            this.l = b;
            this.aa = c;
            this.j = null
        }
        Y() {
            return this.l
        }
        fill(a, b) {
            var c = this.V;
            (a = c.C.l(a, b, this.l, c.m)) && Fs(this, a.Ua);
            return a
        }
    };
    const Hs = (a, b) => {
        if (3 == b.nodeType) return 3 == b.nodeType ? (b = b.data, a = Za(b, "&") ? jg(b, a.document) : b, a = /\S/.test(a)) : a = !1, a;
        if (1 == b.nodeType) {
            var c = a.getComputedStyle(b);
            if ("0" == c.opacity || "none" == c.display || "hidden" == c.visibility) return !1;
            if ((c = b.tagName) && Xl.contains(c.toUpperCase())) return !0;
            b = b.childNodes;
            for (c = 0; c < b.length; c++)
                if (Hs(a, b[c])) return !0
        }
        return !1
    };
    var Is = a => {
        if (460 <= a) return a = Math.min(a, 1200), Math.ceil(800 > a ? a / 4 : 200);
        a = Math.min(a, 600);
        return 420 >= a ? Math.ceil(a / 1.2) : Math.ceil(a / 1.91) + 130
    };
    const Js = class {
        constructor() {
            this.j = {
                clearBoth: !0
            }
        }
        l(a, b, c, d) {
            return xr(d.document, a, null, null, this.j, b)
        }
        m(a) {
            return Is(Math.min(a.screen.width || 0, a.screen.height || 0))
        }
    };
    class Ks {
        constructor(a) {
            this.l = a
        }
        j(a) {
            a = Math.floor(a.l);
            const b = Is(a);
            return new wn(["ap_container"], {
                google_reactive_ad_format: 27,
                google_responsive_auto_format: 16,
                google_max_num_ads: 1,
                google_ad_type: this.l,
                google_ad_format: a + "x" + b,
                google_ad_width: a,
                google_ad_height: b
            })
        }
    };
    const Ls = class {
        constructor(a, b) {
            this.v = a;
            this.m = b
        }
        l() {
            return this.v
        }
        j() {
            return this.m
        }
    };
    const Ms = {
        TABLE: {
            rb: new $m([1, 2])
        },
        THEAD: {
            rb: new $m([0, 3, 1, 2])
        },
        TBODY: {
            rb: new $m([0, 3, 1, 2])
        },
        TR: {
            rb: new $m([0, 3, 1, 2])
        },
        TD: {
            rb: new $m([0, 3])
        }
    };

    function Ns(a, b, c, d) {
        const e = c.childNodes;
        c = c.querySelectorAll(b);
        b = [];
        for (const f of c) c = kb(e, f), 0 > c || b.push(new Os(a, [f], c, f, 3, Cg(f).trim(), d));
        return b
    }

    function Ps(a, b, c) {
        let d = [];
        const e = [],
            f = b.childNodes,
            g = f.length;
        let h = 0,
            k = "";
        for (let n = 0; n < g; n++) {
            var l = f[n];
            if (1 == l.nodeType || 3 == l.nodeType) {
                a: {
                    var m = l;
                    if (1 != m.nodeType) {
                        m = null;
                        break a
                    }
                    if ("BR" == m.tagName) break a;
                    const q = c.getComputedStyle(m).getPropertyValue("display");m = "inline" == q || "inline-block" == q ? null : m
                }
                m ? (d.length && k && e.push(new Os(a, d, n - 1, m, 0, k, c)), d = [], h = n + 1, k = "") : (d.push(l), l = Cg(l).trim(), k += l && k ? " " + l : l)
            }
        }
        d.length && k && e.push(new Os(a, d, h, b, 2, k, c));
        return e
    }

    function Qs(a, b) {
        return a.j - b.j
    }

    function Rs(a) {
        const b = tn();
        return new ps(new Ls(a.sc, a.tc), new js({
            clearBoth: !0
        }), null, !0, 2, [], b, a.l, null, null, null, a.m, a.j)
    }
    class Os {
        constructor(a, b, c, d, e, f, g) {
            this.m = a;
            this.ob = b.slice(0);
            this.j = c;
            this.sc = d;
            this.tc = e;
            this.v = f;
            this.l = g
        }
        R() {
            return this.l
        }
    };

    function Ss(a) {
        return tb(a.A ? Ps(a.l, a.j, a.m) : [], a.v ? Ns(a.l, a.v, a.j, a.m) : []).filter(b => {
            var c = b.sc.tagName;
            c ? (c = Ms[c.toUpperCase()], b = null != c && c.rb.contains(b.tc)) : b = !1;
            return !b
        })
    }
    class Ts {
        constructor(a, b, c) {
            this.j = a;
            this.v = b.Qb;
            this.A = b.Md;
            this.l = b.articleStructure;
            this.m = c
        }
    };

    function Us(a, b) {
        return Jr(() => {
            if (T(mp)) {
                var c = [],
                    d = [];
                for (var e = 0; e < a.length; e++) {
                    var f = a[e],
                        g = ss(f);
                    if (g) {
                        var h = f;
                        if (!h.l && !h.A) {
                            var k = h;
                            var l = h,
                                m = null;
                            try {
                                var n = ss(l);
                                if (n) {
                                    m = ts(l);
                                    cr(m, n, l.j());
                                    var q = m
                                } else q = null
                            } catch (B) {
                                throw $q(m), B;
                            }
                            k.l = q
                        }(h = h.l) && d.push({
                            Pf: f,
                            anchorElement: g,
                            nf: h
                        })
                    }
                }
                if (0 < d.length)
                    for (q = Ll(b), n = Ml(b), e = 0; e < d.length; e++) {
                        const {
                            Pf: B,
                            anchorElement: z,
                            nf: A
                        } = d[e];
                        f = Vs(A, n, q);
                        c.push(new Gs(B, z, f))
                    }
                q = c
            } else {
                q = [];
                n = [];
                try {
                    const B = [];
                    for (let z = 0; z < a.length; z++) {
                        var r = a[z],
                            t = ss(r);
                        t && B.push({
                            pe: r,
                            anchorElement: t
                        })
                    }
                    for (t = 0; t < B.length; t++) {
                        r = n;
                        g = r.push; {
                            k = B[t];
                            l = k.anchorElement;
                            m = k.pe;
                            const z = ts(m);
                            try {
                                cr(z, l, m.j()), h = z
                            } catch (A) {
                                throw $q(z), A;
                            }
                        }
                        g.call(r, h)
                    }
                    c = Ll(b);
                    d = Ml(b);
                    for (g = 0; g < n.length; g++) e = Vs(n[g], d, c), f = B[g], q.push(new Gs(f.pe, f.anchorElement, e))
                } finally {
                    for (c = 0; c < n.length; c++) $q(n[c])
                }
            }
            return q
        }, b)
    }

    function Vs(a, b, c) {
        a = a.getBoundingClientRect();
        return new Km(a.left + b, a.top + c, a.right - a.left)
    };

    function Ws(a, b) {
        const c = Ss(b);
        c.sort(Qs);
        return new Xs(a, b, c)
    }

    function Ys(a, b, c) {
        return new ps(new Ls(b, c), new js({}), null, !0, 2, [], null, a.j, null, null, null, a.A.l, null)
    }
    var Xs = class {
        constructor(a, b, c) {
            this.j = a;
            this.A = b;
            this.v = c;
            this.l = !1;
            this.m = 0
        }
        next() {
            if (!this.l) {
                if (this.m >= this.v.length) var a = null;
                else {
                    {
                        const b = this.v[this.m++].ob[0];
                        ta(b) && 1 == b.nodeType ? a = Ys(this, b, 0) : (a = this.j.document.createElement("div"), M(a, {
                            display: "none"
                        }), b.parentNode.insertBefore(a, b), a = Ys(this, a, 3))
                    }
                    a = Us([a], this.j)[0] || null
                }
                if (a) return a;
                this.l = !0
            }
            return null
        }
    };
    var Zs = class {
        constructor(a) {
            this.l = a
        }
        j() {
            return this.l.next()
        }
    };
    const $s = {
            1: "0.5vp",
            2: "300px"
        },
        at = {
            1: 700,
            2: 1200
        },
        bt = {
            [1]: {
                ze: "3vp",
                ld: "1vp",
                ye: "0.3vp"
            },
            [2]: {
                ze: "900px",
                ld: "300px",
                ye: "90px"
            }
        };

    function ct(a, b, c) {
        var d = dt(a),
            e = O(a).clientHeight || at[d],
            f = void 0;
        c && (f = (c = (c = et(D(c, Gn, 2), d)) ? C(c, Dn, 7) : void 0) ? ft(c, e) : void 0);
        c = f;
        f = dt(a);
        a = O(a).clientHeight || at[f];
        const g = gt(bt[f].ld, a);
        a = null === g ? ht(f, a) : new it(g, g, jt(g, g, 8), 8, .3, c);
        c = gt(bt[d].ze, e);
        f = gt(bt[d].ld, e);
        e = gt(bt[d].ye, e);
        d = a.m;
        c && e && f && void 0 !== b && (d = .5 >= b ? f + (1 - 2 * b) * (c - f) : e + (2 - 2 * b) * (f - e));
        b = d;
        return new it(d, b, jt(d, b, a.l), a.l, a.v, a.j)
    }

    function kt(a, b) {
        const c = dt(a);
        a = O(a).clientHeight || at[c];
        if (b = et(D(b, Gn, 2), c))
            if (b = lt(b, a)) return b;
        return ht(c, a)
    }

    function mt(a) {
        const b = dt(a);
        return ht(b, O(a).clientHeight || at[b])
    }

    function nt(a, b) {
        let c = {
            hc: a.m,
            gb: a.A
        };
        for (let d of a.B) d.adCount <= b && (c = d.kd);
        return c
    }

    function ot(a, b, c) {
        var d = y(b, 2);
        b = C(b, Gn, 1);
        const e = O(c).clientHeight || at[dt(c)];
        c = gt(b ? .D(), e) ? ? a.m;
        const f = gt(b ? .B(), e) ? ? a.A;
        d = d ? [] : pt(b ? .j(), e) ? ? a.B;
        const g = b ? .v() ? ? a.l,
            h = b ? .A() ? ? a.v;
        a = (b ? .G() ? ft(C(b, Dn, 7), e) : null) ? ? a.j;
        return new it(c, f, d, g, h, a)
    }
    class it {
        constructor(a, b, c, d, e, f) {
            this.m = a;
            this.A = b;
            this.B = c.sort((g, h) => g.adCount - h.adCount);
            this.l = d;
            this.v = e;
            this.j = f
        }
    }

    function et(a, b) {
        for (let c of a)
            if (w(c, 1) == b) return c;
        return null
    }

    function pt(a, b) {
        if (void 0 === a) return null;
        const c = [];
        for (let d of a) {
            a = w(d, 1);
            const e = gt(w(d, 2), b);
            if ("number" !== typeof a || null === e) return null;
            c.push({
                adCount: a,
                kd: {
                    hc: e,
                    gb: gt(w(d, 3), b)
                }
            })
        }
        return c
    }

    function lt(a, b) {
        const c = gt(w(a, 2), b),
            d = gt(w(a, 5), b);
        if (null === c) return null;
        const e = w(a, 4);
        if (null == e) return null;
        var f = a.j();
        f = pt(f, b);
        if (null === f) return null;
        const g = C(a, Dn, 7);
        b = g ? ft(g, b) : void 0;
        return new it(c, d, f, e, Sc(a, 6), b)
    }

    function ht(a, b) {
        a = gt($s[a], b);
        return new it(null === a ? Infinity : a, null, [], 3, null)
    }

    function gt(a, b) {
        if (!a) return null;
        const c = parseFloat(a);
        return isNaN(c) ? null : a.endsWith("px") ? c : a.endsWith("vp") ? c * b : null
    }

    function dt(a) {
        a = 900 <= O(a).clientWidth;
        return Hg() && !a ? 1 : 2
    }

    function jt(a, b, c) {
        if (4 > c) return [];
        const d = Math.ceil(c / 2);
        return [{
            adCount: d,
            kd: {
                hc: 2 * a,
                gb: 2 * b
            }
        }, {
            adCount: d + Math.ceil((c - d) / 2),
            kd: {
                hc: 3 * a,
                gb: 3 * b
            }
        }]
    }

    function ft(a, b) {
        return {
            de: gt(w(a, 2), b) || 0,
            ce: w(a, 3) || 1,
            mb: gt(w(a, 1), b) || 0
        }
    };

    function qt(a, b, c) {
        return vl({
            top: a.j.top - (c + 1),
            right: a.j.right + (c + 1),
            bottom: a.j.bottom + (c + 1),
            left: a.j.left - (c + 1)
        }, b.j)
    }

    function rt(a) {
        if (!a.length) return null;
        const b = wl(a.map(c => c.j));
        a = a.reduce((c, d) => c + d.l, 0);
        return new st(b, a)
    }
    class st {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
    };

    function tt(a = window) {
        a = a.googletag;
        return a ? .apiReady ? a : void 0
    };
    var zt = (a, b) => {
        const c = ub(b.document.querySelectorAll(".google-auto-placed")),
            d = ut(b),
            e = vt(b),
            f = wt(b),
            g = xt(b),
            h = ub(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = ub(b.document.querySelectorAll("div.googlepublisherpluginad")),
            l = ub(b.document.querySelectorAll("html > ins.adsbygoogle"));
        let m = [].concat(ub(b.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), ub(b.document.querySelectorAll("body ins.adsbygoogle")));
        b = [];
        for (const [n, q] of [
                [a.Ub, c],
                [a.Xa, d],
                [a.xf, e],
                [a.Vb, f],
                [a.Wb, g],
                [a.vf, h],
                [a.wf, k],
                [a.yf, l]
            ]) a = q, !1 === n ? b = b.concat(a) : m = m.concat(a);
        a = yt(m);
        b = yt(b);
        a = a.slice(0);
        for (const n of b)
            for (b = 0; b < a.length; b++)(n.contains(a[b]) || a[b].contains(n)) && a.splice(b, 1);
        return a
    };
    const At = a => {
            const b = tt(a);
            return b ? mb(nb(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => null != c) : null
        },
        ut = a => ub(a.document.querySelectorAll("ins.adsbygoogle[data-anchor-shown],ins.adsbygoogle[data-anchor-status]")),
        vt = a => ub(a.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]")),
        wt = a => (At(a) || ub(a.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(ub(a.document.querySelectorAll("iframe[id^=google_ads_iframe]"))),
        xt = a => ub(a.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]"));
    var yt = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };
    var Bt = Nk.ta(453, zt),
        Ct;
    Ct = Nk.ta(454, (a, b) => {
        const c = ub(b.document.querySelectorAll(".google-auto-placed")),
            d = ut(b),
            e = vt(b),
            f = wt(b),
            g = xt(b),
            h = ub(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = ub(b.document.querySelectorAll("div.googlepublisherpluginad"));
        b = ub(b.document.querySelectorAll("html > ins.adsbygoogle"));
        return yt([].concat(!0 === a.Ub ? c : [], !0 === a.Xa ? d : [], !0 === a.xf ? e : [], !0 === a.Vb ? f : [], !0 === a.Wb ? g : [], !0 === a.vf ? h : [], !0 === a.wf ? k : [], !0 === a.yf ? b : []))
    });

    function Dt(a, b, c) {
        const d = Et(a);
        b = Ft(d, b, c);
        return new Gt(a, d, b)
    }

    function Ht(a) {
        return 1 < (a.bottom - a.top) * (a.right - a.left)
    }

    function It(a) {
        return a.j.map(b => b.box)
    }

    function Jt(a) {
        return a.j.reduce((b, c) => b + c.box.bottom - c.box.top, 0)
    }
    class Gt {
        constructor(a, b, c) {
            this.m = a;
            this.j = b.slice(0);
            this.v = c.slice(0);
            this.l = null
        }
    }

    function Et(a) {
        const b = Bt({
                Xa: !1
            }, a),
            c = Ml(a),
            d = Ll(a);
        return b.map(e => {
            const f = e.getBoundingClientRect();
            return (e = !!e.className && Za(e.className, "google-auto-placed")) || Ht(f) ? {
                box: {
                    top: f.top + d,
                    right: f.right + c,
                    bottom: f.bottom + d,
                    left: f.left + c
                },
                gk: e ? 1 : 0
            } : null
        }).filter(Qd(e => null === e))
    }

    function Ft(a, b, c) {
        return void 0 != b && a.length <= (void 0 != c ? c : 8) ? Kt(a, b) : nb(a, d => new st(d.box, 1))
    }

    function Kt(a, b) {
        a = nb(a, d => new st(d.box, 1));
        const c = [];
        for (; 0 < a.length;) {
            let d = a.pop(),
                e = !0;
            for (; e;) {
                e = !1;
                for (let f = 0; f < a.length; f++)
                    if (qt(d, a[f], b)) {
                        d = rt([d, a[f]]);
                        Array.prototype.splice.call(a, f, 1);
                        e = !0;
                        break
                    }
            }
            c.push(d)
        }
        return c
    };

    function Lt(a, b, c) {
        const d = Jm(c, b);
        return !pb(a, e => vl(e, d))
    }

    function Mt(a, b, c, d, e) {
        e = e.aa;
        const f = Jm(e, b),
            g = Jm(e, c),
            h = Jm(e, d);
        return !pb(a, k => vl(k, g) || vl(k, f) && !vl(k, h))
    }

    function Nt(a, b, c, d) {
        const e = It(a);
        if (Lt(e, b, d.aa)) return !0;
        if (!Mt(e, b, c.de, c.mb, d)) return !1;
        const f = new st(Jm(d.aa, 0), 1);
        a = mb(a.v, g => qt(g, f, c.mb));
        b = ob(a, (g, h) => g + h.l, 1);
        return 0 === a.length || b > c.ce ? !1 : !0
    };
    var Ot = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function Pt(a, b) {
        const c = new hn,
            d = new Wl;
        b.forEach(e => {
            if (md(e, On, 1, Rn)) {
                e = md(e, On, 1, Rn);
                if (C(e, Nn, 1) && C(e, Nn, 1).Y() && C(e, Nn, 2) && C(e, Nn, 2).Y()) {
                    const g = Qt(a, C(e, Nn, 1).Y()),
                        h = Qt(a, C(e, Nn, 2).Y());
                    if (g && h)
                        for (var f of Ot({
                                anchor: g,
                                position: w(C(e, Nn, 1), 2)
                            }, {
                                anchor: h,
                                position: w(C(e, Nn, 2), 2)
                            })) c.set(ua(f.anchor), f.position)
                }
                C(e, Nn, 3) && C(e, Nn, 3).Y() && (f = Qt(a, C(e, Nn, 3).Y())) && c.set(ua(f), w(C(e, Nn, 3), 2))
            } else md(e, Pn, 2, Rn) ? gu(a, md(e, Pn, 2, Rn), c) : md(e, Mn, 3, Rn) && hu(a, md(e, Mn, 3, Rn), d)
        });
        return new iu(c, d)
    }
    class iu {
        constructor(a, b) {
            this.l = a;
            this.j = b
        }
    }
    const gu = (a, b, c) => {
            C(b, Nn, 2) ? (b = C(b, Nn, 2), (a = Qt(a, b.Y())) && c.set(ua(a), w(b, 2))) : C(b, ln, 1) && (a = ju(a, C(b, ln, 1))) && a.forEach(d => {
                d = ua(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        hu = (a, b, c) => {
            C(b, ln, 1) && (a = ju(a, C(b, ln, 1))) && a.forEach(d => {
                c.add(ua(d))
            })
        },
        Qt = (a, b) => (a = ju(a, b)) && 0 < a.length ? a[0] : null,
        ju = (a, b) => (b = Kr(b)) ? b.query(a) : null;

    function ku(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (lu(b)) return !0;
            if (a.j.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.j.add(d));
        return !1
    }

    function mu(a) {
        a = nu(a);
        return a.has("all") || a.has("after")
    }

    function ou(a) {
        a = nu(a);
        return a.has("all") || a.has("before")
    }

    function nu(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function lu(a) {
        const b = nu(a);
        return a && ("AUTO-ADS-EXCLUSION-AREA" === a.tagName || b.has("inside") || b.has("all"))
    }
    var pu = class {
        constructor() {
            this.j = new Set
        }
    };

    function qu(a) {
        return function(b) {
            return Us(b, a)
        }
    }

    function ru(a) {
        const b = O(a).clientHeight;
        return b ? Ca(su, b + Ll(a)) : Nd
    }

    function tu(a, b, c) {
        if (0 > a) throw Error("ama::ead:nd");
        if (Infinity === a) return Nd;
        const d = It(c || Dt(b));
        return e => Lt(d, a, e.aa)
    }

    function uu(a, b, c, d) {
        if (0 > a || 0 > b.de || 0 > b.ce || 0 > b.mb) throw Error("ama::ead:nd");
        return Infinity === a ? Nd : e => Nt(d || Dt(c, b.mb), a, b, e)
    }

    function vu(a) {
        if (!a.length) return Nd;
        const b = new $m(a);
        return c => b.contains(c.Ya)
    }

    function wu(a) {
        return function(b) {
            for (let c of b.dc)
                if (-1 < a.indexOf(c)) return !1;
            return !0
        }
    }

    function xu(a) {
        return a.length ? function(b) {
            const c = b.dc;
            return a.some(d => -1 < c.indexOf(d))
        } : Od
    }

    function yu(a, b) {
        if (0 >= a) return Od;
        const c = O(b).scrollHeight - a;
        return function(d) {
            return d.aa.j <= c
        }
    }

    function zu(a) {
        const b = {};
        a && a.forEach(c => {
            b[c] = !0
        });
        return function(c) {
            return !b[w(c.qc, 2) || 0]
        }
    }

    function Au(a) {
        return a.length ? b => a.includes(w(b.qc, 1) || 0) : Od
    }

    function Bu(a, b) {
        const c = Pt(a, b);
        return function(d) {
            var e = d.Y();
            d = Qr[d.V.j()];
            var f = ua(e);
            f = c.l.j.get(f);
            if (!(f = f ? f.contains(d) : !1)) a: {
                if (c.j.contains(ua(e))) switch (d) {
                    case 2:
                    case 3:
                        f = !0;
                        break a;
                    default:
                        f = !1;
                        break a
                }
                for (e = e.parentElement; e;) {
                    if (c.j.contains(ua(e))) {
                        f = !0;
                        break a
                    }
                    e = e.parentElement
                }
                f = !1
            }
            return !f
        }
    }

    function Cu() {
        const a = new pu;
        return function(b) {
            var c = b.Y();
            b = Qr[b.V.j()];
            a: switch (b) {
                case 1:
                    var d = mu(c.previousElementSibling) || ou(c);
                    break a;
                case 4:
                    d = mu(c) || ou(c.nextElementSibling);
                    break a;
                case 2:
                    d = ou(c.firstElementChild);
                    break a;
                case 3:
                    d = mu(c.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + b);
            }
            return !(d || ku(a, c, b))
        }
    }
    const su = (a, b) => b.aa.j >= a,
        Du = (a, b, c) => {
            c = c.aa.l;
            return a <= c && c <= b
        };
    var Eu = class {
        constructor(a, b) {
            this.m = a;
            this.l = b
        }
        j() {
            const a = ru(this.m);
            let b = this.l.next();
            for (; b;) {
                if (a(b)) return b;
                b = this.l.next()
            }
            return null
        }
    };
    var Fu = class {
        constructor(a, b) {
            this.l = a;
            this.m = b
        }
        j() {
            var a = new xo;
            var b = C(this.m.l, ln, 1);
            a = ad(a, 1, b);
            a = x(x(a, 2, 2), 8, 1);
            a = os([a], this.l);
            return Us(a, this.l)[0] || null
        }
    };
    var Gu = a => {
            let b = 0;
            a.forEach(c => b = Math.max(b, c.getBoundingClientRect().width));
            return c => c.getBoundingClientRect().width > .5 * b
        },
        Hu = a => {
            const b = O(a).clientHeight || 0;
            return c => c.getBoundingClientRect().height >= .75 * b
        };

    function Iu(a, b) {
        if (!b) return !1;
        const c = ua(b),
            d = a.j.get(c);
        if (null != d) return d;
        if (1 == b.nodeType && ("UL" == b.tagName || "OL" == b.tagName) && "none" != a.l.getComputedStyle(b).getPropertyValue("list-style-type")) return a.j.set(c, !0), !0;
        b = Iu(a, b.parentNode);
        a.j.set(c, b);
        return b
    }

    function Ju(a, b) {
        return pb(b.ob, c => Iu(a, c))
    }
    class Ku {
        constructor(a) {
            this.j = new Vl;
            this.l = a
        }
    };
    class Lu {
        constructor(a, b) {
            this.v = a;
            this.j = [];
            this.l = [];
            this.m = b
        }
    };
    var Nu = (a, {
            mk: b = !1,
            nk: c = 3,
            fg: d = null
        } = {}) => {
            a = Ss(a);
            return Mu(a, b, c, d)
        },
        Mu = (a, b = !1, c = 3, d = null) => {
            if (2 > c) throw Error("minGroupSize should be at least 2, found " + c);
            var e = a.slice(0);
            e.sort(Qs);
            a = [];
            b = new Lu(b, d);
            for (const l of e) {
                d = b;
                e = {
                    mc: l,
                    Xb: 51 > l.v.length ? !1 : null != d.m ? !Ju(d.m, l) : !0
                };
                if (d.v || e.Xb) {
                    if (d.j.length) {
                        var f = d.j[d.j.length - 1].mc;
                        b: {
                            var g = f.R();
                            var h = f.ob[f.ob.length - 1];f = e.mc.ob[0];
                            if (!h || !f) {
                                g = !1;
                                break b
                            }
                            var k = h.parentElement;
                            const m = f.parentElement;
                            if (k && m && k == m) {
                                k = 0;
                                for (h = h.nextSibling; 10 >
                                    k && h;) {
                                    if (h == f) {
                                        g = !0;
                                        break b
                                    }
                                    if (Hs(g, h)) break;
                                    h = h.nextSibling;
                                    k++
                                }
                                g = !1
                            } else g = !1
                        }
                    } else g = !0;
                    g ? (d.j.push(e), e.Xb && d.l.push(e.mc)) : (d.j = [e], d.l = e.Xb ? [e.mc] : [])
                }
                if (b.l.length >= c) {
                    if (1 >= b.l.length) d = null;
                    else {
                        e = b.l[1];
                        for (d = b; d.j.length && !d.j[0].Xb;) d.j.shift();
                        d.j.shift();
                        d.l.shift();
                        d = e
                    }
                    d && a.push(d)
                }
            }
            return a
        };
    var Pu = (a, b) => {
            a = Ou(a, b);
            const c = new Ku(b);
            return Vm(a, d => Nu(d, {
                fg: c
            }))
        },
        Ou = (a, b) => {
            const c = new Vl;
            a.forEach(d => {
                var e = Kr(C(d, ln, 1));
                if (e) {
                    const f = e.toString();
                    Rl(c, f) || c.set(f, {
                        articleStructure: d,
                        Ne: e,
                        Qb: null,
                        Md: !1
                    });
                    e = c.get(f);
                    (d = (d = C(d, ln, 2)) ? w(d, 7) : null) ? e.Qb = e.Qb ? e.Qb + "," + d : d: e.Md = !0
                }
            });
            return Ul(c).map(d => {
                const e = d.Ne.query(b.document);
                return e.length ? new Ts(e[0], d, b) : null
            }).filter(d => null != d)
        };
    var Qu = (a, b) => {
        b = Ou(b, a);
        const c = b.map(d => d.j);
        b = b.filter(d => {
            d = d.j.getBoundingClientRect();
            return 0 < d.width && 0 < d.height
        }).filter(d => Gu(c)(d.j)).filter(d => Hu(a)(d.j));
        b.sort((d, e) => {
            e = e.j;
            return d.j.getBoundingClientRect().top - e.getBoundingClientRect().top
        });
        return b
    };
    var Su = (a, b, c) => {
        if (I(c, 2)) {
            if (a.document.getElementById("google-auto-placed-read-aloud-player-reserved")) {
                var d = new xo;
                var e = new ln;
                e = x(e, 7, "div#google-auto-placed-read-aloud-player-reserved");
                d = ad(d, 1, e);
                d = x(x(d, 2, 2), 8, 1);
                d = os([d], a);
                d = Us(d, a)[0] || null
            } else d = null;
            if (d) return d
        }
        a: {
            c = Ru(c);b = Qu(a, b);
            for (const f of b) {
                b: switch (b = a, d = f, e = c, e) {
                    case 1:
                        b = new Fu(b, d);
                        break b;
                    case 2:
                        b = new Zs(Ws(b, d));
                        break b;
                    case 3:
                        b = new Eu(b, Ws(b, d));
                        break b;
                    default:
                        throw Error(`Unknown position: ${e}`);
                }
                if (b = b.j()) {
                    a =
                        b;
                    break a
                }
            }
            a = null
        }
        return a
    };

    function Ru(a) {
        if (I(a, 2)) return 3;
        switch (ld(a, 1)) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            default:
                throw Error(`Unknown player position: ${ld(a,1)}`);
        }
    };
    var Tu = class {
            constructor(a) {
                this.j = a
            }
        },
        Wu = (a, b, c, d, e) => {
            if (0 < a.document.getElementsByTagName("google-read-aloud-player").length) return cn("Player already created");
            var f = a.document;
            const g = f.createElement("div");
            g.id = "google-auto-placed-read-aloud-player";
            M(g, {
                padding: "5px"
            });
            const h = f.createElement("script");
            var k = Mh `window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;`;
            h.textContent = ke(k);
            qf(h);
            g.appendChild(h);
            Uu(f, g, Ld("https://www.google-analytics.com/analytics.js"));
            Uu(f, g, Ld("https://www.gstatic.com/readaloud/player/web/api/audiosense/js/api.js"));
            f = f.createElement("google-read-aloud-player");
            f.setAttribute("data-api-key", "AIzaSyDTBU0XpbvyTzmA5nS-09w7cnopRavFpxs");
            f.setAttribute("data-tracking-ids", "UA-199725947-1,UA-168915890-13");
            f.setAttribute("data-url", c.url);
            f.setAttribute("data-locale", d);
            f.setAttribute("data-no-settings-screen", "");
            e && (null != w(e, 1) && 0 != ld(e, 1) && f.setAttribute("data-docking-begin-trigger", Vu[ld(e, 1)]), null != w(e, 2) && f.setAttribute("data-experiment",
                e.j()));
            g.appendChild(f);
            Fs(b, g);
            return an(new Tu(a.document.getElementsByTagName("google-read-aloud-player")[0]))
        };
    const Uu = (a, b, c) => {
            a = a.createElement("script");
            rf(a, re(Kd(c)));
            a.setAttribute("async", "true");
            b.appendChild(a)
        },
        Vu = {
            [1]: "out-of-view"
        };
    class Xu {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.j = b
            })
        }
    };

    function Yu() {
        const {
            promise: a,
            resolve: b
        } = new Xu;
        return {
            promise: a,
            resolve: b
        }
    };

    function Zu(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        let d = b[a];
        if (d) return d;
        d = Yu();
        b[a] = d;
        c();
        return d
    }

    function $u(a, b, c) {
        return Zu(a, b, () => {
            Og(b.document, c)
        }).promise
    };

    function av(a, b, c, d) {
        a = $u(7, a, c).then(e => {
            e.init(b);
            e.handleAdConfig({
                preloadAdBreaks: null != w(d, 1, !1) && I(d, 1) ? "auto" : "on",
                sound: "on"
            });
            return e
        });
        Nk.Aa(915, a);
        return new bv(a)
    }

    function cv(a, b) {
        a = a.j.then(c => {
            c.handleAdBreak({
                type: "preroll",
                name: "audiosense-preroll",
                adBreakDone: b
            })
        });
        Nk.Aa(956, a)
    }
    var bv = class {
        constructor(a) {
            this.j = a
        }
    };

    function dv(a) {
        const b = a.m.j;
        b.addEventListener("firstplay", () => {
            if (!a.l) {
                a.l = !0;
                b.pause();
                const c = performance.now();
                cv(a.v, () => {
                    b.play();
                    hs(a.j, "preroll", {
                        kk: performance.now() - c
                    })
                });
                hs(a.j, "play", {})
            }
        })
    }
    var ev = class {
        constructor(a, b, c) {
            this.m = a;
            this.v = b;
            this.j = c;
            this.l = !1
        }
    };

    function fv(a, b, c, d, e, f, g) {
        return 0 == d.length ? cn("No ArticleStructure found") : C(c, $n, 2) ? an(new gv(a, b, d, c, e, f, g ? g : "en")) : cn("No AudioSenseConfig.PlacementConfig found")
    }

    function hv(a) {
        const b = Su(a.v, a.D, C(a.l, $n, 2));
        if (b) {
            var c = !!a.A.Gb && iv(a);
            c && (a.B = av(a.v, a.C, a.A.Gb, C(a.l, Zn, 3) ? .j() || new Xn));
            var d = Wu(a.v, b, a.A, a.G, C(a.l, ao, 4) || void 0);
            null != d.j ? (a.m = d.j.value, a.m.j.addEventListener("firstview", () => {
                hs(a.j, "view", {})
            }), c && dv(new ev(a.m, a.B, a.j)), hs(a.j, "place", {
                sts: "ok",
                pp: b.aa.j
            })) : hs(a.j, "place", {
                sts: "wf"
            })
        } else hs(a.j, "place", {
            sts: "pf"
        })
    }

    function iv(a) {
        return (a = C(a.l, Zn, 3)) ? D(a, Wn, 1).some(b => 1 === ld(b, 1)) : !1
    }
    var gv = class {
        constructor(a, b, c, d, e, f, g) {
            this.v = a;
            this.j = new is(a, b, d);
            this.D = c;
            this.l = d;
            this.A = e;
            this.C = f;
            this.G = g;
            this.m = this.B = null
        }
    };

    function jv(a, b, c) {
        var d = 0 === a.l ? a.j.A() : a.j.B(),
            e = a.m,
            f = O(a.win).clientHeight,
            g = a.j.j() ? .j() || 0;
        a: switch (d ? .j()) {
            case 1:
                d = "AUTO_PROSE_TOP_ANCHOR";
                break a;
            case 2:
                d = "AUTO_PROSE_BOTTOM_ANCHOR";
                break a;
            default:
                d = "UNKNOWN_POSITION"
        }
        a: switch (a.l) {
            case 0:
                var h = "DESKTOP";
                break a;
            case 2:
                h = "MOBILE";
                break a;
            default:
                h = "OTHER_VIEWPORT"
        }
        es(e, $r, { ...c,
            evt: b,
            vh: f,
            eid: g,
            pos: d,
            vpt: h,
            url: a.win.location.href
        })
    }
    var kv = class {
        constructor(a, b, c) {
            this.win = a;
            this.m = b;
            this.j = c;
            this.l = ih()
        }
    };
    var lv = {},
        mv = {},
        nv = {},
        ov = {},
        pv = {};

    function qv() {
        throw Error("Do not instantiate directly");
    }
    qv.prototype.Ed = null;
    qv.prototype.ya = function() {
        return this.content
    };
    qv.prototype.toString = function() {
        return this.content
    };

    function rv(a) {
        if (a.Fd !== lv) throw Error("Sanitized content was not of kind HTML.");
        return We(a.toString())
    }

    function sv() {
        qv.call(this)
    }
    Fa(sv, qv);
    sv.prototype.Fd = lv;

    function tv(a, b) {
        return null != a && a.Fd === b
    };

    function uv(a) {
        if (null != a) switch (a.Ed) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function vv(a) {
        return tv(a, lv) ? a : a instanceof Ue ? wv(Te(a).toString()) : a instanceof Ue ? wv(Te(a).toString()) : wv(String(String(a)).replace(xv, yv), uv(a))
    }
    var wv = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            void 0 !== d && (c.Ed = d);
            return c
        }
    }(sv);

    function zv(a) {
        return a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>")
    }

    function Av(a) {
        return tv(a, lv) ? String(String(a.ya()).replace(Bv, "").replace(Cv, "&lt;")).replace(Dv, yv) : String(a).replace(xv, yv)
    }

    function Ev(a) {
        a = String(a);
        const b = (d, e, f) => {
            const g = Math.min(e.length - f, d.length);
            for (let k = 0; k < g; k++) {
                var h = e[f + k];
                if (d[k] !== ("A" <= h && "Z" >= h ? h.toLowerCase() : h)) return !1
            }
            return !0
        };
        for (var c = 0; - 1 != (c = a.indexOf("<", c));) {
            if (b("\x3c/script", a, c) || b("\x3c!--", a, c)) return "zSoyz";
            c += 1
        }
        return a
    }

    function Fv(a) {
        if (null == a) return " null ";
        if (tv(a, mv)) return a.ya();
        if (a instanceof le || a instanceof le) return ke(a).toString();
        switch (typeof a) {
            case "boolean":
            case "number":
                return " " + a + " ";
            default:
                return "'" + String(String(a)).replace(Gv, Hv) + "'"
        }
    }

    function X(a) {
        tv(a, pv) ? a = zv(a.ya()) : null == a ? a = "" : a instanceof Fe ? a = zv(Ee(a)) : a instanceof Fe ? a = zv(Ee(a)) : a instanceof Re ? a = zv(Qe(a)) : a instanceof Re ? a = zv(Qe(a)) : (a = String(a), a = Iv.test(a) ? a : "zSoyz");
        return a
    }
    const Jv = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\v": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    };

    function yv(a) {
        return Jv[a]
    }
    const Kv = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\v": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    };

    function Hv(a) {
        return Kv[a]
    }
    const Lv = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function Mv(a) {
        return Lv[a]
    }
    const xv = /[\x00\x22\x26\x27\x3c\x3e]/g,
        Dv = /[\x00\x22\x27\x3c\x3e]/g,
        Nv = /[\x00\x09-\x0d \x22\x26\x27\x2d\/\x3c-\x3e`\x85\xa0\u2028\u2029]/g,
        Ov = /[\x00\x09-\x0d \x22\x27\x2d\/\x3c-\x3e`\x85\xa0\u2028\u2029]/g,
        Gv = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
        Pv = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        Iv = /^(?!-*(?:expression|(?:moz-)?binding))(?:(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|(?:rgb|rgba|hsl|hsla|calc|max|min|cubic-bezier)\([-\u0020\t,+.!#%_0-9a-zA-Z]+\)|[-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:e-?[0-9]+)?(?:[a-z]{1,4}|%)?|!important)(?:\s*[,\u0020]\s*|$))*$/i,
        Qv =
        /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^ftp:|^data:image\/[a-z0-9+]+;base64,[a-z0-9+\/]+=*$|^blob:/i;

    function Rv(a) {
        return String(a).replace(Pv, Mv)
    }
    const Bv = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
        Cv = /</g;
    var Sv = void 0;

    function Tv() {
        void 0 === Sv && (Sv = 18);
        return Sv
    }
    var Uv = void 0;

    function Vv() {
        void 0 === Uv && (Uv = 18);
        return Uv
    }

    function Wv(a) {
        a = void 0 === a ? "white" : a;
        return wv('<svg width="' + Av(Vv()) + '" height="' + Av(Tv()) + '" viewBox="0 0 ' + Av(Tv()) + " " + Av(Vv()) + '"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.76 10.27L17.49 16L16 17.49L10.27 11.76C9.2 12.53 7.91 13 6.5 13C2.91 13 0 10.09 0 6.5C0 2.91 2.91 0 6.5 0C10.09 0 13 2.91 13 6.5C13 7.91 12.53 9.2 11.76 10.27ZM6.5 2C4.01 2 2 4.01 2 6.5C2 8.99 4.01 11 6.5 11C8.99 11 11 8.99 11 6.5C11 4.01 8.99 2 6.5 2Z" fill=' + (tv(a, lv) ? String(String(a.ya()).replace(Bv, "").replace(Cv,
            "&lt;")).replace(Ov, yv) : String(a).replace(Nv, yv)) + " /></svg>")
    };

    function Xv(a, b, c) {
        const d = a.Ca.contentWindow.google.search.cse.element.getElement("auto-rs-prose");
        c = {
            rsToken: c,
            afsExperimentId: a.m
        };
        a.B && (c.useStandardProseAdLoad = "1");
        d.execute(b, void 0, c)
    }
    var Yv = class {
        constructor(a, b, c, d, e, f, g, h, k) {
            this.Ca = a;
            this.l = b;
            this.v = c;
            this.j = d;
            this.host = e;
            this.language = f;
            this.A = g;
            this.m = h;
            this.B = k
        }
        init() {
            this.Ca.setAttribute("id", "prose-iframe");
            this.Ca.setAttribute("width", "100%");
            this.Ca.setAttribute("height", "100%");
            var a = this.Ca,
                b = Ge({
                    "box-sizing": "border-box",
                    border: "unset"
                });
            a.style.cssText = Ee(b);
            a = "https://www.google.com/s2/favicons?sz=64&domain_url=" + encodeURIComponent(this.host);
            var c = Be(a) || Ce;
            a = this.v;
            b = this.j;
            var d = this.host,
                e = this.A.replace("${website}",
                    this.host.startsWith("www.") ? this.host.slice(4) : this.host),
                f = wv;
            tv(c, nv) || tv(c, ov) ? c = Rv(c) : c instanceof xe ? c = Rv(ye(c)) : c instanceof xe ? c = Rv(ye(c)) : c instanceof ne ? c = Rv(qe(c).toString()) : c instanceof ne ? c = Rv(qe(c).toString()) : (c = String(c), c = Qv.test(c) ? c.replace(Pv, Mv) : "about:invalid#zSoyz");
            a = f('<style>.cse-favicon {display: block; float: left; height: 16px; position: absolute; left: 15px; width: 16px;}.cse-header {font-size: 16px; font-family: Arial; margin-left: 35px; margin-top: 6px; margin-bottom: unset; line-height: 16px;}.gsc-search-box {max-width: 520px !important;}.gsc-input {padding-right: 0 !important;}.gsc-input-box {border-radius: 16px 0 0 16px !important;}.gsc-search-button-v2 {border-left: 0 !important; border-radius: 0 16px 16px 0 !important; min-height: 30px !important; margin-left: 0 !important;}.gsc-cursor-page, .gsc-cursor-next-page, .gsc-cursor-numbered-page {color: #1a73e8 !important;}.gsc-cursor-chevron {fill: #1a73e8 !important;}.gsc-cursor-box {text-align: center !important;}.gsc-cursor-current-page {color: #000 !important;}.gcsc-find-more-on-google-root, .gcsc-find-more-on-google {display: none !important;}.prose-container {max-width: 652px;}</style><div class="prose-container"><img class="cse-favicon" src="' +
                Av(c) + '" alt="' + Av(d) + ' icon"><p class="cse-header"><strong>' + vv(e) + '</strong></p><div class="gcse-search" data-gname="' + Av(a) + '" data-adclient="' + Av(b) + '" data-adchannel="AutoRsVariant" data-as_sitesearch="' + Av(d) + '" data-personalizedAds="false"></div></div>');
            a = rv(a);
            b = {
                style: Ge({
                    margin: 0
                })
            };
            d = {
                src: te(Ld("https://cse.google.com/cse.js?cx=%{cxId}&language=%{lang}"), {
                    cxId: this.l,
                    lang: this.language
                })
            };
            e = {};
            f = {};
            for (g in d) Object.prototype.hasOwnProperty.call(d, g) && (f[g] = d[g]);
            for (const h in e) Object.prototype.hasOwnProperty.call(e,
                h) && (f[h] = e[h]);
            var g = $e("script", f);
            g = Xe("body", b, [a, g]);
            this.Ca.srcdoc = Te(g)
        }
    };

    function Zv(a, b) {
        return new $v(a, b)
    }

    function aw(a) {
        const b = bw(a);
        lb(a.j.maxZIndexListeners, c => c(b))
    }

    function bw(a) {
        a = Tg(a.j.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }
    class cw {
        constructor(a) {
            this.j = Al(a).floatingAdsStacking
        }
        addListener(a) {
            this.j.maxZIndexListeners.push(a);
            a(bw(this))
        }
    }

    function dw(a) {
        if (null == a.j) {
            var b = a.l,
                c = a.m;
            const d = b.j.nextRestrictionId++;
            b.j.maxZIndexRestrictions[d] = c;
            aw(b);
            a.j = d
        }
    }

    function ew(a) {
        if (null != a.j) {
            var b = a.l;
            delete b.j.maxZIndexRestrictions[a.j];
            aw(b);
            a.j = null
        }
    }
    class $v {
        constructor(a, b) {
            this.l = a;
            this.m = b;
            this.j = null
        }
    };
    const fw = ["-webkit-text-fill-color"];

    function gw(a) {
        if (Ib) {
            {
                const c = Qg(a.document.body, a);
                if (c) {
                    a = {};
                    var b = c.length;
                    for (let d = 0; d < b; ++d) a[c[d]] = "initial";
                    a = hw(a)
                } else a = iw()
            }
        } else a = iw();
        return a
    }
    var iw = () => {
        const a = {
            all: "initial"
        };
        lb(fw, b => {
            a[b] = "unset"
        });
        return a
    };

    function hw(a) {
        lb(fw, b => {
            delete a[b]
        });
        return a
    };

    function jw(a, b) {
        const c = a.document.createElement("div");
        M(c, gw(a));
        const d = c.attachShadow({
            mode: "open"
        });
        b && c.classList.add(b);
        b = {
            gd: c,
            shadowRoot: d
        };
        a.document.body.appendChild(b.gd);
        return b
    }

    function kw(a, b) {
        b = b.getElementById(a);
        if (!b) throw Error(`Element (${a}) does not exist`);
        return b
    }

    function lw(a, b) {
        const c = new bm(b.M);
        jm(b, !0, () => void P(c, !0));
        jm(b, !1, () => {
            a.setTimeout(() => {
                b.M || P(c, !1)
            }, 700)
        });
        return dm(c)
    };
    var mw = void 0;

    function nw(a) {
        a = a.top;
        if (!a) return null;
        try {
            var b = a.history
        } catch (c) {
            b = null
        }
        b = b && b.pushState && "function" === typeof b.pushState ? b : null;
        if (!b) return null;
        if (a.googNavStack) return a.googNavStack;
        b = new ow(a, b);
        b.init();
        return b ? a.googNavStack = b : null
    }

    function pw(a, b) {
        return b ? b.googNavStackId === a.m ? b : null : null
    }

    function qw(a, b) {
        for (let c = b.length - 1; 0 <= c; --c) {
            const d = 0 === c;
            a.J.requestAnimationFrame(() => void b[c].ag({
                isFinal: d
            }))
        }
    }

    function rw(a, b) {
        b = wb(a.stack, b, (c, d) => c - d.Sd.googNavStackStateId);
        if (0 <= b) return a.stack.splice(b, a.stack.length - b);
        b = -b - 1;
        return a.stack.splice(b, a.stack.length - b)
    }
    class ow extends Dk {
        constructor(a, b) {
            super();
            this.J = a;
            this.l = b;
            this.stack = [];
            this.m = 1E9 * Math.random() >>> 0;
            this.A = 0;
            this.v = c => {
                (c = pw(this, c.state)) ? qw(this, rw(this, c.googNavStackStateId + .5)): qw(this, this.stack.splice(0, this.stack.length))
            }
        }
        pushEvent() {
            const a = {
                    googNavStackId: this.m,
                    googNavStackStateId: this.A++
                },
                b = new Promise(c => {
                    this.stack.push({
                        ag: c,
                        Sd: a
                    })
                });
            this.l.pushState(a, "");
            return {
                navigatedBack: b,
                triggerNavigateBack: () => {
                    const c = rw(this, a.googNavStackStateId);
                    var d;
                    if (d = 0 < c.length) {
                        d = c[0].Sd;
                        const e = pw(this, this.l.state);
                        d = e && e.googNavStackId === d.googNavStackId && e.googNavStackStateId === d.googNavStackStateId
                    }
                    d && this.l.go(-c.length);
                    qw(this, c)
                }
            }
        }
        init() {
            this.J.addEventListener("popstate", this.v)
        }
        j() {
            this.J.removeEventListener("popstate", this.v);
            super.j()
        }
    };

    function sw(a) {
        return (a = nw(a)) ? new tw(a) : null
    }

    function uw(a) {
        if (!a.l) {
            var {
                navigatedBack: b,
                triggerNavigateBack: c
            } = a.v.pushEvent();
            a.l = c;
            b.then(() => {
                a.l && !a.B && (a.l = null, lm(a.m))
            })
        }
    }
    var tw = class extends Dk {
        constructor(a) {
            super();
            this.v = a;
            this.m = new mm;
            this.l = null
        }
    };

    function vw(a, b, c) {
        var d = Zv(new cw(a), c.zIndex - 1);
        const e = jw(a, c.Fc),
            f = e.shadowRoot;
        var g = f.appendChild,
            h = new pg(a.document);
        var k = c.Jc;
        var l = c.Hc || !1,
            m = c.Bc,
            n = c.ik || "",
            q = c.zIndex;
        if (c.qk ? ? !0) {
            void 0 === mw && (mw = 20);
            var r = mw
        } else r = 0;
        k = "<style>#hd-drawer-container {position: fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + X(q) + "; pointer-events: none;}#hd-drawer-container.hd-revealed {pointer-events: auto;}#hd-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.hd-revealed > #hd-modal-background {opacity: 0.5;}#hd-drawer {position: absolute; top: 0; height: 100%; width: " +
            X(k) + "; background-color: white; display: flex; flex-direction: column; box-sizing: border-box; padding-bottom: " + X(r) + "px; transition: transform " + X(.5) + "s ease-in-out;" + (l ? "left: 0; border-top-right-radius: " + X(r) + "px; border-bottom-right-radius: " + X(r) + "px; transform: translateX(-100%);" : "right: 0; border-top-left-radius: " + X(r) + "px; border-bottom-left-radius: " + X(r) + "px; transform: translateX(100%);") + "}.hd-revealed > #hd-drawer {transform: translateY(0);}#hd-control-bar {height: 24px;}.hd-control-button {border: none; background: none; cursor: pointer;}#hd-back-arrow-button {" +
            (l ? "float: right;" : "float: left;") + "}#hd-close-button {" + (l ? "float: left;" : "float: right;") + '}#hd-content-container {flex-grow: 1; overflow: auto;}#hd-content-container::-webkit-scrollbar * {background: transparent;}.hd-hidden {visibility: hidden;}</style><div id="hd-drawer-container"><div id="hd-modal-background"></div><div id="hd-drawer"><div id="hd-control-bar"><button id="hd-back-arrow-button" class="hd-control-button hd-hidden" aria-label="' + Av(n) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="#5F6368"><path d="m12 20-8-8 8-8 1.425 1.4-5.6 5.6H20v2H7.825l5.6 5.6Z"/></svg></button><button id="hd-close-button" class="hd-control-button" aria-label="' +
            Av(m) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="#5F6368"><path d="M6.4 19 5 17.6 10.6 12 5 6.4 6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4Z"/></svg></button></div><div id="hd-content-container"></div></div></div>';
        k = wv(k);
        g.call(f, Gg(h, rv(k)));
        g = kw("hd-content-container", f);
        g.appendChild(b);
        Cb(a.document.body.offsetHeight);
        b = {
            sb: kw("hd-drawer-container", f),
            Uc: kw("hd-modal-background", f),
            Cc: g,
            bf: kw("hd-close-button", f),
            hk: kw("hd-back-arrow-button", f),
            hd: e
        };
        d = new ww(a, b, Qm(a), d);
        d.init();
        c.Ia && ((a = sw(a)) ? xw(d, a, c.Vc) : c.Vc ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function xw(a, b, c) {
        jm(a.l, !0, () => {
            try {
                uw(b)
            } catch (d) {
                c ? .(d)
            }
        });
        jm(a.l, !1, () => {
            try {
                b.l && (b.l(), b.l = null)
            } catch (d) {
                c ? .(d)
            }
        });
        (new nm(b.m)).Z(() => void a.collapse());
        Ek(a, Ca(Ck, b))
    }

    function yw(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.v
    }

    function zw(a) {
        const {
            Uc: b,
            bf: c
        } = yw(a);
        b.addEventListener("click", () => void a.collapse());
        c.addEventListener("click", () => void a.collapse())
    }
    var ww = class extends Dk {
        constructor(a, b, c, d) {
            super();
            this.v = b;
            this.l = new bm(!1);
            this.m = lw(a, this.l);
            jm(this.m, !0, () => {
                Sm(c);
                dw(d)
            });
            jm(this.m, !1, () => {
                Um(c);
                ew(d)
            })
        }
        show({
            Id: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            yw(this).sb.classList.add("hd-revealed");
            P(this.l, !0);
            a && jm(this.m, !1, () => {
                this.xa()
            })
        }
        collapse() {
            yw(this).sb.classList.remove("hd-revealed");
            P(this.l, !1)
        }
        isVisible() {
            return this.m
        }
        init() {
            zw(this)
        }
        j() {
            const a = this.v.hd.gd,
                b = a.parentNode;
            b && b.removeChild(a);
            super.j()
        }
    };
    var Aw = void 0;

    function Bw() {
        void 0 === Aw && (Aw = 20);
        return Aw
    }
    var Cw = void 0;

    function Dw() {
        void 0 === Cw && (Cw = 30);
        return Cw
    }

    function Ew(a) {
        return wv('<div class="ved-handle" id="' + Av(a) + '"><div class="ved-handle-icon"></div></div>')
    };

    function Fw(a) {
        return Bm(a.j).map(b => b ? Gw(a, b) : 0)
    }

    function Gw(a, b) {
        switch (a.direction) {
            case 0:
                return Hw(-b.Ee);
            case 1:
                return Hw(-b.De);
            default:
                throw Error(`Unhandled direction: ${a.direction}`);
        }
    }

    function Iw(a) {
        return Dm(a.j).map(b => Gw(a, b))
    }
    var Jw = class {
        constructor(a) {
            this.j = a;
            this.direction = 0
        }
    };

    function Hw(a) {
        return 0 === a ? 0 : a
    };

    function Y(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.A
    }

    function Kw(a) {
        const {
            ba: b,
            Ea: c
        } = Y(a);
        c.getBoundingClientRect().top <= b.getBoundingClientRect().top || Lw(a);
        Y(a).sb.classList.add("ved-revealed");
        P(a.l, !0)
    }

    function Mw(a) {
        return lw(a.win, a.l)
    }

    function Nw(a, b) {
        const c = new bm(b());
        (new nm(a.G)).Z(() => void P(c, b()));
        return dm(c)
    }

    function Ow(a) {
        const {
            ba: b,
            jc: c
        } = Y(a);
        return Nw(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function Pw(a) {
        const {
            ba: b,
            jc: c
        } = Y(a);
        return Nw(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top - 1)
    }

    function Qw(a) {
        const {
            ba: b
        } = Y(a);
        return Nw(a, () => b.scrollTop === b.scrollHeight - b.clientHeight)
    }

    function Rw(a) {
        return em(Ow(a), Qw(a))
    }

    function Sw(a) {
        const {
            ba: b,
            Ea: c
        } = Y(a);
        return Nw(a, () => c.getBoundingClientRect().top < b.getBoundingClientRect().top - 1)
    }

    function Lw(a) {
        Y(a).Ea.classList.add("ved-snap-point-top");
        var b = Tw(a, Y(a).Ea);
        Y(a).ba.scrollTop = b;
        Uw(a)
    }

    function Vw(a) {
        hm(Ow(a), !0, () => {
            const {
                Nd: b,
                Eb: c
            } = Y(a);
            b.classList.remove("ved-hidden");
            c.classList.add("ved-with-background")
        });
        hm(Ow(a), !1, () => {
            const {
                Nd: b,
                Eb: c
            } = Y(a);
            b.classList.add("ved-hidden");
            c.classList.remove("ved-with-background")
        })
    }

    function Ww(a) {
        const b = Fm(a.win, Y(a).Cc);
        gm(Im(b), () => void Xw(a));
        Ek(a, Ca(Ck, b))
    }

    function Yw(a) {
        hm(Zw(a), !0, () => {
            Y(a).me.classList.remove("ved-hidden")
        });
        hm(Zw(a), !1, () => {
            Y(a).me.classList.add("ved-hidden")
        })
    }

    function $w(a) {
        const b = () => void lm(a.C),
            {
                Uc: c,
                Ea: d,
                sf: e
            } = Y(a);
        c.addEventListener("click", b);
        d.addEventListener("click", b);
        e.addEventListener("click", b);
        jm(ax(a), !0, b)
    }

    function bx(a) {
        jm(Mw(a), !1, () => {
            Lw(a)
        })
    }

    function Uw(a) {
        im(a.m, () => void lm(a.G))
    }

    function Xw(a) {
        if (!a.m.M) {
            var {
                Gd: b,
                Cc: c
            } = Y(a), d = c.getBoundingClientRect().height;
            d = Math.max(cx(a), d);
            P(a.m, !0);
            var e = dx(a);
            b.style.setProperty("height", `${d}px`);
            e();
            a.win.requestAnimationFrame(() => {
                a.win.requestAnimationFrame(() => {
                    P(a.m, !1)
                })
            })
        }
    }

    function Zw(a) {
        const {
            ba: b,
            Ea: c
        } = Y(a);
        return Nw(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function ax(a) {
        return cm(a.v.map(jn), ex(a))
    }

    function ex(a) {
        return Nw(a, () => 0 === Y(a).ba.scrollTop)
    }

    function Tw(a, b) {
        ({
            Eb: a
        } = Y(a));
        a = a.getBoundingClientRect().top;
        return b.getBoundingClientRect().top - a
    }

    function fx(a, b) {
        P(a.v, !0);
        const {
            Eb: c,
            ba: d
        } = Y(a);
        d.scrollTop = 0;
        d.classList.add("ved-scrolling-paused");
        c.style.setProperty("margin-top", `-${b}px`);
        return () => void gx(a, b)
    }

    function gx(a, b) {
        const {
            Eb: c,
            ba: d
        } = Y(a);
        c.style.removeProperty("margin-top");
        d.classList.remove("ved-scrolling-paused");
        Y(a).ba.scrollTop = b;
        Uw(a);
        P(a.v, !1)
    }

    function dx(a) {
        const b = Y(a).ba.scrollTop;
        fx(a, b);
        return () => void gx(a, b)
    }

    function cx(a) {
        const {
            ba: b,
            jc: c,
            Gd: d,
            Ea: e
        } = Y(a);
        a = b.getBoundingClientRect();
        const f = c.getBoundingClientRect();
        var g = d.getBoundingClientRect();
        const h = e.getBoundingClientRect();
        g = g.top - f.top;
        return Math.max(a.height - h.height - g, Math.min(a.height, a.bottom - f.top) - g)
    }
    var hx = class extends Dk {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.A = b;
            this.H = c;
            this.C = new mm;
            this.G = new mm;
            this.l = new bm(!1);
            this.v = new bm(!1);
            this.m = new bm(!1)
        }
        init() {
            Lw(this);
            Vw(this);
            Ww(this);
            Yw(this);
            $w(this);
            bx(this);
            Y(this).ba.addEventListener("scroll", () => void Uw(this))
        }
        j() {
            const a = this.A.hd.gd,
                b = a.parentNode;
            b && b.removeChild(a);
            super.j()
        }
    };

    function ix(a, b, c) {
        var d = Zv(new cw(a), c.zIndex - 1),
            e = jw(a, c.Fc),
            f = e.shadowRoot,
            g = f.appendChild,
            h = new pg(a.document);
        var k = 100 * c.Yc;
        var l = 100 * c.Kc;
        k = wv("<style>#ved-drawer-container {position:  fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + X(c.zIndex) + "; pointer-events: none;}#ved-drawer-container.ved-revealed {pointer-events: auto;}#ved-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.ved-revealed > #ved-modal-background {opacity: 0.5;}#ved-ui-revealer {position: absolute; left: 0; bottom: 0; width: 100%; height: " +
            X(l) + "%; transition: transform " + X(.5) + "s ease-in-out; transform: translateY(100%);}#ved-ui-revealer.ved-no-animation {transition-property: none;}.ved-revealed > #ved-ui-revealer {transform: translateY(0);}#ved-scroller-container {position: absolute; left: 0; bottom: 0; width: 100%; height: 100%; clip-path: inset(0 0 -50px 0 round " + X(Bw()) + "px);}#ved-scroller {position: relative; width: 100%; height: 100%; overflow-y: scroll; -ms-overflow-style: none; scrollbar-width: none; overflow-y: scroll; overscroll-behavior: none; scroll-snap-type: y mandatory;}#ved-scroller.ved-scrolling-paused {overflow: hidden;}#ved-scroller.ved-no-snap {scroll-snap-type: none;}#ved-scroller::-webkit-scrollbar {display: none;}#ved-scrolled-stack {width: 100%; height: 100%; overflow: visible;}#ved-scrolled-stack.ved-with-background {background-color: white;}.ved-snap-point-top {scroll-snap-align: start;}.ved-snap-point-bottom {scroll-snap-align: end;}#ved-fully-closed-anchor {height: " +
            X(k / l * 100) + "%;}.ved-with-background #ved-fully-closed-anchor {background-color: white;}#ved-partially-extended-anchor {height: " + X((l - k) / l * 100) + "%;}.ved-with-background #ved-partially-extended-anchor {background-color: white;}#ved-moving-handle-holder {scroll-snap-stop: always;}.ved-with-background #ved-moving-handle-holder {background-color: white;}#ved-fixed-handle-holder {position: absolute; left: 0; top: 0; width: 100%;}#ved-visible-scrolled-items {display: flex; flex-direction: column; min-height: " +
            X(k / l * 100) + "%;}#ved-content-background {width: 100%; flex-grow: 1; padding-top: 1px; margin-top: -1px; background-color: white;}#ved-content-sizer {overflow: hidden; width: 100%; height: 100%;}#ved-content-container {width: 100%;}#ved-over-scroll-block {display: flex; flex-direction: column; position: absolute; bottom: 0; left: 0; width: 100%; height: " + X(k / l * 100) + "%; pointer-events: none;}#ved-over-scroll-handle-spacer {height: " + X(Dw() + 50) + "px;}#ved-over-scroll-background {flex-grow: 1; background-color: white;}.ved-handle {align-items: flex-end; border-radius: " +
            X(Bw()) + "px " + X(Bw()) + "px 0 0; background: white; display: flex; height: " + X(Dw()) + 'px; justify-content: center; cursor: grab;}.ved-handle-icon {background: #dadce0; border-radius: 2px; height: 4px; margin-bottom: 8px; width: 50px;}.ved-hidden {visibility: hidden;}</style><div id="ved-drawer-container"><div id="ved-modal-background"></div><div id="ved-ui-revealer"><div id="ved-over-scroll-block" class="ved-hidden"><div id=\'ved-over-scroll-handle-spacer\'></div><div id=\'ved-over-scroll-background\'></div></div><div id="ved-scroller-container"><div id="ved-scroller"><div id="ved-scrolled-stack"><div id="ved-fully-closed-anchor" class="ved-snap-point-top"></div><div id="ved-partially-extended-anchor" class="ved-snap-point-top"></div><div id="ved-visible-scrolled-items"><div id="ved-moving-handle-holder" class="ved-snap-point-top">' +
            Ew("ved-moving-handle") + '</div><div id="ved-content-background"><div id="ved-content-sizer" class="ved-snap-point-bottom"><div id="ved-content-container"></div></div></div></div></div></div></div><div id="ved-fixed-handle-holder" class="ved-hidden">' + Ew("ved-fixed-handle") + "</div></div></div>");
        g.call(f, Gg(h, rv(k)));
        g = kw("ved-content-container", f);
        g.appendChild(b);
        Cb(a.document.body.offsetHeight);
        b = {
            sb: kw("ved-drawer-container", f),
            Uc: kw("ved-modal-background", f),
            Ae: kw("ved-ui-revealer", f),
            ba: kw("ved-scroller",
                f),
            Eb: kw("ved-scrolled-stack", f),
            sf: kw("ved-fully-closed-anchor", f),
            Ea: kw("ved-partially-extended-anchor", f),
            Gd: kw("ved-content-sizer", f),
            Cc: g,
            pk: kw("ved-moving-handle", f),
            jc: kw("ved-moving-handle-holder", f),
            rf: kw("ved-fixed-handle", f),
            Nd: kw("ved-fixed-handle-holder", f),
            me: kw("ved-over-scroll-block", f),
            hd: e
        };
        e = b.rf;
        e = new Em(new vm(a, e), new sm(e));
        f = e.j;
        f.A.addEventListener("mousedown", f.D);
        f.v.addEventListener("mouseup", f.B);
        f.v.addEventListener("mousemove", f.C, {
            passive: !1
        });
        f = e.l;
        f.l.addEventListener("touchstart",
            f.C);
        f.l.addEventListener("touchend", f.A);
        f.l.addEventListener("touchmove", f.B, {
            passive: !1
        });
        b = new hx(a, b, new Jw(e));
        b.init();
        d = new jx(a, b, Qm(a), d);
        Ek(d, Ca(Ck, b));
        d.init();
        c.Ia && ((a = sw(a)) ? kx(d, a, c.Vc) : c.Vc ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function kx(a, b, c) {
        jm(a.l.l, !0, () => {
            try {
                uw(b)
            } catch (d) {
                c ? .(d)
            }
        });
        jm(a.l.l, !1, () => {
            try {
                b.l && (b.l(), b.l = null)
            } catch (d) {
                c ? .(d)
            }
        });
        (new nm(b.m)).Z(() => void a.collapse());
        Ek(a, Ca(Ck, b))
    }

    function lx(a) {
        jm(cm(Rw(a.l), Sw(a.l)), !0, () => {
            Y(a.l).Ea.classList.remove("ved-snap-point-top")
        });
        hm(Pw(a.l), !0, () => {
            Y(a.l).ba.classList.add("ved-no-snap")
        });
        hm(Pw(a.l), !1, () => {
            Y(a.l).ba.classList.remove("ved-no-snap")
        });
        jm(Pw(a.l), !1, () => {
            var b = a.l;
            var c = Y(b).jc;
            c = fx(b, Tw(b, c));
            b.win.setTimeout(c, 100)
        })
    }

    function mx(a) {
        const b = a.l.H;
        Fw(b).Z(c => {
            c = -c;
            if (0 < c) {
                const {
                    Ae: d
                } = Y(a.l);
                d.classList.add("ved-no-animation");
                d.style.setProperty("transform", `translateY(${c}px)`)
            } else({
                Ae: c
            } = Y(a.l)), c.classList.remove("ved-no-animation"), c.style.removeProperty("transform")
        });
        Iw(b).Z(c => {
            30 < -c && a.collapse()
        })
    }
    var jx = class extends Dk {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.l = b;
            jm(Mw(b), !0, () => {
                Sm(c);
                dw(d)
            });
            jm(Mw(b), !1, () => {
                Um(c);
                ew(d)
            })
        }
        show({
            Id: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            Kw(this.l);
            a && jm(Mw(this.l), !1, () => {
                this.xa()
            })
        }
        collapse() {
            var a = this.l;
            Y(a).sb.classList.remove("ved-revealed");
            P(a.l, !1)
        }
        isVisible() {
            return Mw(this.l)
        }
        init() {
            (new nm(this.l.C)).Z(() => {
                this.collapse()
            });
            lx(this);
            mx(this);
            Cb(this.win.document.body.offsetHeight)
        }
    };

    function nx(a) {
        const b = a.B ? .v(),
            c = a.B ? .A();
        let d, e;
        1 === a.B ? .j() ? d = 14 : e = 2;
        return {
            backgroundColor: b,
            Wa: c,
            ge: d,
            fe: e
        }
    }

    function ox(a) {
        const b = a.v.getElementsByClassName("autoprose-search-button")[0];
        return b ? b : a.v.getElementsByClassName("autoprose-searchbox")[0]
    }

    function px(a) {
        const b = new ResizeObserver(async d => {
                a.j.height = 0;
                await new Promise(e => a.m.requestAnimationFrame(e));
                a.j.height = d[0].target.scrollHeight
            }),
            c = () => {
                const d = a.j.contentDocument ? .documentElement;
                d ? b.observe(d) : (console.warn("iframe body missing"), setTimeout(c, 1E3))
            };
        c()
    }
    var qx = class {
        constructor(a, b, c, d, e, f) {
            this.m = a;
            this.A = 2 === ih();
            this.v = c;
            this.l = d;
            this.I = e ? .v() ? .j() || "en";
            this.K = e ? .v() ? .v() || "Search results from ${website}";
            this.H = b.replace("ca", "partner");
            this.C = new pg(window.document);
            this.j = this.C.createElement("IFRAME");
            this.G = new Yv(this.j, e ? .D() || "", "auto-prose", this.H, a.location.host, this.I, this.K, f, !1);
            a = this.j;
            this.D = this.A ? ix(this.m, a, {
                Yc: .95,
                Kc: .95,
                zIndex: 100001,
                Ia: !0
            }) : vw(this.m, a, {
                Jc: "80vw",
                Bc: "",
                Hc: !1,
                zIndex: 100001,
                Ia: !0
            });
            this.B = this.A ? e ? .B() : e ? .A()
        }
        init() {
            this.v.appendChild(yg(document,
                (() => {
                    if (this.A) {
                        var b = nx(this),
                            c = {
                                backgroundColor: b.backgroundColor,
                                Wa: b.Wa,
                                offsetTop: b.ge,
                                Wc: b.fe
                            };
                        c = c || {};
                        var d = c.Jf,
                            e = c.Wc;
                        b = c.backgroundColor;
                        var f = c.Wa;
                        d = void 0 === d ? 16 : d;
                        c = c.offsetTop;
                        e = void 0 === e ? 2 : e;
                        f = void 0 === f ? "white" : f;
                        b = "<style>.autoprose-search-button {background: " + X(void 0 === b ? "#000" : b) + "; border-radius: " + X(24) + "px;" + (c ? "top: " + X(c) + "%;" : "bottom: " + X(e) + "%;") + "box-shadow: 0 0 10px rgba(0, 0, 0, 0.35); cursor: pointer; height: " + X(48) + "px; position: fixed; right: " + X(d) + "px; width: 48px;}.autoprose-search-icon {left: " +
                            X((48 - Vv()) / 2) + "px; position: relative; top: " + X((48 - Tv()) / 2) + 'px;}</style><div class="autoprose-search-button"><div class="autoprose-search-icon">' + Wv(f) + "</div></div>";
                        b = wv(b);
                        return rv(b)
                    }
                    b = nx(this);
                    c = {
                        dg: "Search",
                        backgroundColor: b.backgroundColor,
                        Wa: b.Wa,
                        offsetTop: b.ge,
                        Wc: b.fe
                    };
                    d = c.Jf;
                    var g = c.Wc;
                    b = c.backgroundColor;
                    f = c.Wa;
                    d = void 0 === d ? 16 : d;
                    e = c.offsetTop;
                    g = void 0 === g ? 2 : g;
                    c = c.dg;
                    f = void 0 === f ? "white" : f;
                    b = "<style>.autoprose-search-button {align-items: center; background: " + X(void 0 === b ? "#000" : b) +
                        "; border-radius: " + X(24) + "px;" + (e ? "top: " + X(e) + "%;" : "bottom: " + X(g) + "%;") + "box-shadow: 0 0 10px rgba(0, 0, 0, 0.35); cursor: pointer; display: flex; height: " + X(48) + "px; line-height: 1; padding: 0 20px; position: fixed; right: " + X(d) + "px;}.autoprose-search-text {color: " + X(f) + '; font-family: Google Sans, Roboto, sans-serif; margin: 10px; user-select: none;}</style><div class="autoprose-search-button"><div class="autoprose-search-icon">' + Wv(f) + '</div><div class="autoprose-search-text">' + vv(c) + "</div></div>";
                    b = wv(b);
                    return rv(b)
                })()));
            this.G.init();
            const a = ox(this);
            a ? (jv(this.l, "place", {
                sts: "ok"
            }), L(a, "click", () => {
                jv(this.l, "click", {});
                px(this);
                this.D.show();
                const b = this.j.contentDocument.getElementsByTagName("input")[0];
                b ? b.focus({
                    preventScroll: !0
                }) : console.warn("searchbox missing")
            })) : jv(this.l, "place", {
                sts: "pfmsb"
            })
        }
    };

    function rx(a) {
        const b = C(a.j, ho, 31) ? .j() ? .j() || 0,
            c = a.l.document,
            d = c.createElement("div");
        d.classList.add("auto-prose-wrapper");
        c.body.appendChild(d);
        (new qx(a.l, a.m, d, a.v, C(a.j, ho, 31), b)).init()
    }
    var sx = class {
        constructor(a, b, c, d) {
            this.l = a;
            this.j = c;
            this.v = new kv(a, b, C(this.j, ho, 31) || new ho);
            this.m = d
        }
    };

    function tx(a, b) {
        es(a.j, Zr, { ...b,
            evt: "place",
            vh: O(a.win).clientHeight,
            eid: a.l.j() ? .j() || 0,
            url: a.win.location.href
        })
    }
    var ux = class {
        constructor(a, b, c) {
            this.win = a;
            this.j = b;
            this.l = c
        }
    };
    var vx = class {
        constructor(a) {
            this.j = a
        }
        ya(a) {
            const b = a.document.createElement("div");
            M(b, gw(a));
            M(b, {
                width: "100%",
                "max-width": "1000px",
                margin: "auto"
            });
            b.appendChild(this.j);
            const c = a.document.createElement("div");
            M(c, gw(a));
            M(c, {
                width: "100%",
                "text-align": "center",
                display: "block",
                padding: "5px 5px 2px",
                "box-sizing": "border-box",
                "background-color": "#FFF"
            });
            c.appendChild(b);
            return c
        }
    };
    var wx = (a, b) => (b = C(b, ro, 6)) ? Pu(b.j(), a).map(c => Rs(c)) : [];
    var xx = class {
        constructor(a, b) {
            this.l = a;
            this.j = b
        }
    };

    function yx(a) {
        L(a.l, "click", () => zx(a));
        L(a.D, "click", () => void zx(a));
        const b = a.width / a.win.innerWidth;
        L(a.win, "resize", () => {
            a.width = Math.floor(b * a.win.innerWidth);
            a.j.style.width = `${a.width}px`;
            a.j.style.height = `${a.win.innerHeight}px`;
            a.l.style.width = `${a.win.innerWidth}px`;
            a.l.style.height = `${a.win.innerHeight}px`;
            a.A && (a.v.style.transform = `translateX(${a.width}px)`)
        })
    }

    function zx(a) {
        a.A = !0;
        a.j.scrollTop = 0;
        a.v.style.transitionDuration = ".5s";
        a.v.style.transform = `translateX(${a.width}px)`;
        a.l.style.opacity = "0";
        a.m.style.transitionDelay = ".5s";
        Cb(a.m.offsetWidth);
        a.m.style.visibility = "hidden";
        setTimeout(() => {
            a.win.document.documentElement.style.overflow = ""
        }, 500);
        for (const b of a.C) try {
            b()
        } catch (c) {
            console.error(c)
        }
    }
    var Ax = class {
        constructor(a, b) {
            this.win = a;
            this.width = b;
            this.C = [];
            this.A = !0;
            b = new pg(a.document);
            this.l = b.ga("DIV", {
                "class": "adpub-drawer-modal-background"
            });
            var c = a.document.createElementNS("http://www.w3.org/2000/svg", "svg");
            c.setAttribute("viewBox", "0 0 24 24");
            var d = a.document.createElementNS("http://www.w3.org/2000/svg", "path");
            d.setAttribute("fill", "#5f6368");
            d.setAttribute("d", "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z");
            c.appendChild(d);
            this.D = b.ga("DIV", {
                "class": "adpub-drawer-close-button"
            }, c);
            this.j = b.ga("DIV", {
                "class": "adpub-drawer-contents"
            });
            this.v = b.ga("DIV", {
                "class": "adpub-drawer"
            }, this.D, this.j);
            this.m = b.ga("DIV", {
                "class": "adpub-drawer-container"
            }, this.l, this.v);
            this.B = b.ga("DIV", {
                "class": "adpub-drawer-root"
            });
            c = this.B.attachShadow({
                mode: "open"
            });
            d = c.appendChild;
            var e = this.win.innerHeight - 5;
            const f = this.width,
                g = a.innerWidth;
            e = wv("<style>.adpub-drawer-container {height: 100%; position: fixed; top: 0; transition: visibility 0s linear .5s; visibility: hidden; width: 100%; z-index: " +
                X(100002) + ";}.adpub-drawer-modal-background {background-color: black; height: " + X(e + 5) + "px; opacity: 0; position: absolute; transition: opacity .5s ease-in-out; width: " + X(g) + "px;}.adpub-drawer {position: absolute; transform: translateX(" + X(f) + "px); transition: transform .5s ease-in-out; height: 100%; overflow: auto; right: 0; border-radius: 20px 0 0 20px;}.adpub-drawer-close-button {color: #5f6368; height: 24px; width: 24px; top: 20px; right: 20px; position: fixed; cursor: pointer;}.adpub-drawer-contents {background: white; height: " +
                X(e) + "px; overflow-y: auto; padding-top: " + X(5) + "px; width: " + X(f) + "px;}</style>");
            d.call(c, Gg(b, rv(e)));
            c.appendChild(this.m);
            M(this.B, gw(a))
        }
        init() {
            this.win.document.body.appendChild(this.B);
            yx(this)
        }
        T(a) {
            for (; this.j.firstChild;) this.j.removeChild(this.j.firstChild);
            this.j.appendChild(a)
        }
        show() {
            this.A = !1;
            this.win.document.documentElement.style.overflow = "hidden";
            this.m.style.transitionDelay = "0s";
            this.m.style.visibility = "visible";
            this.l.style.opacity = ".5";
            this.v.style.transform = "translateX(0)"
        }
        ca(a) {
            this.C.push(a)
        }
    };

    function Bx(a) {
        L(a.H, "click", () => Cx(a));
        L(a.v, "mousedown", () => {
            const d = f => {
                    Dx(a, f.movementY)
                },
                e = () => {
                    Ex(a);
                    Yd(a.v, "mousemove", d);
                    Yd(a.v, "mouseup", e);
                    Yd(a.v, "mouseleave", e)
                };
            L(a.v, "mousemove", d);
            L(a.v, "mouseup", e);
            L(a.v, "mouseleave", e)
        });
        L(a.j, "touchstart", d => {
            let e = d.touches[0];
            const f = h => {
                    const k = h.touches[0];
                    0 === Fx(a) ? a.l.classList.add("scrollable") : a.l.classList.remove("scrollable");
                    if (e) {
                        var l = 0 === Fx(a) && a.l.scrollTop;
                        const m = k.target === a.v || k.target.parentElement === a.v;
                        if (!l || m) l = k.screenY - e.screenY,
                            Dx(a, l), l = 0 < l && 0 === a.l.scrollTop, l = a.G && !l, h.cancelable && !l && h.preventDefault()
                    }
                    e = k
                },
                g = () => {
                    Ex(a);
                    Yd(a.j, "touchmove", f);
                    Yd(a.j, "touchend", g);
                    Yd(a.j, "touchcancel", g)
                };
            L(a.j, "touchmove", f, {
                passive: !1
            });
            L(a.j, "touchend", g);
            L(a.j, "touchcancel", g)
        });
        L(a.A, "touchstart", () => {});
        const b = a.m / a.win.innerHeight,
            c = a.C / a.m;
        L(a.win, "resize", () => {
            a.m = Math.floor(b * a.win.innerHeight);
            a.C = Math.floor(c * a.m);
            a.B = a.win.innerHeight - (a.m + 30 - 20);
            const d = a.G ? 0 : a.m - a.C;
            a.l.style.height = `${a.m}px`;
            a.j.style.transform = a.I ? `translateY(${a.m+ 
a.B}px)` : `translateY(${d+a.B}px)`
        })
    }

    function Gx(a, b) {
        var c = ["https://cse.google.com"];
        const d = ["touchstart", "touchmove", "touchend", "touchcancel"],
            e = (k, l, m) => {
                try {
                    const n = m.map(q => new Touch(q));
                    k.dispatchEvent(new TouchEvent(l, {
                        bubbles: !0,
                        cancelable: !0,
                        touches: n
                    }))
                } catch {
                    l = new UIEvent(l, {
                        bubbles: !0,
                        cancelable: !0,
                        detail: 1,
                        view: a.win
                    });
                    for (const n of m) k.dispatchEvent(Object.assign(l, {
                        touches: [n]
                    }))
                }
            },
            f = k => {
                k = k.contentDocument;
                for (const l of d) L(k, l, m => {
                    m = [...m.touches].map(n => ({
                        clientX: n.clientX,
                        clientY: n.clientY,
                        force: n.force,
                        identifier: n.identifier,
                        pageX: n.pageX,
                        pageY: n.pageY,
                        radiusX: n.radiusX,
                        radiusY: n.radiusY,
                        rotationAngle: n.rotationAngle,
                        screenX: n.screenX,
                        screenY: n.screenY,
                        target: a.l
                    }));
                    e(a.j, l, m)
                })
            },
            g = k => {
                if ((void 0 === c || c.includes(k.origin)) && d.includes(k.data ? .type) && Array.isArray(k.data ? .touches)) {
                    var l = k.data.type;
                    k = k.data.touches.map(m => ({ ...m,
                        target: a.l
                    }));
                    e(a.j, l, k)
                }
            },
            h = k => {
                k.contentWindow ? L(k.contentWindow, "message", g) : console.error("Loaded iframe missing content window.")
            };
        "complete" === b.contentDocument ? .readyState && (h(b), f(b));
        L(b, "load", () => {
            h(b);
            f(b)
        })
    }

    function Hx(a, b, c) {
        a.N.set(b, a.win.document.documentElement.style.getPropertyValue(b) ? ? "");
        a.win.document.documentElement.style.setProperty(b, c)
    }

    function Ix(a, b) {
        const c = a.N.get(b) ? ? "";
        a.win.document.documentElement.style.setProperty(b, c)
    }

    function Cx(a) {
        a.I = !0;
        a.G = !1;
        Ix(a, "position");
        Ix(a, "width");
        Ix(a, "transform");
        Ix(a, "overflow");
        Ix(a, "touch-action");
        null != a.D && (a.win.document.documentElement.scrollTop = a.D, a.win.document.body.scrollTop = a.D);
        Ix(a, "scroll-behavior");
        a.A.style.transform = "";
        a.l.scrollTop = 0;
        a.l.classList.remove("scrollable");
        a.j.style.transitionDuration = ".5s";
        a.j.style.transform = `translateY(${a.m+a.B}px)`;
        a.H.style.opacity = "0";
        a.A.style.transitionDelay = ".5s";
        Cb(a.A.offsetHeight);
        a.A.style.visibility = "hidden";
        for (const b of a.L) try {
            b()
        } catch (c) {
            console.error(c)
        }
    }

    function Dx(a, b) {
        a.j.style.transitionDuration = "0s";
        b = Math.max(Fx(a) + b, 0) + a.B;
        a.j.style.transform = `translateY(${b}px)`;
        Cb(a.j.offsetHeight);
        a.j.style.transitionDuration = ".5s"
    }

    function Ex(a) {
        const b = Fx(a);
        if (a.G) 50 < b ? Cx(a) : 0 !== b && Jx(a, 0);
        else {
            const c = a.m - a.C;
            b < c - 50 ? Jx(a, 0) : b > c + 50 ? Cx(a) : b !== c && Jx(a, a.m - a.C)
        }
    }

    function Fx(a) {
        return Number(((new DOMMatrix(a.j.style.transform ? ? null)).f - a.B).toFixed(1))
    }

    function Jx(a, b) {
        a.I = !1;
        0 === b && (a.G = !0, a.l.classList.add("scrollable"));
        a.A.style.transitionDelay = "0s";
        a.A.style.visibility = "visible";
        a.H.style.opacity = ".5";
        a.j.style.transform = `translateY(${b+a.B}px)`
    }
    var Kx = class {
        constructor(a, b, c) {
            this.win = a;
            this.C = b;
            this.m = c;
            this.L = [];
            this.N = new Map;
            this.G = !1;
            this.I = !0;
            this.D = null;
            b = new pg(a.document);
            this.H = b.ga("DIV", {
                "class": "cse-modal-background",
                tabindex: 1
            });
            var d = b.ga("DIV", {
                "class": "cse-drawer-handle-icon"
            });
            this.v = b.ga("DIV", {
                "class": "cse-drawer-handle"
            }, d);
            this.l = b.ga("DIV", {
                "class": "cse-drawer-contents"
            });
            this.j = b.ga("DIV", {
                "class": "cse-drawer"
            }, this.v, this.l);
            this.A = b.ga("DIV", {
                "class": "cse-drawer-container"
            }, this.H, this.j);
            this.K = b.ga("DIV", {
                "class": "adpub-drawer-root"
            });
            this.B = a.innerHeight - (c + 30 - 20);
            c = this.K.attachShadow({
                mode: "open"
            });
            d = c.appendChild;
            var e = this.m;
            const f = this.B;
            e = wv("<style>.cse-drawer-container {height: 100%; left: 0; position: fixed; top: 0; transition: visibility 0s linear .5s; visibility: hidden; width: 100%; z-index: " + X(100002) + ";}.cse-modal-background {background-color: black; height: 100vh; opacity: 0; overflow: hidden; position: absolute; transition: opacity .5s ease-in-out; width: 100%;}.cse-drawer {background: white; position: absolute; transform: translateY(" +
                X(e + f) + "px); transition: transform .5s ease-in-out; width: 100%;}.cse-drawer-handle {align-items: flex-end; border-radius: " + X(20) + "px " + X(20) + "px 0 0; background: white; display: flex; height: " + X(30) + "px; justify-content: center; margin-top: " + X(-20) + "px;}.cse-drawer-handle-icon {background: #dadce0; border-radius: 2px; height: 4px; margin-bottom: 8px; width: 50px;}.cse-drawer-contents {background: white; height: " + X(e) + "px; scrollbar-width: none; overflow: hidden;}.cse-drawer-scroller::-webkit-scrollbar {display: none;}.scrollable {overflow: auto;}</style>");
            d.call(c, Gg(b, rv(e)));
            c.appendChild(this.A);
            M(this.K, gw(a))
        }
        init() {
            this.win.document.body.appendChild(this.K);
            Bx(this)
        }
        T(a) {
            for (; this.l.firstChild;) this.l.removeChild(this.l.firstChild);
            this.l.appendChild(a)
        }
        show() {
            this.D = this.win.document.documentElement.scrollTop + this.win.document.body.scrollTop;
            Hx(this, "transform", `translateY(${-this.D}px)`);
            Hx(this, "position", "fixed");
            Hx(this, "width", "100%");
            Hx(this, "overflow", "hidden");
            Hx(this, "touch-action", "none");
            Hx(this, "scroll-behavior", "auto");
            this.A.style.transform =
                `translateY(${this.D}px)`;
            Jx(this, this.m - this.C)
        }
        ca(a) {
            this.L.push(a)
        }
    };

    function Lx(a) {
        if (a.j instanceof Kx || a.j instanceof Ax) a.j.init(), a.j.T(a.l), a.j instanceof Kx && Gx(a.j, a.l), a.j.ca(() => void ew(a.G)), Ir(1075, () => a.B.init(), a.win)
    }

    function Mx(a) {
        let b;
        a.m.id = "cse-overlay-div";
        M(a.m, {
            "background-color": "white",
            border: "none",
            "border-radius": "16px 16px 16px 16px",
            "box-shadow": "0 3px 10px rgb(34 25 25 / 40%)",
            display: "none",
            "flex-direction": "column",
            height: "90%",
            left: "2.5%",
            margin: "auto",
            overflow: "auto",
            position: "fixed",
            padding: "1%",
            top: "5%",
            transition: "all 0.25s linear",
            width: "95%",
            "z-index": 100002
        });
        b = a.v.createElement("DIV");
        b.id = "cse-overlay-close-button";
        M(b, {
            "background-image": "url(//www.google.com/images/nav_logo114.png)",
            "background-position": "-140px -230px",
            "background-repeat": "no-repeat",
            cursor: "pointer",
            display: "block",
            "float": "right",
            height: "12px",
            opacity: 1,
            position: "absolute",
            right: "15px",
            top: "15px",
            width: "12px"
        });
        a.A.classList.add("gsc-modal-background-image");
        a.A.setAttribute("tabindex", 0);
        a.win.document.body.appendChild(a.m);
        a.win.document.body.appendChild(a.A);
        const c = () => {
            "flex" === a.m.style.display && (a.m.style.display = "none");
            a.A.classList.remove("gsc-modal-background-image-visible");
            ew(a.G)
        };
        b.onclick =
            c;
        a.A.onclick = c;
        a.m.appendChild(b);
        a.m.appendChild(a.l);
        Ir(1075, () => a.B.init(), a.win)
    }

    function Nx(a) {
        const b = a.v.createElement("SCRIPT");
        var c = N `https://cse.google.com/cse.js?cx=9d449ff4a772956c6`;
        c = Lh(c, new Map([
            ["language", a.language]
        ]));
        rf(b, c);
        a.win.document.head.appendChild(b)
    }

    function Ox(a) {
        (function(c, d) {
            c[d] = c[d] || function() {
                (c[d].q = c[d].q || []).push(arguments)
            };
            c[d].t = 1 * new Date
        })(a.win, "_googCsa");
        const b = a.K.map(c => ({
            container: c,
            relatedSearches: 5
        }));
        a.win._googCsa("relatedsearch", {
            pubId: a.H,
            styleId: "5134551505",
            hl: a.language,
            fexp: a.I,
            channel: "AutoRsVariant",
            resultsPageBaseUrl: "http://google.com",
            resultsPageQueryParam: "q",
            relatedSearchTargeting: "content",
            relatedSearchResultClickedCallback: a.T.bind(a),
            relatedSearchUseResultCallback: !0
        }, b)
    }
    var Px = class {
        constructor(a, b, c, d, e, f, g, h, k, l) {
            this.win = a;
            this.K = b;
            this.language = d ? .j() || "en";
            this.N = d ? .v() || "Search results from ${website}";
            this.L = e;
            this.D = f;
            this.C = g;
            this.I = h;
            this.H = c.replace("ca", "partner");
            this.G = Zv(new cw(a), 1E5);
            this.v = new pg(a.document);
            this.m = this.v.createElement("DIV");
            this.A = this.v.createElement("DIV");
            this.l = this.v.createElement("IFRAME");
            this.B = new Yv(this.l, l.l ? l.j : "9d449ff4a772956c6", "auto-rs-prose", this.H, a.location.host, this.language, this.N, this.I, k);
            g ? (a = this.l, a =
                this.C ? 2 === ih() ? ix(this.win, a, {
                    Yc: .95,
                    Kc: .95,
                    zIndex: 100001,
                    Ia: !0
                }) : vw(this.win, a, {
                    Jc: "min(65vw, 768px)",
                    Bc: "",
                    Hc: !1,
                    zIndex: 100001,
                    Ia: !0
                }) : null) : this.D ? 2 === ih() ? (a = Math.round(.95 * this.win.innerHeight) - 30, a = new Kx(this.win, a, a)) : a = new Ax(this.win, Math.min(768, Math.round(.65 * this.win.innerWidth))) : a = null;
            this.j = a
        }
        init() {
            this.D || this.C || !this.win.document.querySelector('script[src*="cse.google.com/cse"]') ? 0 !== this.K.length && (this.C ? Ir(1075, () => this.B.init(), this.win) : this.D ? Lx(this) : (Mx(this), Nx(this)),
                Ir(1076, () => {
                    const a = this.v.createElement("SCRIPT");
                    rf(a, N `https://www.google.com/adsense/search/async-ads.js`);
                    this.win.document.head.appendChild(a)
                }, this.win), Ox(this), tx(this.L, {
                    sts: "ok"
                })) : tx(this.L, {
                sts: "pfec"
            })
        }
        T(a, b) {
            this.C || dw(this.G);
            this.D || this.C ? (Xv(this.B, a, b), (() => {
                const c = new ResizeObserver(async e => {
                        this.l.height = 0;
                        await new Promise(f => this.win.requestAnimationFrame(f));
                        this.l.height = e[0].target.scrollHeight
                    }),
                    d = () => {
                        const e = this.l.contentDocument ? .documentElement;
                        e ? c.observe(e) : (console.warn("iframe body missing"),
                            setTimeout(d, 1E3))
                    };
                d();
                this.j.show()
            })()) : (this.A.classList.add("gsc-modal-background-image-visible"), this.m.style.display = "flex", Xv(this.B, a, b))
        }
    };

    function Qx(a) {
        const b = xs(a.m.V),
            c = a.A.ya(a.B, () => a.remove());
        b.appendChild(c);
        a.v && (b.className = a.v);
        return {
            kf: b,
            ef: c
        }
    }
    class Rx {
        constructor(a, b, c, d) {
            this.B = a;
            this.m = b;
            this.A = c;
            this.v = d || null;
            this.j = null;
            this.l = new bm(null)
        }
        init() {
            const a = Qx(this);
            this.j = a.kf;
            Fs(this.m, this.j);
            P(this.l, a.ef)
        }
        remove() {
            this.j && this.j.parentNode && this.j.parentNode.removeChild(this.j);
            this.j = null;
            P(this.l, null)
        }
        C() {
            return this.l
        }
    };

    function Sx(a) {
        var b = wx(a.l, a.j);
        b = Tx(a.l, b, a.U, a.A, a.m);
        const c = Ux(b, a.l),
            d = Oo(a.j) ? .j() ? .j() || Oo(a.j) ? .v() || 0,
            e = Oo(a.j) ? .D() || !1,
            f = Oo(a.j) ? .G() || !1,
            g = Oo(a.j) ? .H() || !1,
            h = Vx(a.j);
        C(a.j, Un, 25) ? .j() || Ir(1074, () => (new Px(a.l, c, a.v, Oo(a.j) ? .B(), a.m, e, f, d, g, h)).init(), a.l)
    }
    var Wx = class {
        constructor(a, b, c, d, e, f) {
            this.l = a;
            this.j = c;
            this.m = new ux(a, b, Oo(this.j) || new io);
            this.v = d;
            this.U = e;
            this.A = f
        }
    };

    function Xx(a, b, c) {
        c = c ? D(c, Qn, 5) : [];
        const d = Bu(a.document, c),
            e = Cu();
        return b.filter(f => !(e(f) || d(f)))
    }

    function Tx(a, b, c, d, e) {
        b = Us(b, a).sort(Yx);
        return 0 == b.length ? (tx(e, {
            sts: "pfno"
        }), []) : d && (b = Xx(a, b, c), 0 == b.length) ? (tx(e, {
            sts: "pffa"
        }), []) : [b[Math.floor(b.length / 2)]]
    }

    function Yx(a, b) {
        return a.aa.j - b.aa.j
    }

    function Ux(a, b) {
        const c = [];
        for (let d = 0; d < a.length; d++) {
            const e = a[d],
                f = "autors-container-" + d,
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            (new Rx(b, e, new vx(g))).init();
            c.push(f)
        }
        return c
    }

    function Vx(a) {
        const b = Oo(a) ? .I() || !1;
        a = Oo(a) ? .A() || "";
        return new xx(b, a)
    };
    var Zx = {
            mh: "google_ads_preview",
            Vh: "google_mc_lab",
            li: "google_anchor_debug",
            ki: "google_bottom_anchor_debug",
            INTERSTITIAL: "google_ia_debug",
            Ii: "google_scr_debug",
            Ki: "google_ia_debug_allow_onclick",
            dj: "googleads",
            Fe: "google_pedestal_debug",
            wj: "google_responsive_slot_preview",
            vj: "google_responsive_dummy_ad",
            eh: "google_audio_sense",
            fh: "google_auto_gallery",
            hh: "google_auto_storify_swipeable",
            gh: "google_auto_storify_scrollable",
            fj: "google_pga_monetization"
        },
        $x = {
            google_bottom_anchor_debug: 1,
            google_anchor_debug: 2,
            google_ia_debug: 8,
            google_scr_debug: 9,
            googleads: 2,
            google_pedestal_debug: 30
        };
    var ay = {
        INTERSTITIAL: 1,
        BOTTOM_ANCHOR: 2,
        TOP_ANCHOR: 3,
        Aj: 4,
        1: "INTERSTITIAL",
        2: "BOTTOM_ANCHOR",
        3: "TOP_ANCHOR",
        4: "SCROLL_TRIGGERED_IMMERSIVE"
    };

    function by(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (-1 != a.indexOf(b)) return !0;
        b = cy(b);
        return "go" != b && -1 != a.indexOf(b) ? !0 : !1
    }

    function cy(a) {
        let b = "";
        Sg(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    }

    function dy() {
        var a = u.location;
        let b = !1;
        Sg(Zx, c => {
            by(a, c) && (b = !0)
        });
        return b
    }

    function ey(a, b) {
        switch (a) {
            case 1:
                return by(b, "google_ia_debug");
            case 2:
                return by(b, "google_bottom_anchor_debug");
            case 3:
                return by(b, "google_anchor_debug") || by(b, "googleads");
            case 4:
                return by(b, "google_scr_debug")
        }
    };
    var fy = (a, b, c) => {
        const d = [];
        C(a, zo, 18) && d.push(2);
        b.U && d.push(0);
        Oo(a) && 1 == ld(Oo(a), 1) && d.push(1);
        C(a, ho, 31) && 1 == ld(C(a, ho, 31), 1) && d.push(5);
        (C(a, co, 27) && 1 == ld(C(a, co, 27), 1) || by(c, "google_audio_sense")) && d.push(3);
        C(a, Co, 29) && d.push(4);
        return d
    };

    function gy(a, b) {
        const c = og(a).createElement("IMG");
        hy(a, c);
        c.src = "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg";
        M(c, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: null == b ? "auto" : "pointer"
        });
        b && c.addEventListener("click", d => {
            b();
            d.stopPropagation()
        });
        return c
    }

    function iy(a, b) {
        const c = b.document.createElement("button");
        hy(b, c);
        M(c, {
            display: "inline",
            "line-height": "24px",
            cursor: "pointer"
        });
        c.appendChild(b.document.createTextNode(a.l));
        c.addEventListener("click", d => {
            a.m();
            d.stopPropagation()
        });
        return c
    }

    function jy(a, b, c) {
        const d = og(b).createElement("IMG");
        d.src = "https://www.gstatic.com/adsense/autoads/icons/arrow_left_24px_grey_800.svg";
        d.setAttribute("aria-label", a.v);
        hy(b, d);
        M(d, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: "pointer"
        });
        d.addEventListener("click", e => {
            c();
            e.stopPropagation()
        });
        return d
    }

    function ky(a) {
        const b = a.document.createElement("ins");
        hy(a, b);
        M(b, {
            "float": "left",
            display: "inline-flex",
            padding: "8px 0px",
            "background-color": "#FFF",
            "border-radius": "0px 20px 20px 0px",
            "box-shadow": "0px 1px 2px 0px rgba(60,64,67,0.3), 0px 1px 3px 1px rgba(60,64,67,0.15)"
        });
        return b
    }
    class ly {
        constructor(a, b, c) {
            this.l = a;
            this.v = b;
            this.m = c;
            this.j = new bm(!1)
        }
        ya(a, b, c, d) {
            const e = gy(a, d),
                f = gy(a),
                g = iy(this, a),
                h = jy(this, a, c);
            a = ky(a);
            a.appendChild(e);
            a.appendChild(f);
            a.appendChild(g);
            a.appendChild(h);
            this.j.Z(k => {
                M(e, {
                    display: k ? "none" : "inline"
                });
                M(f, {
                    display: k ? "inline" : "none"
                });
                k ? (M(g, {
                        "line-height": "24px",
                        "max-width": "100vw",
                        opacity: "1",
                        transition: "line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms"
                    }), M(h, {
                        margin: "0px 12px 0px 8px",
                        opacity: 1,
                        width: "24px",
                        transition: "margin 100ms 50ms, opacity 50ms 50ms, width 100ms 50ms"
                    })) :
                    (M(g, {
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        transition: "line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms"
                    }), M(h, {
                        margin: "0",
                        opacity: "0",
                        width: "0",
                        transition: "margin 100ms, opacity 50ms, width 100ms"
                    }))
            }, !0);
            return a
        }
        Qd() {
            return 40
        }
        ie() {
            P(this.j, !1);
            return 0
        }
        ke() {
            P(this.j, !0)
        }
    }

    function hy(a, b) {
        M(b, gw(a));
        M(b, {
            "font-family": "Arial,sans-serif",
            "font-weight": "bold",
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: "#3C4043",
            "user-select": "none"
        })
    };

    function my(a, b) {
        const c = b.document.createElement("button");
        ny(a, b, c);
        b = {
            width: "100%",
            "text-align": "center",
            display: "block",
            padding: "8px 0px",
            "background-color": a.l
        };
        a.j && (b["border-top"] = a.j, b["border-bottom"] = a.j);
        M(c, b);
        c.addEventListener("click", d => {
            a.B();
            d.stopPropagation()
        });
        return c
    }

    function oy(a, b, c, d) {
        const e = b.document.createElement("div");
        M(e, gw(b));
        M(e, {
            "align-items": "center",
            "background-color": a.l,
            display: "flex",
            "justify-content": "center"
        });
        const f = b.document.createElement("span");
        f.appendChild(b.document.createTextNode(d));
        M(f, gw(b));
        M(f, {
            "font-family": "Arial,sans-serif",
            "font-size": "12px",
            padding: "8px 0px"
        });
        b = b.matchMedia("(min-width: 768px)");
        d = g => {
            g.matches ? (M(e, {
                    "flex-direction": "row"
                }), a.j && M(e, {
                    "border-top": a.j,
                    "border-bottom": a.j
                }), M(f, {
                    "margin-left": "8px",
                    "text-align": "start"
                }),
                M(c, {
                    border: "0",
                    "margin-right": "8px",
                    width: "auto"
                })) : (M(e, {
                border: "0",
                "flex-direction": "column"
            }), M(f, {
                "margin-left": "0",
                "text-align": "center"
            }), M(c, {
                "margin-right": "0",
                width: "100%"
            }), a.j && M(c, {
                "border-top": a.j,
                "border-bottom": a.j
            }))
        };
        d(b);
        b.addEventListener("change", d);
        e.appendChild(c);
        e.appendChild(f);
        return e
    }

    function ny(a, b, c) {
        M(c, gw(b));
        M(c, {
            "font-family": "Arial,sans-serif",
            "font-weight": a.C,
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: a.D,
            "user-select": "none",
            cursor: "pointer"
        })
    }
    class py {
        constructor(a, b, c, d, e, f = null, g = null, h = null) {
            this.A = a;
            this.B = b;
            this.D = c;
            this.l = d;
            this.C = e;
            this.v = f;
            this.j = g;
            this.m = h
        }
        ya(a) {
            const b = a.document.createElement("div");
            ny(this, a, b);
            M(b, {
                display: "inline-flex",
                padding: "8px 0px",
                "background-color": this.l
            });
            if (this.v) {
                var c = og(a).createElement("IMG");
                c.src = this.v;
                ny(this, a, c);
                M(c, {
                    margin: "0px 8px 0px 0px",
                    width: "24px",
                    height: "24px"
                })
            } else c = null;
            c && b.appendChild(c);
            c = a.document.createElement("span");
            ny(this, a, c);
            M(c, {
                "line-height": "24px"
            });
            c.appendChild(a.document.createTextNode(this.A));
            b.appendChild(c);
            c = my(this, a);
            c.appendChild(b);
            return this.m ? oy(this, a, c, this.m) : c
        }
    };
    var qy = (a, b) => {
        b = b.filter(c => {
            var d = C(c, un, 4);
            return 5 == w(d, 1) && 1 == w(c, 8)
        });
        b = os(b, a);
        a = Us(b, a);
        a.sort((c, d) => d.aa.j - c.aa.j);
        return a[0] || null
    };

    function ry({
        J: a,
        Tc: b,
        Rc: c,
        Cd: d,
        sa: e,
        Ze: f
    }) {
        let g = 0;
        try {
            g |= a != a.top ? 512 : 0;
            const h = Math.min(a.screen.width || 0, a.screen.height || 0);
            g |= h ? 320 > h ? 8192 : 0 : 2048;
            g |= a.navigator && sy(a.navigator.userAgent) ? 1048576 : 0;
            g = b ? g | (a.innerHeight >= b ? 0 : 1024) : g | (a.innerHeight >= a.innerWidth ? 0 : 8);
            g |= El(a, c);
            g |= Fl(a)
        } catch {
            g |= 32
        }
        switch (d) {
            case 2:
                ty(a, e) && (g |= 16777216);
                break;
            case 1:
                uy(a, e) && (g |= 16777216)
        }
        f && vy(a, e) && (g |= 16777216);
        return g
    }

    function sy(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    }
    var ty = (a, b = null) => {
            const c = wy(a.innerWidth, 3, 0, Math.min(Math.round(a.innerWidth / 320 * 50), xy) + 15, 3);
            return yy(a, c, b)
        },
        uy = (a, b = null) => {
            const c = a.innerWidth,
                d = a.innerHeight,
                e = Math.min(Math.round(a.innerWidth / 320 * 50), xy) + 15,
                f = wy(c, 3, d - e, d, 3);
            25 < e && f.push({
                x: c - 25,
                y: d - 25
            });
            return yy(a, f, b)
        };

    function vy(a, b = null) {
        return null != zy(a, b)
    }

    function zy(a, b = null) {
        var c = a.innerWidth;
        const d = a.innerHeight,
            e = V(iq);
        c = wy(c, 10, d - e, d, 10);
        return Ay(a, c, b)
    }

    function By(a, b) {
        const c = a.innerWidth,
            d = a.innerHeight;
        let e = d;
        for (; e > b;) {
            var f = wy(c, 9, e - b, e, 9);
            f = Ay(a, f);
            if (!f) return d - e;
            e = f.getBoundingClientRect().top - 1
        }
        return null
    }

    function yy(a, b, c = null) {
        return null != Ay(a, b, c)
    }

    function Ay(a, b, c = null) {
        for (const d of b)
            if (b = Cy(a, d, c)) return b;
        return null
    }

    function Cy(a, b, c = null) {
        const d = Dy(a.document, b.x, b.y);
        return d ? Ey(d, a, b, c) || Fy(d, a, b, c) || null : null
    }

    function Dy(a, b, c) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b, c));
        return a.elementFromPoint(b, c)
    }

    function Fy(a, b, c, d = null) {
        const e = b.document;
        for (a = a.offsetParent; a && a !== e.body; a = a.offsetParent) {
            const f = Ey(a, b, c, d);
            if (f) return f
        }
        return null
    }

    function wy(a, b, c, d, e) {
        const f = [];
        for (let l = 0; l < e; l++)
            for (let m = 0; m < b; m++) {
                var g = f,
                    h = b - 1,
                    k = e - 1;
                g.push.call(g, {
                    x: (0 === h ? 0 : m / h) * a,
                    y: c + (0 === k ? 0 : l / k) * (d - c)
                })
            }
        return f
    }

    function Ey(a, b, c, d = null) {
        if ("fixed" !== Sh(a, "position")) return null;
        var e = "GoogleActiveViewInnerContainer" === a.getAttribute("class") || 1 >= Vh(a).width && 1 >= Vh(a).height ? !0 : !1;
        d && Ci(d, "ach_evt", {
            url: b.location.href,
            tn: a.tagName,
            id: a.getAttribute("id") ? ? "",
            cls: a.getAttribute("class") ? ? "",
            ign: String(e),
            pw: b.innerWidth,
            ph: b.innerHeight,
            x: c.x,
            y: c.y
        }, !0, 1);
        return e ? null : a
    }
    const xy = 90 * 1.38;

    function Gy(a) {
        if (a.D) {
            const b = Ll(a.j);
            if (b > a.l + 100 || b < a.l - 100) Hy(a), a.l = Hl(a.j)
        }
        a.G && a.j.clearTimeout(a.G);
        a.G = a.j.setTimeout(() => Iy(a), 200)
    }

    function Iy(a) {
        var b = Hl(a.j);
        a.l && a.l > b && (a.l = b);
        b = Ll(a.j);
        b >= a.l - 100 && (a.l = Math.max(a.l, b), Jy(a))
    }

    function Ky(a) {
        a.j.removeEventListener("scroll", a.I)
    }

    function Hy(a) {
        a.D = !1;
        const b = a.A.ie();
        switch (b) {
            case 0:
                P(a.v, a.B);
                break;
            case 1:
                a.m && (M(a.m, {
                    display: "none"
                }), P(a.v, null));
                break;
            default:
                throw Error("Unhandled OnHideOutcome: " + b);
        }
    }

    function Jy(a) {
        a.m || (a.m = Ly(a));
        M(a.m, {
            display: "block"
        });
        a.D = !0;
        a.A.ke();
        P(a.v, a.B)
    }

    function Ly(a) {
        var b = By(a.j, a.A.Qd() + 60);
        b = null == b ? 30 : b + 30;
        const c = a.j.document.createElement("div");
        M(c, gw(a.j));
        M(c, {
            position: "fixed",
            left: "0px",
            bottom: b + "px",
            width: "100vw",
            "text-align": "center",
            "z-index": 2147483642,
            display: "none",
            "pointer-events": "none"
        });
        a.B = a.A.ya(a.j, () => a.remove(), () => {
            Ky(a);
            Hy(a)
        }, () => {
            Ky(a);
            Jy(a)
        });
        c.appendChild(a.B);
        a.H && (c.className = a.H);
        a.j.document.body.appendChild(c);
        return c
    }
    class My {
        constructor(a, b, c) {
            this.j = a;
            this.A = b;
            this.B = null;
            this.v = new bm(null);
            this.H = c || null;
            this.m = null;
            this.D = !1;
            this.l = 0;
            this.G = null;
            this.I = () => Gy(this)
        }
        init() {
            this.j.addEventListener("scroll", this.I);
            this.l = Hl(this.j);
            Iy(this)
        }
        remove() {
            this.m && this.m.parentNode && this.m.parentNode.removeChild(this.m);
            this.m = null;
            Ky(this);
            P(this.v, null)
        }
        C() {
            return this.v
        }
    };

    function Ny(a) {
        P(a.B, 0);
        null != a.m && (a.m.remove(), a.m = null);
        null != a.l && (a.l.remove(), a.l = null)
    }

    function Oy(a) {
        a.l = new My(a.A, a.H, a.D);
        a.l.init();
        km(a.v, a.l.C());
        P(a.B, 2)
    }
    class Py {
        constructor(a, b, c, d, e) {
            this.A = a;
            this.G = b;
            this.I = c;
            this.H = d;
            this.D = e;
            this.B = new bm(0);
            this.v = new bm(null);
            this.l = this.m = this.j = null
        }
        init() {
            this.G ? (this.m = new Rx(this.A, this.G, this.I, this.D), this.m.init(), km(this.v, this.m.C()), P(this.B, 1), null == this.j && (this.j = new Pm(this.A), this.j.init(2E3)), this.j.addListener(() => {
                Ny(this);
                Oy(this)
            })) : Oy(this)
        }
        remove() {
            Ny(this);
            this.j && (this.j.xa(), this.j = null)
        }
        C() {
            return this.v
        }
    };
    var Qy = (a, b, c, d, e) => {
        a = new Py(a, qy(a, e), new py(b, d, "#FFF", "#4A4A4A", "normal"), new ly(b, c, d), "google-dns-link-placeholder");
        a.init();
        return a
    };
    var Ry = a => a.googlefc = a.googlefc || {},
        Sy = a => {
            a = a.googlefc = a.googlefc || {};
            return a.ccpa = a.ccpa || {}
        };

    function Ty(a) {
        var b = Sy(a.j);
        if (Uy(b.getInitialCcpaStatus(), b.InitialCcpaStatusEnum)) {
            var c = b.getLocalizedDnsText();
            b = b.getLocalizedDnsCollapseText();
            null != c && null != b && (a.l = Qy(a.j, c, b, () => Vy(a), a.v))
        }
    }

    function Wy(a) {
        const b = Ry(a.j);
        Sy(a.j).overrideDnsLink = !0;
        b.callbackQueue = b.callbackQueue || [];
        b.callbackQueue.push({
            INITIAL_CCPA_DATA_READY: () => Ty(a)
        })
    }

    function Vy(a) {
        dw(a.m);
        Sy(a.j).openConfirmationDialog(b => {
            b && a.l && (a.l.remove(), a.l = null);
            ew(a.m)
        })
    }
    class Xy {
        constructor(a, b, c) {
            this.j = a;
            this.m = Zv(b, 2147483643);
            this.v = c;
            this.l = null
        }
    }

    function Uy(a, b) {
        switch (a) {
            case b.CCPA_DOES_NOT_APPLY:
            case b.OPTED_OUT:
                return !1;
            case b.NOT_OPTED_OUT:
                return !0;
            default:
                return !0
        }
    };

    function Yy(a) {
        const b = a.document.createElement("ins");
        Zy(a, b);
        M(b, {
            display: "flex",
            padding: "8px 0px",
            width: "100%"
        });
        return b
    }

    function $y(a, b, c, d) {
        const e = og(a).createElement("IMG");
        e.src = b;
        d && e.setAttribute("aria-label", d);
        Zy(a, e);
        M(e, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: "pointer"
        });
        e.addEventListener("click", f => {
            c();
            f.stopPropagation()
        });
        return e
    }

    function az(a, b) {
        const c = b.document.createElement("span");
        Zy(b, c);
        M(c, {
            "line-height": "24px",
            cursor: "pointer"
        });
        c.appendChild(b.document.createTextNode(a.v));
        c.addEventListener("click", d => {
            a.l();
            d.stopPropagation()
        });
        return c
    }

    function bz(a, b) {
        const c = b.document.createElement("span");
        c.appendChild(b.document.createTextNode(a.m));
        M(c, gw(b));
        M(c, {
            "border-top": "11px solid #ECEDED",
            "font-family": "Arial,sans-serif",
            "font-size": "12px",
            "line-height": "1414px",
            padding: "8px 32px",
            "text-align": "center"
        });
        return c
    }

    function cz(a) {
        const b = a.document.createElement("div");
        M(b, gw(a));
        M(b, {
            "align-items": "flex-start",
            "background-color": "#FFF",
            "border-radius": "0px 20px 20px 0px",
            "box-shadow": "0px 1px 3px 1px rgba(60,64,67,0.5)",
            display: "inline-flex",
            "flex-direction": "column",
            "float": "left"
        });
        return b
    }
    class dz {
        constructor(a, b, c, d) {
            this.v = a;
            this.A = b;
            this.m = c;
            this.l = d;
            this.j = new bm(!1)
        }
        ya(a, b, c, d) {
            c = Yy(a);
            const e = $y(a, "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg", d),
                f = $y(a, "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg", this.l),
                g = az(this, a),
                h = $y(a, "https://www.gstatic.com/adsense/autoads/icons/close_24px_grey_700.svg", b, this.A);
            M(h, {
                "margin-left": "auto"
            });
            c.appendChild(e);
            c.appendChild(f);
            c.appendChild(g);
            c.appendChild(h);
            const k = bz(this, a);
            a = cz(a);
            a.appendChild(c);
            a.appendChild(k);
            this.j.Z(l => {
                M(e, {
                    display: l ? "none" : "inline"
                });
                M(f, {
                    display: l ? "inline" : "none"
                });
                l ? (M(g, {
                        "line-height": "24px",
                        "max-width": "100vw",
                        opacity: "1",
                        transition: "line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms"
                    }), M(h, {
                        "margin-right": "12px",
                        opacity: 1,
                        width: "24px",
                        transition: "margin 50ms, opacity 50ms 50ms, width 50ms"
                    }), M(k, {
                        "border-width": "1px",
                        "line-height": "14px",
                        "max-width": "100vw",
                        opacity: "1",
                        padding: "8px 32px",
                        transition: "border-width 0s 50ms, line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms, padding 50ms"
                    })) :
                    (M(g, {
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        transition: "line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms"
                    }), M(h, {
                        "margin-right": "0",
                        opacity: "0",
                        width: "0",
                        transition: "margin 50ms 50ms, opacity 50ms, width 50ms 50ms"
                    }), M(k, {
                        "border-width": "0px",
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        padding: "0",
                        transition: "border-width 0s 50ms, line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms, padding 50ms 50ms"
                    }))
            }, !0);
            return a
        }
        Qd() {
            return 71
        }
        ie() {
            P(this.j, !1);
            return 0
        }
        ke() {
            P(this.j, !0)
        }
    }

    function Zy(a, b) {
        M(b, gw(a));
        M(b, {
            "font-family": "Arial,sans-serif",
            "font-weight": "bold",
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: "#1A73E8",
            "user-select": "none"
        })
    };

    function ez(a) {
        fz(a.l, b => {
            var c = a.v,
                d = b.bg,
                e = b.cf,
                f = b.Pe;
            b = b.showRevocationMessage;
            (new Py(c, qy(c, a.m), new py(d, b, "#1A73E8", "#FFF", "bold", "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_blue_600.svg", "2px solid #ECEDED", f), new dz(d, e, f, b), "google-revocation-link-placeholder")).init()
        }, () => {
            ew(a.j)
        })
    }
    class gz {
        constructor(a, b, c, d) {
            this.v = a;
            this.j = Zv(b, 2147483643);
            this.m = c;
            this.l = d
        }
    };
    var hz = a => {
        if (!a || null == w(a, 1)) return !1;
        a = w(a, 1);
        switch (a) {
            case 1:
                return !0;
            case 2:
                return !1;
            default:
                throw Error("Unhandled AutoConsentUiStatus: " + a);
        }
    };

    function iz(a) {
        if (!0 !== a.l.adsbygoogle_ama_fc_has_run) {
            var b = !1;
            hz(a.j) && (b = new gz(a.l, a.A, a.v || D(a.j, xo, 4), a.m), dw(b.j), ez(b), b = !0);
            var c;
            a: if ((c = a.j) && null != w(c, 3)) switch (c = w(c, 3), c) {
                case 1:
                    c = !0;
                    break a;
                case 2:
                    c = !1;
                    break a;
                default:
                    throw Error("Unhandled AutoCcpaUiStatus: " + c);
            } else c = !1;
            c && (Wy(new Xy(a.l, a.A, a.v || D(a.j, xo, 4))), b = !0);
            if (c = (c = a.j) ? !0 === y(c, 5) : !1) c = ((c = a.j) ? !0 === y(c, 6) : !1) || T(Ap);
            c && (b = !0);
            b && (a.m.start(), a.l.adsbygoogle_ama_fc_has_run = !0)
        }
    }
    class jz {
        constructor(a, b, c, d, e) {
            this.l = a;
            this.m = b;
            this.j = c;
            this.A = d;
            this.v = e || null
        }
    };
    var kz = (a, b, c, d, e, f) => {
            try {
                const g = a.j,
                    h = Pg("SCRIPT", g);
                h.async = !0;
                rf(h, b);
                g.head.appendChild(h);
                h.addEventListener("load", () => {
                    e();
                    d && g.head.removeChild(h)
                });
                h.addEventListener("error", () => {
                    0 < c ? kz(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
                })
            } catch (g) {
                f()
            }
        },
        lz = (a, b, c = () => {}, d = () => {}) => {
            kz(og(a), b, 0, !1, c, d)
        };
    var mz = (a = null) => {
        a = a || u;
        return a.googlefc || (a.googlefc = {})
    };
    ce(tl).map(a => Number(a));
    ce(ul).map(a => Number(a));
    var nz = (a, b) => {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = Pg("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    const oz = a => {
        void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
        void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
        return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
    };

    function pz(a) {
        if (!1 === a.gdprApplies) return !0;
        void 0 === a.internalErrorState && (a.internalErrorState = oz(a));
        return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (ui({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
    }

    function qz(a) {
        return pz(a) ? !1 !== a.gdprApplies && "tcunavailable" !== a.tcString && void 0 !== a.gdprApplies && "string" === typeof a.tcString && a.tcString.length ? rz(a, "1") : !0 : !1
    }

    function rz(a, b) {
        a: {
            if (a.publisher && a.publisher.restrictions) {
                var c = a.publisher.restrictions[b];
                if (void 0 !== c) {
                    c = c["755"];
                    break a
                }
            }
            c = void 0
        }
        if (0 === c) return !1;a.purpose && a.vendor ? (c = a.vendor.consents, (c = !(!c || !c["755"])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
        return b
    }

    function sz(a) {
        var b = ["3", "4"];
        return !1 === a.gdprApplies ? !0 : b.every(c => rz(a, c))
    }

    function tz(a) {
        if (a.l) return a.l;
        a.l = hh(a.m, "__tcfapiLocator");
        return a.l
    }

    function uz(a) {
        return "function" === typeof a.m.__tcfapi || null != tz(a)
    }

    function vz(a, b, c, d) {
        c || (c = () => {});
        if ("function" === typeof a.m.__tcfapi) a = a.m.__tcfapi, a(b, 2, c, d);
        else if (tz(a)) {
            wz(a);
            const e = ++a.H;
            a.C[e] = c;
            a.l && a.l.postMessage({
                __tcfapiCall: {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }
            }, "*")
        } else c({}, !1)
    }

    function xz(a, b) {
        let c = {
            internalErrorState: 0,
            internalBlockOnErrors: a.A
        };
        const d = Sd(() => b(c));
        let e = 0; - 1 !== a.G && (e = setTimeout(() => {
            e = 0;
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, a.G));
        vz(a, "addEventListener", f => {
            f && (c = f, c.internalErrorState = oz(c), c.internalBlockOnErrors = a.A, pz(c) ? (0 != c.internalErrorState && (c.tcString = "tcunavailable"), vz(a, "removeEventListener", null, c.listenerId), (f = e) && clearTimeout(f), d()) : ("error" === c.cmpStatus || 0 !== c.internalErrorState) && (f = e) && clearTimeout(f))
        })
    }

    function wz(a) {
        a.v || (a.v = b => {
            try {
                var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                a.C[c.callId](c.returnValue, c.success)
            } catch (d) {}
        }, L(a.m, "message", a.v))
    }
    class yz extends Dk {
        constructor(a, b = {}) {
            super();
            this.m = a;
            this.l = null;
            this.C = {};
            this.H = 0;
            this.G = b.jg ? ? 500;
            this.A = b.We ? ? !1;
            this.v = null
        }
        j() {
            this.C = {};
            this.v && (Yd(this.m, "message", this.v), delete this.v);
            delete this.C;
            delete this.m;
            delete this.l;
            super.j()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.A
            };
            const c = Sd(() => a(b));
            let d = 0; - 1 !== this.G && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.G));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = oz(b), b.internalBlockOnErrors =
                    this.A, g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                vz(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && vz(this, "removeEventListener", null, a.listenerId)
        }
    };

    function fz(a, b, c) {
        const d = mz(a.j);
        d.callbackQueue = d.callbackQueue || [];
        d.callbackQueue.push({
            CONSENT_DATA_READY: () => {
                const e = mz(a.j),
                    f = new yz(a.j);
                uz(f) && xz(f, g => {
                    300 === g.cmpId && g.tcString && "tcunavailable" !== g.tcString && b({
                        bg: e.getDefaultConsentRevocationText(),
                        cf: e.getDefaultConsentRevocationCloseText(),
                        Pe: e.getDefaultConsentRevocationAttestationText(),
                        showRevocationMessage: () => e.showRevocationMessage()
                    })
                });
                c()
            }
        })
    }

    function zz(a) {
        const b = te(Ld("https://fundingchoicesmessages.google.com/i/%{id}?ers=%{ers}"), {
            id: a.l,
            ers: 2
        });
        lz(a.j, b, () => {}, () => {})
    }
    class Az {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
        start() {
            if (this.j === this.j.top) try {
                nz(this.j, "googlefcPresent"), zz(this)
            } catch (a) {}
        }
    };
    var Bz = (a, b, c) => {
        const d = C(a, ro, 6);
        if (!d) return [];
        c = Pu(d.j(), c);
        return (a = a.j()) && y(a, 11) ? c.map(e => Rs(e)) : c.map(e => {
            const f = tn();
            return new ps(new Ls(e.sc, e.tc), new Js, new Ks(b), !0, 2, [], f, e.l, null, null, null, e.m, e.j)
        })
    };
    var Cz = class extends K {
        constructor(a) {
            super(a)
        }
        getHeight() {
            return ed(this, 2)
        }
    };

    function Dz(a, b) {
        return x(a, 1, b)
    }

    function Ez(a, b) {
        return cd(a, 2, b)
    }
    var Gz = class extends K {
            constructor(a) {
                super(a, -1, Fz)
            }
        },
        Fz = [2];
    var Iz = class extends K {
            constructor() {
                super(void 0, -1, Hz)
            }
        },
        Hz = [5];
    var Jz = class extends K {
            constructor() {
                super()
            }
        },
        Kz = [1, 2];

    function Lz(a) {
        return new wn(["pedestal_container"], {
            google_reactive_ad_format: 30,
            google_phwr: 2.189,
            google_ad_width: Math.floor(a),
            google_ad_format: "autorelaxed",
            google_full_width_responsive: !0,
            google_enable_content_recommendations: !0,
            google_content_recommendation_ui_type: "pedestal"
        })
    }
    class Mz {
        j(a) {
            return Lz(Math.floor(a.l))
        }
    };

    function Nz(a) {
        var b = ["Could not locate a suitable placement in the content below the fold."];
        a = Al(a) ? .tagSpecificState[1];
        (a = null == a ? null : 4 === a.debugCard ? .getAdType() ? a.debugCard : null) && a.displayAdLoadedContent(b)
    };
    var Oz = class extends K {
        constructor() {
            super()
        }
    };

    function Pz(a, b) {
        if (b) {
            var c = b.adClient;
            if ("string" === typeof c && c) {
                a.uc = c;
                a.m = !!b.adTest;
                c = b.pubVars;
                ta(c) && (a.F = c);
                if (Array.isArray(b.fillMessage) && 0 < b.fillMessage.length) {
                    a.B = {};
                    for (d of b.fillMessage) a.B[d.key] = d.value
                }
                a.v = b.adWidth;
                a.l = b.adHeight;
                ai(a.v) && ai(a.l) || Rk("rctnosize", b);
                var d = !0
            } else d = !1
        } else d = !1;
        return d && a.D(b)
    }
    class Qz {
        constructor() {
            this.B = this.F = this.m = this.uc = null;
            this.l = this.v = 0
        }
        D() {
            return !0
        }
    };

    function Rz(a, b = []) {
        const c = Date.now();
        return mb(b, d => c - d < 1E3 * a)
    }

    function Sz(a, b) {
        try {
            const c = a.getItem("__lsv__");
            if (!c) return [];
            let d;
            try {
                d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || pb(d, e => !Number.isInteger(e))) return a.removeItem("__lsv__"), [];
            d = Rz(b, d);
            d.length || a ? .removeItem("__lsv__");
            return d
        } catch (c) {
            return null
        }
    }

    function Tz(a, b) {
        var c;
        if (!(c = 0 >= b) && !(c = null == a)) {
            try {
                a.setItem("__storage_test__", "__storage_test__");
                const e = a.getItem("__storage_test__");
                a.removeItem("__storage_test__");
                var d = "__storage_test__" === e
            } catch (e) {
                d = !1
            }
            c = !d
        }
        return c ? null : Sz(a, b)
    };
    var Uz = (a, b, c) => {
        let d = 0;
        try {
            d |= a != a.top ? 512 : 0;
            d |= Fl(a);
            d |= El(a);
            d |= a.innerHeight >= a.innerWidth ? 0 : 8;
            d |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            var e;
            if (e = b) {
                var f = Tz(c, 3600);
                e = !(f && 1 > f.length)
            }
            e && (d |= 134217728);
            T(Zp) && (d |= 128)
        } catch (g) {
            d |= 32
        }
        return d
    };
    class Vz extends Qz {
        constructor() {
            super();
            this.A = !1;
            this.j = null;
            this.C = !1
        }
        D(a) {
            this.A = !!a.enableAma;
            var b = a.amaConfig;
            if (b) try {
                var c = Qo(b)
            } catch (d) {
                c = null
            } else c = null;
            this.j = c;
            Array.isArray(a.fillMessage) && (this.C = !0);
            return !0
        }
    };
    const Wz = {};

    function Xz(a, b, c) {
        let d = Yz(a, c, b);
        if (!d) return !0;
        let e = -1;
        const f = c.B.l;
        for (; d.Cb && d.Cb.length;) {
            const h = d.Cb.shift();
            var g = ys(h.V);
            const k = h.aa.j,
                l = !!c.m.jd || !!c.m.od || c.Da() || !!c.m.Hd || k > e;
            g = !g || g <= d.Mb;
            if (l && g && Zz(c, h, {
                    ec: d.Mb
                })) {
                e = k;
                if (d.Lb.j.length + 1 >= f) return !0;
                d = Yz(a, c, b);
                if (!d) return !0
            }
        }
        return c.v
    }
    const Yz = (a, b, c) => {
        var d = b.B.l,
            e = b.B.v,
            f = b.B;
        f = Dt(b.R(), f.j ? f.j.mb : void 0, d);
        if (f.j.length >= d) return null;
        e ? (d = f.l || (f.l = O(f.m).scrollHeight || null), e = !d || 0 > d ? -1 : f.l * e - Jt(f)) : e = void 0;
        a = null == e || 50 <= e ? $z(b, f, {
            types: a
        }, c) : null;
        return {
            Lb: f,
            Mb: e,
            Cb: a
        }
    };
    Wz[2] = Ca(function(a, b) {
        a = $z(b, Dt(b.R()), {
            types: a,
            Qa: mt(b.R())
        }, 2);
        if (0 == a.length) return !0;
        for (var c = 0; c < a.length; c++)
            if (Zz(b, a[c])) return !0;
        return b.v ? (b.A.push(11), !0) : !1
    }, [0]);
    Wz[5] = Ca(Xz, [0], 5);
    Wz[10] = Ca(function(a, b) {
        a = [];
        const c = b.ca;
        c.includes(3) && a.push(2);
        c.includes(1) && a.push(0);
        c.includes(2) && !T(np) && a.push(1);
        return Xz(a, 10, b)
    }, 10);
    Wz[3] = function(a) {
        if (!a.v) return !1;
        var b = $z(a, Dt(a.R()), {
            types: [0],
            Qa: mt(a.R())
        }, 3);
        if (0 == b.length) return !0;
        for (var c = b.length - 1; 0 <= c; c--)
            if (Zz(a, b[c])) return !0;
        a.A.push(11);
        return !0
    };
    const aA = a => {
            var b;
            a.m.Be ? b = new it(0, null, [], 3, null) : b = mt(a.R());
            return {
                types: [0],
                Qa: b
            }
        },
        cA = a => {
            const b = a.R().document.body.getBoundingClientRect().width;
            bA(a, Lz(b))
        },
        eA = (a, b) => {
            var c = aA(a);
            c.Yf = [5];
            c = $z(a, Dt(a.R()), c, 8);
            dA(a, c.reverse(), b)
        },
        dA = (a, b, c) => {
            for (const d of b)
                if (b = c.j(d.aa), Zz(a, d, {
                        vc: b
                    })) return !0;
            return !1
        };
    Wz[8] = function(a) {
        var b = a.R().document;
        if ("complete" != b.readyState) return b.addEventListener("readystatechange", () => Wz[8](a), {
            once: !0
        }), !0;
        if (!a.v) return !1;
        if (!a.ac()) return !0;
        b = aA(a);
        b.cd = [2, 4, 5];
        b = $z(a, Dt(a.R()), b, 8);
        const c = new Mz;
        if (dA(a, b, c)) return !0;
        if (a.m.Kd) switch (a.m.ne || 0) {
            case 1:
                eA(a, c);
                break;
            default:
                cA(a)
        }
        return !0
    };
    Wz[6] = Ca(Xz, [2], 6);
    Wz[7] = Ca(Xz, [1], 7);
    Wz[9] = function(a) {
        const b = Yz([0, 2], a, 9);
        if (!b || !b.Cb) return a.A.push(17), Nz(a.R()), a.v;
        for (const e of b.Cb) {
            var c = e;
            var d = a.m.Ic || null;
            null == d ? c = null : (d = zs(c.V, new fA, new gA(d, a.R())), c = new Gs(d, c.Y(), c.aa));
            if (c && !(ys(c.V) > b.Mb) && Zz(a, c, {
                    ec: b.Mb,
                    Ac: !0
                })) return a = c.V.N, ws(e.V, 0 < a.length ? a[0] : null), !0
        }
        a.A.push(17);
        Nz(a.R());
        return a.v
    };
    class fA {
        l(a, b, c, d) {
            return Ar(d.document, a, b)
        }
        m(a) {
            return O(a).clientHeight || 0
        }
    };
    var hA = class {
        constructor(a, b, c) {
            this.l = a;
            this.j = b;
            this.Lb = c
        }
        ha(a) {
            return this.j ? uu(this.l, this.j, a, this.Lb) : tu(this.l, a, this.Lb)
        }
        ia() {
            return this.j ? 16 : 9
        }
    };
    var iA = class {
        constructor(a) {
            this.wc = a
        }
        ha(a) {
            return Bu(a.document, this.wc)
        }
        ia() {
            return 11
        }
    };
    var jA = class {
        constructor(a) {
            this.gb = a
        }
        ha(a) {
            return yu(this.gb, a)
        }
        ia() {
            return 13
        }
    };
    var kA = class {
        ha(a) {
            return ru(a)
        }
        ia() {
            return 12
        }
    };
    var lA = class {
        constructor(a) {
            this.ub = a
        }
        ha() {
            return wu(this.ub)
        }
        ia() {
            return 2
        }
    };
    var mA = class {
        constructor(a) {
            this.j = a
        }
        ha() {
            return zu(this.j)
        }
        ia() {
            return 3
        }
    };
    var nA = class {
        ha() {
            return Cu()
        }
        ia() {
            return 17
        }
    };
    var oA = class {
        constructor(a) {
            this.j = a
        }
        ha() {
            return vu(this.j)
        }
        ia() {
            return 1
        }
    };
    var pA = class {
        ha() {
            return Qd(qs)
        }
        ia() {
            return 7
        }
    };
    var qA = class {
        constructor(a) {
            this.cd = a
        }
        ha() {
            return xu(this.cd)
        }
        ia() {
            return 6
        }
    };
    var rA = class {
        constructor(a) {
            this.j = a
        }
        ha() {
            return Au(this.j)
        }
        ia() {
            return 5
        }
    };
    var sA = class {
        constructor(a, b) {
            this.minWidth = a;
            this.maxWidth = b
        }
        ha() {
            return Ca(Du, this.minWidth, this.maxWidth)
        }
        ia() {
            return 10
        }
    };
    var tA = class {
        constructor(a) {
            this.v = a.l.slice(0);
            this.l = a.j.slice(0);
            this.m = a.m;
            this.A = a.v;
            this.j = a.A
        }
    };

    function uA(a) {
        var b = new vA;
        b.A = a;
        b.l.push(new oA(a));
        return b
    }

    function wA(a, b) {
        a.l.push(new qA(b));
        return a
    }

    function xA(a, b) {
        a.l.push(new lA(b));
        return a
    }

    function yA(a, b) {
        a.l.push(new rA(b));
        return a
    }

    function zA(a, b) {
        a.l.push(new mA(b));
        return a
    }

    function AA(a) {
        a.l.push(new pA);
        return a
    }

    function BA(a) {
        a.j.push(new kA);
        return a
    }

    function CA(a, b = 0, c, d) {
        a.j.push(new hA(b, c, d));
        return a
    }

    function DA(a, b = 0, c = Infinity) {
        a.j.push(new sA(b, c));
        return a
    }

    function EA(a) {
        a.j.push(new nA);
        return a
    }

    function FA(a, b = 0) {
        a.j.push(new jA(b));
        return a
    }

    function GA(a, b) {
        a.m = b;
        return a
    }
    var vA = class {
        constructor() {
            this.m = 0;
            this.v = !1;
            this.l = [].slice(0);
            this.j = [].slice(0)
        }
        build() {
            return new tA(this)
        }
    };
    class gA {
        constructor(a, b) {
            this.l = a;
            this.m = b
        }
        j() {
            var a = this.l,
                b = this.m;
            const c = a.F || {};
            c.google_ad_client = a.uc;
            c.google_ad_height = O(b).clientHeight || 0;
            c.google_ad_width = O(b).clientWidth || 0;
            c.google_reactive_ad_format = 9;
            b = new Oz;
            x(b, 1, a.A);
            a.j && ad(b, 2, a.j);
            a.C && x(b, 3, !0);
            c.google_rasc = Ad(b);
            a.m && (c.google_adtest = "on");
            return new wn(["fsi_container"], c)
        }
    };
    var HA = pn(new mn(0, {})),
        IA = pn(new mn(1, {})),
        JA = a => a === HA || a === IA;

    function KA(a, b, c) {
        Rl(a.j, b) || a.j.set(b, []);
        a.j.get(b).push(c)
    }
    class LA {
        constructor() {
            this.j = new Vl
        }
    };

    function MA(a, b) {
        b && (a.j.apv = w(b, 4), Oc(b, Vn, 23) && (a.j.sat = "" + hd(C(b, Vn, 23), 1)));
        return a
    }

    function NA(a, b) {
        a.j.afm = b.join(",");
        return a
    }
    class OA extends ds {
        constructor(a) {
            super(a);
            this.j = {}
        }
        D(a) {
            null != a && (this.j.allp = a);
            return this
        }
        v(a) {
            try {
                this.j.su = a.location.hostname
            } catch (b) {
                this.j.su = "_ex"
            }
            a = super.v(a);
            fe(a, this.j);
            return a
        }
    }

    function PA(a) {
        return null == a ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function QA(a, b) {
        a.l.op = RA(b)
    }

    function SA(a, b, c) {
        30 >= c.length ? a.l[b] = TA(c) : (a.l[b] = TA(c.slice(0, 30)), a.l[b + "_c"] = c.length.toString())
    }

    function UA(a, b, c) {
        SA(a, "fap", b);
        a.l.fad = RA(c)
    }

    function VA(a, b, c) {
        SA(a, "fmp", b);
        a.l.fmd = RA(c)
    }

    function WA(a, b, c) {
        SA(a, "vap", b);
        a.l.vad = RA(c)
    }

    function XA(a, b, c) {
        SA(a, "vmp", b);
        a.l.vmd = RA(c)
    }

    function YA(a, b, c) {
        SA(a, "pap", b);
        a.l.pad = RA(c)
    }

    function ZA(a, b, c) {
        SA(a, "pmp", b);
        a.l.pmd = RA(c)
    }

    function $A(a, b) {
        SA(a, "psq", b)
    }
    var aB = class extends OA {
        constructor(a) {
            super(0);
            Object.assign(this, a);
            this.l = {}
        }
        v(a) {
            a = super.v(a);
            Object.assign(a, this.l);
            return a
        }
    };

    function TA(a) {
        return a.map(b => b ? .toString() ? ? "null").join("~")
    }

    function RA(a) {
        return null == a ? "null" : "string" === typeof a ? a : "boolean" === typeof a ? a ? "1" : "0" : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function bB(a, b, c) {
        const d = b.V;
        Rl(a.j, d) || a.j.set(d, new cB(en(Es(b)) ? ? ""));
        c(a.j.get(d))
    }

    function dB(a, b) {
        bB(a, b, c => {
            c.j = !0
        })
    }

    function eB(a, b) {
        bB(a, b, c => {
            c.l = !0
        })
    }

    function fB(a, b) {
        bB(a, b, c => {
            c.m = !0
        });
        a.I.push(b.V)
    }

    function gB(a, b, c) {
        bB(a, b, d => {
            d.bb = c
        })
    }

    function hB(a, b, c) {
        const d = [];
        let e = 0;
        for (const f of c.filter(b)) JA(f.bb ? ? "") ? ++e : (b = a.l.get(f.bb ? ? "", null), d.push(b));
        return {
            list: d.sort((f, g) => (f ? ? -1) - (g ? ? -1)),
            cb: e
        }
    }

    function iB(a, b) {
        QA(b, a.l.xb());
        var c = Ul(a.j).filter(f => 0 === (f.Ma.startsWith(HA) ? 0 : 1)),
            d = Ul(a.j).filter(f => 1 === (f.Ma.startsWith(HA) ? 0 : 1)),
            e = hB(a, f => f.j, c);
        UA(b, e.list, e.cb);
        e = hB(a, f => f.j, d);
        VA(b, e.list, e.cb);
        e = hB(a, f => f.l, c);
        WA(b, e.list, e.cb);
        e = hB(a, f => f.l, d);
        XA(b, e.list, e.cb);
        c = hB(a, f => f.m, c);
        YA(b, c.list, c.cb);
        d = hB(a, f => f.m, d);
        ZA(b, d.list, d.cb);
        $A(b, a.I.map(f => a.j.get(f) ? .bb).map(f => a.l.get(f) ? ? null))
    }

    function xj() {
        var a = Ik(jB);
        if (!a.A) return lj();
        const b = uj(tj(sj(rj(qj(pj(oj(nj(kj(jj(new mj, a.A ? ? []), a.H ? ? []), a.B), a.D), a.G), a.K), a.L), a.C ? ? 0), Ul(a.j).map(c => {
            var d = new ij;
            d = jd(d, 1, c.Ma);
            var e = a.l.get(c.bb ? ? "", -1);
            d = id(d, 2, e);
            d = nd(d, 3, c.j);
            return nd(d, 4, c.l)
        })), a.I.map(c => a.j.get(c) ? .bb).map(c => a.l.get(c) ? ? null));
        null != a.m && nd(b, 6, a.m);
        null != a.v && Wc(b, 13, a.v, 0);
        return b
    }
    var jB = class {
        constructor() {
            this.v = this.H = this.A = null;
            this.G = this.D = !1;
            this.m = null;
            this.L = this.B = this.K = !1;
            this.C = null;
            this.l = new Vl;
            this.j = new Vl;
            this.I = []
        }
    };
    class cB {
        constructor(a) {
            this.m = this.l = this.j = !1;
            this.bb = null;
            this.Ma = a
        }
    };
    class kB {
        constructor(a = 0) {
            this.j = a
        }
    };
    class lB {
        constructor(a) {
            this.l = a;
            this.j = -1
        }
    };

    function mB(a) {
        let b = 0;
        for (; a;)(!b || a.previousElementSibling || a.nextElementSibling) && b++, a = a.parentElement;
        return b
    };

    function nB(a, b) {
        const c = a.H.filter(d => Tl(d.Rb).every(e => d.Rb.get(e) === b.get(e)));
        return 0 === c.length ? (a.l.push(19), null) : c.reduce((d, e) => d.Rb.xb() > e.Rb.xb() ? d : e, c[0])
    }

    function oB(a, b) {
        b = Es(b);
        if (null == b.j) return a.l.push(18), null;
        b = b.j.value;
        if (Rl(a.m, b)) return a.m.get(b);
        var c = nn(b);
        c = nB(a, c);
        a.m.set(b, c);
        return c
    }
    var pB = class {
        constructor(a) {
            this.j = a;
            this.m = new Vl;
            this.H = (C(a, Ko, 2) ? .j() || []).map(b => {
                const c = nn(G(b, 1)),
                    d = fd(b, 2);
                return {
                    Rb: c,
                    qe: d,
                    Ma: G(b, 1)
                }
            });
            this.l = []
        }
        G() {
            const a = Ik(jB);
            var b = this.B();
            a.A = b;
            b = this.A();
            a.H = b;
            b = this.v();
            null != b && (a.v = b);
            b = !!this.j.v() ? .j() ? .j();
            a.G = b;
            b = new Vl;
            for (const c of C(this.j, Ko, 2) ? .j() ? ? []) b.set(G(c, 1), fd(c, 2));
            a.l = b
        }
        C() {
            return [...this.l]
        }
        B() {
            return [...this.j.j()]
        }
        A() {
            return [...Tc(this.j, 4, Ic)]
        }
        v() {
            return C(this.j, Do, 5) ? .j() ? ? null
        }
        D(a) {
            const b = oB(this, a);
            null != b ? .Ma &&
                gB(Ik(jB), a, b.Ma)
        }
        I(a) {
            const b = V(Bp) || 0;
            if (0 == a.length || 0 == b) return !0;
            const c = (new Ym(a)).filter(d => {
                d = oB(this, d) ? .Ma || "";
                return "" != d && !(d === HA || d === IA)
            });
            return b <= c.j.length / a.length
        }
    };

    function qB(a, b) {
        return 0 == b.j.length ? b : b.sort((c, d) => (oB(a.j, c) ? .qe ? ? Number.MAX_VALUE) - (oB(a.j, d) ? .qe ? ? Number.MAX_VALUE))
    }

    function rB(a, b) {
        var c = b.aa.j,
            d = Math,
            e = d.min;
        const f = b.Y(),
            g = b.V.j();
        c += 200 * e.call(d, 20, 0 == g || 3 == g ? mB(f.parentElement) : mB(f));
        d = a.m;
        0 > d.j && (d.j = O(d.l).scrollHeight || 0);
        d = d.j - b.aa.j;
        c += 1E3 < d ? 0 : 2 * (1E3 - d);
        a = a.l;
        b = b.Y();
        return c + ("string" === typeof b.className && 0 <= b.className.indexOf("adsbygoogle-ablated-ad-slot") ? a.j : 0)
    }

    function sB(a, b) {
        return 0 == b.j.length ? b : b.sort((c, d) => rB(a, c) - rB(a, d))
    }

    function tB(a, b) {
        return b.sort((c, d) => {
            const e = c.V.D,
                f = d.V.D;
            var g;
            null == e || null == f ? g = null == e && null == f ? rB(a, c) - rB(a, d) : null == e ? 1 : -1 : g = e - f;
            return g
        })
    }
    class uB {
        constructor(a, b = 0, c = null) {
            this.m = new lB(a);
            this.l = new kB(b);
            this.j = c && new pB(c)
        }
    };

    function vB(a, b, c = 0) {
        var d = a.l;
        for (var e of b.v) d = Xm(d, e.ha(a.m), wB(e.ia(), c));
        e = d = d.apply(qu(a.m));
        for (const f of b.l) e = Xm(e, f.ha(a.m), xB(f.ia(), c));
        switch (b.m) {
            case 1:
                e = sB(a.j, e);
                break;
            case 2:
                e = tB(a.j, e);
                break;
            case 3:
                const f = Ik(jB);
                e = qB(a.j, e);
                d.forEach(g => {
                    dB(f, g);
                    a.j.j ? .D(g)
                });
                e.forEach(g => eB(f, g))
        }
        b.A && (e = Zm(e, lg(a.m.location.href + a.m.localStorage.google_experiment_mod)));
        1 === b.j ? .length && KA(a.v, b.j[0], {
            Re: d.j.length,
            lg: e.j.length
        });
        return e.j.slice(0)
    }
    class yB {
        constructor(a, b, c = 0, d = null) {
            this.l = new Ym(a);
            this.j = new uB(b, c, d);
            this.m = b;
            this.v = new LA
        }
        A() {
            this.l.forEach(a => {
                a.l && $q(a.l);
                a.l = null
            })
        }
    }
    const wB = (a, b) => c => vs(c, b, a),
        xB = (a, b) => c => vs(c.V, b, a);

    function zB(a, b, c, d) {
        a: {
            switch (b) {
                case 0:
                    a = AB(BB(c), a);
                    break a;
                case 3:
                    a = AB(c, a);
                    break a;
                case 2:
                    var e = c.lastChild;
                    a = AB(e ? 1 == e.nodeType ? e : BB(e) : null, a);
                    break a
            }
            a = !1
        }
        if (d = !a && !(!d && 2 == b && !CB(c))) b = 1 == b || 2 == b ? c : c.parentNode,
        d = !(b && !$o(b) && 0 >= b.offsetWidth);
        return d
    }

    function AB(a, b) {
        if (!a) return !1;
        a = Qg(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return "left" == a || "right" == a
    }

    function BB(a) {
        for (a = a.previousSibling; a && 1 != a.nodeType;) a = a.previousSibling;
        return a ? a : null
    }

    function CB(a) {
        return !!a.nextSibling || !!a.parentNode && CB(a.parentNode)
    };
    var DB = !Fb && !gb();

    function EB(a) {
        if (/-[a-z]/.test("adFormat")) return null;
        if (DB && a.dataset) {
            if (ib() && !("adFormat" in a.dataset)) return null;
            a = a.dataset.adFormat;
            return void 0 === a ? null : a
        }
        return a.getAttribute("data-" + "adFormat".replace(/([A-Z])/g, "-$1").toLowerCase())
    };
    var FB = (a, b, c) => {
            if (!b) return null;
            const d = xg(document, "INS");
            d.id = "google_pedestal_container";
            d.style.width = "100%";
            d.style.zIndex = "-1";
            if (c) {
                var e = a.getComputedStyle(c),
                    f = "";
                if (e && "static" != e.position) {
                    var g = c.parentNode.lastElementChild;
                    for (f = e.position; g && g != c;) {
                        if ("none" != a.getComputedStyle(g).display) {
                            f = a.getComputedStyle(g).position;
                            break
                        }
                        g = g.previousElementSibling
                    }
                }
                if (c = f) d.style.position = c
            }
            b.appendChild(d);
            if (d) {
                var h = a.document;
                f = h.createElement("div");
                f.style.width = "100%";
                f.style.height =
                    "2000px";
                c = O(a).clientHeight;
                e = h.body.scrollHeight;
                a = a.innerHeight;
                g = h.body.getBoundingClientRect().bottom;
                d.appendChild(f);
                var k = f.getBoundingClientRect().top;
                h = h.body.getBoundingClientRect().top;
                d.removeChild(f);
                f = e;
                e <= a && 0 < c && 0 < g && (f = g - h);
                a = k - h >= .8 * f
            } else a = !1;
            return a ? d : (b.removeChild(d), null)
        },
        GB = a => {
            const b = a.document.body;
            var c = FB(a, b, null);
            if (c) return c;
            if (a.document.body) {
                c = Math.floor(a.document.body.getBoundingClientRect().width);
                for (var d = [{
                        element: a.document.body,
                        depth: 0,
                        height: 0
                    }], e = -1, f = null; 0 < d.length;) {
                    const h = d.pop(),
                        k = h.element;
                    var g = h.height;
                    0 < h.depth && g > e && (e = g, f = k);
                    if (5 > h.depth)
                        for (let l = 0; l < k.children.length; l++) {
                            const m = k.children[l];
                            g = c;
                            const n = m.getBoundingClientRect().width;
                            (null == n || null == g ? 0 : n >= .9 * g && n <= 1.01 * g) && d.push({
                                element: m,
                                depth: h.depth + 1,
                                height: m.getBoundingClientRect().height
                            })
                        }
                }
                c = f
            } else c = null;
            return c ? FB(a, c.parentNode || b, c) : null
        },
        IB = a => {
            let b = 0;
            try {
                b |= a != a.top ? 512 : 0, Hg() || (b |= 1048576), 1200 >= Math.floor(a.document.body.getBoundingClientRect().width) ||
                    (b |= 32768), HB(a) && (b |= 33554432)
            } catch (c) {
                b |= 32
            }
            return b
        },
        HB = a => {
            a = a.document.getElementsByClassName("adsbygoogle");
            for (let b = 0; b < a.length; b++)
                if ("autorelaxed" == EB(a[b])) return !0;
            return !1
        };

    function JB(a) {
        const b = Gl(a, !0),
            c = O(a).scrollWidth,
            d = O(a).scrollHeight;
        let e = "unknown";
        a && a.document && a.document.readyState && (e = a.document.readyState);
        var f = Ll(a);
        const g = [];
        var h = [];
        const k = [],
            l = [];
        var m = [],
            n = [],
            q = [];
        let r = 0,
            t = 0,
            B = Infinity,
            z = Infinity,
            A = null;
        var J = zt({
            Xa: !1
        }, a);
        for (var E of J) {
            J = E.getBoundingClientRect();
            const W = b - (J.bottom + f);
            var F = void 0,
                H = void 0;
            if (E.className && Za(E.className, "adsbygoogle-ablated-ad-slot")) {
                F = E.getAttribute("google_element_uid");
                H = a.google_sv_map;
                if (!F || !H || !H[F]) continue;
                F = (H = mi(H[F])) ? H.height : 0;
                H = H ? H.width : 0
            } else if (F = J.bottom - J.top, H = J.right - J.left, 1 >= F || 1 >= H) continue;
            g.push(F);
            k.push(H);
            l.push(F * H);
            E.className && Za(E.className, "google-auto-placed") ? (t += 1, E.className && Za(E.className, "pedestal_container") && (A = F)) : (B = Math.min(B, W), n.push(J), r += 1, h.push(F), m.push(F * H));
            z = Math.min(z, W);
            q.push(J)
        }
        B = Infinity === B ? null : B;
        z = Infinity === z ? null : z;
        f = KB(n);
        q = KB(q);
        h = LB(b, h);
        n = LB(b, g);
        m = LB(b * c, m);
        E = LB(b * c, l);
        return new MB(a, {
            jf: e,
            Xc: b,
            Mf: c,
            Lf: d,
            Ef: r,
            Qe: t,
            Te: NB(g),
            Ue: NB(k),
            Se: NB(l),
            If: f,
            Hf: q,
            Gf: B,
            Ff: z,
            Ec: h,
            Dc: n,
            Me: m,
            Le: E,
            Nf: A
        })
    }

    function OB(a, b, c, d) {
        const e = Hg() && !(900 <= O(a.l).clientWidth);
        d = mb(d, f => rb(a.m, f)).join(",");
        return {
            wpc: b,
            su: c,
            eid: d,
            doc: a.j.jf,
            pg_h: PB(a.j.Xc),
            pg_w: PB(a.j.Mf),
            pg_hs: PB(a.j.Lf),
            c: PB(a.j.Ef),
            aa_c: PB(a.j.Qe),
            av_h: PB(a.j.Te),
            av_w: PB(a.j.Ue),
            av_a: PB(a.j.Se),
            s: PB(a.j.If),
            all_s: PB(a.j.Hf),
            b: PB(a.j.Gf),
            all_b: PB(a.j.Ff),
            d: PB(a.j.Ec),
            all_d: PB(a.j.Dc),
            ard: PB(a.j.Me),
            all_ard: PB(a.j.Le),
            pd_h: PB(a.j.Nf),
            dt: e ? "m" : "d"
        }
    }
    class MB {
        constructor(a, b) {
            this.l = a;
            this.j = b;
            this.m = "633794002 633794005 21066126 21066127 21065713 21065714 21065715 21065716 42530887 42530888 42530889 42530890 42530891 42530892 42530893".split(" ")
        }
    }

    function NB(a) {
        return fg.apply(null, mb(a, b => 0 < b)) || null
    }

    function LB(a, b) {
        return 0 >= a ? null : eg.apply(null, b) / a
    }

    function KB(a) {
        let b = Infinity;
        for (let e = 0; e < a.length - 1; e++)
            for (let f = e + 1; f < a.length; f++) {
                var c = a[e],
                    d = a[f];
                c = Math.max(Math.max(0, c.left - d.right, d.left - c.right), Math.max(0, c.top - d.bottom, d.top - c.bottom));
                0 < c && (b = Math.min(c, b))
            }
        return Infinity !== b ? b : null
    }

    function PB(a) {
        return null == a ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function QB(a, b) {
        b = (O(b).clientHeight || 0) - Ll(b);
        let c = 0;
        for (let d = 0; d < a.length; d++) {
            const e = a[d].getBoundingClientRect();
            Ht(e) && e.top <= b && (c += 1)
        }
        return c
    }

    function RB(a) {
        const b = {};
        var c = Bt({
            Xa: !1,
            Ub: !1,
            Vb: !1,
            Wb: !1
        }, a).map(d => d.getBoundingClientRect()).filter(Ht);
        b.qd = c.length;
        c = Ct({
            Vb: !0
        }, a).map(d => d.getBoundingClientRect()).filter(Ht);
        b.Jd = c.length;
        c = Ct({
            Wb: !0
        }, a).map(d => d.getBoundingClientRect()).filter(Ht);
        b.ee = c.length;
        c = Ct({
            Ub: !0
        }, a).map(d => d.getBoundingClientRect()).filter(Ht);
        b.yd = c.length;
        c = (O(a).clientHeight || 0) - Ll(a);
        c = Bt({
            Xa: !1
        }, a).map(d => d.getBoundingClientRect()).filter(Ht).filter(Ba(SB, null, c));
        b.rd = c.length;
        a = JB(a);
        c = null != a.j.Ec ? a.j.Ec :
            null;
        null != c && (b.ae = c);
        a = null != a.j.Dc ? a.j.Dc : null;
        null != a && (b.ud = a);
        return b
    }

    function Zz(a, b, {
        ec: c,
        vc: d,
        Ac: e
    } = {}) {
        return Ir(997, () => TB(a, b, {
            ec: c,
            vc: d,
            Ac: e
        }), a.j)
    }

    function $z(a, b, c, d) {
        var e = c.Qa ? c.Qa : a.B;
        const f = nt(e, b.j.length);
        e = a.m.vd ? e.j : void 0;
        const g = EA(FA(BA(DA(CA(AA(yA(zA(wA(xA(uA(c.types), a.N), c.cd || []), a.L), c.Yf || [])), f.hc || void 0, e, b), c.minWidth, c.maxWidth)), f.gb || void 0));
        a.K && g.j.push(new iA(a.K));
        b = 1;
        a.m.od ? b = 2 : a.Da() && (b = 3);
        GA(g, b);
        a.m.jd && (g.v = !0);
        return Ir(995, () => vB(a.l, g.build(), d), a.j)
    }

    function bA(a, b) {
        const c = GB(a.j);
        if (c) {
            const d = vn(a.H, b),
                e = xr(a.j.document, a.C, null, null, {}, d);
            e && (cr(e.Ua, c, 2, 256), Ir(996, () => UB(a, e, d), a.j))
        }
    }

    function VB(a) {
        return a.D ? a.D : a.D = a.j.google_ama_state
    }

    function TB(a, b, {
        ec: c,
        vc: d,
        Ac: e
    } = {}) {
        const f = b.V;
        if (f.A) return !1;
        var g = b.Y();
        if (!zB(a.j, f.j(), g, a.v)) return !1;
        var h = null;
        T(lp) && f.dc ? .includes(6) ? (g = Math.round(g.getBoundingClientRect().height), h = null == c ? g : Math.min(c, g)) : h = c;
        c = null == h ? null : new wn(null, {
            google_max_responsive_height: h
        });
        g = xn(w(f.qc, 2) || 0);
        h = yn(f.D);
        const k = WB(a, f),
            l = XB(a),
            m = vn(a.H, f.L ? f.L.j(b.aa) : null, c, d || null, g, h, k, l),
            n = b.fill(a.C, m);
        if (e && !YB(a, n, m) || !Ir(996, () => UB(a, n, m), a.j)) return !1;
        nl(9, [f.D, f.Ya]);
        a.Da() && fB(Ik(jB), b);
        return !0
    }

    function WB(a, b) {
        return en(gn(Cs(b).map(zn), () => {
            a.A.push(18)
        }))
    }

    function XB(a) {
        if (!a.Da()) return null;
        var b = a.l.j.j ? .A();
        if (null == b) return null;
        b = b.join("~");
        a = a.l.j.j ? .v() ? ? null;
        return An({
            ff: b,
            lf: a
        })
    }

    function YB(a, b, c) {
        if (!b) return !1;
        var d = b.va,
            e = d.style.width;
        d.style.width = "100%";
        var f = d.offsetWidth;
        d.style.width = e;
        d = a.j;
        e = b.va;
        c = c && c.yb() || {};
        if (d !== d.top) var g = Ng(d) ? 3 : 16;
        else if (488 > O(d).clientWidth)
            if (d.innerHeight >= d.innerWidth)
                if (g = O(d).clientWidth, !g || .3 < (g - f) / g) g = 6;
                else {
                    if (g = "true" != c.google_full_width_responsive) b: {
                        var h = e.parentElement;
                        for (g = O(d).clientWidth; h; h = h.parentElement) {
                            const k = Qg(h, d);
                            if (!k) continue;
                            const l = ah(k.width);
                            if (l && !(l >= g) && "visible" != k.overflow) {
                                g = !0;
                                break b
                            }
                        }
                        g = !1
                    }
                    g = g ? 7 : !0
                }
        else g = 5;
        else g = 4;
        if (!0 !== g) f = g;
        else {
            if (!(c = "true" == c.google_full_width_responsive)) a: {
                do
                    if ((c = Qg(e, d)) && "fixed" == c.position) {
                        c = !1;
                        break a
                    }
                while (e = e.parentElement);
                c = !0
            }
            c ? (d = O(d).clientWidth, f = d - f, f = d && 0 <= f ? !0 : d ? -10 > f ? 11 : 0 > f ? 14 : 12 : 10) : f = 9
        }
        if (f) {
            a = a.j;
            b = b.va;
            if (f = tr(a, b)) b.style.border = b.style.borderStyle = b.style.outline = b.style.outlineStyle = b.style.transition = "none", b.style.borderSpacing = b.style.padding = "0", rr(b, f, "0px"), b.style.width = O(a).clientWidth + "px", ur(a, b, f), b.style.zIndex = 30;
            return !0
        }
        $q(b.Ua);
        return !1
    }

    function UB(a, b, c) {
        if (!b) return !1;
        try {
            Br(a.j, b.va, c)
        } catch (d) {
            return $q(b.Ua), a.A.push(6), !1
        }
        return !0
    }
    class ZB {
        constructor(a, b, c, d, e = {}, f = []) {
            this.l = a;
            this.C = b;
            this.j = c;
            this.B = d.Qa;
            this.N = d.ub || [];
            this.H = d.mf || null;
            this.L = d.hf || [];
            this.K = d.wc || [];
            this.m = e;
            this.v = !1;
            this.I = [];
            this.A = [];
            this.G = this.D = void 0;
            this.ca = f
        }
        T() {
            return this.l
        }
        R() {
            return this.j
        }
        wa(a) {
            this.I.push(a)
        }
        Da() {
            if (0 == (this.l.j.j ? .B().length ? ? 0)) return !1;
            if (0 == (V(Bp) || 0)) return !0;
            if (void 0 === this.G) {
                const a = GA(BA(AA(uA([0, 1, 2]))), 1).build(),
                    b = Ir(995, () => vB(this.l, a), this.j);
                this.G = this.l.j.j ? .I(b) || !1
            }
            return this.G
        }
        Oc() {
            return !!this.m.ve
        }
        ac() {
            return !HB(this.j)
        }
    }
    const SB = (a, b) => b.top <= a;

    function $B(a, b, c, d, e, f = 0, g = 0) {
        this.Ba = a;
        this.oc = f;
        this.nc = g;
        this.errors = b;
        this.Pa = c;
        this.j = d;
        this.l = e
    };
    var aC = (a, {
        ac: b = !1,
        Oc: c = !1,
        cg: d = !1,
        Da: e = !1
    } = {}) => {
        const f = [];
        d && f.push(9);
        if (e) {
            a.includes(4) && !c && b && f.push(8);
            a.includes(1) && f.push(1);
            d = a.includes(3);
            e = a.includes(2) && !T(np);
            const g = a.includes(1);
            (d || e || g) && f.push(10)
        } else a.includes(3) && f.push(6), a.includes(4) && !c && b && f.push(8), a.includes(1) && f.push(1, 5), a.includes(2) && !T(np) && f.push(7);
        a.includes(4) && c && b && f.push(8);
        return f
    };

    function bC(a, b, c) {
        a = aC(a, {
            ac: b.ac(),
            Oc: b.Oc(),
            cg: !!b.m.Ic,
            Da: b.Da()
        });
        return new cC(a, b, c)
    }

    function dC(a, b) {
        const c = Wz[b];
        return c ? Ir(998, () => c(a.j), a.A) : (a.j.wa(12), !0)
    }

    function eC(a, b) {
        return new Promise(c => {
            setTimeout(() => {
                c(dC(a, b))
            })
        })
    }

    function fC(a) {
        a.j.v = !0;
        return Promise.all(a.l.map(b => eC(a, b))).then(b => {
            b.includes(!1) && a.j.wa(5);
            a.l.splice(0, a.l.length)
        })
    }
    class cC {
        constructor(a, b, c) {
            this.v = a.slice(0);
            this.l = a.slice(0);
            this.m = sb(this.l, 1);
            this.j = b;
            this.A = c
        }
    };
    const gC = class {
        constructor(a) {
            this.j = a;
            this.exception = void 0
        }
    };

    function hC(a) {
        return fC(a).then(() => {
            var b = a.j.l.l.filter(qs).j.length;
            var c = a.j.I.slice(0);
            var d = a.j;
            d = [...d.A, ...(d.l.j.j ? .C() || [])];
            b = new $B(b, c, d, a.j.l.l.j.length, a.j.l.v.j, a.j.l.l.filter(qs).filter(rs).j.length, a.j.l.l.filter(rs).j.length);
            return new gC(b)
        })
    };
    class iC {
        j() {
            return new wn([], {
                google_reactive_ad_format: 40,
                google_tag_origin: "qs"
            })
        }
    };
    class jC {
        j() {
            return new wn(["adsbygoogle-resurrected-ad-slot"], {})
        }
    };

    function kC(a) {
        return ap(a.j.document).map(b => {
            const c = new Ls(b, 3);
            b = new ls(Dr(a.j, b));
            return new ps(c, b, a.l, !1, 0, [], null, a.j, null)
        })
    }
    class lC {
        constructor(a) {
            var b = new jC;
            this.j = a;
            this.l = b || null
        }
    };
    const mC = {
        nd: "10px",
        zc: "10px"
    };

    function nC(a) {
        return Ql(a.j.document.querySelectorAll("INS.adsbygoogle-placeholder")).map(b => new ps(new Ls(b, 1), new js(mC), a.l, !1, 0, [], null, a.j, null))
    }
    class oC {
        constructor(a, b) {
            this.j = a;
            this.l = b || null
        }
    };

    function pC(a, b) {
        return null == a ? b + "ShouldNotBeNull" : 0 == a ? b + "ShouldNotBeZero" : -1 > a ? b + "ShouldNotBeLessMinusOne" : null
    }

    function qC(a, b, c) {
        const d = pC(c.Sb, "gapsMeasurementWindow") || pC(c.wb, "gapsPerMeasurementWindow") || pC(c.Ab, "maxGapsToReport");
        return null != d ? cn(d) : c.xd || -1 != c.wb || -1 != c.Ab ? an(new rC(a, b, c)) : cn("ShouldHaveLimits")
    }

    function sC(a) {
        return VB(a.m) && VB(a.m).placed || []
    }

    function tC(a) {
        return sC(a).map(b => Nm(Lm(b.element, a.j)))
    }

    function uC(a) {
        return sC(a).map(b => b.index)
    }

    function vC(a, b) {
        const c = b.V;
        return !a.B && c.v && null != w(c.v, 8) && 1 == w(c.v, 8) ? [] : c.A ? (c.N || []).map(d => Nm(Lm(d, a.j))) : [Nm(new Mm(b.aa.j, 0))]
    }

    function wC(a) {
        a.sort((e, f) => e.j - f.j);
        const b = [];
        let c = 0;
        for (let e = 0; e < a.length; ++e) {
            var d = a[e];
            let f = d.j;
            d = d.j + d.l;
            f <= c ? c = Math.max(c, d) : (b.push(new Mm(c, f - c)), c = d)
        }
        return b
    }

    function xC(a, b) {
        b = b.map(c => {
            var d = new Cz;
            d = x(d, 1, c.j);
            c = c.getHeight();
            return x(d, 2, c)
        });
        return Ez(Dz(new Gz, a), b)
    }

    function yC(a) {
        const b = D(a, Cz, 2).map(c => `G${ed(c,1)}~${c.getHeight()}`);
        return `W${ed(a,1)}${b.join("")}`
    }

    function zC(a, b) {
        const c = [];
        let d = 0;
        for (const e of Tl(b)) {
            const f = b.get(e);
            f.sort((g, h) => h.getHeight() - g.getHeight());
            a.G || f.splice(a.A, f.length);
            !a.C && d + f.length > a.l && f.splice(a.l - d, f.length);
            c.push(xC(e, f));
            d += f.length;
            if (!a.C && d >= a.l) break
        }
        return c
    }

    function AC(a) {
        const b = D(a, Gz, 5).map(c => yC(c));
        return `M${ed(a,1)}H${ed(a,2)}C${ed(a,3)}B${Number(!!I(a,4))}${b.join("")}`
    }

    function BC(a) {
        var b = Us(a.m.l.l.j.slice(0), a.j),
            c = tC(a),
            d = new Wl(uC(a));
        for (var e = 0; e < b.length; ++e)
            if (!d.contains(e)) {
                var f = vC(a, b[e]);
                c.push(...f)
            }
        c.push(new Mm(0, 0));
        c.push(Nm(new Mm(O(a.j).scrollHeight, 0)));
        b = wC(c);
        c = new Vl;
        for (d = 0; d < b.length; ++d) e = b[d], f = a.D ? 0 : Math.floor(e.j / a.v), Rl(c, f) || c.set(f, []), c.get(f).push(e);
        b = zC(a, c);
        c = new Iz;
        c = x(c, 1, a.l);
        c = x(c, 2, a.v);
        c = x(c, 3, a.A);
        a = x(c, 4, a.B);
        return cd(a, 5, b)
    }

    function CC(a) {
        a = BC(a);
        return AC(a)
    }
    var rC = class {
        constructor(a, b, c) {
            this.D = -1 == c.Sb;
            this.v = c.Sb;
            this.G = -1 == c.wb;
            this.A = c.wb;
            this.C = -1 == c.Ab;
            this.l = c.Ab;
            this.B = c.Vd;
            this.m = b;
            this.j = a
        }
    };
    const DC = a => {
            const b = /[a-zA-Z0-9._~-]/,
                c = /%[89a-zA-Z]./;
            return a.replace(/(%[a-zA-Z0-9]{2})/g, function(d) {
                if (!d.match(c)) {
                    const e = decodeURIComponent(d);
                    if (e.match(b)) return e
                }
                return d.toUpperCase()
            })
        },
        EC = a => {
            let b = "";
            const c = /[/%?&=]/;
            for (let d = 0; d < a.length; ++d) {
                const e = a[d];
                b = e.match(c) ? b + e : b + encodeURIComponent(e)
            }
            return b
        };
    var FC = (a, b) => {
        a = Rc(a, 2);
        if (!a) return !1;
        for (let c = 0; c < a.length; c++)
            if (a[c] == b) return !0;
        return !1
    };
    const HC = (a, b) => {
            a = EC(DC(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
            const c = Ug(a),
                d = GC(a);
            return b.find(e => {
                const f = Oc(e, Ln, 7) ? w(C(e, Ln, 7), 1) : w(e, 1);
                Oc(e, Ln, 7) ? (e = C(e, Ln, 7), e = w(e, 2)) : e = 2;
                if ("number" !== typeof f) return !1;
                switch (e) {
                    case 1:
                        return f == c;
                    case 2:
                        return d[f] || !1
                }
                return !1
            }) || null
        },
        GC = a => {
            const b = {};
            for (;;) {
                b[Ug(a)] = !0;
                if (!a) return b;
                a = a.substring(0, a.lastIndexOf("/"))
            }
        };
    const IC = {
        google_ad_channel: !0,
        google_ad_host: !0
    };
    var JC = (a, b) => {
            a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
            Rk("ama", b, .01)
        },
        KC = a => {
            const b = {};
            Sg(IC, (c, d) => {
                d in a && (b[d] = a[d])
            });
            return b
        };
    var LC = a => {
        try {
            try {
                a.localStorage.removeItem("google_ama_config")
            } catch (b) {
                JC(a, {
                    lserr: 1
                })
            }
        } catch (b) {
            JC(a, {
                lserr: 1
            })
        }
    };

    function MC(a) {
        a.google_ad_modifications || (a.google_ad_modifications = {});
        return a.google_ad_modifications
    }

    function NC(a, b) {
        a = MC(a);
        a.processed_sra_frame_pingbacks = a.processed_sra_frame_pingbacks || {};
        const c = !a.processed_sra_frame_pingbacks[b];
        a.processed_sra_frame_pingbacks[b] = !0;
        return c
    };

    function OC() {
        if (PC) return PC;
        const a = Jh() || window,
            b = a.google_persistent_state_async;
        return null != b && "object" == typeof b && null != b.S && "object" == typeof b.S ? PC = b : a.google_persistent_state_async = PC = new QC
    }

    function RC(a, b, c) {
        b = SC[b] || "google_ps_" + b;
        a = a.S;
        const d = a[b];
        return void 0 === d ? (a[b] = c(), a[b]) : d
    }

    function TC(a, b, c) {
        return RC(a, b, () => c)
    }

    function UC(a, b, c) {
        return a.S[SC[b] || "google_ps_" + b] = c
    }

    function VC(a, b) {
        return UC(a, b, TC(a, b, 0) + 1)
    }

    function WC() {
        var a = OC();
        return TC(a, 20, {})
    }

    function XC() {
        var a = OC();
        const b = TC(a, 31, !1);
        b || UC(a, 31, !0);
        return !b
    }

    function YC() {
        var a = OC();
        return TC(a, 26)
    }

    function ZC() {
        var a = OC();
        return TC(a, 28, [])
    }

    function $C(a) {
        return !!TC(OC(), 30, a)
    }
    class QC {
        constructor() {
            this.S = {}
        }
    }
    var PC = null;
    const SC = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };
    var aD = {
            google_ad_block: "ad_block",
            google_ad_client: "client",
            google_ad_output: "output",
            google_ad_callback: "callback",
            google_ad_height: "h",
            google_ad_resize: "twa",
            google_ad_slot: "slotname",
            google_ad_unit_key: "adk",
            google_ad_dom_fingerprint: "adf",
            google_placement_id: "pi",
            google_daaos_ts: "daaos",
            google_erank: "epr",
            google_ad_width: "w",
            google_captcha_token: "captok",
            google_content_recommendation_columns_num: "cr_col",
            google_content_recommendation_rows_num: "cr_row",
            google_ctr_threshold: "ctr_t",
            google_cust_criteria: "cust_params",
            gfwrnwer: "fwrn",
            gfwrnher: "fwrnh",
            google_image_size: "image_size",
            google_last_modified_time: "lmt",
            google_loeid: "loeid",
            google_max_num_ads: "num_ads",
            google_max_radlink_len: "max_radlink_len",
            google_mtl: "mtl",
            google_native_settings_key: "nsk",
            google_enable_content_recommendations: "ecr",
            google_num_radlinks: "num_radlinks",
            google_num_radlinks_per_unit: "num_radlinks_per_unit",
            google_pucrd: "pucrd",
            google_reactive_plaf: "plaf",
            google_reactive_plat: "plat",
            google_reactive_fba: "fba",
            google_reactive_sra_channels: "plach",
            google_responsive_auto_format: "rafmt",
            armr: "armr",
            google_plas: "plas",
            google_rl_dest_url: "rl_dest_url",
            google_rl_filtering: "rl_filtering",
            google_rl_mode: "rl_mode",
            google_rt: "rt",
            google_video_play_muted: "vpmute",
            google_source_type: "src_type",
            google_restrict_data_processing: "rdp",
            google_tag_for_child_directed_treatment: "tfcd",
            google_tag_for_under_age_of_consent: "tfua",
            google_tag_origin: "to",
            google_ad_semantic_area: "sem",
            google_tfs: "tfs",
            google_package: "pwprc",
            google_tag_partner: "tp",
            fra: "fpla",
            google_ml_rank: "mlr",
            google_apsail: "psa",
            google_ad_channel: "channel",
            google_ad_type: "ad_type",
            google_ad_format: "format",
            google_color_bg: "color_bg",
            google_color_border: "color_border",
            google_color_link: "color_link",
            google_color_text: "color_text",
            google_color_url: "color_url",
            google_page_url: "url",
            google_allow_expandable_ads: "ea",
            google_ad_section: "region",
            google_cpm: "cpm",
            google_encoding: "oe",
            google_safe: "adsafe",
            google_font_face: "f",
            google_font_size: "fs",
            google_hints: "hints",
            google_ad_host: "host",
            google_ad_host_channel: "h_ch",
            google_ad_host_tier_id: "ht_id",
            google_kw_type: "kw_type",
            google_kw: "kw",
            google_contents: "contents",
            google_targeting: "targeting",
            google_adtest: "adtest",
            google_alternate_color: "alt_color",
            google_alternate_ad_url: "alternate_ad_url",
            google_cust_age: "cust_age",
            google_cust_ch: "cust_ch",
            google_cust_gender: "cust_gender",
            google_cust_interests: "cust_interests",
            google_cust_job: "cust_job",
            google_cust_l: "cust_l",
            google_cust_lh: "cust_lh",
            google_cust_u_url: "cust_u_url",
            google_cust_id: "cust_id",
            google_language: "hl",
            google_city: "gcs",
            google_country: "gl",
            google_region: "gr",
            google_content_recommendation_ad_positions: "ad_pos",
            google_content_recommendation_columns_num: "cr_col",
            google_content_recommendation_rows_num: "cr_row",
            google_content_recommendation_ui_type: "crui",
            google_content_recommendation_use_square_imgs: "cr_sq_img",
            google_color_line: "color_line",
            google_disable_video_autoplay: "disable_video_autoplay",
            google_full_width_responsive_allowed: "fwr",
            google_full_width_responsive: "fwrattr",
            efwr: "efwr",
            google_pgb_reactive: "pra",
            google_resizing_allowed: "rs",
            google_resizing_height: "rh",
            google_resizing_width: "rw",
            rpe: "rpe",
            google_responsive_formats: "resp_fmts",
            google_safe_for_responsive_override: "sfro",
            google_video_doc_id: "video_doc_id",
            google_video_product_type: "video_product_type",
            google_webgl_support: "wgl",
            easpi: "easpi",
            easpa: "easai",
            asgr: "asgr",
            asmrc: "asmrc",
            asntp: "asntp",
            asntpv: "asntpv",
            asntpl: "asntpl",
            asntpm: "asntpm",
            asntpc: "asntpc",
            asna: "asna",
            asnd: "asnd",
            asnp: "asnp",
            asns: "asns",
            asmat: "asmat",
            asptt: "asptt",
            aspe: "aspe",
            asro: "asro",
            ascet: "easct",
            asrc: "asdrc",
            asbu: "asbu",
            aseb: "aseb",
            asla: "aslmt",
            asaa: "asamt",
            asupm: "asupm"
        },
        bD = a => (a = a.innerText || a.innerHTML) && (a = a.replace(/^\s+/, "").split(/\r?\n/, 1)[0].match(/^\x3c!--+(.*?)(?:--+>)?\s*$/)) && RegExp("google_ad_client").test(a[1]) ? a[1] : null,
        cD = a => {
            if (a = a.innerText || a.innerHTML)
                if (a = a.replace(/^\s+|\s+$/g, "").replace(/\s*(\r?\n)+\s*/g, ";"), (a = a.match(/^\x3c!--+(.*?)(?:--+>)?$/) || a.match(/^\/*\s*<!\[CDATA\[(.*?)(?:\/*\s*\]\]>)?$/i)) && RegExp("google_ad_client").test(a[1])) return a[1];
            return null
        },
        dD = a => {
            switch (a) {
                case "true":
                    return !0;
                case "false":
                    return !1;
                case "null":
                    return null;
                case "undefined":
                    break;
                default:
                    try {
                        const b = a.match(/^(?:'(.*)'|"(.*)")$/);
                        if (b) return b[1] || b[2] || "";
                        if (/^[-+]?\d*(\.\d+)?$/.test(a)) {
                            const c = parseFloat(a);
                            return c === c ? c : void 0
                        }
                    } catch (b) {}
            }
        };
    async function eD(a, b, c) {
        return 0 >= c ? Promise.reject() : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e())
            }, 200)
        })
    };

    function fD(a) {
        const b = a.state.pc;
        return null !== b && 0 !== b ? b : a.state.pc = qh(a.win)
    }

    function gD(a) {
        var b = a.state.wpc;
        if (null === b || "" === b) {
            b = a.state;
            var c = a.win;
            if (c.google_ad_client) a = String(c.google_ad_client);
            else {
                if (null == (a = MC(c).head_tag_slot_vars ? .google_ad_client ? ? c.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client"))) {
                    b: {
                        a = c.document.getElementsByTagName("script");c = c.navigator && c.navigator.userAgent || "";c = RegExp("appbankapppuzdradb|daumapps|fban|fbios|fbav|fb_iab|gsa/|messengerforios|naver|niftyappmobile|nonavigation|pinterest|twitter|ucbrowser|yjnewsapp|youtube", "i").test(c) ||
                        /i(phone|pad|pod)/i.test(c) && /applewebkit/i.test(c) && !/version|safari/i.test(c) && !ki() ? bD : cD;
                        for (var d = a.length - 1; 0 <= d; d--) {
                            var e = a[d];
                            if (!e.google_parsed_script_for_pub_code && (e.google_parsed_script_for_pub_code = !0, e = c(e))) {
                                a = e;
                                break b
                            }
                        }
                        a = null
                    }
                    if (a) {
                        c = /(google_\w+) *= *(['"]?[\w.-]+['"]?) *(?:;|$)/gm;
                        for (d = {}; e = c.exec(a);) d[e[1]] = dD(e[2]);
                        a = d;
                        a = a.google_ad_client ? a.google_ad_client : ""
                    } else a = ""
                }
                a = a ? ? ""
            }
            b = b.wpc = a
        }
        return b
    }

    function hD(a, b) {
        var c = new wk,
            d = fD(a);
        c = id(c, 1, d).Na(gD(a));
        c = id(c, 3, a.state.sd);
        return id(c, 7, Math.round(b || a.win.performance.now()))
    }
    async function iD(a) {
        await eD(a.win, () => !(!fD(a) || !gD(a)), 10)
    }
    async function jD(a, b, c) {
        if (a.j && c.length && !a.state.lgdp.includes(Number(b))) {
            a.state.lgdp.push(Number(b));
            var d = a.win.performance.now();
            await iD(a);
            var e = a.sa;
            a = hD(a, d);
            d = new Mj;
            b = od(d, 1, b);
            c = Uc(b, 2, c);
            c = bd(a, 9, xk, c);
            yk(e, c)
        }
    }

    function kD(a, b) {
        var c = hD(a);
        b = bd(c, 5, xk, b);
        a.j && !a.state.le.includes(2) && (a.state.le.push(2), yk(a.sa, b))
    }
    var lD = class {
        constructor(a) {
            this.win = Jh() || window;
            this.sa = a ? ? new Hk;
            if (T(dp)) this.state = RC(OC(), 33, () => {
                const b = V(ep);
                return {
                    sd: b,
                    ssp: 0 < b && Rg() < 1 / b,
                    pc: null,
                    wpc: null,
                    le: [],
                    lgdp: []
                }
            });
            else {
                a = V(ep);
                const b = $C(0 < a && Rg() < 1 / a);
                this.state = {
                    sd: a,
                    ssp: b,
                    pc: null,
                    wpc: null,
                    le: [],
                    lgdp: []
                }
            }
        }
        get j() {
            return this.state.ssp
        }
    };
    var nD = (a, b, c, d, e, f = null, g = null, h) => {
            mD(a, new gs(a), b, c, d, e, f, new Pm(a), g, h)
        },
        mD = (a, b, c, d, e, f, g = null, h = null, k = null, l) => {
            if (c)
                if (d) {
                    var m = fy(d, e, a.location);
                    try {
                        const n = new oD(a, b, c, d, e, m, f, g, h, k, l);
                        Ir(990, () => pD(n), a)
                    } catch (n) {
                        ml() && nl(15, [n]), fs(b, Sr, cs(NA(MA((new OA(0)).Na(c), d), m).wa(1), n)), kD(Ik(lD), Bj(new Kj, Yi(1)))
                    }
                } else fs(b, Sr, (new OA(0)).Na(c).wa(8)), kD(Ik(lD), Bj(new Kj, Yi(8)));
            else fs(b, Sr, (new OA(0)).wa(9)), kD(Ik(lD), Bj(new Kj, Yi(9)))
        };

    function pD(a) {
        a.C.forEach(b => {
            switch (b) {
                case 0:
                    Ir(991, () => qD(a), a.l);
                    break;
                case 1:
                    Ir(1073, () => {
                        const c = T(wp),
                            d = a.m.U ? Rc(a.m.U, 2) : [];
                        c && 0 == d.length || Sx(new Wx(a.l, a.A, a.j, a.B, a.m.U, c))
                    }, a.l);
                    break;
                case 5:
                    rx(new sx(a.l, a.A, a.j, a.B));
                    break;
                case 2:
                    rD(a);
                    break;
                case 3:
                    sD(a);
                    break;
                case 4:
                    tD(a)
            }
        })
    }

    function qD(a) {
        (a.j ? .j() ? .j() ? ? !1) && uD(a, "p", vD(a));
        if (No(a.j) && 1 === w(No(a.j), 1)) {
            var b = C(No(a.j), Bn, 6);
            b && 2 === w(b, 1) && (Cr(a.l), a.D = "b")
        }
        var c = a.m.Qf;
        b = kt(a.l, c);
        if (a.m.U && Oc(a.m.U, Kn, 10)) {
            var d = Sc(C(a.m.U, Kn, 10), 1);
            null !== d && void 0 !== d && (b = ct(a.l, d, c))
        }
        Oc(a.j, Hn, 26) && (b = ot(b, C(a.j, Hn, 26), a.l));
        c = a.m.U ? Rc(a.m.U, 6) : [];
        d = a.m.U ? D(a.m.U, Qn, 5) : [];
        const e = a.m.U ? Rc(a.m.U, 2) : [],
            f = Ir(993, () => {
                var g = a.j,
                    h = D(g, xo, 1);
                const k = a.m.U && FC(a.m.U, 1) ? "text_image" : "text";
                var l = new iC;
                let m = os(h, a.l, {
                    Ve: l,
                    Af: new ms(k)
                });
                h.length != m.length && a.H.push(13);
                m = m.concat(nC(new oC(a.l, l)));
                h = 0;
                l = T(up);
                var n = !1;
                if (No(g) && 1 === w(No(g), 1)) {
                    var q = C(No(g), Bn, 6);
                    q && (h = w(q, 2) || 0, 1 === w(q, 1) && (n = !0))
                }
                q = C(g, Mo, 24) ? .v() ? .j() ? .j() || !1;
                if (l || n || q) l = kC(new lC(a.l)), n = Ik(jB), m = m.concat(l), n.K = !0, n.C = l.length, "n" === a.D && (a.D = C(g, Mo, 24) ? .j() ? .length ? "o" : "p");
                m = m.concat(Bz(g, k, a.l));
                g = C(g, Mo, 24);
                return new yB(m, a.l, h, g)
            }, a.l);
        a.v = new ZB(f, a.B, a.l, {
            Qa: b,
            mf: a.N,
            ub: a.m.ub,
            hf: c,
            wc: d
        }, wD(a), e);
        VB(a.v) ? .optimization ? .ablatingThisPageview && !a.v.Da() &&
            (Cr(a.l), Ik(jB).B = !0, a.D = "f");
        a.G = bC(e, a.v, a.l);
        Ir(992, () => hC(a.G), a.l).then(Ir(994, () => a.Fa.bind(a), a.l), a.ua.bind(a))
    }

    function rD(a) {
        const b = C(a.j, zo, 18);
        b && iz(new jz(a.l, new Az(a.l, a.B), b, new cw(a.l), D(a.j, xo, 1)))
    }

    function sD(a) {
        const b = by(a.l.location, "google_audio_sense") ? bo() : C(a.j, co, 27);
        if (b) {
            const c = C(a.j, ro, 6) ? .j() || [];
            fn(fv(a.l, a.A, b, c, a.T, {
                google_ad_client: a.B
            }, C(a.j, oo, 22) ? .j() || null), d => hv(d))
        }
    }

    function tD(a) {
        const b = C(a.j, Co, 29);
        b && xD(a.ca, {
            win: a.l,
            webPropertyCode: a.B,
            Od: b,
            Ad: C(a.j, ro, 6) ? .j() ? ? []
        })
    }

    function wD(a) {
        const b = T(vp);
        if (!a.j.j()) return {
            jd: b,
            od: !1,
            Hd: !1,
            Be: !1,
            Kd: !1,
            ve: !1,
            Of: 0,
            ne: 0,
            vd: yD(a),
            Ic: a.L
        };
        const c = a.j.j();
        return {
            jd: b || I(c, 14, !1),
            od: I(c, 2, !1),
            Hd: I(c, 3, !1),
            Be: I(c, 4, !1),
            Kd: I(c, 5, !1),
            ve: I(c, 6, !1),
            Of: gd(Sc(c, 8), 0),
            ne: w(c, 10),
            vd: yD(a),
            Ic: a.L
        }
    }

    function yD(a) {
        return a.m.U && Oc(a.m.U, Kn, 10) ? .5 <= (Sc(C(a.m.U, Kn, 10), 1) || 0) : !0
    }

    function zD(a, b) {
        for (var c = bs(bs(new OA(b.Ba), b.errors), a.H), d = b.Pa, e = 0; e < d.length; e++) a: {
            for (var f = d[e], g = 0; g < c.B.length; g++)
                if (c.B[g] == f) break a;c.B.push(f)
        }
        c.j.pp = b.nc;
        c.j.ppp = b.oc;
        c.j.ppos = b.placementPositionDiffs;
        c.j.eatf = b.pb;
        c.j.eatfAbg = b.qb;
        c.j.reatf = b.Va;
        c.j.a = a.G.v.slice(0).join(",");
        c = NA(MA(c, a.j), a.C).Na(a.B);
        if (d = b.na) c.j.as_count = d.qd, c.j.d_count = d.Jd, c.j.ng_count = d.ee, c.j.am_count = d.yd, c.j.atf_count = d.rd, c.j.mdns = PA(d.ae), c.j.alldns = PA(d.ud);
        c = c.D(b.hb);
        if (d = b.pf) {
            e = [];
            for (var h of Tl(d)) 0 <
                d.get(h).length && (f = d.get(h)[0], e.push("(" + [h, f.Re, f.lg].join() + ")"));
            c.j.fd = e.join(",")
        }
        h = b.Xc;
        null != h && (c.j.pgh = h);
        c.j.abl = b.Rd;
        c.j.rr = a.D;
        void 0 !== b.exception && cs(c, b.exception).wa(1);
        return c
    }

    function AD(a, b) {
        var c = zD(a, b);
        fs(a.A, 0 < b.errors.length || 0 < a.H.length || void 0 !== b.exception ? 0 < a.K ? Ur : Sr : 0 < a.K ? Tr : Rr, c);
        if (C(a.j, Mo, 24)) {
            a.v.l.j.j ? .G();
            b = VB(a.v);
            var d = Ik(jB);
            d.m = !!b ? .optimization ? .ablationFromStorage;
            b ? .optimization ? .ablatingThisPageview && (d.D = !0);
            d.L = !!b ? .optimization ? .availableAbg;
            b = Ik(jB);
            c = new aB(c);
            b.A ? (c.l.sl = (b.A ? ? []).join("~"), c.l.daaos = (b.H ? ? []).join("~"), c.l.ab = RA(b.D), c.l.rr = RA(b.K), c.l.oab = RA(b.G), null != b.m && (c.l.sab = RA(b.m)), b.B && (c.l.fb = RA(b.B)), c.l.ls = RA(b.L), QA(c,
                b.l.xb()), null != b.C && (c.l.rp = RA(b.C)), null != b.v && (c.l.expl = RA(b.v)), iB(b, c)) : (b = c, d = "irr".replace(RegExp("~", "g"), ""), b.l.e = b.l.e ? b.l.e + ("~" + d) : d);
            fs(a.A, Xr, c)
        }
    }

    function BD(a, b) {
        const c = Ik(lD);
        if (c.j) {
            var d = new Kj,
                e = b.Pa.filter(g => null !== g),
                f = a.H.concat(b.errors, b.exception ? [1] : []).filter(g => null !== g);
            Fj(Dj(Ij(Hj(Gj(Ej(yj(Aj(Cj(zj(d, a.G.v.slice(0).map(g => {
                var h = new Xi;
                return x(h, 1, g)
            })), e.map(g => {
                var h = new $i;
                return x(h, 1, g)
            })), f.map(g => Yi(g))), C(a.j, Vn, 23) ? .j()), b.Ba).D(b.hb), b.Va), b.pb), b.qb), a.C.map(g => g.toString())), gj(fj(ej(dj(cj(bj(aj(new hj, b.na ? .qd), b.na ? .Jd), b.na ? .ee), b.na ? .yd), b.na ? .rd), b.na ? .ae), b.na ? .ud));
            C(a.j, Mo, 24) && wj(d);
            kD(c, d)
        }
    }

    function CD(a) {
        if (No(a.j) && 1 === w(No(a.j), 1)) {
            var b;
            if (b = C(No(a.j), Bn, 6)) a = C(No(a.j), Bn, 6), b = 1 <= (w(a, 3) || 0);
            a = !b
        } else a = !1;
        return a
    }

    function DD(a) {
        if (CD(a)) {
            a = a.v;
            var b = Ct({
                Vb: !0,
                Wb: !0
            }, a.j);
            a = 0 < QB(b, a.j)
        } else a = a.v.j, b = Bt({
            Xa: !1,
            Ub: !1
        }, a), a = 0 < QB(b, a);
        return a
    }

    function ED(a, b) {
        try {
            T(mp) && a.v ? .T() ? .A()
        } catch (c) {
            fs(a.A, as, cs(NA(MA((new OA(b)).Na(a.B), a.j), a.C).wa(14), c))
        }
    }

    function FD(a) {
        if (a.j ? .j() ? .j() ? ? !1) {
            var b = vD(a);
            a.I.init(null == b ? void 0 : b, () => {
                uD(a, "s", b)
            });
            a.I.addListener(c => {
                uD(a, "d", vD(a), c);
                a.I.xa();
                if (a.j ? .j() ? .v()) {
                    a.j ? .j() ? .A();
                    try {
                        a.C ? .includes(0) && (a.K++, qD(a), uD(a, "r", vD(a), c))
                    } catch (d) {
                        uD(a, "f", vD(a), c), fs(a.A, Ur, cs(NA(MA((new OA(0)).Na(a.B), a.j), a.C).wa(1), d))
                    }
                }
            })
        }
    }

    function GD(a, b, c) {
        {
            var d = VB(a.v),
                e = b.j;
            const f = e.j,
                g = e.nc;
            let h = e.Ba,
                k = e.oc,
                l = e.errors.slice(),
                m = e.Pa.slice(),
                n = b.exception;
            const q = MC(a.l).had_ads_ablation ? ? !1;
            d ? (d.numAutoAdsPlaced ? h += d.numAutoAdsPlaced : a.G.m && m.push(13), void 0 !== d.exception && (n = d.exception), d.numPostPlacementsPlaced && (k += d.numPostPlacementsPlaced), c = {
                Ba: h,
                nc: g,
                oc: k,
                hb: f,
                errors: e.errors.slice(),
                Pa: m,
                exception: n,
                Va: c,
                pb: !!d.eatf,
                qb: !!d.eatfAbg,
                Rd: q
            }) : (m.push(12), a.G.m && m.push(13), c = {
                Ba: h,
                nc: g,
                oc: k,
                hb: f,
                errors: l,
                Pa: m,
                exception: n,
                Va: c,
                pb: !1,
                qb: !1,
                Rd: q
            })
        }
        c.na = RB(a.v.j);
        if (b = b.j.l) c.pf = b;
        c.Xc = O(a.l).scrollHeight;
        if (ml()) {
            d = a.v.l.l.j.slice(0);
            b = [];
            for (const f of d) {
                d = {};
                e = f.I;
                for (const g of Tl(e)) d[g] = e.get(g);
                d = {
                    anchorElement: ss(f),
                    position: f.j(),
                    clearBoth: f.H,
                    locationType: f.Ya,
                    placed: f.A,
                    placementProto: f.v ? f.v.toJSON() : null,
                    articleStructure: f.B ? f.B.toJSON() : null,
                    rejectionReasons: d
                };
                b.push(d)
            }
            nl(14, [{
                placementIdentifiers: b
            }, a.v.C, c.na])
        }
        return c
    }

    function HD(a, b) {
        var c = a.v.j;
        c = c.googleSimulationState = c.googleSimulationState || {};
        c.amaConfigPlacementCount = b.hb;
        c.numAutoAdsPlaced = b.Ba;
        c.hasAtfAd = b.Va;
        void 0 !== b.exception && (c.exception = b.exception);
        null != a.v && (a = qC(a.l, a.v, {
            Sb: -1,
            wb: -1,
            Ab: -1,
            Vd: !0,
            xd: !0
        }), null != a.j ? (c.placementPositionDiffs = CC(a.j.value), b = BC(a.j.value), a = new Jz, a = bd(a, 2, Kz, b), c.placementPositionDiffsReport = Ad(a)) : (b = a.l.message, c.placementPositionDiffs = "E" + b, a = new Jz, a = Xc(a, 1, Kz, b), c.placementPositionDiffsReport = Ad(a)))
    }

    function ID(a, b) {
        AD(a, {
            Ba: 0,
            hb: void 0,
            errors: [],
            Pa: [],
            exception: b,
            Va: void 0,
            pb: void 0,
            qb: void 0,
            na: void 0
        });
        BD(a, {
            Ba: 0,
            hb: void 0,
            errors: [],
            Pa: [],
            exception: b,
            Va: void 0,
            pb: void 0,
            qb: void 0,
            na: void 0
        })
    }

    function uD(a, b, c, d) {
        b = {
            r: b,
            pg_h: O(a.l).scrollHeight,
            su: a.l.location.hostname,
            d: void 0 == c ? -1 : c
        };
        void 0 !== d && (b.pg_hd = d);
        es(a.A, Wr, b)
    }

    function vD(a) {
        let b = null;
        a.j.j() && null != hd(a.j.j(), 19) && (b = hd(a.j.j(), 19));
        return b
    }
    class oD {
        constructor(a, b, c, d, e, f, g, h, k, l, m) {
            this.l = a;
            this.A = b;
            this.B = c;
            this.j = d;
            this.m = e;
            this.C = f;
            this.N = h || null;
            this.H = [];
            this.I = k;
            this.L = l;
            this.ca = g;
            this.K = 0;
            this.T = m ? m : {
                url: a.location.href,
                Gb: void 0
            };
            this.D = "n"
        }
        Fa(a) {
            try {
                ED(this, a.j.Ba);
                const b = DD(this) || CD(this) ? DD(this) : void 0;
                Uo({
                    Gc: b
                }, this.l);
                FD(this);
                const c = GD(this, a, DD(this));
                Oc(this.j, Un, 25) && y(C(this.j, Un, 25), 1) && HD(this, c);
                AD(this, c);
                BD(this, c);
                Qk(753, () => {
                    if (T(pp) && null != this.v) {
                        var d = qC(this.l, this.v, {
                                Sb: V(tp),
                                wb: V(sp),
                                Ab: V(qp),
                                Vd: !0,
                                xd: !1
                            }),
                            e = de(c);
                        null != d.j ? (d = CC(d.j.value), e.placementPositionDiffs = d) : e.placementPositionDiffs = "E" + d.l.message;
                        e = zD(this, e);
                        fs(this.A, Vr, e)
                    }
                })()
            } catch (b) {
                ID(this, b)
            }
        }
        ua(a) {
            ED(this, 0);
            ID(this, a)
        }
    };
    var JD = class extends K {
            constructor(a) {
                super(a)
            }
        },
        KD = Gd(JD);

    function LD(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? dn(() => KD(c)) : an(null)
    };

    function MD(a) {
        this.j = a || {
            cookie: ""
        }
    }
    p = MD.prototype;
    p.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        "object" === typeof c && (h = c.rk, g = c.eg || !1, f = c.domain || void 0, e = c.path || void 0, d = c.be);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === d && (d = -1);
        this.j.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (0 > d ? "" : 0 == d ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * d)).toUTCString()) + (g ? ";secure" : "") + (null != h ? ";samesite=" + h : "")
    };
    p.get = function(a, b) {
        const c = a + "=",
            d = (this.j.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = Oa(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    p.remove = function(a, b, c) {
        const d = void 0 !== this.get(a);
        this.set(a, "", {
            be: 0,
            path: b,
            domain: c
        });
        return d
    };
    p.isEmpty = function() {
        return !this.j.cookie
    };
    p.xb = function() {
        return this.j.cookie ? (this.j.cookie || "").split(";").length : 0
    };
    p.clear = function() {
        var a = (this.j.cookie || "").split(";");
        const b = [],
            c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = Oa(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) this.remove(b[a])
    };

    function ND(a, b = window) {
        if (y(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    }

    function OD(a) {
        return "null" !== a.origin
    }

    function PD(a, b, c) {
        b = y(b, 5) && OD(c) ? c.document.cookie : null;
        return null === b ? null : (new MD({
            cookie: b
        })).get(a) || ""
    };

    function QD(a, b) {
        return x(a, 5, b)
    }
    var RD = class extends K {
        constructor() {
            super()
        }
        j() {
            return y(this, 6)
        }
    };
    var UD = ({
        win: a,
        Yb: b,
        Td: c = !1,
        Ud: d = !1
    }) => {
        if (!SD({
                win: a,
                Yb: b,
                Td: c,
                Ud: d
            })) return TD(a, QD(new RD, !0));
        (b = TC(OC(), 24)) ? (b = QD(new RD, qz(b)), a = TD(a, b)) : a = new bn(null, Error("tcunav"));
        return a
    };

    function SD({
        win: a,
        Yb: b,
        Td: c,
        Ud: d
    }) {
        if (!(d = !d && uz(new yz(a)))) {
            if (c = !c) {
                if (b) {
                    a = LD(a);
                    if (null != a.j)
                        if ((a = a.j.value) && null != w(a, 1)) b: switch (a = w(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else Sk(806, a.l), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function TD(a, b) {
        return (a = ND(b, a)) ? an(a) : new bn(null, Error("unav"))
    };
    var VD = class extends K {
        constructor(a) {
            super(a)
        }
    };
    class WD {
        constructor(a, b, c, d) {
            this.j = a;
            this.m = b;
            this.A = c;
            this.l = !1;
            this.v = d
        }
    };

    function xD(a, {
        win: b,
        webPropertyCode: c,
        Od: d,
        Ad: e
    }) {
        a = $u(8, b, a.j).then(f => f.runGallerify({
            win: b,
            webPropertyCode: c,
            serializedGallerifyConfig: Ad(d),
            serializedArticleStructures: e.map(g => Ad(g))
        }));
        Nk.Aa(927, a)
    }
    var XD = class {
        constructor(a) {
            this.j = a
        }
    };

    function YD({
        win: a,
        webPropertyCode: b,
        vb: c
    }) {
        if (by(a.location, "google_auto_gallery")) {
            var d = new Co;
            var e = new Ao;
            e = x(e, 1, !0);
            d = ad(d, 3, e);
            xD(new XD(c), {
                win: a,
                webPropertyCode: b,
                Od: d,
                Ad: []
            })
        }
    };
    var ZD = "a".charCodeAt(),
        $D = ce(tl),
        aE = ce(ul);

    function bE(a, b) {
        if (a.j + b > a.l.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.l.substring(a.j, a.j + b);
        a.j += b;
        return parseInt(c, 2)
    }

    function cE(a) {
        return String.fromCharCode(ZD + bE(a, 6)) + String.fromCharCode(ZD + bE(a, 6))
    }

    function dE(a) {
        let b = bE(a, 12);
        const c = [];
        for (; b--;) {
            var d = !0 === !!bE(a, 1),
                e = bE(a, 16);
            if (d)
                for (d = bE(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function eE(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (bE(a, 1)) {
                const f = e + 1;
                if (c && -1 === c.indexOf(f)) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function fE(a) {
        const b = bE(a, 16);
        return !0 === !!bE(a, 1) ? (a = dE(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : eE(a, b)
    }
    class gE {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.l = a;
            this.j = 0
        }
    };
    var iE = (a, b) => {
        try {
            var c = Zb(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new gE(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = !0;
            d.j += 78;
            c.cmpId = bE(d, 12);
            c.cmpVersion = bE(d, 12);
            d.j += 30;
            c.tcfPolicyVersion = bE(d, 6);
            c.isServiceSpecific = !!bE(d, 1);
            c.useNonStandardStacks = !!bE(d, 1);
            c.specialFeatureOptins = hE(eE(d, 12, aE), aE);
            c.purpose = {
                consents: hE(eE(d, 24, $D), $D),
                legitimateInterests: hE(eE(d, 24, $D), $D)
            };
            c.purposeOneTreatment = !!bE(d, 1);
            c.publisherCC = cE(d);
            c.vendor = {
                consents: hE(fE(d), b),
                legitimateInterests: hE(fE(d),
                    b)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const hE = (a, b) => {
        const c = {};
        if (Array.isArray(b) && 0 !== b.length)
            for (const d of b) c[d] = -1 !== a.indexOf(d);
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var jE = class {
        constructor() {
            this.j = {}
        }
    };
    var kE = class extends K {
        constructor() {
            super()
        }
    };
    var lE = class extends K {
        constructor() {
            super()
        }
    };
    var mE = class extends K {
            constructor() {
                super()
            }
        },
        nE = [8, 11, 12, 13, 15, 17, 18, 19, 20, 21, 22, 25, 26, 27];
    var oE = class {};
    var pE = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var qE = class extends K {
        constructor(a) {
            super(a)
        }
    };
    var sE = Gd(class extends K {
            constructor(a) {
                super(a, -1, rE)
            }
        }),
        rE = [7];
    var tE = new class {
        constructor() {
            this.key = "45369554";
            this.defaultValue = !1;
            this.valueType = "boolean"
        }
    };
    var uE = class extends jE {
            constructor() {
                super();
                var a = u.__fcexpdef || "";
                try {
                    const b = JSON.parse(a)[0];
                    a = "";
                    for (let c = 0; c < b.length; c++) a += String.fromCharCode(b.charCodeAt(c) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(c % 10));
                    this.j = JSON.parse(a)
                } catch (b) {}
            }
        },
        vE;

    function wE(a) {
        return (a = xE(a)) ? C(a, qE, 4) : null
    }

    function xE(a) {
        if (a = (new MD(a)).get("FCCDCF", ""))
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                yE(1), b = null
            } else b = a;
            else b = null;
        try {
            return b ? sE(b) : null
        } catch (c) {
            return yE(2), null
        }
    }

    function yE(a) {
        new oE;
        var b = new kE;
        a = x(b, 7, a);
        b = new lE;
        a = ad(b, 1, a);
        b = new mE;
        bd(b, 22, nE, a);
        vE || (vE = new uE);
        a = vE.j[tE.key];
        if ("proto" === tE.valueType) try {
            JSON.parse(a)
        } catch (c) {}
    };

    function zE(a) {
        a.__tcfapiPostMessageReady || AE(new BE(a))
    }

    function AE(a) {
        a.l = b => {
            const c = "string" == typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.j.__tcfapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = "removeEventListener" === e.command ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.j.addEventListener("message", a.l);
        a.j.__tcfapiPostMessageReady = !0
    }
    var BE = class {
        constructor(a) {
            this.j = a;
            this.l = null
        }
    };

    function CE(a) {
        var b = T(zp);
        a.__uspapi || a.frames.__uspapiLocator || (a = new DE(a), EE(a), b && FE(a))
    }

    function EE(a) {
        !a.A || a.j.__uspapi || a.j.frames.__uspapiLocator || (a.j.__uspapiManager = "fc", nz(a.j, "__uspapiLocator"), Ea("__uspapi", (...b) => GE(a, ...b)))
    }

    function FE(a) {
        !a.m || a.j.__tcfapi || a.j.frames.__tcfapiLocator || (a.j.__tcfapiManager = "fc", nz(a.j, "__tcfapiLocator"), a.j.__tcfapiEventListeners = a.j.__tcfapiEventListeners || [], Ea("__tcfapi", (...b) => HE(a, ...b)), zE(a.j))
    }

    function GE(a, b, c, d) {
        "function" === typeof d && "getUSPData" === b && d({
            version: 1,
            uspString: a.A
        }, !0)
    }

    function HE(a, b, c, d, e = null) {
        if ("function" === typeof d)
            if (c && 2 !== c) d(null, !1);
            else switch (c = a.j.__tcfapiEventListeners, b) {
                case "getTCData":
                    !e || Array.isArray(e) && e.every(f => "number" === typeof f) ? d(IE(a, e, null), !0) : d(null, !1);
                    break;
                case "ping":
                    d({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.0",
                        cmpVersion: 1,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    b = c.push(d);
                    d(IE(a, null, b - 1), !0);
                    break;
                case "removeEventListener":
                    c[e] ? (c[e] = null, d(!0)) : d(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    d(null, !1)
            }
    }

    function IE(a, b, c) {
        if (!a.m) return null;
        b = iE(a.m, b);
        b.addtlConsent = null != a.v ? a.v : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    }
    class DE {
        constructor(a) {
            this.j = a;
            this.l = a.document;
            this.A = (a = (a = xE(this.l)) ? C(a, pE, 5) || null : null) ? w(a, 2) : null;
            this.m = (a = wE(this.l)) && null != w(a, 1) ? w(a, 1) : null;
            this.v = (a = wE(this.l)) && null != w(a, 2) ? w(a, 2) : null
        }
    };

    function JE(a) {
        const b = a[0] / 255,
            c = a[1] / 255;
        a = a[2] / 255;
        return .2126 * (.03928 >= b ? b / 12.92 : Math.pow((b + .055) / 1.055, 2.4)) + .7152 * (.03928 >= c ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4)) + .0722 * (.03928 >= a ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4))
    }

    function KE(a, b) {
        a = JE(a);
        b = JE(b);
        return (Math.max(a, b) + .05) / (Math.min(a, b) + .05)
    };
    var LE = Promise;
    class ME {
        constructor(a) {
            this.m = a
        }
        l(a, b, c) {
            this.m.then(d => {
                d.l(a, b, c)
            })
        }
        j(a, b) {
            return this.m.then(c => c.j(a, b))
        }
    };
    class NE {
        constructor(a) {
            this.data = a
        }
    };

    function OE(a, b) {
        PE(a, b);
        return new QE(a)
    }
    class QE {
        constructor(a) {
            this.m = a
        }
        l(a, b, c = []) {
            const d = new MessageChannel;
            PE(d.port1, b);
            this.m.postMessage(a, [d.port2].concat(c))
        }
        j(a, b) {
            return new LE(c => {
                this.l(a, c, b)
            })
        }
    }

    function PE(a, b) {
        b && (a.onmessage = c => {
            b(new NE(c.data, OE(c.ports[0])))
        })
    };
    var TE = ({
        destination: a,
        Ca: b,
        origin: c,
        Sa: d = "ZNWN1d",
        onMessage: e,
        he: f
    }) => RE({
        destination: a,
        uf: () => b.contentWindow,
        Kf: SE(c),
        Sa: d,
        onMessage: e,
        he: f
    });
    const RE = ({
            destination: a,
            uf: b,
            Kf: c,
            uk: d,
            Sa: e,
            onMessage: f,
            he: g
        }) => {
            const h = Object.create(null);
            c.forEach(k => {
                h[k] = !0
            });
            return new ME(new LE((k, l) => {
                const m = n => {
                    n.source && n.source === b() && !0 === h[n.origin] && (n.data.n || n.data) === e && (a.removeEventListener("message", m, !1), d && n.data.t !== d ? l(Error(`Token mismatch while establishing channel "${e}". Expected ${d}, but received ${n.data.t}.`)) : (k(OE(n.ports[0], f)), g && g(n)))
                };
                a.addEventListener("message", m, !1)
            }))
        },
        SE = a => {
            a = "string" === typeof a ? [a] : a;
            const b = Object.create(null);
            a.forEach(c => {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };

    function UE(a, b, c, d, e, f, g = null, h) {
        try {
            var k = a.localStorage
        } catch (r) {
            k = null
        }
        if (k) {
            if (T(op)) var l = null;
            else try {
                l = k.getItem("google_ama_config")
            } catch (r) {
                l = null
            }
            try {
                var m = l ? Qo(l) : null
            } catch (r) {
                m = null
            }
            l = m
        } else l = null;
        a: {
            if (d) try {
                var n = Qo(d);
                break a
            } catch (r) {
                JC(a, {
                    cfg: 1,
                    inv: 1
                })
            }
            n = null
        }
        if (d = n) {
            if (e) {
                n = new Jn;
                ad(d, 3, n);
                l = d.j() && hd(d.j(), 13) ? hd(d.j(), 13) : 1;
                x(n, 1, Date.now() + 864E5 * l);
                n = zd(d, !1);
                d.j() && (l = new In, m = d.j(), m = y(m, 23), l = x(l, 23, null == m ? void 0 : m), m = I(d.j(), 12, !1), l = x(l, 12, m), m = I(d.j(), 15, !1), l = x(l,
                    15, m), ad(n, 15, l));
                l = D(n, xo, 1);
                for (m = 0; m < l.length; m++) x(l[m], 11, Cc);
                x(n, 22, void 0, !1);
                if (T(op)) LC(a);
                else try {
                    (e || a.localStorage).setItem("google_ama_config", Ad(n))
                } catch (r) {
                    JC(a, {
                        lserr: 1
                    })
                }
            }
            e = HC(a, D(d, Tn, 7));
            a: {
                if (e && (n = w(e, 3), l = C(d, no, 9), n && l)) {
                    b: {
                        l = D(l, lo, 1);
                        for (q of l)
                            if (w(q, 1) == n) {
                                var q = C(q, ko, 2) || null;
                                break b
                            }
                        q = null
                    }
                    if (q) break a
                }
                q = C(d, ko, 8) || new ko
            }
            q = {
                Qf: q
            };
            e && (q.U = e);
            e && FC(e, 3) && (q.ub = [1]);
            if (7 === c.google_pgb_reactive && (e = q.U, !e || !y(e, 8))) return !1;
            NC(a, 2) && (nl(5, [d.toJSON()]), e = KC(c), f = new XD(f),
                c = q.U, e.google_package = c && w(c, 4) || "", nD(a, b, d, q, f, new wn(["google-auto-placed"], e), g, {
                    url: a.location.href,
                    Gb: h
                }));
            return !0
        }
        l && (JC(a, {
            cfg: 1,
            cl: 1
        }), LC(a));
        return !1
    };
    var WE = a => {
        const b = a.F;
        null == b.google_ad_output && (b.google_ad_output = "html");
        if (null != b.google_ad_client) {
            var c;
            (c = String(b.google_ad_client)) ? (c = c.toLowerCase(), "ca-" != c.substring(0, 3) && (c = "ca-" + c)) : c = "";
            b.google_ad_client = c
        }
        null != b.google_ad_slot && (b.google_ad_slot = String(b.google_ad_slot));
        b.google_webgl_support = !!Yf.WebGLRenderingContext;
        b.google_ad_section = b.google_ad_section || b.google_ad_region || "";
        b.google_country = b.google_country || b.google_gl || "";
        c = (new Date).getTime();
        Array.isArray(b.google_color_bg) &&
            (b.google_color_bg = VE(a, b.google_color_bg, c));
        Array.isArray(b.google_color_text) && (b.google_color_text = VE(a, b.google_color_text, c));
        Array.isArray(b.google_color_link) && (b.google_color_link = VE(a, b.google_color_link, c));
        Array.isArray(b.google_color_url) && (b.google_color_url = VE(a, b.google_color_url, c));
        Array.isArray(b.google_color_border) && (b.google_color_border = VE(a, b.google_color_border, c));
        Array.isArray(b.google_color_line) && (b.google_color_line = VE(a, b.google_color_line, c))
    };

    function VE(a, b, c) {
        a.j |= 2;
        return b[c % b.length]
    };

    function XE(a, b) {
        var c = Nk,
            d;
        var e;
        d = (e = (e = Eh()) && (d = e.initialLayoutRect) && "number" === typeof d.top && "number" === typeof d.left && "number" === typeof d.width && "number" === typeof d.height ? new Ah(d.left, d.top, d.width, d.height) : null) ? new gg(e.left, e.top) : (d = Hh()) && ta(d.rootBounds) ? new gg(d.rootBounds.left + d.boundingClientRect.left, d.rootBounds.top + d.boundingClientRect.top) : null;
        if (d) return d;
        try {
            var f = new gg(0, 0),
                g = vg(qg(b));
            if (Db(g, "parent")) {
                do {
                    if (g == a) var h = Uh(b);
                    else {
                        var k = Th(b);
                        h = new gg(k.left, k.top)
                    }
                    d =
                        h;
                    f.x += d.x;
                    f.y += d.y
                } while (g && g != a && g != g.parent && (b = g.frameElement) && (g = g.parent))
            }
            return f
        } catch (l) {
            return c.ka(888, l), new gg(-12245933, -12245933)
        }
    };
    var YE = class extends K {
        constructor(a) {
            super(a)
        }
        j() {
            return I(this, 6)
        }
        v() {
            return I(this, 7)
        }
    };
    var $E = class extends K {
            constructor(a) {
                super(a, -1, ZE)
            }
            j() {
                return Tc(this, 1, Lc, !1)
            }
        },
        ZE = [1];
    var bF = class extends K {
            constructor(a) {
                super(a, -1, aF)
            }
        },
        aF = [19],
        cF = [13, 14];

    function dF(a, b) {
        b && !a.j && (a.j = b.split(":").find(c => 0 === c.indexOf("ID=")) || null)
    }
    var eF = class {
            constructor() {
                this.j = null;
                this.l = {
                    [3]: {},
                    [4]: {},
                    [5]: {}
                };
                const a = b => this.j ? Ug(`${b} + ${this.j}`) % 1E3 : void 0;
                this.l[4] = {
                    [9]: (...b) => a(b[0])
                }
            }
        },
        fF;
    let gF = void 0;

    function hF() {
        Fd(gF, Dd);
        return gF
    };

    function iF(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : $d(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && "string" === typeof e && Array.isArray(d))
        } catch (b) {
            return {}
        }
    };

    function jF(a = u) {
        return a.ggeac || (a.ggeac = {})
    };

    function kF(a = document) {
        return !!a.featurePolicy ? .allowedFeatures().includes("browsing-topics")
    };

    function lF(a, b) {
        a.j = Jk(14, b, () => {})
    }
    class mF {
        constructor() {
            this.j = () => {}
        }
    };

    function nF(a = jF()) {
        Kk(Ik(Lk), a);
        oF(a);
        lF(Ik(mF), a);
        Ik(Wq).A()
    }

    function oF(a) {
        const b = Ik(Wq);
        b.j = (c, d) => Jk(5, a, () => !1)(c, d, 1);
        b.l = (c, d) => Jk(6, a, () => 0)(c, d, 1);
        b.m = (c, d) => Jk(7, a, () => "")(c, d, 1);
        b.v = (c, d) => Jk(8, a, () => [])(c, d, 1);
        b.A = () => {
            Jk(15, a, () => {})(1)
        }
    };

    function pF(a) {
        var b = Ik(Lk).l(a);
        a = jD(Ik(lD), a, b);
        pl.Aa(1085, a)
    }
    var qF = a => {
        const b = Ik(Lk).j();
        a = MC(a);
        a.eids || (a.eids = []);
        return b.concat(a.eids).join(",")
    };

    function rF(a, b, c) {
        return c ? PD(b, c, a.j) : null
    }

    function sF(a, b, c, d) {
        if (d) {
            var e = {
                be: w(c, 2) - Date.now() / 1E3,
                path: w(c, 3),
                domain: w(c, 4),
                eg: !1
            };
            a = a.j;
            y(d, 5) && OD(a) && (new MD(a.document)).set(b, w(c, 1), e)
        }
    }

    function tF(a, b, c) {
        if (c && PD(b, c, a.j))
            for (const e of uF(a.j.location.hostname)) {
                var d = a.j;
                y(c, 5) && OD(d) && (new MD(d.document)).remove(b, "/", e)
            }
    }
    var vF = class {
        constructor(a) {
            this.j = a;
            this.l = 0
        }
    };

    function uF(a) {
        if ("localhost" === a) return ["localhost"];
        a = a.split(".");
        if (2 > a.length) return [];
        const b = [];
        for (let c = 0; c < a.length - 1; ++c) b.push(a.slice(c).join("."));
        return b
    };

    function wF(a, b, c) {
        return Qk(629, function(d) {
            delete a._gfp_s_;
            if (!d) throw Error("Invalid JSONP response");
            d = d._cookies_;
            if (!d) return Promise.resolve();
            if (0 === d.length) throw Error("Invalid JSONP response");
            for (const f of d) {
                var e = f._domain_;
                const g = f._value_,
                    h = f._expires_,
                    k = f._path_;
                d = f._version_ || 1;
                if ("string" !== typeof e || "string" !== typeof g || "number" !== typeof h || "string" !== typeof k || "number" !== typeof d || !g) throw Error("Invalid JSONP response");
                e = Lf(Kf(Jf(If(new Mf, g), h), k), e);
                switch (d) {
                    case 1:
                        sF(c,
                            "__gads", e, b);
                        break;
                    case 2:
                        sF(c, "__gpi", e, b)
                }
            }
            return Promise.resolve()
        })
    }

    function xF(a, b, c) {
        let d;
        if (0 === a.l) {
            if (rF(a, "__gads", b)) var e = !0;
            else if (e = a.j, y(b, 5) && OD(e) && (new MD(e.document)).set("GoogleAdServingTest", "Good", void 0), e = "Good" === PD("GoogleAdServingTest", b, a.j)) {
                var f = a.j;
                y(b, 5) && OD(f) && (new MD(f.document)).remove("GoogleAdServingTest", void 0, void 0)
            }
            a.l = e ? 2 : 1
        }
        2 === a.l && (d = wF(c, b, a));
        c._gfp_p_ = !0;
        return d
    }

    function yF(a, b, c, d) {
        d = {
            domain: c.location.hostname,
            callback: "_gfp_s_",
            client: d
        };
        var e = rF(b, "__gads", a);
        e && (d.cookie = e);
        (e = rF(b, "__gpi", a)) && !e.includes("&") && (d.gpic = e);
        const f = oe(re(Kd(Ld("https://partner.googleadservices.com/gampad/cookie.js"))), d),
            g = xF(b, a, c);
        g ? new Promise(h => {
            c._gfp_s_ = k => {
                g(k).then(h)
            };
            Og(c.document, f)
        }) : Promise.resolve()
    }

    function zF(a, b, c) {
        "_gfp_p_" in b || (b._gfp_p_ = !1, "_gfp_a_" in b || (b._gfp_a_ = !0));
        const d = new vF(b);
        c = b.google_ad_client || c;
        var e = b._gfp_a_;
        if ("boolean" !== typeof e) throw Error(`Illegal value of ${"_gfp_a_"}: ${e}`);
        if (e) {
            e = b._gfp_p_;
            if ("boolean" !== typeof e) throw Error(`Illegal value of ${"_gfp_p_"}: ${e}`);
            e ? Promise.resolve() : yF(a, d, b, c)
        } else Promise.resolve();
        a = rF(d, "__gads", a) || "";
        fF || (fF = new eF);
        b = fF;
        dF(b, a);
        a = b.l;
        Ik(mF).j(a);
        pF(20);
        pF(17)
    };

    function AF(a) {
        if (T(gq)) {
            a.easpi = T(gq);
            T(fq) && (a.easpa = !0);
            a.asntp = 0;
            a.asntpv = 0;
            a.asntpl = 0;
            a.asntpm = 0;
            a.asntpc = V(xq);
            a.asna = 5;
            a.asnd = 5;
            a.asnp = 5;
            a.asns = 5;
            a.asmat = V(vq);
            a.asptt = -1;
            T(Eq) || (a.aspe = !0);
            a.asro = T(zq);
            T(yq) && (a.ascet = !0);
            T(sq) && (a.asgr = !0);
            T(Aq) || (a.asrc = !1);
            T(oq) && (a.asbu = !0);
            T(qq) && (a.aseb = !0);
            1 > V(tq) && (a.asla = V(tq));
            1 > V(jq) && (a.asaa = V(jq));
            T(Lq) && (a.asupm = !0);
            var b = V(uq);
            0 < b && (a.asmrc = b)
        }
    };

    function BF(a, b) {
        return ry({
            J: a,
            Rc: 3E3,
            Tc: a.innerWidth > Dl ? 650 : 0,
            sa: Mk,
            Cd: b
        })
    };
    var CF = a => {
        let b = 0;
        try {
            b |= a != a.top ? 512 : 0, b |= El(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };
    var DF = a => {
        let b = 0;
        try {
            b |= a != a.top ? 512 : 0, b |= El(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };
    var EF = a => {
            let b = 0;
            try {
                b |= a != a.top ? 512 : 0, b |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0
            } catch (c) {
                b |= 32
            }
            return b
        },
        FF = (a, b, c) => {
            let d = 0;
            try {
                d |= El(a, 2500);
                if (T(Vp)) {
                    const g = O(a).clientHeight;
                    d |= g ? 320 > g ? 2097152 : 0 : 1073741824
                }
                d |= Fl(a);
                var e;
                if (e = 0 < b) {
                    var f = Tz(c, b);
                    e = !(f && 1 > f.length)
                }
                e && (d |= 134217728)
            } catch (g) {
                d |= 32
            }
            return d
        };

    function GF(a, b, c, d = null) {
        if (!T(Yp)) return 32;
        let e = a != a.top ? 512 : 0;
        sy(a.navigator ? .userAgent) && (e |= 1048576);
        const f = a.innerWidth;
        1200 > f && (e |= 65536);
        const g = a.innerHeight;
        650 > g && (e |= 2097152);
        d && 0 === e && (HF({
            J: a,
            Yd: b,
            xe: 1,
            position: 3 === d ? "left" : "right",
            O: f,
            W: g,
            Ja: new Set,
            minWidth: 120,
            minHeight: 500,
            ue: c
        }) || (e |= 16));
        return e
    }

    function IF(a) {
        var b = T(Fp);
        if (0 !== GF(a, !0, b)) return "";
        const c = [],
            d = a.innerWidth,
            e = a.innerHeight;
        for (const f of ["left", "right"]) {
            const g = HF({
                J: a,
                Yd: !0,
                xe: 1,
                position: f,
                O: d,
                W: e,
                Ja: new Set,
                minWidth: 120,
                minHeight: 500,
                ue: b
            });
            g && c.push(`${g.width}x${g.height}_${String(f).charAt(0)}`)
        }
        return c.join("|")
    }

    function JF(a, b) {
        return null !== Fg(a, c => c.nodeType === Node.ELEMENT_NODE && b.has(c))
    }

    function KF(a, b) {
        return Fg(a, c => c.nodeType === Node.ELEMENT_NODE && "fixed" === b.getComputedStyle(c, null).position)
    }

    function LF(a) {
        const b = [];
        for (const c of a.document.querySelectorAll("*")) {
            const d = a.getComputedStyle(c, null);
            "fixed" === d.position && "none" !== d.display && "hidden" !== d.visibility && b.push(c)
        }
        return b
    }

    function MF(a) {
        return Math.round(10 * Math.round(a / 10))
    }

    function NF(a) {
        return `${a.position}-${MF(a.O)}x${MF(a.W)}-${MF(a.scrollY+a.ib)}Y`
    }

    function OF(a) {
        return `f-${NF({position:a.position,ib:a.ib,scrollY:0,O:a.O,W:a.W})}`
    }

    function PF(a, b) {
        a = Math.min(a ? ? Infinity, b ? ? Infinity);
        return Infinity !== a ? a : 0
    }

    function QF(a, b, c) {
        const d = Al(c.J).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.max(e.top - 10, 0),
                    g = Math.min(e.bottom + 10, c.W),
                    h = Math.max(e.left - 10, 0);
                e = Math.min(e.right + 10, c.O);
                for (var k = .3 * c.O; f <= g; f += 10) {
                    if (0 < e && h < k) {
                        var l = OF({
                            position: "left",
                            ib: f,
                            O: c.O,
                            W: c.W
                        });
                        b.set(l, PF(b.get(l), h))
                    }
                    if (h < c.O && e > c.O - k) {
                        l = OF({
                            position: "right",
                            ib: f,
                            O: c.O,
                            W: c.W
                        });
                        const m = c.O - e;
                        b.set(l, PF(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    }

    function HF(a) {
        if (a.ue && (1200 > a.O || 650 > a.W)) return null;
        var b = Al(a.J).sideRailAvailableSpace;
        if (!a.Yd) {
            var c = {
                    J: a.J,
                    O: a.O,
                    W: a.W,
                    Ja: a.Ja
                },
                d = `f-${MF(c.O)}x${MF(c.W)}`;
            if (!b.has(d)) {
                b.set(d, 0);
                Al(c.J).sideRailProcessedFixedElements.clear();
                d = new Set([...Array.from(c.J.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]")), ...c.Ja]);
                for (var e of LF(c.J)) JF(e, d) || QF(e, b, c)
            }
        }
        c = [];
        d = .9 * a.W;
        var f = Ll(a.J),
            g = e = (a.W - d) / 2,
            h = d / 7;
        for (var k = 0; 8 > k; k++) {
            var l = c,
                m = l.push;
            a: {
                var n = g;
                var q = a.position,
                    r = b,
                    t = {
                        J: a.J,
                        O: a.O,
                        W: a.W,
                        Ja: a.Ja
                    };
                const z = OF({
                        position: q,
                        ib: n,
                        O: t.O,
                        W: t.W
                    }),
                    A = NF({
                        position: q,
                        ib: n,
                        scrollY: f,
                        O: t.O,
                        W: t.W
                    });
                if (r.has(A)) {
                    n = PF(r.get(z), r.get(A));
                    break a
                }
                const J = "left" === q ? 20 : t.O - 20;
                let E = J;q = .3 * t.O / 5 * ("left" === q ? 1 : -1);
                for (let F = 0; 6 > F; F++) {
                    const H = Dy(t.J.document, Math.round(E), Math.round(n));
                    var B = JF(H, t.Ja);
                    const W = KF(H, t.J);
                    if (!B && null !== W) {
                        QF(W, r, t);
                        r.delete(A);
                        break
                    }
                    B || (B = H.offsetHeight >= .25 * t.W, B = H.offsetWidth >= .9 * t.O && B);
                    if (B) r.set(A, Math.round(Math.abs(E - J) + 20));
                    else if (E !== J) E -=
                        q, q /= 2;
                    else {
                        r.set(A, 0);
                        break
                    }
                    E += q
                }
                n = PF(r.get(z), r.get(A))
            }
            m.call(l, n);
            g += h
        }
        b = a.xe;
        f = a.position;
        d = Math.round(d / 8);
        e = Math.round(e);
        g = a.minWidth;
        a = a.minHeight;
        m = [];
        h = Array(c.length).fill(0);
        for (l = 0; l < c.length; l++) {
            for (; 0 !== m.length && c[m[m.length - 1]] >= c[l];) m.pop();
            h[l] = 0 === m.length ? 0 : m[m.length - 1] + 1;
            m.push(l)
        }
        m = [];
        k = c.length - 1;
        l = Array(c.length).fill(0);
        for (n = k; 0 <= n; n--) {
            for (; 0 !== m.length && c[m[m.length - 1]] >= c[n];) m.pop();
            l[n] = 0 === m.length ? k : m[m.length - 1] - 1;
            m.push(n)
        }
        m = null;
        for (k = 0; k < c.length; k++)
            if (n = {
                    position: f,
                    width: Math.round(c[k]),
                    height: Math.round((l[k] - h[k] + 1) * d),
                    tk: e + h[k] * d
                }, r = n.width >= g && n.height >= a, 0 === b && r) {
                m = n;
                break
            } else 1 === b && r && (!m || n.width * n.height > m.width * m.height) && (m = n);
        return m
    };
    const RF = {
        [27]: 512,
        [26]: 128
    };
    var SF = (a, b, c, d) => {
            switch (c) {
                case 1:
                case 2:
                    return 0 === BF(a, c);
                case 3:
                case 4:
                    return 0 === GF(a, !1, T(Fp), c);
                case 8:
                    return b = "on" === b.google_adtest || by(a.location, "google_ia_debug") ? -1 : 3600, 0 == (EF(a) | FF(a, b, d));
                case 9:
                    return b = !("on" === b.google_adtest || by(a.location, "google_scr_debug")), !Uz(a, b, d);
                case 30:
                    return 0 == IB(a);
                case 26:
                    return 0 == DF(a);
                case 27:
                    return 0 === CF(a);
                case 40:
                    return !0;
                default:
                    return !1
            }
        },
        TF = (a, b, c, d) => {
            switch (c) {
                case 0:
                case 40:
                case 10:
                case 11:
                    return 0;
                case 1:
                case 2:
                    return BF(a, c);
                case 3:
                case 4:
                    return GF(a, !1, T(Fp), c);
                case 8:
                    return b = "on" === b.google_adtest || by(a.location, "google_ia_debug") ? -1 : 3600, EF(a) | FF(a, b, d);
                case 9:
                    return Uz(a, !("on" === b.google_adtest || by(a.location, "google_scr_debug")), d);
                case 16:
                    return qr(b, a) ? 0 : 8388608;
                case 30:
                    return IB(a);
                case 26:
                    return DF(a);
                case 27:
                    return CF(a);
                default:
                    return 32
            }
        },
        UF = (a, b, c) => {
            const d = b.google_reactive_ad_format;
            if (!ae(d)) return !1;
            a = Ng(a);
            if (!a || !SF(a, b, d, c)) return !1;
            b = Al(a);
            if (Jl(b, d)) return !1;
            b.adCount[d] || (b.adCount[d] = 0);
            b.adCount[d]++;
            return !0
        },
        WF = a => {
            const b = a.google_reactive_ad_format;
            return !a.google_reactive_ads_config && VF(a) && 16 !== b && 10 !== b && 11 !== b && 40 !== b && 41 !== b
        },
        XF = a => {
            if (!a.hash) return null;
            let b = null;
            Sg(Zx, c => {
                !b && by(a, c) && (b = $x[c])
            });
            return b
        },
        ZF = (a, b) => {
            const c = Al(a).tagSpecificState[1] || null;
            null != c && null == c.debugCard && Sg(ay, d => {
                !c.debugCardRequested && "number" === typeof d && ey(d, a.location) && (c.debugCardRequested = !0, YF(a, b, e => {
                    c.debugCard = e.createDebugCard(d, a)
                }))
            })
        },
        aG = (a, b, c) => {
            if (!b) return null;
            const d = Al(b);
            let e = 0;
            Sg(be, f => {
                const g =
                    RF[f];
                g && 0 === $F(a, b, f, c) && (e |= g)
            });
            d.wasPlaTagProcessed && (e |= 256);
            a.google_reactive_tag_first && (e |= 1024);
            return e ? "" + e : null
        },
        bG = (a, b, c) => {
            const d = [];
            Sg(be, e => {
                if (T(Yp) || 3 !== e && 4 !== e) {
                    var f = $F(b, a, e, c);
                    0 !== f && d.push(e + ":" + f)
                }
            });
            return d.join(",") || null
        },
        cG = a => {
            const b = [],
                c = {};
            Sg(a, (d, e) => {
                if ((e = yl[e]) && !c[e]) {
                    c[e] = !0;
                    if (d) d = 1;
                    else if (!1 === d) d = 2;
                    else return;
                    b.push(e + ":" + d)
                }
            });
            return b.join(",")
        },
        dG = a => {
            a = a.overlays;
            if (!a) return "";
            a = a.bottom;
            return "boolean" === typeof a ? a ? "1" : "0" : ""
        },
        $F = (a, b, c, d) => {
            if (!b) return 256;
            let e = 0;
            const f = Al(b),
                g = Jl(f, c);
            if (a.google_reactive_ad_format == c || g) e |= 64;
            let h = !1;
            Sg(f.reactiveTypeDisabledByPublisher, (k, l) => {
                String(c) === String(l) && (h = !0)
            });
            h && XF(b.location) !== c && (e |= 128);
            return e | TF(b, a, c, d)
        },
        eG = (a, b) => {
            if (a) {
                var c = Al(a),
                    d = {};
                Sg(b, (e, f) => {
                    (f = yl[f]) && (!1 === e || /^false$/i.test(e)) && (d[f] = !0)
                });
                Sg(be, e => {
                    d[zl[e]] && (c.reactiveTypeDisabledByPublisher[e] = !0)
                })
            }
        },
        fG = (a, b, c) => {
            b = Nk.ta(b, c);
            return $u(1, window, oe(a, Xq(hp) ? {
                bust: Xq(hp)
            } : {})).then(b)
        },
        YF = (a, b, c) => {
            c = Nk.ta(212, c);
            $u(3, a,
                b).then(c)
        };
    const gG = a => {
        a.adsbygoogle || (a.adsbygoogle = [], Og(a.document, N `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`))
    };
    var hG = (a, b) => {
            L(a, "load", () => {
                gG(a);
                a.adsbygoogle.push(b)
            })
        },
        iG = a => {
            a = a.google_reactive_ad_format;
            return ae(a) ? "" + a : null
        },
        VF = a => !!iG(a) || null != a.google_pgb_reactive,
        jG = a => {
            a = iG(a);
            return 26 == a || 27 == a || 30 == a || 16 == a || 40 == a || 41 == a
        };

    function kG(a) {
        return "number" === typeof a.google_reactive_sra_index
    }

    function lG(a, b, c) {
        const d = b.J || b.pubWin,
            e = b.F;
        e.google_reactive_plat = bG(d, e, c);
        var f = cG(a);
        f && (e.google_reactive_plaf = f);
        (f = dG(a)) && (e.google_reactive_fba = f);
        (f = IF(d)) && (e.google_plas = f);
        mG(a, e);
        f = XF(b.pubWin.location);
        nG(a, f, e);
        f ? (e.fra = f, e.google_pgb_reactive = 6) : e.google_pgb_reactive = 5;
        AF(e);
        T(Gp) && (e.fsapi = !0);
        Ih() || fr(b.pubWin.top);
        f = Vk(b.pubWin, "rsrai", Qk(429, (g, h) => oG(b, d, e.google_ad_client, a, g, h, c)), Qk(430, (g, h) => Ol(b.pubWin, "431", Mk, h)));
        b.m.push(f);
        Al(d).wasReactiveTagRequestSent = !0;
        pG(b,
            a, c)
    }

    function pG(a, b, c) {
        const d = a.F,
            e = ta(b.page_level_pubvars) ? b.page_level_pubvars : {};
        b = Vk(a.pubWin, "apcnf", Qk(353, (f, g) => {
            var h = a.pubWin,
                k = d.google_ad_client,
                l = a.da.vb,
                m = a.da.Gb;
            return nh(g.origin) ? UE(h, k, e, f.config, c, l, null, m) : !1
        }), Qk(353, (f, g) => Ol(a.pubWin, "353", Mk, g)));
        a.m.push(b)
    }

    function oG(a, b, c, d, e, f, g) {
        if (!nh(f.origin)) return !1;
        f = e.data;
        if (!Array.isArray(f)) return !1;
        if (!NC(b, 1)) return !0;
        f && nl(6, [f]);
        e = e.amaConfig;
        const h = [],
            k = [],
            l = Al(b);
        let m = null;
        for (let n = 0; n < f.length; n++) {
            if (!f[n]) continue;
            const q = f[n],
                r = q.adFormat;
            l && q.enabledInAsfe && (l.reactiveTypeEnabledInAsfe[r] = !0);
            if (!q.noCreative) {
                q.google_reactive_sra_index = n;
                if (9 === r && e) {
                    q.pubVars = Object.assign(q.pubVars || {}, qG(d, q));
                    const t = new Vz;
                    if (Pz(t, q)) {
                        m = t;
                        continue
                    }
                }
                h.push(q);
                k.push(r)
            }
        }
        h.length && (Rk("rasra::pm", {
            rt: k.join(","),
            c
        }, .1), fG(a.da.re, 522, n => {
            rG(h, b, c, n, d, g)
        }));
        e && UE(b, c, d, e, g, a.da.vb, m);
        return !0
    }

    function qG(a, b) {
        const c = b.adFormat,
            d = b.adKey;
        delete b.adKey;
        const e = {};
        a = a.page_level_pubvars;
        ta(a) && Object.assign(e, a);
        e.google_ad_unit_key = d;
        e.google_reactive_sra_index = b.google_reactive_sra_index;
        30 === c && (e.google_reactive_ad_format = 30);
        e.google_pgb_reactive = e.google_pgb_reactive || 5;
        return b.pubVars = e
    }

    function rG(a, b, c, d, e, f) {
        const g = [];
        for (let h = 0; h < a.length; h++) {
            const k = a[h],
                l = k.adFormat,
                m = k.adKey,
                n = d.configProcessorForAdFormat(l);
            l && n && m ? (k.pubVars = qG(e, k), delete k.google_reactive_sra_index, g.push(l), Pk(466, () => n.verifyAndProcessConfig(b, k, f))) : Rk("rasra::ivc", {
                af: l,
                ak: String(m),
                c
            }, .1)
        }
        Rk("rasra::pr", {
            rt: g.join(","),
            c
        }, .1)
    }

    function mG(a, b) {
        const c = [];
        let d = !1;
        Sg(yl, (e, f) => {
            let g;
            a.hasOwnProperty(f) && (f = a[f], f ? .google_ad_channel && (g = String(f.google_ad_channel)));
            --e;
            c[e] && "+" !== c[e] || (c[e] = g ? g.replace(/,/g, "+") : "+", d || (d = !!g))
        });
        d && (b.google_reactive_sra_channels = c.join(","))
    }

    function nG(a, b, c) {
        if (!c.google_adtest) {
            var d = a.page_level_pubvars;
            if ("on" === a.google_adtest || "on" === d ? .google_adtest || b) c.google_adtest = "on"
        }
    };
    Cb("script");
    var sG = {
        "image-top": 0,
        "image-middle": 1,
        "image-side": 2,
        "text-only": 3,
        "in-article": 4
    };

    function tG(a, b) {
        if (!qr(b, a)) return () => {};
        a = uG(b, a);
        if (!a) return () => {};
        const c = ZC();
        b = de(b);
        const d = {
            La: a,
            F: b,
            offsetWidth: a.offsetWidth
        };
        c.push(d);
        return () => sb(c, d)
    }

    function uG(a, b) {
        a = b.document.getElementById(a.google_async_iframe_id + (T(Hp) ? "_host" : ""));
        if (!a) return null;
        for (a = a.parentElement; a && !vr.test(a.className);) a = a.parentElement;
        return a
    }

    function vG(a, b) {
        for (let g = 0; g < a.childNodes.length; g++) {
            const h = {},
                k = a.childNodes[g];
            var c = k.style,
                d = h,
                e = ["width", "height"];
            for (let l = 0; l < e.length; l++) {
                const m = "google_ad_" + e[l];
                if (!d.hasOwnProperty(m)) {
                    var f = ah(c[e[l]]);
                    f = null === f ? null : Math.round(f);
                    null != f && (d[m] = f)
                }
            }
            if (h.google_ad_width == b.google_ad_width && h.google_ad_height == b.google_ad_height) return k
        }
        return null
    }

    function wG(a, b) {
        a.style.display = b ? "inline-block" : "none";
        const c = a.parentElement;
        b ? c.dataset.adStatus = a.dataset.adStatus : (a.dataset.adStatus = c.dataset.adStatus, delete c.dataset.adStatus)
    }

    function xG(a, b) {
        const c = b.innerHeight >= b.innerWidth ? 1 : 2;
        if (a.l != c) {
            a.l = c;
            a = ZC();
            for (const d of a)
                if (d.La.offsetWidth != d.offsetWidth || d.F.google_full_width_responsive_allowed) d.offsetWidth = d.La.offsetWidth, Pk(467, () => {
                    var e = d.La,
                        f = d.F;
                    const g = vG(e, f);
                    f.google_full_width_responsive_allowed && (e.style.marginLeft = f.gfwroml || "", e.style.marginRight = f.gfwromr || "", e.style.height = f.gfwroh ? f.gfwroh + "px" : "", e.style.width = f.gfwrow ? f.gfwrow + "px" : "", e.style.zIndex = f.gfwroz || "", delete f.google_full_width_responsive_allowed);
                    delete f.google_ad_format;
                    delete f.google_ad_width;
                    delete f.google_ad_height;
                    delete f.google_content_recommendation_ui_type;
                    delete f.google_content_recommendation_rows_num;
                    delete f.google_content_recommendation_columns_num;
                    b.google_spfd(e, f, b);
                    const h = vG(e, f);
                    !h && g && 1 == e.childNodes.length ? (wG(g, !1), f.google_reactive_ad_format = 16, f.google_ad_section = "responsive_resize", e.dataset.adsbygoogleStatus = "reserved", e.className += " adsbygoogle-noablate", gG(b), b.adsbygoogle.push({
                            element: e,
                            params: f
                        })) : h && g ? h !=
                        g && (wG(g, !1), wG(h, !0)) : Rk("auto_size_refresh", {
                            context: "showOrHideElm",
                            url: b.location.href,
                            nodes: e.childNodes.length
                        })
                })
        }
    }
    var yG = class extends Dk {
        constructor() {
            super(...arguments);
            this.l = null
        }
        init(a) {
            const b = OC();
            if (!TC(b, 27, !1)) {
                UC(b, 27, !0);
                this.l = a.innerHeight >= a.innerWidth ? 1 : 2;
                var c = () => xG(this, a);
                L(a, "resize", c);
                Ek(this, () => {
                    Yd(a, "resize", c)
                })
            }
        }
    };
    var zG = class {
        constructor(a, b, c) {
            this.J = a;
            this.La = b;
            this.F = c;
            this.j = null;
            this.l = this.m = 0
        }
        v() {
            10 <= ++this.m && u.clearInterval(this.j);
            var a = tr(this.J, this.La);
            a = ur(this.J, this.La, a);
            const b = pr(this.La, this.J);
            null != b && 0 === b.x || u.clearInterval(this.j);
            a && (this.l++, Rk("rspv:al", {
                aligns: this.l,
                attempt: this.m,
                client: this.F.google_ad_client,
                eoffs: String(null != b ? b.x : null),
                eids: qF(this.F),
                slot: this.F.google_ad_slot,
                url: this.F.google_page_url
            }, .01))
        }
    };
    var Wi = {
        Zj: 0,
        Wj: 1,
        Uj: 2,
        Vj: 3,
        Yj: 5,
        Xj: 7
    };
    var AG = class {
        constructor(a) {
            this.J = a.J;
            this.pubWin = a.pubWin;
            this.F = a.F;
            this.ea = a.ea;
            this.da = a.da;
            this.Za = a.Za;
            this.X = a.X;
            this.A = -1;
            this.j = 0;
            this.l = this.H = null;
            this.G = this.D = 0;
            this.m = [];
            this.tb = this.C = "";
            this.v = this.B = null
        }
    };

    function BG(a, b) {
        var c = QD(a, qz(b));
        c = x(c, 2, b.tcString);
        c = x(c, 4, b.addtlConsent || "");
        x(c, 7, b.internalErrorState);
        c = !sz(b);
        x(a, 9, c);
        null != b.gdprApplies && x(a, 3, b.gdprApplies)
    }

    function CG(a) {
        const b = new yz(a.pubWin, {
            jg: -1,
            We: !0
        });
        if (!uz(b)) return Promise.resolve(null);
        const c = OC(),
            d = TC(c, 24);
        if (d) return Promise.resolve(d);
        const e = new Promise(f => {
            f = {
                resolve: f
            };
            const g = TC(c, 25, []);
            g.push(f);
            UC(c, 25, g)
        });
        d || null === d || (UC(c, 24, null), b.addEventListener(f => {
            if (pz(f)) {
                UC(c, 24, f);
                BG(a.l, f);
                for (const g of TC(c, 25, [])) g.resolve(f);
                UC(c, 25, [])
            } else UC(c, 24, null)
        }));
        return e
    };

    function DG(a, b, c = 1E5) {
        a -= b;
        return a >= c ? "M" : 0 <= a ? a : "-M"
    };
    var FG = (a, b, c) => {
        const d = b.parentElement ? .classList.contains("adsbygoogle") ? b.parentElement : b;
        c.addEventListener("load", () => EG(d));
        return Vk(a, "adpnt", (e, f) => {
            if (Kl(f, c.contentWindow)) {
                e = Nl(e).qid;
                try {
                    c.setAttribute("data-google-query-id", e);
                    a.googletag ? ? (a.googletag = {
                        cmd: []
                    });
                    var g = a.googletag.queryIds ? ? [];
                    g.push(e);
                    500 < g.length && g.shift();
                    a.googletag.queryIds = g
                } catch {}
                d.dataset.adStatus && Rk("adsense_late_fill", {
                    status: d.dataset.adStatus
                });
                d.dataset.adStatus = "filled";
                g = !0
            } else g = !1;
            return g
        })
    };

    function EG(a) {
        setTimeout(() => {
            "filled" !== a.dataset.adStatus && (a.dataset.adStatus = "unfilled")
        }, 1E3)
    };

    function GG(a, b, c) {
        try {
            if (!nh(c.origin) || a.l && !Kl(c, a.l.contentWindow)) return
        } catch (f) {
            return
        }
        const d = b.msg_type;
        let e;
        "string" === typeof d && (e = a.Fa[d]) && a.L.Db(168, () => {
            e.call(a, b, c)
        })
    }
    class HG extends Dk {
        constructor(a, b) {
            var c = Nk,
                d = Mk;
            super();
            this.m = a;
            this.l = b;
            this.L = c;
            this.sa = d;
            this.Fa = {};
            this.He = this.L.ta(168, (e, f) => void GG(this, e, f));
            this.Je = this.L.ta(169, (e, f) => Ol(this.m, "ras::xsf", this.sa, f));
            this.T = [];
            this.ca(this.Fa);
            this.T.push(Uk(this.m, "sth", this.He, this.Je))
        }
        j() {
            for (const a of this.T) a();
            this.T.length = 0;
            super.j()
        }
    };
    class IG extends HG {
        constructor(a, b = null) {
            super(a, b);
            this.m = a
        }
    };
    var JG = class extends IG {
        constructor(a, b) {
            super(a, b);
            this.v = () => {};
            this.l && L(this.l, "load", this.v)
        }
        j() {
            this.l && Yd(this.l, "load", this.v);
            super.j();
            this.l = null
        }
        ca(a) {
            a["adsense-labs"] = b => {
                if (b = Nl(b).settings) try {
                    var c = new Hf(JSON.parse(b));
                    if (null != w(c, 1)) {
                        var d = this.m,
                            e = w(c, 1) || "";
                        if (T(cp) ? null != UD({
                                win: d,
                                Yb: hF()
                            }).j : 1) {
                            if (T(cp)) {
                                const g = UD({
                                    win: d,
                                    Yb: hF()
                                });
                                var f = null != g.j ? iF(g.j.value) : {}
                            } else f = iF(d.localStorage);
                            null !== c && (f[e] = c.toJSON());
                            try {
                                d.localStorage.setItem("google_adsense_settings", JSON.stringify(f))
                            } catch (g) {}
                        }
                    }
                } catch (g) {}
            }
        }
    };

    function KG(a) {
        a.A = a.C;
        a.G.style.transition = "height 500ms";
        a.v.style.transition = "height 500ms";
        a.l.style.transition = "height 500ms";
        LG(a)
    }

    function MG(a, b) {
        a.l.contentWindow.postMessage(JSON.stringify({
            msg_type: "expand-on-scroll-result",
            eos_success: !0,
            eos_amount: b,
            googMsgType: "sth"
        }), "*")
    }

    function LG(a) {
        const b = `rect(0px, ${a.l.width}px, ${a.A}px, 0px)`;
        a.l.style.clip = b;
        a.v.style.clip = b;
        a.l.setAttribute("height", a.A);
        a.l.style.height = a.A + "px";
        a.v.setAttribute("height", a.A);
        a.v.style.height = a.A + "px";
        a.G.style.height = a.A + "px"
    }

    function NG(a, b) {
        b = Zg(b.r_nh);
        a.C = null == b ? 0 : b;
        if (0 >= a.C) return "1";
        a.I = Uh(a.G).y;
        a.H = Ll(a.m);
        if (a.I + a.A < a.H) return "2";
        if (a.I > Gl(a.m) - a.m.innerHeight) return "3";
        b = a.H;
        a.l.setAttribute("height", a.C);
        a.l.style.height = a.C + "px";
        a.v.style.overflow = "hidden";
        a.G.style.position = "relative";
        a.G.style.transition = "height 100ms";
        a.v.style.transition = "height 100ms";
        a.l.style.transition = "height 100ms";
        b = Math.min(b + a.m.innerHeight - a.I, a.A);
        Oh(a.v, {
            position: "relative",
            top: "auto",
            bottom: "auto"
        });
        b = `rect(0px, ${a.l.width}px, ${b}px, 0px)`;
        Oh(a.l, {
            clip: b
        });
        Oh(a.v, {
            clip: b
        });
        return "0"
    }

    function OG(a, b = {}) {
        a.N && (b.eid = a.N);
        b.qid = a.Hb;
        Rk("eoscrl", b, sl(String(a.Ib)))
    }
    class PG extends IG {
        constructor(a, b) {
            super(a.J, b);
            this.v = a.X;
            this.G = this.v.parentElement && this.v.parentElement.classList.contains("adsbygoogle") ? this.v.parentElement : this.v;
            this.A = parseInt(this.v.style.height, 10);
            this.N = null;
            this.Jb = this.Kb = !1;
            this.Hb = "";
            this.ua = this.H = this.C = 0;
            this.Ie = this.A / 5;
            this.I = Uh(this.G).y;
            this.Ib = null;
            this.Ge = Ud(Qk(651, () => {
                this.I = Uh(this.G).y;
                var c = this.H;
                this.H = Ll(this.m);
                this.A < this.C ? (c = this.H - c, 0 < c && (this.ua += c, this.ua >= this.Ie ? (KG(this), MG(this, this.C)) : (this.A = Math.min(this.C,
                    this.A + c), MG(this, c), LG(this)))) : Yd(this.m, "scroll", this.K)
            }), this);
            this.K = () => {
                var c = this.Ge;
                Yf.requestAnimationFrame ? Yf.requestAnimationFrame(c) : c()
            }
        }
        ca(a) {
            a["expand-on-scroll"] = (b, c) => {
                b = Nl(b);
                this.N = b.i_expid;
                this.Hb = b.qid;
                this.Ib = b.gen204_fraction;
                this.Kb || (this.Kb = !0, b = NG(this, b), "0" === b && L(this.m, "scroll", this.K, Vd), c.source.postMessage(JSON.stringify({
                    msg_type: "expand-on-scroll-result",
                    eos_success: "0" === b,
                    googMsgType: "sth"
                }), "*"), OG(this, {
                    err: b
                }))
            };
            a["expand-on-scroll-force-expand"] = () => {
                this.Jb ||
                    (this.Jb = !0, KG(this), Yd(this.m, "scroll", this.K))
            }
        }
        j() {
            this.K && Yd(this.m, "scroll", this.K, Vd);
            super.j()
        }
    };

    function QG(a) {
        const b = a.I.getBoundingClientRect(),
            c = 0 > b.top + b.height;
        return !(b.top > a.m.innerHeight) && !c
    }
    class RG extends Dk {
        constructor(a, b, c) {
            super();
            this.m = a;
            this.A = b;
            this.I = c;
            this.C = 0;
            this.v = QG(this);
            this.H = Td(this.G, this);
            this.l = Qk(433, () => {
                var d = this.H;
                Yf.requestAnimationFrame ? Yf.requestAnimationFrame(d) : d()
            });
            L(this.m, "scroll", this.l, Vd)
        }
        G() {
            const a = QG(this);
            if (a && !this.v) {
                var b = {
                    rr: "vis-bcr"
                };
                const c = this.A.contentWindow;
                c && (Wk(c, "ig", b, "*", 2), 10 <= ++this.C && this.l && Yd(this.m, "scroll", this.l, Vd))
            }
            this.v = a
        }
    };

    function SG(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    }

    function TG(a) {
        let b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function UG(a) {
        return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
    };

    function VG(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return "string" === typeof c ? c : c.bd + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        Oh(a, "transition", b.join(","))
    }
    var WG = Rd(function() {
        if (Fb) return !0;
        var a = xg(document, "DIV"),
            b = Kb ? "-webkit" : Jb ? "-moz" : Fb ? "-ms" : null,
            c = {
                transition: "opacity 1s linear"
            };
        b && (c[b + "-transition"] = "opacity 1s linear");
        b = Xe("div", {
            style: c
        });
        ag(a, b);
        a = a.firstChild;
        b = a.style[mg("transition")];
        return "" != ("undefined" !== typeof b ? b : a.style[Ph(a, "transition")] || "")
    });

    function XG(a, b, c) {
        0 > a.l[b].indexOf(c) && (a.l[b] += c)
    }

    function YG(a, b) {
        0 <= a.j.indexOf(b) || (a.j = b + a.j)
    }

    function ZG(a, b) {
        0 > a.m.indexOf(b) && (a.m = b + a.m)
    }

    function $G(a, b, c, d) {
        return "" != a.m || b ? null : "" == a.j.replace(aH, "") ? null != c && a.l[0] || null != d && a.l[1] ? !1 : !0 : !1
    }

    function bH(a) {
        var b = $G(a, "", null, 0);
        if (null === b) return "XS";
        b = b ? "C" : "N";
        a = a.j;
        return 0 <= a.indexOf("a") ? b + "A" : 0 <= a.indexOf("f") ? b + "F" : b + "S"
    }
    var cH = class {
        constructor(a, b) {
            this.l = ["", ""];
            this.j = a || "";
            this.m = b || ""
        }
        toString() {
            return [this.l[0], this.l[1], this.j, this.m].join("|")
        }
    };

    function dH(a) {
        let b = a.T;
        a.H = function() {};
        eH(a, a.D, b);
        let c = a.D.parentElement;
        if (!c) return a.j;
        let d = !0,
            e = null;
        for (; c;) {
            try {
                e = /^head|html$/i.test(c.nodeName) ? null : Qg(c, b)
            } catch (g) {
                ZG(a.j, "c")
            }
            const f = fH(a, b, c, e);
            c.classList.contains("adsbygoogle") && e && (/^\-.*/.test(e["margin-left"]) || /^\-.*/.test(e["margin-right"])) && (a.N = !0);
            if (d && !f && gH(e)) {
                YG(a.j, "l");
                a.I = c;
                break
            }
            d = d && f;
            if (e && hH(a, e)) break;
            c.parentNode && "#document-fragment" === c.parentNode.nodeName && c.parentNode.toString && "[object ShadowRoot]" ===
                c.parentNode.toString() ? c = c.parentNode.host : c = c.parentElement;
            if (!c) {
                if (b === a.Jb) break;
                try {
                    if (c = b.frameElement, b = b.parent, !Kg(b)) {
                        YG(a.j, "c");
                        break
                    }
                } catch (g) {
                    YG(a.j, "c");
                    break
                }
            }
        }
        a.G && a.v && iH(a);
        return a.j
    }

    function jH(a) {
        function b() {
            kH(c, f, g);
            if (h && !k && !g) {
                const l = function(m) {
                    for (let n = 0; n < m.length; n++) Oh(h, m[n], "0px")
                };
                l(lH);
                l(mH)
            }
        }
        const c = a.D;
        c.style.overflow = a.Ib ? "visible" : "hidden";
        a.G && (a.I ? (VG(c, nH), VG(a.I, nH)) : VG(c, "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1) .3s, height .5s cubic-bezier(.4, 0, 1, 1)"));
        null !== a.L && (c.style.opacity = a.L);
        const d = null != a.C && null != a.m && (a.ua || a.m > a.C) ? a.m : null,
            e = null != a.B && null != a.l && (a.ua || a.l > a.B) ? a.l : null;
        if (a.K) {
            const l = a.K.length;
            for (let m = 0; m < l; m++) kH(a.K[m], d, e)
        }
        const f = a.m,
            g = a.l,
            h = a.I,
            k = a.N;
        a.G ? u.setTimeout(b, 1E3) : b()
    }

    function oH(a) {
        if (a.v && !a.Hb || null == a.m && null == a.l && null == a.L && a.v) return a.j;
        var b = a.v;
        a.v = !1;
        dH(a);
        a.v = b;
        if (!b || null != a.ca && !$G(a.j, a.ca, a.m, a.l)) return a.j;
        0 <= a.j.j.indexOf("n") && (a.C = null, a.B = null);
        if (null == a.C && null !== a.m || null == a.B && null !== a.l) a.G = !1;
        (0 == a.m || 0 == a.l) && 0 <= a.j.j.indexOf("l") && (a.m = 0, a.l = 0);
        b = a.j;
        b.l[0] = "";
        b.l[1] = "";
        b.j = "";
        b.m = "";
        jH(a);
        return dH(a)
    }

    function hH(a, b) {
        let c = !1;
        "none" == b.display && (YG(a.j, "n"), a.v && (c = !0));
        "hidden" != b.visibility && "collapse" != b.visibility || YG(a.j, "v");
        "hidden" == b.overflow && YG(a.j, "o");
        "absolute" == b.position ? (YG(a.j, "a"), c = !0) : "fixed" == b.position && (YG(a.j, "f"), c = !0);
        return c
    }

    function eH(a, b, c) {
        let d = 0;
        if (!b || !b.parentElement) return !0;
        let e = !1,
            f = 0;
        const g = b.parentElement.childNodes;
        for (let k = 0; k < g.length; k++) {
            var h = g[k];
            h == b ? e = !0 : (h = pH(a, h, c), d |= h, e && (f |= h))
        }
        f & 1 && (d & 2 && XG(a.j, 0, "o"), d & 4 && XG(a.j, 1, "o"));
        return !(d & 1)
    }

    function fH(a, b, c, d) {
        let e = null;
        try {
            e = c.style
        } catch (B) {
            ZG(a.j, "s")
        }
        var f = c.getAttribute("width"),
            g = Zg(f),
            h = c.getAttribute("height"),
            k = Zg(h),
            l = d && /^block$/.test(d.display) || e && /^block$/.test(e.display);
        b = eH(a, c, b);
        var m = d && d.width;
        const n = d && d.height;
        var q = e && e.width,
            r = e && e.height,
            t = ah(m) == a.C && ah(n) == a.B;
        m = t ? m : q;
        r = t ? n : r;
        q = ah(m);
        t = ah(r);
        g = null !== a.C && (null !== q && a.C >= q || null !== g && a.C >= g);
        t = null !== a.B && (null !== t && a.B >= t || null !== k && a.B >= k);
        k = !b && gH(d);
        t = b || t || k || !(f || m || d && (!qH(String(d.minWidth)) || !rH(String(d.maxWidth))));
        l = b || g || k || l || !(h || r || d && (!qH(String(d.minHeight)) || !rH(String(d.maxHeight))));
        sH(a, 0, t, c, "width", f, a.C, a.m);
        tH(a, 0, "d", t, e, d, "width", m, a.C, a.m);
        tH(a, 0, "m", t, e, d, "minWidth", e && e.minWidth, a.C, a.m);
        tH(a, 0, "M", t, e, d, "maxWidth", e && e.maxWidth, a.C, a.m);
        a.Kb ? (c = /^html|body$/i.test(c.nodeName), f = ah(n), h = d ? "auto" === d.overflowY || "scroll" === d.overflowY : !1, h = null != a.l && d && f && Math.round(f) !== a.l && !h && "100%" !== d.minHeight, a.v && !c && h && (e.setProperty("height", "auto", "important"), d && !qH(String(d.minHeight)) && e.setProperty("min-height",
            "0px", "important"), d && !rH(String(d.maxHeight)) && a.l && Math.round(f) < a.l && e.setProperty("max-height", "none", "important"))) : (sH(a, 1, l, c, "height", h, a.B, a.l), tH(a, 1, "d", l, e, d, "height", r, a.B, a.l), tH(a, 1, "m", l, e, d, "minHeight", e && e.minHeight, a.B, a.l), tH(a, 1, "M", l, e, d, "maxHeight", e && e.maxHeight, a.B, a.l));
        return b
    }

    function iH(a) {
        function b() {
            if (0 < c) {
                var l = Qg(e, d) || {};
                const m = ah(l.width);
                l = ah(l.height);
                null !== m && null !== f && h && h(0, f - m);
                null !== l && null !== g && h && h(1, g - l);
                --c
            } else u.clearInterval(k), h && (h(0, 0), h(1, 0))
        }
        let c = 31.25;
        const d = a.T,
            e = a.D,
            f = a.m,
            g = a.l,
            h = a.H;
        let k;
        u.setTimeout(function() {
            k = u.setInterval(b, 16)
        }, 990)
    }

    function pH(a, b, c) {
        if (3 == b.nodeType) return /\S/.test(b.data) ? 1 : 0;
        if (1 == b.nodeType) {
            if (/^(head|script|style)$/i.test(b.nodeName)) return 0;
            let d = null;
            try {
                d = Qg(b, c)
            } catch (e) {}
            if (d) {
                if ("none" == d.display || "fixed" == d.position) return 0;
                if ("absolute" == d.position) {
                    if (!a.A.boundingClientRect || "hidden" == d.visibility || "collapse" == d.visibility) return 0;
                    c = null;
                    try {
                        c = b.getBoundingClientRect()
                    } catch (e) {
                        return 0
                    }
                    return (c.right > a.A.boundingClientRect.left ? 2 : 0) | (c.bottom > a.A.boundingClientRect.top ? 4 : 0)
                }
            }
            return 1
        }
        return 0
    }

    function sH(a, b, c, d, e, f, g, h) {
        if (null != h) {
            if ("string" == typeof f) {
                if ("100%" == f || !f) return;
                f = Zg(f);
                null == f && (ZG(a.j, "n"), XG(a.j, b, "d"))
            }
            if (null != f)
                if (c) {
                    if (a.v)
                        if (a.G) {
                            const k = Math.max(f + h - (g || 0), 0),
                                l = a.H;
                            a.H = function(m, n) {
                                m == b && d.setAttribute(e, k - n);
                                l && l(m, n)
                            }
                        } else d.setAttribute(e, h)
                } else XG(a.j, b, "d")
        }
    }

    function tH(a, b, c, d, e, f, g, h, k, l) {
        if (null != l) {
            f = f && f[g];
            "string" != typeof f || ("m" == c ? qH(f) : rH(f)) || (f = ah(f), null == f ? YG(a.j, "p") : null != k && YG(a.j, f == k ? "E" : "e"));
            if ("string" == typeof h) {
                if ("m" == c ? qH(h) : rH(h)) return;
                h = ah(h);
                null == h && (ZG(a.j, "p"), XG(a.j, b, c))
            }
            if (null != h)
                if (d && e) {
                    if (a.v)
                        if (a.G) {
                            const m = Math.max(h + l - (k || 0), 0),
                                n = a.H;
                            a.H = function(q, r) {
                                q == b && (e[g] = m - r + "px");
                                n && n(q, r)
                            }
                        } else e[g] = l + "px"
                } else XG(a.j, b, c)
        }
    }
    var yH = class {
        constructor(a, b, c, d, e, f, g) {
            this.Jb = a;
            this.K = c;
            this.D = b;
            this.T = (a = this.D.ownerDocument) && (a.defaultView || a.parentWindow);
            this.A = new uH(this.D);
            this.v = g;
            this.Hb = vH(this.A, d.md, d.height, d.we);
            this.C = this.v ? this.A.boundingClientRect ? this.A.boundingClientRect.right - this.A.boundingClientRect.left : null : e;
            this.B = this.v ? this.A.boundingClientRect ? this.A.boundingClientRect.bottom - this.A.boundingClientRect.top : null : f;
            this.m = wH(d.width);
            this.l = wH(d.height);
            this.L = this.v ? wH(d.opacity) : null;
            this.ca =
                d.check;
            this.G = "animate" == d.md && !xH(this.A, this.l, this.Fa) && WG();
            this.Ib = !!d.wd;
            this.j = new cH;
            xH(this.A, this.l, this.Fa) && YG(this.j, "r");
            e = this.A;
            e.j && e.l >= e.m && YG(this.j, "b");
            this.I = this.H = null;
            this.N = !1;
            this.ua = !!d.Xf;
            this.Kb = !!d.Zf;
            this.Fa = !!d.we
        }
    };

    function xH(a, b, c) {
        var d;
        (d = a.j) && !(d = !a.v) && (c ? (b = a.l + Math.min(b, wH(a.getHeight())), a = a.j && b >= a.m) : a = a.j && a.l >= a.m, d = a);
        return d
    }
    var uH = class {
        constructor(a) {
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c && Ng(c);
            this.j = !!c;
            this.boundingClientRect = null;
            if (a) try {
                this.boundingClientRect = a.getBoundingClientRect()
            } catch (g) {}
            var d = a;
            let e = 0,
                f = this.boundingClientRect;
            for (; d;) try {
                f && (e += f.top);
                const g = d.ownerDocument,
                    h = g && (g.defaultView || g.parentWindow);
                (d = h && h.frameElement) && (f = d.getBoundingClientRect())
            } catch (g) {
                break
            }
            this.l = e;
            c = c || u;
            this.m = ("CSS1Compat" == c.document.compatMode ? c.document.documentElement : c.document.body).clientHeight;
            b = b && SG(b);
            this.v = !!a && !(2 == b || 3 == b) && !(this.boundingClientRect && this.boundingClientRect.top >= this.boundingClientRect.bottom && this.boundingClientRect.left >= this.boundingClientRect.right)
        }
        isVisible() {
            return this.v
        }
        getWidth() {
            return this.boundingClientRect ? this.boundingClientRect.right - this.boundingClientRect.left : null
        }
        getHeight() {
            return this.boundingClientRect ? this.boundingClientRect.bottom - this.boundingClientRect.top : null
        }
    };

    function vH(a, b, c, d) {
        switch (b) {
            case "no_rsz":
                return !1;
            case "force":
            case "animate":
                return !0;
            default:
                return xH(a, c, d)
        }
    }

    function gH(a) {
        return !!a && /^left|right$/.test(a.cssFloat || a.styleFloat)
    }

    function zH(a, b, c, d) {
        return oH(new yH(a, b, d, c, null, null, !0))
    }
    var AH = new cH("s", ""),
        aH = RegExp("[lonvafrbpEe]", "g");

    function rH(a) {
        return !a || /^(auto|none|100%)$/.test(a)
    }

    function qH(a) {
        return !a || /^(0px|auto|none|0%)$/.test(a)
    }

    function kH(a, b, c) {
        null !== b && null !== Zg(a.getAttribute("width")) && a.setAttribute("width", b);
        null !== c && null !== Zg(a.getAttribute("height")) && a.setAttribute("height", c);
        null !== b && (a.style.width = b + "px");
        null !== c && (a.style.height = c + "px")
    }
    var lH = "margin-left margin-right padding-left padding-right border-left-width border-right-width".split(" "),
        mH = "margin-top margin-bottom padding-top padding-bottom border-top-width border-bottom-width".split(" ");
    let BH = "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1), height .3s cubic-bezier(.4, 0, 1, 1) .2s",
        CH = lH;
    for (let a = 0; a < CH.length; a++) BH += ", " + CH[a] + " .2s cubic-bezier(.4, 0, 1, 1)";
    CH = mH;
    for (let a = 0; a < CH.length; a++) BH += ", " + CH[a] + " .3s cubic-bezier(.4, 0, 1, 1) .2s";
    var nH = BH;

    function wH(a) {
        return "string" === typeof a ? Zg(a) : "number" === typeof a && isFinite(a) ? a : null
    };

    function DH(a, b, c) {
        const d = {
            scrl: Ll(a.m || window),
            adk: a.C,
            adf: a.A,
            fmt: a.v
        };
        b && (d.str = xH(b, Zg(c.r_nh), $g(c.r_cab)), d.ad_y = b.l, d.vph = b.m);
        Sg(c, (e, f) => {
            d[f] = e
        });
        return d
    }

    function EH(a, b, c) {
        const d = sl(String(b.gen204_fraction));
        b = DH(a, c, b);
        b.url = a.m.document.URL;
        Rk("resize", b, d)
    }
    var FH = class extends IG {
        constructor(a, b, c) {
            super(a, b);
            this.C = String(c.google_ad_unit_key || "");
            this.A = String(c.google_ad_dom_fingerprint || "");
            this.v = String(c.google_ad_format || "")
        }
        ca(a) {
            a["resize-me"] = (b, c) => {
                b = Nl(b);
                var d = b.r_chk;
                if (null == d || "" === d) {
                    var e = Zg(b.r_nw),
                        f = Zg(b.r_nh),
                        g = Zg(b.r_no);
                    null != g || 0 !== e && 0 !== f || (g = 0);
                    var h = b.r_str;
                    h = h ? h : null; {
                        var k = g,
                            l = $g(b.r_ao),
                            m = $g(b.r_ifr),
                            n = $g(b.r_cab);
                        const r = window;
                        if (this.l && r)
                            if ("no_rsz" === h) b.err = "7", EH(this, b, null), f = !0;
                            else if (g = new uH(this.l), g.j) {
                            var q =
                                g.getWidth();
                            null != q && (b.w = q);
                            q = g.getHeight();
                            null != q && (b.h = q);
                            if (vH(g, h, f, n)) {
                                const t = this.l.ownerDocument.getElementById(this.l.id + "_host");
                                q = t || this.l;
                                d = zH(r, q, {
                                    width: e,
                                    height: f,
                                    opacity: k,
                                    check: d,
                                    md: h,
                                    wd: l,
                                    Xf: m,
                                    we: n
                                }, t ? [this.l] : null);
                                b.r_cui && $g(b.r_cui.toString()) && M(q, {
                                    height: (null === f ? 0 : f - 48) + "px",
                                    top: "24px"
                                });
                                null != e && (b.nw = e);
                                null != f && (b.nh = f);
                                b.rsz = d.toString();
                                b.abl = bH(d);
                                b.frsz = ("force" === h).toString();
                                b.err = "0";
                                EH(this, b, g);
                                f = !0
                            } else b.err = "1", EH(this, b, g), f = !1
                        } else b.err = "3", EH(this,
                            b, null), f = !1;
                        else b.err = "2", EH(this, b, null), f = !1
                    }
                    e = {
                        msg_type: "resize-result"
                    };
                    e.r_str = h;
                    e.r_status = f;
                    c = c.source;
                    e.googMsgType = "sth";
                    c.postMessage(JSON.stringify(e), "*");
                    this.l.dataset.googleQueryId || this.l.setAttribute("data-google-query-id", b.qid)
                }
            }
        }
        j() {
            super.j();
            this.l = null
        }
    };
    const GH = {
        google: 1,
        googlegroups: 1,
        gmail: 1,
        googlemail: 1,
        googleimages: 1,
        googleprint: 1
    };
    const HH = /^blogger$/,
        IH = /^wordpress(.|\s|$)/i,
        JH = /^joomla!/i,
        KH = /^drupal/i,
        LH = /\/wp-content\//,
        MH = /\/wp-content\/plugins\/advanced-ads/,
        NH = /\/wp-content\/themes\/genesis/,
        OH = /\/wp-content\/plugins\/genesis/;

    function PH(a) {
        var b = a.getElementsByTagName("script"),
            c = b.length;
        for (var d = 0; d < c; ++d) {
            var e = b[d];
            if (e.hasAttribute("src")) {
                e = e.getAttribute("src") || "";
                if (MH.test(e)) return 5;
                if (OH.test(e)) return 6
            }
        }
        b = a.getElementsByTagName("link");
        c = b.length;
        for (d = 0; d < c; ++d)
            if (e = b[d], e.hasAttribute("href") && (e = e.getAttribute("href") || "", NH.test(e) || OH.test(e))) return 6;
        a = a.getElementsByTagName("meta");
        d = a.length;
        for (e = 0; e < d; ++e) {
            var f = a[e];
            if ("generator" == f.getAttribute("name") && f.hasAttribute("content")) {
                f = f.getAttribute("content") ||
                    "";
                if (HH.test(f)) return 1;
                if (IH.test(f)) return 2;
                if (JH.test(f)) return 3;
                if (KH.test(f)) return 4
            }
        }
        for (a = 0; a < c; ++a)
            if (d = b[a], "stylesheet" == d.getAttribute("rel") && d.hasAttribute("href") && (d = d.getAttribute("href") || "", LH.test(d))) return 2;
        return 0
    };
    let QH = navigator;
    var RH = a => {
            let b = 1;
            let c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        SH = (a, b) => {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return RH(a.toLowerCase())
        };
    const TH = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        UH = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        VH = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");
    var WH = () => {
        const a = new kr;
        u.SVGElement && u.document.createElementNS && a.set(0);
        const b = fh();
        b["allow-top-navigation-by-user-activation"] && a.set(1);
        b["allow-popups-to-escape-sandbox"] && a.set(2);
        u.crypto && u.crypto.subtle && a.set(3);
        u.TextDecoder && u.TextEncoder && a.set(4);
        return jr(a)
    };
    var XH = new Map([
        [".google.com", a => N `https://adservice.google.com/adsid/integrator.${a}`],
        [".google.ad", a => N `https://adservice.google.ad/adsid/integrator.${a}`],
        [".google.ae", a => N `https://adservice.google.ae/adsid/integrator.${a}`],
        [".google.com.af", a => N `https://adservice.google.com.af/adsid/integrator.${a}`],
        [".google.com.ag", a => N `https://adservice.google.com.ag/adsid/integrator.${a}`],
        [".google.com.ai", a => N `https://adservice.google.com.ai/adsid/integrator.${a}`],
        [".google.al", a => N `https://adservice.google.al/adsid/integrator.${a}`],
        [".google.co.ao", a => N `https://adservice.google.co.ao/adsid/integrator.${a}`],
        [".google.com.ar", a => N `https://adservice.google.com.ar/adsid/integrator.${a}`],
        [".google.as", a => N `https://adservice.google.as/adsid/integrator.${a}`],
        [".google.at", a => N `https://adservice.google.at/adsid/integrator.${a}`],
        [".google.com.au", a => N `https://adservice.google.com.au/adsid/integrator.${a}`],
        [".google.az", a => N `https://adservice.google.az/adsid/integrator.${a}`],
        [".google.com.bd", a => N `https://adservice.google.com.bd/adsid/integrator.${a}`],
        [".google.be", a => N `https://adservice.google.be/adsid/integrator.${a}`],
        [".google.bf", a => N `https://adservice.google.bf/adsid/integrator.${a}`],
        [".google.bg", a => N `https://adservice.google.bg/adsid/integrator.${a}`],
        [".google.com.bh", a => N `https://adservice.google.com.bh/adsid/integrator.${a}`],
        [".google.bi", a => N `https://adservice.google.bi/adsid/integrator.${a}`],
        [".google.bj", a => N `https://adservice.google.bj/adsid/integrator.${a}`],
        [".google.com.bn", a => N `https://adservice.google.com.bn/adsid/integrator.${a}`],
        [".google.com.bo", a => N `https://adservice.google.com.bo/adsid/integrator.${a}`],
        [".google.com.br", a => N `https://adservice.google.com.br/adsid/integrator.${a}`],
        [".google.bs", a => N `https://adservice.google.bs/adsid/integrator.${a}`],
        [".google.bt", a => N `https://adservice.google.bt/adsid/integrator.${a}`],
        [".google.co.bw", a => N `https://adservice.google.co.bw/adsid/integrator.${a}`],
        [".google.com.bz", a => N `https://adservice.google.com.bz/adsid/integrator.${a}`],
        [".google.ca", a => N `https://adservice.google.ca/adsid/integrator.${a}`],
        [".google.cd", a => N `https://adservice.google.cd/adsid/integrator.${a}`],
        [".google.cf", a => N `https://adservice.google.cf/adsid/integrator.${a}`],
        [".google.cg", a => N `https://adservice.google.cg/adsid/integrator.${a}`],
        [".google.ch", a => N `https://adservice.google.ch/adsid/integrator.${a}`],
        [".google.ci", a => N `https://adservice.google.ci/adsid/integrator.${a}`],
        [".google.co.ck", a => N `https://adservice.google.co.ck/adsid/integrator.${a}`],
        [".google.cl", a => N `https://adservice.google.cl/adsid/integrator.${a}`],
        [".google.cm", a => N `https://adservice.google.cm/adsid/integrator.${a}`],
        [".google.com.co", a => N `https://adservice.google.com.co/adsid/integrator.${a}`],
        [".google.co.cr", a => N `https://adservice.google.co.cr/adsid/integrator.${a}`],
        [".google.com.cu", a => N `https://adservice.google.com.cu/adsid/integrator.${a}`],
        [".google.cv", a => N `https://adservice.google.cv/adsid/integrator.${a}`],
        [".google.com.cy", a => N `https://adservice.google.com.cy/adsid/integrator.${a}`],
        [".google.cz", a => N `https://adservice.google.cz/adsid/integrator.${a}`],
        [".google.de", a => N `https://adservice.google.de/adsid/integrator.${a}`],
        [".google.dj", a => N `https://adservice.google.dj/adsid/integrator.${a}`],
        [".google.dk", a => N `https://adservice.google.dk/adsid/integrator.${a}`],
        [".google.dm", a => N `https://adservice.google.dm/adsid/integrator.${a}`],
        [".google.dz", a => N `https://adservice.google.dz/adsid/integrator.${a}`],
        [".google.com.ec", a => N `https://adservice.google.com.ec/adsid/integrator.${a}`],
        [".google.ee", a => N `https://adservice.google.ee/adsid/integrator.${a}`],
        [".google.com.eg", a => N `https://adservice.google.com.eg/adsid/integrator.${a}`],
        [".google.es", a => N `https://adservice.google.es/adsid/integrator.${a}`],
        [".google.com.et", a => N `https://adservice.google.com.et/adsid/integrator.${a}`],
        [".google.fi", a => N `https://adservice.google.fi/adsid/integrator.${a}`],
        [".google.com.fj", a => N `https://adservice.google.com.fj/adsid/integrator.${a}`],
        [".google.fm", a => N `https://adservice.google.fm/adsid/integrator.${a}`],
        [".google.fr", a => N `https://adservice.google.fr/adsid/integrator.${a}`],
        [".google.ga", a => N `https://adservice.google.ga/adsid/integrator.${a}`],
        [".google.ge", a => N `https://adservice.google.ge/adsid/integrator.${a}`],
        [".google.gg", a => N `https://adservice.google.gg/adsid/integrator.${a}`],
        [".google.com.gh", a => N `https://adservice.google.com.gh/adsid/integrator.${a}`],
        [".google.com.gi", a => N `https://adservice.google.com.gi/adsid/integrator.${a}`],
        [".google.gl", a => N `https://adservice.google.gl/adsid/integrator.${a}`],
        [".google.gm", a => N `https://adservice.google.gm/adsid/integrator.${a}`],
        [".google.gr", a => N `https://adservice.google.gr/adsid/integrator.${a}`],
        [".google.com.gt", a => N `https://adservice.google.com.gt/adsid/integrator.${a}`],
        [".google.gy", a => N `https://adservice.google.gy/adsid/integrator.${a}`],
        [".google.com.hk", a => N `https://adservice.google.com.hk/adsid/integrator.${a}`],
        [".google.hn", a => N `https://adservice.google.hn/adsid/integrator.${a}`],
        [".google.hr", a => N `https://adservice.google.hr/adsid/integrator.${a}`],
        [".google.ht", a => N `https://adservice.google.ht/adsid/integrator.${a}`],
        [".google.hu", a => N `https://adservice.google.hu/adsid/integrator.${a}`],
        [".google.co.id", a => N `https://adservice.google.co.id/adsid/integrator.${a}`],
        [".google.ie", a => N `https://adservice.google.ie/adsid/integrator.${a}`],
        [".google.co.il", a => N `https://adservice.google.co.il/adsid/integrator.${a}`],
        [".google.im", a => N `https://adservice.google.im/adsid/integrator.${a}`],
        [".google.co.in", a => N `https://adservice.google.co.in/adsid/integrator.${a}`],
        [".google.iq", a => N `https://adservice.google.iq/adsid/integrator.${a}`],
        [".google.is", a => N `https://adservice.google.is/adsid/integrator.${a}`],
        [".google.it", a => N `https://adservice.google.it/adsid/integrator.${a}`],
        [".google.je", a => N `https://adservice.google.je/adsid/integrator.${a}`],
        [".google.com.jm", a => N `https://adservice.google.com.jm/adsid/integrator.${a}`],
        [".google.jo", a => N `https://adservice.google.jo/adsid/integrator.${a}`],
        [".google.co.jp", a => N `https://adservice.google.co.jp/adsid/integrator.${a}`],
        [".google.co.ke", a => N `https://adservice.google.co.ke/adsid/integrator.${a}`],
        [".google.com.kh", a => N `https://adservice.google.com.kh/adsid/integrator.${a}`],
        [".google.ki", a => N `https://adservice.google.ki/adsid/integrator.${a}`],
        [".google.kg", a => N `https://adservice.google.kg/adsid/integrator.${a}`],
        [".google.co.kr", a => N `https://adservice.google.co.kr/adsid/integrator.${a}`],
        [".google.com.kw", a => N `https://adservice.google.com.kw/adsid/integrator.${a}`],
        [".google.kz", a => N `https://adservice.google.kz/adsid/integrator.${a}`],
        [".google.la", a => N `https://adservice.google.la/adsid/integrator.${a}`],
        [".google.com.lb", a => N `https://adservice.google.com.lb/adsid/integrator.${a}`],
        [".google.li", a => N `https://adservice.google.li/adsid/integrator.${a}`],
        [".google.lk", a => N `https://adservice.google.lk/adsid/integrator.${a}`],
        [".google.co.ls", a => N `https://adservice.google.co.ls/adsid/integrator.${a}`],
        [".google.lt", a => N `https://adservice.google.lt/adsid/integrator.${a}`],
        [".google.lu", a => N `https://adservice.google.lu/adsid/integrator.${a}`],
        [".google.lv", a => N `https://adservice.google.lv/adsid/integrator.${a}`],
        [".google.com.ly", a => N `https://adservice.google.com.ly/adsid/integrator.${a}`],
        [".google.md", a => N `https://adservice.google.md/adsid/integrator.${a}`],
        [".google.me", a => N `https://adservice.google.me/adsid/integrator.${a}`],
        [".google.mg", a => N `https://adservice.google.mg/adsid/integrator.${a}`],
        [".google.mk", a => N `https://adservice.google.mk/adsid/integrator.${a}`],
        [".google.ml", a => N `https://adservice.google.ml/adsid/integrator.${a}`],
        [".google.com.mm", a => N `https://adservice.google.com.mm/adsid/integrator.${a}`],
        [".google.mn", a => N `https://adservice.google.mn/adsid/integrator.${a}`],
        [".google.ms", a => N `https://adservice.google.ms/adsid/integrator.${a}`],
        [".google.com.mt", a => N `https://adservice.google.com.mt/adsid/integrator.${a}`],
        [".google.mu", a => N `https://adservice.google.mu/adsid/integrator.${a}`],
        [".google.mv", a => N `https://adservice.google.mv/adsid/integrator.${a}`],
        [".google.mw", a => N `https://adservice.google.mw/adsid/integrator.${a}`],
        [".google.com.mx", a => N `https://adservice.google.com.mx/adsid/integrator.${a}`],
        [".google.com.my", a => N `https://adservice.google.com.my/adsid/integrator.${a}`],
        [".google.co.mz", a => N `https://adservice.google.co.mz/adsid/integrator.${a}`],
        [".google.com.na", a => N `https://adservice.google.com.na/adsid/integrator.${a}`],
        [".google.com.ng", a => N `https://adservice.google.com.ng/adsid/integrator.${a}`],
        [".google.com.ni", a => N `https://adservice.google.com.ni/adsid/integrator.${a}`],
        [".google.ne", a => N `https://adservice.google.ne/adsid/integrator.${a}`],
        [".google.nl", a => N `https://adservice.google.nl/adsid/integrator.${a}`],
        [".google.no", a => N `https://adservice.google.no/adsid/integrator.${a}`],
        [".google.com.np", a => N `https://adservice.google.com.np/adsid/integrator.${a}`],
        [".google.nr", a => N `https://adservice.google.nr/adsid/integrator.${a}`],
        [".google.nu", a => N `https://adservice.google.nu/adsid/integrator.${a}`],
        [".google.co.nz", a => N `https://adservice.google.co.nz/adsid/integrator.${a}`],
        [".google.com.om", a => N `https://adservice.google.com.om/adsid/integrator.${a}`],
        [".google.com.pa", a => N `https://adservice.google.com.pa/adsid/integrator.${a}`],
        [".google.com.pe", a => N `https://adservice.google.com.pe/adsid/integrator.${a}`],
        [".google.com.pg", a => N `https://adservice.google.com.pg/adsid/integrator.${a}`],
        [".google.com.ph", a => N `https://adservice.google.com.ph/adsid/integrator.${a}`],
        [".google.com.pk", a => N `https://adservice.google.com.pk/adsid/integrator.${a}`],
        [".google.pl", a => N `https://adservice.google.pl/adsid/integrator.${a}`],
        [".google.pn", a => N `https://adservice.google.pn/adsid/integrator.${a}`],
        [".google.com.pr", a => N `https://adservice.google.com.pr/adsid/integrator.${a}`],
        [".google.ps", a => N `https://adservice.google.ps/adsid/integrator.${a}`],
        [".google.pt", a => N `https://adservice.google.pt/adsid/integrator.${a}`],
        [".google.com.py", a => N `https://adservice.google.com.py/adsid/integrator.${a}`],
        [".google.com.qa", a => N `https://adservice.google.com.qa/adsid/integrator.${a}`],
        [".google.ro", a => N `https://adservice.google.ro/adsid/integrator.${a}`],
        [".google.rw", a => N `https://adservice.google.rw/adsid/integrator.${a}`],
        [".google.com.sa", a => N `https://adservice.google.com.sa/adsid/integrator.${a}`],
        [".google.com.sb", a => N `https://adservice.google.com.sb/adsid/integrator.${a}`],
        [".google.sc", a => N `https://adservice.google.sc/adsid/integrator.${a}`],
        [".google.se", a => N `https://adservice.google.se/adsid/integrator.${a}`],
        [".google.com.sg", a => N `https://adservice.google.com.sg/adsid/integrator.${a}`],
        [".google.sh", a => N `https://adservice.google.sh/adsid/integrator.${a}`],
        [".google.si", a => N `https://adservice.google.si/adsid/integrator.${a}`],
        [".google.sk", a => N `https://adservice.google.sk/adsid/integrator.${a}`],
        [".google.sn", a => N `https://adservice.google.sn/adsid/integrator.${a}`],
        [".google.so", a => N `https://adservice.google.so/adsid/integrator.${a}`],
        [".google.sm", a => N `https://adservice.google.sm/adsid/integrator.${a}`],
        [".google.sr", a => N `https://adservice.google.sr/adsid/integrator.${a}`],
        [".google.st", a => N `https://adservice.google.st/adsid/integrator.${a}`],
        [".google.com.sv", a => N `https://adservice.google.com.sv/adsid/integrator.${a}`],
        [".google.td", a => N `https://adservice.google.td/adsid/integrator.${a}`],
        [".google.tg", a => N `https://adservice.google.tg/adsid/integrator.${a}`],
        [".google.co.th", a => N `https://adservice.google.co.th/adsid/integrator.${a}`],
        [".google.com.tj", a => N `https://adservice.google.com.tj/adsid/integrator.${a}`],
        [".google.tl", a => N `https://adservice.google.tl/adsid/integrator.${a}`],
        [".google.tm", a => N `https://adservice.google.tm/adsid/integrator.${a}`],
        [".google.tn", a => N `https://adservice.google.tn/adsid/integrator.${a}`],
        [".google.to", a => N `https://adservice.google.to/adsid/integrator.${a}`],
        [".google.com.tr", a => N `https://adservice.google.com.tr/adsid/integrator.${a}`],
        [".google.tt", a => N `https://adservice.google.tt/adsid/integrator.${a}`],
        [".google.com.tw", a => N `https://adservice.google.com.tw/adsid/integrator.${a}`],
        [".google.co.tz", a => N `https://adservice.google.co.tz/adsid/integrator.${a}`],
        [".google.com.ua", a => N `https://adservice.google.com.ua/adsid/integrator.${a}`],
        [".google.co.ug", a => N `https://adservice.google.co.ug/adsid/integrator.${a}`],
        [".google.co.uk", a => N `https://adservice.google.co.uk/adsid/integrator.${a}`],
        [".google.com.uy", a => N `https://adservice.google.com.uy/adsid/integrator.${a}`],
        [".google.co.uz", a => N `https://adservice.google.co.uz/adsid/integrator.${a}`],
        [".google.com.vc", a => N `https://adservice.google.com.vc/adsid/integrator.${a}`],
        [".google.co.ve", a => N `https://adservice.google.co.ve/adsid/integrator.${a}`],
        [".google.vg", a => N `https://adservice.google.vg/adsid/integrator.${a}`],
        [".google.co.vi", a => N `https://adservice.google.co.vi/adsid/integrator.${a}`],
        [".google.com.vn", a => N `https://adservice.google.com.vn/adsid/integrator.${a}`],
        [".google.vu", a => N `https://adservice.google.vu/adsid/integrator.${a}`],
        [".google.ws", a => N `https://adservice.google.ws/adsid/integrator.${a}`],
        [".google.rs", a => N `https://adservice.google.rs/adsid/integrator.${a}`],
        [".google.co.za", a => N `https://adservice.google.co.za/adsid/integrator.${a}`],
        [".google.co.zm", a => N `https://adservice.google.co.zm/adsid/integrator.${a}`],
        [".google.co.zw", a => N `https://adservice.google.co.zw/adsid/integrator.${a}`],
        [".google.cat", a => N `https://adservice.google.cat/adsid/integrator.${a}`]
    ].map(([a,
        b
    ]) => [a, {
        json: b("json"),
        js: b("js"),
        ["sync.js"]: b("sync.js")
    }]));

    function YH(a, b, c) {
        const d = Pg("LINK", a);
        try {
            if (d.rel = "preload", Za("preload", "stylesheet")) {
                d.href = qe(b).toString();
                const k = cg('style[nonce],link[rel="stylesheet"][nonce]', d.ownerDocument && d.ownerDocument.defaultView);
                k && d.setAttribute("nonce", k)
            } else {
                if (b instanceof ne) var e = qe(b).toString();
                else {
                    if (b instanceof xe) var f = ye(b);
                    else {
                        if (b instanceof xe) var g = b;
                        else {
                            b = "object" == typeof b && b.qa ? b.ja() : String(b);
                            b: {
                                let k;
                                try {
                                    k = new URL(b)
                                } catch (l) {
                                    var h = "https:";
                                    break b
                                }
                                h = k.protocol
                            }
                            "javascript:" === h && (b =
                                "about:invalid#zClosurez");
                            g = new xe(b, we)
                        }
                        f = ye(g)
                    }
                    e = f
                }
                d.href = e
            }
        } catch {
            return
        }
        d.as = "script";
        c && d.setAttribute("nonce", c);
        if (a = a.getElementsByTagName("head")[0]) try {
            a.appendChild(d)
        } catch {}
    };
    let ZH = u;
    const aI = a => {
        const b = new Map([
            ["domain", u.location.hostname]
        ]);
        $H[3] >= Da() && b.set("adsid", $H[1]);
        return Lh(XH.get(a).js, b)
    };
    let $H, bI;
    const cI = () => {
        ZH = u;
        $H = ZH.googleToken = ZH.googleToken || {};
        const a = Da();
        $H[1] && $H[3] > a && 0 < $H[2] || ($H[1] = "", $H[2] = -1, $H[3] = -1, $H[4] = "", $H[6] = "");
        bI = ZH.googleIMState = ZH.googleIMState || {};
        XH.has(bI[1]) || (bI[1] = ".google.com");
        Array.isArray(bI[5]) || (bI[5] = []);
        "boolean" !== typeof bI[6] && (bI[6] = !1);
        Array.isArray(bI[7]) || (bI[7] = []);
        "number" !== typeof bI[8] && (bI[8] = 0)
    };
    var dI = a => {
        cI();
        XH.has(a) && (bI[1] = a)
    };
    const eI = {
        Lc: () => 0 < bI[8],
        Uf: () => {
            bI[8]++
        },
        Vf: () => {
            0 < bI[8] && bI[8]--
        },
        Wf: () => {
            bI[8] = 0
        },
        sk: () => !1,
        Pd: () => bI[5],
        Bd: a => {
            try {
                a()
            } catch (b) {
                u.setTimeout(() => {
                    throw b;
                }, 0)
            }
        },
        se: () => {
            if (!eI.Lc()) {
                var a = u.document,
                    b = e => {
                        e = aI(e);
                        a: {
                            try {
                                var f = cg("script[nonce]");
                                break a
                            } catch {}
                            f = void 0
                        }
                        YH(a, e.toString(), f);
                        f = Pg("SCRIPT", a);
                        f.type = "text/javascript";
                        f.onerror = () => u.processGoogleToken({}, 2);
                        rf(f, e);
                        try {
                            (a.head || a.body || a.documentElement).appendChild(f), eI.Uf()
                        } catch (g) {}
                    },
                    c = bI[1];
                b(c);
                ".google.com" != c && b(".google.com");
                var d = {
                    newToken: "FBT"
                };
                u.setTimeout(() => u.processGoogleToken(d, 1), 1E3)
            }
        }
    };

    function fI(a) {
        cI();
        const b = ZH.googleToken[5] || 0;
        a && (0 != b || $H[3] >= Da() ? eI.Bd(a) : (eI.Pd().push(a), eI.se()));
        $H[3] >= Da() && $H[2] >= Da() || eI.se()
    }
    var hI = a => {
        u.processGoogleToken = u.processGoogleToken || ((b, c) => gI(b, c));
        fI(a)
    };
    const gI = (a = {}, b = 0) => {
        var c = a.newToken || "",
            d = "NT" == c,
            e = parseInt(a.freshLifetimeSecs || "", 10),
            f = parseInt(a.validLifetimeSecs || "", 10);
        const g = a["1p_jar"] || "";
        a = a.pucrd || "";
        cI();
        1 == b ? eI.Wf() : eI.Vf();
        var h = ZH.googleToken = ZH.googleToken || {},
            k = 0 == b && c && "string" === typeof c && !d && "number" === typeof e && 0 < e && "number" === typeof f && 0 < f && "string" === typeof g;
        d = d && !eI.Lc() && (!($H[3] >= Da()) || "NT" == $H[1]);
        var l = !($H[3] >= Da()) && 0 != b;
        if (k || d || l) d = Da(), e = d + 1E3 * e, f = d + 1E3 * f, 1E-5 > Math.random() && ri(u, "https://pagead2.googlesyndication.com/pagead/gen_204?id=imerr" +
            `&err=${b}`), h[5] = b, h[1] = c, h[2] = e, h[3] = f, h[4] = g, h[6] = a, cI();
        if (k || !eI.Lc()) {
            b = eI.Pd();
            for (c = 0; c < b.length; c++) eI.Bd(b[c]);
            b.length = 0
        }
    };
    const iI = new Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        jI = new Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);

    function kI(a) {
        try {
            const b = a.performance ? .getEntriesByType("navigation") ? .[0];
            if (b ? .type) return iI.get(b.type) ? ? null
        } catch {}
        return jI.get(a.performance ? .navigation ? .type) ? ? null
    };

    function lI(a, b) {
        if (hb()) {
            var c = a.document.documentElement.lang;
            mI(a) ? nI(b, qh(a), !0, "", c) : (new MutationObserver((d, e) => {
                mI(a) && (nI(b, qh(a), !1, c, a.document.documentElement.lang), e.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    }

    function mI(a) {
        a = a.document ? .documentElement ? .classList;
        return !(!a ? .contains("translated-rtl") && !a ? .contains("translated-ltr"))
    }

    function nI(a, b, c, d, e) {
        ui({
            ptt: `${a}`,
            pvsid: `${b}`,
            ibatl: String(c),
            pl: d,
            nl: e
        }, "translate-event")
    };
    var oI = {
            issuerOrigin: "https://attestation.android.com",
            issuancePath: "/att/i",
            redemptionPath: "/att/r"
        },
        pI = {
            issuerOrigin: "https://pagead2.googlesyndication.com",
            issuancePath: "/dtt/i",
            redemptionPath: "/dtt/r",
            getStatePath: "/dtt/s"
        };

    function qI() {
        const a = window.navigator.userAgent,
            b = /Chrome/.test(a);
        return /Android/.test(a) && b
    }

    function rI(a = window) {
        return !a.PeriodicSyncManager
    }

    function sI(a, b, c) {
        a = a.goog_tt_state_map;
        let d, e = [];
        b && (d = a ? .get(oI.issuerOrigin)) && e.push(d);
        c && (d = a ? .get(pI.issuerOrigin)) && e.push(d);
        return e
    }

    function tI(a) {
        return T(Sq) ? !0 : a.some(b => b.hasRedemptionRecord)
    }

    function uI(a, b, c) {
        return b || ".google.ch" === c || "function" === typeof a.__tcfapi
    }

    function vI(a, b) {
        a = T(Sq) ? a.filter(c => 12 !== c.state).map(c => c.issuerOrigin) : a.filter(c => c.hasRedemptionRecord).map(c => c.issuerOrigin);
        if (0 == a.length) return null;
        a = {
            type: "send-redemption-record",
            issuers: a,
            refreshPolicy: "none",
            signRequestData: T(Sq) ? "omit" : "include",
            includeTimestampHeader: !0,
            additionalSignedHeaders: ["sec-time", "Sec-Redemption-Record"]
        };
        !T(Sq) && b && 0 < Object.keys(b).length && (a.additionalSigningData = Yb(JSON.stringify(b)));
        return a
    }

    function wI(a, b, c) {
        if (a = window.goog_tt_state_map ? .get(a)) a.state = b, void 0 != c && (a.hasRedemptionRecord = c)
    }

    function xI() {
        const a = `${oI.issuerOrigin}${oI.redemptionPath}`,
            b = {
                keepalive: !0,
                trustToken: {
                    type: "token-redemption",
                    issuer: oI.issuerOrigin,
                    refreshPolicy: "none"
                }
            };
        wI(oI.issuerOrigin, 2);
        return window.fetch(a, b).then(c => {
            if (!c.ok) throw Error(`${c.status}: Network response was not ok!`);
            wI(oI.issuerOrigin, 6, !0)
        }).catch(c => {
            c && "NoModificationAllowedError" === c.name ? wI(oI.issuerOrigin, 6, !0) : wI(oI.issuerOrigin, 5)
        })
    }

    function yI() {
        const a = `${oI.issuerOrigin}${oI.issuancePath}`;
        wI(oI.issuerOrigin, 8);
        return window.fetch(a, {
            keepalive: !0,
            trustToken: {
                type: "token-request"
            }
        }).then(b => {
            if (!b.ok) throw Error(`${b.status}: Network response was not ok!`);
            wI(oI.issuerOrigin, 10);
            return xI()
        }).catch(b => {
            if (b && "NoModificationAllowedError" === b.name) return wI(oI.issuerOrigin, 10), xI();
            wI(oI.issuerOrigin, 9)
        })
    }

    function zI() {
        wI(oI.issuerOrigin, 13);
        return document.hasTrustToken(oI.issuerOrigin).then(a => a ? xI() : yI())
    }

    function AI() {
        wI(pI.issuerOrigin, 13);
        if (window.Promise) {
            var a = document.hasTrustToken(pI.issuerOrigin).then(e => e).catch(e => window.Promise.reject({
                state: 19,
                error: e
            }));
            const b = `${pI.issuerOrigin}${pI.redemptionPath}`,
                c = {
                    keepalive: !0,
                    trustToken: {
                        type: "token-redemption",
                        refreshPolicy: "none"
                    }
                };
            wI(pI.issuerOrigin, 16);
            a = a.then(e => window.fetch(b, c).then(f => {
                if (!f.ok) throw Error(`${f.status}: Network response was not ok!`);
                wI(pI.issuerOrigin, 18, !0)
            }).catch(f => {
                if (f && "NoModificationAllowedError" === f.name) wI(pI.issuerOrigin,
                    18, !0);
                else {
                    if (e) return window.Promise.reject({
                        state: 17,
                        error: f
                    });
                    wI(pI.issuerOrigin, 17)
                }
            })).then(() => document.hasTrustToken(pI.issuerOrigin).then(e => e).catch(e => window.Promise.reject({
                state: 19,
                error: e
            }))).then(e => {
                const f = `${pI.issuerOrigin}${pI.getStatePath}`;
                wI(pI.issuerOrigin, 20);
                return window.fetch(`${f}?ht=${e}`, {
                    trustToken: {
                        type: "send-redemption-record",
                        issuers: [pI.issuerOrigin]
                    }
                }).then(g => {
                    if (!g.ok) throw Error(`${g.status}: Network response was not ok!`);
                    wI(pI.issuerOrigin, 22);
                    return g.text().then(h =>
                        JSON.parse(h))
                }).catch(g => window.Promise.reject({
                    state: 21,
                    error: g
                }))
            });
            const d = qh(window);
            return a.then(e => {
                const f = `${pI.issuerOrigin}${pI.issuancePath}`;
                return e && e.srqt && e.cs ? (wI(pI.issuerOrigin, 23), window.fetch(`${f}?cs=${e.cs}&correlator=${d}`, {
                    keepalive: !0,
                    trustToken: {
                        type: "token-request"
                    }
                }).then(g => {
                    if (!g.ok) throw Error(`${g.status}: Network response was not ok!`);
                    wI(pI.issuerOrigin, 25);
                    return e
                }).catch(g => window.Promise.reject({
                    state: 24,
                    error: g
                }))) : e
            }).then(e => {
                if (e && e.srdt && e.cs) return wI(pI.issuerOrigin,
                    26), window.fetch(`${b}?cs=${e.cs}&correlator=${d}`, {
                    keepalive: !0,
                    trustToken: {
                        type: "token-redemption",
                        refreshPolicy: "refresh"
                    }
                }).then(f => {
                    if (!f.ok) throw Error(`${f.status}: Network response was not ok!`);
                    wI(pI.issuerOrigin, 28, !0)
                }).catch(f => window.Promise.reject({
                    state: 27,
                    error: f
                }))
            }).then(() => {
                wI(pI.issuerOrigin, 29)
            }).catch(e => {
                if (e instanceof Object && e.hasOwnProperty("state") && e.hasOwnProperty("error"))
                    if ("number" === typeof e.state && e.error instanceof Error) {
                        wI(pI.issuerOrigin, e.state);
                        const f = V(Rq);
                        Math.random() <= f && ui({
                            state: e.state,
                            err: e.error.toString()
                        }, "dtt_err")
                    } else throw Error(e);
                else throw e;
            })
        }
    }

    function BI(a) {
        if (document.hasTrustToken && !T(Pq) && a.m) {
            var b = window.goog_tt_promise_map;
            if (b && b instanceof Map) {
                var c = [];
                if (a.l.some(d => d.issuerOrigin === oI.issuerOrigin)) {
                    let d = b.get(oI.issuerOrigin);
                    d || (d = zI(), b.set(oI.issuerOrigin, d));
                    c.push(d)
                }
                a.l.some(d => d.issuerOrigin === pI.issuerOrigin) && (a = b.get(pI.issuerOrigin), a || (a = AI(), b.set(pI.issuerOrigin, a)), c.push(a));
                if (0 < c.length && window.Promise && window.Promise.all) return window.Promise.all(c)
            }
        }
    }
    var CI = class extends Dk {
        constructor(a, b, c) {
            super();
            this.m = a;
            this.l = [];
            b && qI() && this.l.push(oI);
            c && this.l.push(pI);
            if (document.hasTrustToken && !T(Pq)) {
                const d = new Map;
                this.l.forEach(e => {
                    d.set(e.issuerOrigin, {
                        issuerOrigin: e.issuerOrigin,
                        state: this.m ? 1 : 12,
                        hasRedemptionRecord: !1
                    })
                });
                window.goog_tt_state_map = window.goog_tt_state_map && window.goog_tt_state_map instanceof Map ? new Map([...d, ...window.goog_tt_state_map]) : d;
                window.goog_tt_promise_map && window.goog_tt_promise_map instanceof Map || (window.goog_tt_promise_map =
                    new Map)
            }
        }
    };

    function DI(a) {
        if (a = a.navigator ? .userActivation) {
            var b = 0;
            a ? .hasBeenActive && (b |= 1);
            a ? .isActive && (b |= 2);
            return b
        }
    };
    const EI = /[+, ]/;

    function FI(a, b) {
        const c = a.F;
        var d = a.pubWin,
            e = {},
            f = d.document;
        var g = vh(d);
        var h = lr(d, c.google_ad_width, c.google_ad_height);
        var k = nr(g).Pc;
        var l = d.top == d ? 0 : Kg(d.top) ? 1 : 2;
        var m = 4;
        h || 1 != l ? h || 2 != l ? h && 1 == l ? m = 7 : h && 2 == l && (m = 8) : m = 6 : m = 5;
        k && (m |= 16);
        k = "" + m;
        l = or(d);
        m = !!c.google_page_url;
        e.google_iframing = k;
        0 != l && (e.google_iframing_environment = l);
        if (!m && "ad.yieldmanager.com" == f.domain) {
            for (k = f.URL.substring(f.URL.lastIndexOf("http")); - 1 < k.indexOf("%");) try {
                k = decodeURIComponent(k)
            } catch (q) {
                break
            }
            c.google_page_url = k;
            m = !!k
        }
        m ? (e.google_page_url = c.google_page_url, e.google_page_location = (h ? f.referrer : f.URL) || "EMPTY") : (h && Kg(d.top) && f.referrer && d.top.document.referrer === f.referrer ? e.google_page_url = d.top.document.URL : e.google_page_url = h ? f.referrer : f.URL, e.google_page_location = null);
        if (f.URL === e.google_page_url) try {
            var n = Math.round(Date.parse(f.lastModified) / 1E3) || null
        } catch {
            n = null
        } else n = null;
        e.google_last_modified_time = n;
        d = g == g.top ? g.document.referrer : (d = Eh()) && d.referrer || "";
        e.google_referrer_url = d;
        mr(e, c);
        e = c.google_page_location ||
            c.google_page_url;
        "EMPTY" == e && (e = c.google_page_url);
        e ? (e = e.toString(), 0 == e.indexOf("http://") ? e = e.substring(7, e.length) : 0 == e.indexOf("https://") && (e = e.substring(8, e.length)), d = e.indexOf("/"), -1 == d && (d = e.length), e = e.substring(0, d).split("."), d = !1, 3 <= e.length && (d = e[e.length - 3] in GH), 2 <= e.length && (d = d || e[e.length - 2] in GH), e = d) : e = !1;
        e = e ? "pagead2.googlesyndication.com" : "googleads.g.doubleclick.net";
        b = GI(a, b);
        d = a.F;
        f = d.google_ad_channel;
        g = "/pagead/ads?";
        "ca-pub-6219811747049371" === d.google_ad_client && HI.test(f) &&
            (g = "/pagead/lopri?");
        a = ci(b, `https://${e}${g}` + (I(a.ea, 9) && c.google_debug_params ? c.google_debug_params : ""));
        return c.google_ad_url = a
    }

    function II(a) {
        return encodeURIComponent("RS-" + a.google_reactive_sra_index + "-") + "&" + bi({
            adk: a.google_ad_unit_key,
            client: a.google_ad_client,
            fa: a.google_reactive_ad_format
        })
    }

    function JI(a) {
        try {
            if (a.parentNode) return a.parentNode
        } catch {
            return null
        }
        if (9 === a.nodeType) a: {
            try {
                const c = vg(a);
                if (c) {
                    const d = c.frameElement;
                    if (d && Kg(c.parent)) {
                        var b = d;
                        break a
                    }
                }
            } catch {}
            b = null
        }
        else b = null;
        return b
    }

    function KI(a, b) {
        b.eid = qF(a.pubWin);
        const c = a.F.google_loeid;
        "string" === typeof c && (a.j |= 4096, b.loeid = c)
    }

    function LI(a, b) {
        a = (a = Ng(a.pubWin)) && a.document ? hr(a.document, a) : new gg(-12245933, -12245933);
        b.scr_x = Math.round(a.x);
        b.scr_y = Math.round(a.y)
    }

    function MI(a) {
        try {
            const b = u.top.location.hash;
            if (b) {
                const c = b.match(a);
                return c && c[1] || ""
            }
        } catch {}
        return ""
    }

    function NI(a) {
        const b = Fi();
        b && (a.debug_experiment_id = b);
        a.creatives = MI(/\b(?:creatives)=([\d,]+)/);
        a.adgroups = MI(/\b(?:adgroups)=([\d,]+)/);
        a.adgroups && (a.adtest = "on", a.disable_budget_throttling = !0, a.use_budget_filtering = !1, a.retrieve_only = !0, a.disable_fcap = !0)
    }

    function OI(a, b, c) {
        const d = a.F;
        var e = a.pubWin,
            f = a.J,
            g = vh(window);
        d.fsapi && (b.fsapi = !0);
        b.ref = d.google_referrer_url;
        b.loc = d.google_page_location;
        var h;
        (h = Eh(e)) && ta(h.data) && "string" === typeof h.data.type ? (h = h.data.type.toLowerCase(), h = "doubleclick" == h || "adsense" == h ? null : h) : h = null;
        h && (b.apn = h.substr(0, 10));
        g = nr(g);
        b.url || b.loc || !g.url || (b.url = g.url, g.Pc || (b.usrc = 1));
        h = d.google_trust_token_additional_signing_data || {};
        h.url = b.url;
        d.google_trust_token_additional_signing_data = h;
        g.url != (b.loc || b.url) && (b.top =
            g.url);
        a.tb && (b.etu = a.tb);
        !T(xp) && 0 <= a.A && (b.eae = a.A);
        (c = aG(d, f, f ? ND(c, f) : null)) && (b.fc = c);
        if (!li(d)) {
            c = a.pubWin.document;
            g = "";
            if (c.documentMode && (h = (new pg(c)).createElement("IFRAME"), h.frameBorder = "0", h.style.height = 0, h.style.width = 0, h.style.position = "absolute", c.body)) {
                c.body.appendChild(h);
                try {
                    const Q = h.contentWindow.document;
                    Q.open();
                    Q.write(Te(ef));
                    Q.close();
                    g += Q.documentMode
                } catch (Q) {}
                c.body.removeChild(h)
            }
            b.docm = g
        }
        let k, l, m, n, q, r, t, B, z;
        try {
            var A = e.screenX;
            k = e.screenY
        } catch (Q) {}
        try {
            l = e.outerWidth,
                m = e.outerHeight
        } catch (Q) {}
        try {
            n = e.innerWidth, q = e.innerHeight
        } catch (Q) {}
        try {
            r = e.screenLeft, t = e.screenTop
        } catch (Q) {}
        try {
            n = e.innerWidth, q = e.innerHeight
        } catch (Q) {}
        try {
            B = e.screen.availWidth, z = e.screen.availTop
        } catch (Q) {}
        b.brdim = [r, t, A, k, B, z, l, m, n, q].join();
        A = 0;
        void 0 === u.postMessage && (A |= 1);
        0 < A && (b.osd = A);
        b.vis = SG(e.document);
        A = a.X;
        e = VF(d) ? AH : oH(new yH(e, A, null, {
            width: 0,
            height: 0
        }, d.google_ad_width, d.google_ad_height, !1));
        b.rsz = e.toString();
        b.abl = bH(e);
        if (!VF(d) && (e = mi(d), null != e)) {
            A = 0;
            a: {
                try {
                    {
                        var J = d.google_async_iframe_id;
                        const Q = window.document;
                        if (J) var E = Q.getElementById(J + (T(Hp) ? "_host" : ""));
                        else {
                            var F = Q.getElementsByTagName("script"),
                                H = F[F.length - 1];
                            E = H && H.parentNode || null
                        }
                    }
                    if (J = E) {
                        E = [];
                        F = 0;
                        for (var W = Date.now(); 100 >= ++F && 50 > Date.now() - W && (J = JI(J));) 1 === J.nodeType && E.push(J);
                        var Va = E;
                        b: {
                            for (W = 0; W < Va.length; W++) {
                                c: {
                                    var ea = Va[W];
                                    try {
                                        if (ea.parentNode && 0 < ea.offsetWidth && 0 < ea.offsetHeight && ea.style && "none" !== ea.style.display && "hidden" !== ea.style.visibility && (!ea.style.opacity || 0 !== Number(ea.style.opacity))) {
                                            const Q =
                                                ea.getBoundingClientRect();
                                            var Z = 0 < Q.right && 0 < Q.bottom;
                                            break c
                                        }
                                    } catch (Q) {}
                                    Z = !1
                                }
                                if (!Z) {
                                    var va = !1;
                                    break b
                                }
                            }
                            va = !0
                        }
                        if (va) {
                            b: {
                                const Q = Date.now();va = /^html|body$/i;Z = /^fixed/i;
                                for (ea = 0; ea < Va.length && 50 > Date.now() - Q; ea++) {
                                    const qb = Va[ea];
                                    if (!va.test(qb.tagName) && Z.test(qb.style.position || Sh(qb, "position"))) {
                                        var ja = qb;
                                        break b
                                    }
                                }
                                ja = null
                            }
                            break a
                        }
                    }
                } catch {}
                ja = null
            }
            ja && ja.offsetWidth * ja.offsetHeight <= 4 * e.width * e.height && (A = 1);
            b.pfx = A
        }
        a: {
            if (.05 > Math.random() && f) try {
                const Q = f.document.getElementsByTagName("head")[0];
                var U = Q ? PH(Q) : 0;
                break a
            } catch (Q) {}
            U = 0
        }
        f = U;
        0 !== f && (b.cms = f);
        d.google_lrv !== G(a.ea, 2) && (b.alvm = d.google_lrv || "none")
    }

    function PI(a, b) {
        let c = 0;
        a.location && a.location.ancestorOrigins ? c = a.location.ancestorOrigins.length : Lg(() => {
            c++;
            return !1
        }, !0, !0, a);
        c && (b.nhd = c)
    }

    function QI(a, b) {
        const c = TC(b, 8, {});
        b = TC(b, 9, {});
        const d = a.google_ad_section,
            e = a.google_ad_format;
        a = a.google_ad_slot;
        e ? c[d] = c[d] ? c[d] + `,${e}` : e : a && (b[d] = b[d] ? b[d] + `,${a}` : a)
    }

    function RI(a, b, c) {
        const d = a.F;
        var e = a.F;
        b.dt = rl;
        e.google_async_iframe_id && e.google_bpp && (b.bpp = e.google_bpp);
        a: {
            try {
                var f = u.performance;
                if (f && f.timing && f.now) {
                    var g = f.timing.navigationStart + Math.round(f.now()) - f.timing.domLoading;
                    break a
                }
            } catch (H) {}
            g = null
        }(e = (e = g) ? DG(e, u.Date.now() - rl, 1E6) : null) && (b.bdt = e);
        b.idt = DG(a.G, rl);
        e = a.F;
        b.shv = G(a.ea, 2);
        a.Za && (b.mjsv = a.Za);
        "sa" == e.google_loader_used ? b.ptt = 5 : "aa" == e.google_loader_used && (b.ptt = 9);
        /^\w{1,3}$/.test(e.google_loader_used) && (b.saldr = e.google_loader_used);
        if (e = Eh(a.pubWin)) b.is_amp = 1, b.amp_v = Fh(e), (e = Gh(e)) && (b.act = e);
        e = a.pubWin;
        e == e.top && (b.abxe = 1);
        if ("_gfp_a_" in a.pubWin) {
            e = a.pubWin._gfp_a_;
            if ("boolean" !== typeof e) throw Error(`Illegal value of ${"_gfp_a_"}: ${e}`);
            e && (e = new vF(a.pubWin), (g = rF(e, "__gads", c)) && (b.cookie = g), (g = rF(e, "__gpi", c)) && !g.includes("&") && (b.gpic = g), "1" === rF(e, "__gpi_opt_out", c) && (b.gpico = "1", b.pdopt = "1"))
        }
        e = OC();
        f = TC(e, 8, {});
        g = d.google_ad_section;
        f[g] && (b.prev_fmts = f[g]);
        f = TC(e, 9, {});
        f[g] && (b.prev_slotnames = f[g].toLowerCase());
        QI(d, e);
        g = TC(e, 15, 0);
        0 < g && (b.nras = String(g));
        (f = Eh(window)) ? (f ? (g = f.pageViewId, f = f.clientId, "string" === typeof f && (g += f.replace(/\D/g, "").substr(0, 6))) : g = null, g = +g) : (g = vh(window), (f = g.google_global_correlator) || (g.google_global_correlator = f = 1 + Math.floor(Math.random() * Math.pow(2, 43))), g = f);
        b.correlator = TC(e, 7, g);
        T(Pp) && (b.rume = 1);
        if (d.google_ad_channel) {
            g = TC(e, 10, {});
            f = "";
            var h = d.google_ad_channel.split(EI);
            for (var k = 0; k < h.length; k++) {
                var l = h[k];
                g[l] ? f += l + "+" : g[l] = !0
            }
            b.pv_ch = f
        }
        if (d.google_ad_host_channel) {
            f =
                TC(e, 11, []);
            h = d.google_ad_host_channel.split("|");
            e = -1;
            g = [];
            for (k = 0; k < h.length; k++) {
                l = h[k].split(EI);
                f[k] || (f[k] = {});
                var m = "";
                for (var n = 0; n < l.length; n++) {
                    var q = l[n];
                    "" !== q && (f[k][q] ? m += "+" + q : f[k][q] = !0)
                }
                m = m.slice(1);
                g[k] = m;
                "" !== m && (e = k)
            }
            f = "";
            if (-1 < e) {
                for (h = 0; h < e; h++) f += g[h] + "|";
                f += g[e]
            }
            b.pv_h_ch = f
        }
        b.frm = d.google_iframing;
        b.ife = d.google_iframing_environment;
        e = d.google_ad_client;
        try {
            var r = vh(window),
                t = r.google_prev_clients;
            t || (t = r.google_prev_clients = {});
            if (e in t) var B = 1;
            else t[e] = !0, B = 2
        } catch {
            B = 0
        }
        b.pv =
            B;
        a.J && T(Ep) && (B = a.J, B = hb() && mI(B) ? B.document.documentElement.lang : void 0, B && (b.tl = B));
        t = a.pubWin.document;
        B = a.F;
        e = a.pubWin;
        r = t.domain;
        e = (y(c, 5) && OD(e) ? e.document.cookie : null) || "";
        h = a.pubWin.screen;
        k = t.referrer;
        m = ei();
        if (Eh()) var z = window.gaGlobal || {};
        else {
            g = Math.round((new Date).getTime() / 1E3);
            f = B.google_analytics_domain_name;
            c = "undefined" == typeof f ? SH("auto", r) : SH(f, r);
            n = -1 < e.indexOf("__utma=" + c + ".");
            l = -1 < e.indexOf("__utmb=" + c);
            (r = (Jh() || window).gaGlobal) || (r = {}, (Jh() || window).gaGlobal = r);
            t = !1;
            if (n) {
                var A = e.split("__utma=" + c + ".")[1].split(";")[0].split(".");
                l ? r.sid = A[3] : r.sid || (r.sid = g + "");
                r.vid = A[0] + "." + A[1];
                r.from_cookie = !0
            } else {
                r.sid || (r.sid = g + "");
                if (!r.vid) {
                    t = !0;
                    l = Math.round(2147483647 * Math.random());
                    n = QH.appName;
                    q = QH.version;
                    var J = QH.language ? QH.language : QH.browserLanguage,
                        E = QH.platform,
                        F = QH.userAgent;
                    try {
                        A = QH.javaEnabled()
                    } catch (H) {
                        A = !1
                    }
                    A = [n, q, J, E, F, A ? 1 : 0].join("");
                    h ? A += h.width + "x" + h.height + h.colorDepth : u.java && u.java.awt && (h = u.java.awt.Toolkit.getDefaultToolkit().getScreenSize(),
                        A += h.screen.width + "x" + h.screen.height);
                    A = A + e + (k || "");
                    for (h = A.length; 0 < m;) A += m-- ^ h++;
                    r.vid = (l ^ RH(A) & 2147483647) + "." + g
                }
                r.from_cookie || (r.from_cookie = !1)
            }
            if (!r.cid) {
                b: for (g = f, A = 999, g && (g = 0 == g.indexOf(".") ? g.substr(1) : g, A = g.split(".").length), g = 999, e = e.split(";"), f = 0; f < e.length; f++)
                    if (h = TH.exec(e[f]) || UH.exec(e[f]) || VH.exec(e[f])) {
                        k = h[1] || 0;
                        if (k == A) {
                            z = h[2];
                            break b
                        }
                        k < g && (g = k, z = h[2])
                    }t && z && -1 != z.search(/^\d+\.\d+$/) ? (r.vid = z, r.from_cookie = !0) : z != r.vid && (r.cid = z)
            }
            r.dh = c;
            r.hid || (r.hid = Math.round(2147483647 *
                Math.random()));
            z = r
        }
        b.ga_vid = z.vid;
        b.ga_sid = z.sid;
        b.ga_hid = z.hid;
        b.ga_fc = z.from_cookie;
        b.ga_cid = z.cid;
        b.ga_wpids = B.google_analytics_uacct;
        PI(a.pubWin, b);
        (a = d.google_ad_layout) && 0 <= sG[a] && (b.rplot = sG[a])
    }

    function SI(a, b) {
        a = a.l;
        if (a ? .j() || YC()) b.npa = 1;
        if (a) {
            null != w(a, 3, !1) && (b.gdpr = y(a, 3) ? "1" : "0");
            var c = w(a, 1);
            c && (b.us_privacy = c);
            (c = w(a, 2)) && (b.gdpr_consent = c);
            (c = w(a, 4)) && (b.addtl_consent = c);
            (a = w(a, 7)) && (b.tcfe = a)
        }
    }

    function TI(a, b) {
        const c = a.F;
        SI(a, b);
        Sg(aD, (d, e) => {
            b[d] = c[e]
        });
        VF(c) && (a = iG(c), b.fa = a);
        b.pi || null == c.google_ad_slot || (a = As(c), null != a.j && (a = pn(a.j.value), b.pi = a))
    }

    function UI(a, b) {
        var c = Ih() || fr(a.pubWin.top);
        c && (b.biw = c.width, b.bih = c.height);
        c = a.pubWin;
        c !== c.top && (a = fr(a.pubWin)) && (b.isw = a.width, b.ish = a.height)
    }

    function VI(a, b) {
        var c = a.pubWin;
        null !== c && c != c.top ? (a = [c.document.URL], c.name && a.push(c.name), c = fr(c, !1), a.push(c.width.toString()), a.push(c.height.toString()), a = Ug(a.join(""))) : a = 0;
        0 !== a && (b.ifk = a)
    }

    function WI(a, b) {
        (a = WC()[a.F.google_ad_client]) && (b.psts = a.join())
    }

    function XI(a, b) {
        (a = a.pubWin.tmod) && (b.tmod = a)
    }

    function YI(a, b) {
        (a = a.pubWin.google_user_agent_client_hint) && (b.uach = Yb(a))
    }

    function ZI(a, b) {
        const c = T(rI(window) ? Oq : Nq),
            d = T(Qq);
        (a = sI(a.pubWin, c, d)) && 0 < a.length && (b.tt_state = Yb(JSON.stringify(a)))
    }

    function $I(a, b) {
        try {
            const e = a.pubWin && a.pubWin.external && a.pubWin.external.getHostEnvironmentValue && a.pubWin.external.getHostEnvironmentValue.bind(a.pubWin.external);
            if (e) {
                var c = JSON.parse(e("os-mode")),
                    d = parseInt(c["os-mode"], 10);
                0 <= d && (b.wsm = d + 1)
            }
        } catch {}
    }

    function aJ(a, b) {
        0 <= a.F.google_ad_public_floor && (b.pubf = a.F.google_ad_public_floor);
        0 <= a.F.google_ad_private_floor && (b.pvtf = a.F.google_ad_private_floor)
    }

    function bJ(a, b) {
        const c = Number(a.F.google_traffic_source);
        c && Object.values(Ja).includes(c) && (b.trt = a.F.google_traffic_source)
    }

    function cJ(a, b) {
        T(Vq) || "runAdAuction" in a.pubWin.navigator && "joinAdInterestGroup" in a.pubWin.navigator && (b.td = 1)
    }

    function GI(a, b) {
        const c = {};
        TI(a, c);
        cI();
        c.adsid = $H[1];
        cI();
        c.pucrd = $H[6];
        YI(a, c);
        ZI(a, c);
        RI(a, c, b);
        hi(c);
        c.u_sd = gr(a.pubWin);
        c.dmc = a.pubWin.navigator ? .deviceMemory;
        Pk(889, () => {
            if (null == a.J) c.adx = -12245933, c.ady = -12245933;
            else {
                var e = XE(a.J, a.X);
                c.adx && -12245933 != c.adx && c.ady && -12245933 != c.ady || (c.adx = Math.round(e.x), c.ady = Math.round(e.y));
                ir(a.X) || (c.adx = -12245933, c.ady = -12245933, a.j |= 32768)
            }
        });
        UI(a, c);
        VI(a, c);
        LI(a, c);
        KI(a, c);
        a.D && (c.oid = a.D);
        WI(a, c);
        c.pvsid = qh(a.pubWin, Nk);
        XI(a, c);
        $I(a, c);
        c.uas =
            DI(a.pubWin);
        const d = kI(a.pubWin);
        d && (c.nvt = d);
        a.C && (c.scar = a.C);
        a.v && (c.topics = a.v instanceof Uint8Array ? Wb(a.v, 3) : a.v, !T(Mq) || a.v instanceof Uint8Array || (c.tps = a.v));
        OI(a, c, b);
        c.fu = a.j;
        c.bc = WH();
        cI();
        c.jar = $H[4];
        I(a.ea, 9) && NI(c);
        ll() && (c.atl = !0);
        aJ(a, c);
        bJ(a, c);
        cJ(a, c);
        null == Xq(Lp) || !1 !== a.F.google_video_play_muted && !0 !== T(Mp) || 10 !== a.F.google_reactive_ad_format && 11 !== a.F.google_reactive_ad_format || (c.sdkv = Xq(Lp));
        return c
    }
    const HI = /YtLoPri/;
    var dJ = class extends K {
            constructor(a) {
                super(a)
            }
        },
        eJ = Gd(dJ);
    var fJ = class {
        constructor(a) {
            this.j = a
        }
        Ka() {
            return this.j.now()
        }
    };
    const gJ = [255, 255, 255];

    function hJ(a) {
        function b(d) {
            return [Number(d[1]), Number(d[2]), Number(d[3]), 4 < d.length ? Number(d[4]) : 1]
        }
        var c = a.match(/rgb\(([0-9]+),\s*([0-9]+),\s*([0-9]+)\)/);
        if (c || (c = a.match(/rgba\(([0-9]+),\s*([0-9]+),\s*([0-9]+),\s*([0-9\\.]+)\)/))) return b(c);
        if ("transparent" === a) return [0, 0, 0, 0];
        throw Error(`Invalid color: ${a}`);
    }

    function iJ(a) {
        var b = getComputedStyle(a);
        if ("none" !== b.backgroundImage) return null;
        b = hJ(b.backgroundColor);
        var c = jJ(b);
        if (c) return c;
        a = (a = a.parentElement) ? iJ(a) : gJ;
        if (!a) return null;
        c = b[3];
        return [Math.round(c * b[0] + (1 - c) * a[0]), Math.round(c * b[1] + (1 - c) * a[1]), Math.round(c * b[2] + (1 - c) * a[2])]
    }

    function jJ(a) {
        return 1 === a[3] ? [a[0], a[1], a[2]] : null
    };
    var lJ = class {
        constructor(a, b, c) {
            this.dd = a;
            this.yc = b;
            this.eb = c;
            this.j = new kJ;
            this.l = 0
        }
    };
    class kJ {
        constructor() {
            this.j = new Map;
            this.l = 0
        }
        get m() {
            return this.l
        }
    };

    function mJ(a) {
        M(a, {
            border: "0",
            "box-shadow": "none",
            display: "inline",
            "float": "none",
            margin: "0",
            outline: "0",
            padding: "0"
        })
    };

    function nJ(a, b, c, d, e) {
        var f = new mk;
        d = jd(f, 4, d);
        a = x(d, 1, a);
        b = x(a, 2, b);
        c = x(b, 3, c);
        e = e.v;
        b = oJ(e, 4);
        c = bd(b, 8, vk, c);
        return pJ(e, c)
    };
    const qJ = [{
        Fb: "1907259590",
        ic: 480,
        Ra: 220
    }, {
        Fb: "2837189651",
        ic: 400,
        Ra: 180
    }, {
        Fb: "9211025045",
        ic: 360,
        Ra: 160
    }, {
        Fb: "6584860439",
        ic: -Infinity,
        Ra: 150
    }];

    function rJ(a) {
        return qJ.find(b => b.ic <= a)
    };
    const sJ = new class {
        constructor() {
            this.j = []
        }
    };
    let tJ = !1;

    function uJ(a) {
        return vJ(a.j, 1065, a.win, () => {
            if (!a.l) {
                var b = new sk;
                b = id(b, 1, a.m);
                var c = new rk;
                b = bd(b, 2, tk, c);
                wJ(a.j.v, b)
            }
        }, 1E4)
    }
    class xJ {
        constructor(a, b, c) {
            this.win = a;
            this.j = b;
            this.m = c;
            this.l = !1
        }
        cancel(a) {
            this.win.clearTimeout(a)
        }
    }

    function yJ(a, b, c, d, e) {
        const f = rJ(a.document.body.clientWidth),
            g = b.j ? zJ(a, b, d, f, e) : AJ(a, b, d, f, e);
        jm(g.isVisible(), !1, () => {
            tJ = !1;
            for (const l of sJ.j) l();
            sJ.j.length = 0
        });
        g.show({
            Id: !0
        });
        tJ = !0;
        const h = new xJ(a, b, c),
            k = uJ(h);
        sJ.j.push(() => {
            var l = b.v;
            var m = new sk;
            m = id(m, 1, c);
            var n = new qk;
            m = bd(m, 3, tk, n);
            wJ(l, m);
            h.l = !0
        });
        BJ.push(() => {
            g.isVisible().M && g.collapse();
            h.cancel(k)
        })
    }

    function zJ(a, b, c, d, e) {
        b = CJ(a, b, c, d, a.innerWidth, "100%", "15px", "13px", "center", e);
        return ix(a, b, {
            Yc: .75,
            Kc: .95,
            zIndex: 100001,
            Ia: !0,
            Fc: "adpub-drawer-root"
        })
    }

    function AJ(a, b, c, d, e) {
        a: {
            var f = a.document.body.clientWidth;
            var g = .9 * f;
            for (f = 768 >= f ? 3 : 4; 1 <= f; f--) {
                const h = d.Ra * f + 42;
                if (h <= g) {
                    g = h;
                    break a
                }
            }
        }
        c = CJ(a, b, c, d, g, "600px", "24px", "24px", "start", e);
        return vw(a, c, {
            Jc: `${g}px`,
            Hc: DJ(b),
            Bc: G(b.l, 14),
            zIndex: 100001,
            Ia: !0,
            Fc: "adpub-drawer-root"
        })
    }

    function CJ(a, b, c, d, e, f, g, h, k, l) {
        var m = b.l,
            n = G(m, 10),
            q = n.indexOf("TERM");
        var r = T(Jq) ? {
            Ce: "partner-pub-undefined",
            pd: "ads"
        } : {
            Ce: "pub-adfiliates-rockskipper",
            pd: "ads"
        };
        let t = "";
        T(Cq) && (t = b.D.get(c) || "");
        var B = V(hq);
        e = Math.max(Math.floor((e - Math.floor(e / d.Ra) * d.Ra) / 2), 5);
        var z = b.I ? "on" : "",
            A = G(m, 3),
            J = T(Iq) ? `${b.H.kb}` : `${V(pq)}`,
            E = G(m, 7),
            F = G(m, 6),
            H = b.C,
            W = n.substring(0, q);
        n = n.substring(q + 4);
        q = d.Fb;
        var Va = r.Ce;
        r = r.pd;
        var ea = !!I(m, 13),
            Z = t,
            va = T(Bq),
            ja = T(Fq);
        Z = void 0 === Z ? "" : Z;
        f = wv('<link href="https://fonts.googleapis.com/css2?family=Google+Material+Icons:wght@400;500;700" rel="stylesheet"><link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400;500;700&display=swap" rel="stylesheet"><div style="font-family: Roboto, sans-serif;"><div style="border: 0 solid #eee; border-bottom-width: 1px; color: #3c4043; font-size: 13px; line-height: 20px; padding: 0 ' +
            Av(X(g)) + " " + Av(X(h)) + "; text-align: " + Av(X(k)) + ';">' + (l ? '<div style="max-width: ' + Av(X(f)) + '">' + vv(A) + '\u00a0<a href="https://support.google.com/adsense/answer/11188578" target="_blank" style="color: #1967d2; text-decoration: none; white-space: nowrap">' + vv(F) + "</a></div>" : "") + "</div><div style=\"border-bottom: 1px solid #eee; color: #202124; font-family: 'Google Sans'; font-size: 15px; line-height: 24px; padding: 15px " + Av(X(g)) + "; text-align: " + Av(X(k)) + '"><div style="display: -webkit-box; overflow: hidden; -webkit-line-clamp: 2; -webkit-box-orient: vertical;"><span style="bottom: -2px; color: #1967d2; font-family: \'Google Material Icons\'; padding-right: 5px; position: relative">' +
            (va ? "search" : "shoppingmode") + '</span><span style="color:#80868b"> ' + vv(W) + "</span>" + vv(c) + '<span style="color:#80868b">' + vv(n) + '</span></div></div><div id="anno-csa" style="margin:5px ' + Av(X(e)) + "px\"></div><script>(function(g,o){g[o]=g[o]||function(){(g[o]['q']=g[o]['q']||[]).push(arguments)},g[o]['t']=1*new Date})(window,'_googCsa');" + (ja ? "" : "const pageOptions = {'pubId': " + Ev(Fv(Va)) + ", 'styleId': " + Ev(Fv(q)) + ", 'disableCarousel': true, 'query': " + Ev(Fv(c)) + ", 'hl': " + Ev(Fv(E)) + ", 'personalizedAds': 'false', 'fexp': " +
                Ev(Fv(J)) + ", 'adfiliateWp': " + Ev(Fv(H)) + "," + (Z ? "'afdToken': " + Ev(Fv(Z)) + "," : "") + "'adtest': " + Ev(Fv(z)) + "}; const adBlock = {'container': 'anno-csa', 'linkTarget': '_blank', 'number': " + Ev(Fv(B)) + ", 'width': document.body.offsetWidth - 30}; _googCsa(" + Ev(Fv(r)) + ", pageOptions, adBlock);") + "\x3c/script>" + (ea ? "<script>const el = document.getElementById('anno-csa'); el.dir = 'ltr'; el.style.height = '800px'; el.style.width = '75vw'; el.style.overflow = 'hidden'; el.style.overflowWrap = 'break-word'; el.textContent = JSON.stringify(window._googCsa.q);\x3c/script>" :
                '<script async="async" src="https://www.google.com/adsense/search/ads.js">\x3c/script>') + "</div>");
        m = Xe("body", {
            dir: DJ(b) ? "rtl" : "ltr",
            lang: G(m, 7),
            style: Ge({
                margin: "0",
                height: "100%",
                "padding-top": "0px",
                overflow: "hidden"
            })
        }, rv(f));
        f = a.document.createElement("IFRAME");
        M(f, {
            border: "0",
            width: "100%"
        });
        EJ(a, b, f, c, d, t);
        f.srcdoc = Te(m);
        return f
    }

    function EJ(a, b, c, d, e, f) {
        function g(l) {
            const m = new ResizeObserver(() => {
                c.height = `${l.parentElement.offsetHeight}px`
            });
            m.observe(l);
            const n = FJ(b, a, () => {
                const q = c.contentDocument ? .body ? .parentElement ? .offsetHeight;
                q && (c.height = `${q}px`)
            });
            T(Fq) && vJ(b, 999, a, () => {
                var q = b.l;
                const r = c.contentWindow;
                var t = c ? .contentDocument || c.contentWindow ? .document;
                if (r) {
                    if (void 0 === r._googCsa) throw Error("No _googCsa");
                    if (!t) throw Error("No contentDocument");
                } else throw Error("No googCsa window");
                q = {
                    pubId: "pub-adfiliates-rockskipper",
                    styleId: e.Fb,
                    disableCarousel: !0,
                    query: d,
                    hl: G(q, 7),
                    personalizedAds: "false",
                    fexp: T(Iq) ? `${b.H.kb}` : `${V(pq)}`,
                    adfiliateWp: b.C,
                    adtest: b.I ? "on" : ""
                };
                f && (q.afdToken = f);
                t = {
                    container: "anno-csa",
                    linkTarget: "_blank",
                    number: V(hq),
                    width: t.body.offsetWidth - 30
                };
                r._googCsa("ads", q, t)
            }, 100);
            BJ.push(() => {
                m.disconnect();
                a.clearInterval(n)
            })
        }

        function h() {
            if (!k) {
                const l = c.contentDocument ? .body || c.contentWindow ? .document ? .body;
                l && (k = !0, g(l))
            }
            return k
        }
        let k = !1;
        c.onload = () => void h();
        b.Aa(1066, eD(a, () => h(), 100))
    }
    const BJ = [];

    function GJ(a, b, c) {
        return a.substring(Math.max(b - 30, 0), b) + "~~" + a.substring(c, Math.min(c + 30, a.length))
    }

    function HJ(a) {
        a = hJ(a);
        var b = new ak;
        b = Wc(b, 1, a[0], 0);
        b = Wc(b, 2, a[1], 0);
        b = Wc(b, 3, a[2], 0);
        return Wc(b, 4, Gc(a[3]), 0)
    };
    class IJ {
        constructor(a, b) {
            this.m = a;
            this.j = !1;
            this.v = b;
            this.l = this.v.ta(264, c => {
                this.j && (JJ || (c = Date.now()), this.m(c), JJ ? KJ.call(u, this.l) : u.setTimeout(this.l, 17))
            })
        }
        start() {
            this.j || (this.j = !0, JJ ? KJ.call(u, this.l) : this.l(0))
        }
    }
    var KJ = u.requestAnimationFrame || u.webkitRequestAnimationFrame,
        JJ = !!KJ && !/'iPhone'/.test(u.navigator.userAgent);

    function LJ(a) {
        return a * a * a
    }

    function MJ(a) {
        a = 1 - a;
        return 1 - a * a * a
    }
    class NJ {
        constructor(a, b, c) {
            this.j = a;
            this.B = b;
            this.H = 100;
            this.progress = 0;
            this.l = null;
            this.G = !1;
            this.m = [];
            this.v = null;
            this.A = new IJ(Ba(this.I, this), c)
        }
        I(a) {
            if (this.G) this.A.j = !1;
            else {
                null === this.l && (this.l = a);
                this.progress = (a - this.l) / this.H;
                1 <= this.progress && (this.progress = 1);
                a = this.v ? this.v(this.progress) : this.progress;
                this.m = [];
                for (let b = 0; b < this.j.length; b++) this.m.push((this.B[b] - this.j[b]) * a + this.j[b]);
                this.C();
                1 == this.progress && (this.A.j = !1, this.D())
            }
        }
        D() {}
        C() {}
        play() {
            this.G = !1;
            this.A.start()
        }
        reset(a,
            b, c) {
            this.l = null;
            this.j = a;
            this.B = b;
            this.H = c;
            this.progress = 0
        }
    };
    var OJ = class {
        constructor(a, b, c, d) {
            this.C = a;
            this.D = b;
            this.m = c;
            this.B = d
        }
        get j() {
            return this.C
        }
        get A() {
            return this.D
        }
        get v() {
            return this.m
        }
        get l() {
            return this.B
        }
    };

    function PJ(a, b) {
        a = QJ(a.document, T(Bq) ? "search" : "shoppingmode");
        M(a, b);
        a.className = "google-material-icons";
        return a
    }

    function RJ(a, b) {
        a = QJ(a, "close");
        M(a, {
            color: "#5F6368",
            display: "block",
            "font-size": "15px",
            left: b ? "" : "20px",
            right: b ? "20px" : "",
            "pointer-events": "initial",
            position: "absolute",
            top: "16px",
            transform: "none"
        });
        return a
    }

    function SJ(a, b, c) {
        a = QJ(a, "expand_more");
        M(a, {
            color: "#5F6368",
            cursor: "pointer",
            display: "block",
            "font-size": "15px",
            left: c ? "" : "0",
            right: c ? "0" : "",
            padding: c ? "0 0 0 16px" : "0 16px 0 0",
            "pointer-events": "initial",
            position: "absolute",
            top: "20px",
            transform: `${b}`
        });
        return a
    }

    function QJ(a, b) {
        const c = a.createElement("SPAN");
        c.appendChild(a.createTextNode(b));
        mJ(c);
        M(c, {
            "font-family": '"Google Material Icons"',
            "font-style": "normal",
            "font-weight": "normal",
            "text-decoration": "none"
        });
        c.className = "google-material-icons";
        return c
    };

    function TJ(a, b, c) {
        return ry({
            J: a,
            Rc: 3E3,
            Tc: a.innerWidth > Dl ? 650 : 0,
            sa: c,
            Cd: b
        })
    }

    function UJ(a) {
        return a.document.getElementById("google-anno-sa")
    }

    function VJ(a, b) {
        const c = document.createElement("SPAN");
        c.id = "gda";
        if (T(Kq)) c.appendChild(RJ(a.document, b.j === DJ(b)));
        else {
            const d = WJ(a, b);
            c.appendChild(d)
        }
        XJ(b, 1064, c, d => {
            const e = DJ(b),
                f = (b.j ? e : !e) ? a.innerWidth : -a.innerWidth;
            YJ(b, UJ(a), 0, f, LJ).play();
            const g = ZJ(b);
            g.appendChild(PJ(a, {
                "font-size": "18px",
                "margin-right": "8px",
                "margin-top": "10px",
                left: "13px",
                top: "14px",
                margin: "0",
                position: "absolute",
                "line-height": "normal"
            }));
            XJ(b, 1064, g, h => {
                const k = (b.j ? e : !e) ? a.innerWidth : -a.innerWidth;
                YJ(b, UJ(a), k,
                    0, MJ).play();
                a.document.body.removeChild(g);
                h.preventDefault();
                return !1
            });
            a.document.body.appendChild(g);
            d.preventDefault();
            return !1
        });
        return c
    }

    function WJ(a, b) {
        var c = a.document;
        a = c.createElementNS("http://www.w3.org/2000/svg", "svg");
        var d = DJ(b);
        b = b.j ? d : !d;
        M(a, {
            bottom: "12.5px",
            display: "block",
            height: "20px",
            left: b ? "" : "0",
            right: b ? "0" : "",
            margin: "0 20px",
            "pointer-events": "initial",
            position: "absolute",
            top: "12.5px",
            transform: "none",
            width: "20px"
        });
        b = c.createElementNS("http://www.w3.org/2000/svg", "defs");
        a.appendChild(b);
        c = c.createElementNS("http://www.w3.org/2000/svg", "g");
        c.setAttribute("class", "down");
        c.setAttribute("stroke", "#616161");
        c.setAttribute("stroke-linecap",
            "square");
        c.setAttribute("stroke-width", "2px");
        b = c.ownerDocument;
        d = b.createElementNS("http://www.w3.org/2000/svg", "line");
        d.setAttribute("x1", "6");
        d.setAttribute("y1", "14");
        d.setAttribute("x2", "14");
        d.setAttribute("y2", "6");
        c.appendChild(d);
        b = b.createElementNS("http://www.w3.org/2000/svg", "line");
        b.setAttribute("x1", "6");
        b.setAttribute("y1", "6");
        b.setAttribute("x2", "14");
        b.setAttribute("y2", "14");
        c.appendChild(b);
        a.appendChild(c);
        return a
    }

    function $J(a, b) {
        var c = a.document;
        a = c.createElementNS("http://www.w3.org/2000/svg", "svg");
        var d = DJ(b);
        d = b.j ? d : !d;
        M(a, {
            bottom: "12.5px",
            display: "block",
            height: "20px",
            margin: "0 20px",
            "pointer-events": "initial",
            position: "absolute",
            left: d ? "0" : "",
            right: d ? "" : "0",
            top: "12.5px",
            transform: "none",
            width: "20px"
        });
        d = c.createElementNS("http://www.w3.org/2000/svg", "defs");
        a.appendChild(d);
        c = c.createElementNS("http://www.w3.org/2000/svg", "g");
        c.setAttribute("class", "down");
        c.setAttribute("stroke", "#616161");
        c.setAttribute("stroke-width",
            "2px");
        c.setAttribute("stroke-linecap", "square");
        b.j ? (b = c.ownerDocument, d = b.createElementNS("http://www.w3.org/2000/svg", "line"), d.setAttribute("x1", "6"), d.setAttribute("y1", "12"), d.setAttribute("x2", "10"), d.setAttribute("y2", "8"), c.appendChild(d), b = b.createElementNS("http://www.w3.org/2000/svg", "line"), b.setAttribute("x1", "10"), b.setAttribute("y1", "8"), b.setAttribute("x2", "14"), b.setAttribute("y2", "12"), c.appendChild(b)) : DJ(b) ? (b = c.ownerDocument, d = b.createElementNS("http://www.w3.org/2000/svg", "line"),
            d.setAttribute("x1", "6"), d.setAttribute("y1", "6"), d.setAttribute("x2", "10"), d.setAttribute("y2", "10"), c.appendChild(d), b = b.createElementNS("http://www.w3.org/2000/svg", "line"), b.setAttribute("x1", "10"), b.setAttribute("y1", "10"), b.setAttribute("x2", "6"), b.setAttribute("y2", "14"), c.appendChild(b)) : (b = c.ownerDocument, d = b.createElementNS("http://www.w3.org/2000/svg", "line"), d.setAttribute("x1", "10"), d.setAttribute("y1", "6"), d.setAttribute("x2", "6"), d.setAttribute("y2", "10"), c.appendChild(d), b = b.createElementNS("http://www.w3.org/2000/svg",
            "line"), b.setAttribute("x1", "6"), b.setAttribute("y1", "10"), b.setAttribute("x2", "10"), b.setAttribute("y2", "14"), c.appendChild(b));
        a.appendChild(c);
        return a
    }

    function ZJ(a) {
        const b = document.createElement("div");
        b.id = "gca";
        const c = DJ(a);
        a = a.j ? c : !c;
        M(b, {
            position: "fixed",
            bottom: "0%",
            left: a ? "" : "0%",
            right: a ? "0%" : "",
            width: "45px",
            height: "45px",
            background: "white",
            "border-top-left-radius": "20px",
            "border-top-right-radius": "20px",
            "box-shadow": "0px 0px 10px 0px #00000026",
            color: "#1967D2",
            "z-index": "1000"
        });
        return b
    }

    function aK(a) {
        (new MutationObserver(b => {
            b.forEach(c => {
                "attributes" === c.type && "0px" === a.document.body.style.paddingBottom && M(a.document.body, {
                    "padding-bottom": "45px"
                })
            })
        })).observe(a.document.body, {
            attributes: !0
        })
    }

    function bK(a) {
        try {
            return null !== a.location ? .href ? .match(/goog_fsa=1/)
        } catch (b) {
            return !1
        }
    }

    function cK(a, b, c) {
        var d = G(c.l, 11);
        b = b.getElementsByClassName("google-anno-sa-qtx")[0];
        b instanceof HTMLElement && (b.innerText = d.replace("TERM", a.j));
        c = c.v;
        d = new Oj;
        d = x(d, 1, a.m);
        a = jd(d, 4, a.j);
        d = oJ(c, 7);
        a = bd(d, 6, vk, a);
        return pJ(c, a)
    }

    function dK(a, b, c, d, e) {
        if (a.j !== d || null !== a.m || a.v !== e) {
            if (null !== a.l) {
                var f = a.l,
                    g = c.v,
                    h = new Nj;
                f = id(h, 1, f);
                h = oJ(g, 8);
                f = bd(h, 7, vk, f);
                pJ(g, f)
            }
            a.j = d;
            a.m = null;
            a.v = e;
            (d = UJ(b)) ? a.l = cK(a, d, c): (vy(b) ? b = null : (d = b.getComputedStyle(b.document.body).paddingBottom.match(/\d+/), M(b.document.body, {
                "padding-bottom": (d && d.length ? Number(d[0]) + 45 : 45) + "px"
            }), aK(b), d = document.createElement("div"), d.id = "google-anno-sa", d.dir = DJ(c) ? "rtl" : "ltr", M(d, {
                background: "white",
                "border-style": "solid",
                "border-top-left-radius": "20px",
                "border-top-right-radius": "20px",
                bottom: "0",
                height: "45px",
                position: "fixed",
                "text-align": "center",
                width: "100%",
                border: "0px",
                left: "0px",
                "box-shadow": "0px 0px 10px 0px #00000026",
                "z-index": "1000"
            }), d.appendChild(VJ(b, c)), d.appendChild(eK(a, b, c)), d.appendChild(fK(a, b, c)), c = cK(a, d, c), b.document.body.appendChild(d), b = c), a.l = b)
        }
    }

    function eK(a, b, c) {
        const d = document.createElement("SPAN");
        mJ(d);
        M(d, {
            position: "absolute",
            top: "2.5px",
            bottom: "2.5px",
            left: "60px",
            right: "60px",
            display: "flex",
            "flex-direction": "row",
            "justify-content": "center",
            color: "#1967D2",
            cursor: "pointer"
        });
        var e = DJ(c);
        c.j || M(d, {
            "justify-content": ""
        });
        d.appendChild(PJ(b, {
            "font-size": "18px",
            width: "15px",
            height: "15px",
            "margin-left": e ? "8px" : "",
            "margin-right": e ? "" : "8px",
            "margin-top": "11px",
            "line-height": "normal"
        }));
        e = document.createElement("SPAN");
        e.classList ? .add("google-anno-sa-qtx",
            "google-anno-skip");
        M(e, {
            height: "40px",
            "align-items": "center",
            "line-height": "40px",
            "font-size": "16px",
            "font-weight": "400",
            "font-style": "normal",
            "font-family": "Roboto",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
            overflow: "hidden",
            "-webkit-tap-highlight-color": "transparent"
        });
        XJ(c, 999, d, f => gK(a, b, c, f));
        d.appendChild(e);
        return d
    }

    function fK(a, b, c) {
        const d = document.createElement("DIV");
        d.id = "google-anno-ea";
        c.j || M(d, {
            width: "60px",
            height: "45px",
            cursor: "pointer"
        });
        const e = T(Kq) ? SJ(b.document, c.j ? "rotate(180deg) translateY(5px)" : DJ(c) ? "rotate(270deg) translateX(-5px)" : "rotate(90deg) translateX(5px)", c.j !== DJ(c)) : $J(b, c);
        d.appendChild(e);
        XJ(c, 999, d, f => gK(a, b, c, f));
        return d
    }

    function gK(a, b, c, d) {
        const e = nJ(a.m, null, a.l, a.j, c);
        yJ(b, c, e, a.j, !1);
        d.preventDefault();
        return !1
    }
    var hK = class {
        constructor() {
            this.j = "";
            this.m = null;
            this.v = "";
            this.l = null
        }
    };

    function iK(a) {
        if (a.j >= a.m.length) {
            if (!T(Gq)) {
                a.l = !0;
                return
            }
            a.j = 0
        }
        if (tJ) sJ.j.push(() => void iK(a));
        else {
            var b = a.m[a.j++];
            a.l = !1;
            dK(a.A, a.win, a.v, b.j, b.l);
            vJ(a.v, 898, a.win, () => void iK(a), a.B)
        }
    }
    var jK = class {
        constructor(a, b, c) {
            var d = new hK;
            this.B = a;
            this.win = b;
            this.v = c;
            this.A = d;
            this.m = [];
            this.l = !0;
            this.j = 0
        }
    };
    class kK {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
    };
    const lK = /[\s!'",:;\\(\\)\\?\\.\u00bf\u00a1\u30a0\uff1d\u037e\u061f\u3002\uff1f\uff1b\uff1a\u2014\u2014\uff5e\u300a\u300b\u3008\u3009\uff08\uff09\u300c\u300d\u3001\u00b7\u2026\u2025\uff01\uff0c\u00b7\u2019\u060c\u061b\u060d\u06d4\u0648]/;

    function mK(a, b) {
        switch (b) {
            case 1:
                return !0;
            default:
                return "" === a || lK.test(a)
        }
    }

    function nK(a, b, c, d) {
        return mK(a.charAt(b - 1), d) && mK(a.charAt(c + 1), d)
    };

    function oK(a, b, c) {
        c = new pK(c);
        for (const f of a) {
            a = f;
            var d = b,
                e = c;
            const g = G(a, 1);
            if (1 === d && I(a, 3)) qK(e, g, g);
            else if (2 === d) {
                I(a, 4) && qK(e, g, g);
                for (const h of Tc(a, 5, Lc, !1)) qK(e, h, g)
            }
        }
        rK(c);
        return new sK(c)
    }

    function tK(a, b, c) {
        c = new pK(c);
        for (const d of a)
            for (const e of D(d, Qf, 2)) Rc(e, 3).length && !Rc(e, 3).includes(b) || qK(c, G(e, 1), G(d, 1));
        rK(c);
        return new sK(c)
    }
    var sK = class {
        constructor(a) {
            this.j = a
        }
        match(a) {
            return this.j.match(a)
        }
    };

    function qK(a, b, c) {
        const d = a.v.has(c) ? a.v.get(c) : a.B++;
        a.v.set(c, d);
        a.m.set(d, c);
        c = 0;
        for (let e = 0; e < b.length; e++) {
            const f = b.charCodeAt(e);
            a.j[c].contains(f) || (a.j.push(new uK), a.j[a.size].B = c, a.j[a.size].D = f, a.j[c].m.set(f, a.size), a.size++);
            c = a.j[c].m.get(f)
        }
        a.j[c].A = !0;
        a.j[c].v = d;
        a.j[c].C = a.l.length;
        a.l.push(b.length)
    }

    function rK(a) {
        const b = [];
        for (b.push(0); 0 < b.length;) {
            const g = b.shift();
            var c = a,
                d = g,
                e = c.j[d];
            if (0 === d) e.j = 0, e.l = 0;
            else if (0 === e.B) e.j = 0, e.l = e.A ? d : c.j[c.j[d].j].l;
            else {
                e = c.j[c.j[d].B].j;
                for (var f = c.j[d].D;;) {
                    if (c.j[e].contains(f)) {
                        c.j[d].j = c.j[e].m.get(f);
                        break
                    }
                    if (0 === e) {
                        c.j[d].j = 0;
                        break
                    }
                    e = c.j[e].j
                }
                c.j[d].l = c.j[d].A ? d : c.j[c.j[d].j].l
            }
            for (const h of a.j[g].childNodes) b.push(h)
        }
    }

    function vK(a, b) {
        a: {
            let d = 0;
            for (let e = 0; e < b.length; e++) {
                for (;;) {
                    var c = b.charCodeAt(e);
                    if (a.j[d].contains(c)) {
                        d = a.j[d].m.get(c);
                        break
                    }
                    if (0 === d) break;
                    d = a.j[d].j
                }
                for (c = d;;) {
                    c = a.j[c].l;
                    if (0 === c) break;
                    const f = e + 1 - a.l[a.j[c].C],
                        g = e;
                    if (nK(b, f, g, a.A)) {
                        a = new wK(f, g, a.m.get(a.j[c].v));
                        break a
                    }
                    c = a.j[c].j
                }
            }
            a = void 0
        }
        return void 0 !== a
    }
    class pK {
        constructor(a) {
            this.A = a;
            this.size = 1;
            this.j = [new uK];
            this.l = [];
            this.v = new Map;
            this.m = new Map;
            this.B = 0
        }
        match(a) {
            let b = 0;
            const c = [];
            for (let f = 0; f < a.length; f++) {
                for (;;) {
                    var d = a.charCodeAt(f),
                        e = this.j[b];
                    if (e.contains(d)) {
                        b = e.m.get(d);
                        break
                    }
                    if (0 === b) break;
                    b = e.j
                }
                for (d = b;;) {
                    d = this.j[d].l;
                    if (0 === d) break;
                    e = f + 1 - this.l[this.j[d].C];
                    const g = f;
                    nK(a, e, g, this.A) && c.push(new wK(e, g, this.m.get(this.j[d].v)));
                    d = this.j[d].j
                }
            }
            return c
        }
    }
    class uK {
        constructor() {
            this.m = new Map;
            this.I = !1;
            this.T = this.H = this.G = this.N = this.K = this.L = -1
        }
        contains(a) {
            return this.m.has(a)
        }
        set B(a) {
            this.L = a
        }
        get B() {
            return this.L
        }
        set D(a) {
            this.K = a
        }
        get D() {
            return this.K
        }
        set A(a) {
            this.I = a
        }
        get A() {
            return this.I
        }
        set v(a) {
            this.H = a
        }
        get v() {
            return this.H
        }
        set j(a) {
            this.N = a
        }
        get j() {
            return this.N
        }
        set l(a) {
            this.G = a
        }
        get l() {
            return this.G
        }
        set C(a) {
            this.T = a
        }
        get C() {
            return this.T
        }
        get childNodes() {
            return this.m.values()
        }
    }
    var wK = class {
            constructor(a, b, c) {
                this.A = a;
                this.v = b;
                this.B = c
            }
            get l() {
                return this.A
            }
            get m() {
                return this.v
            }
            get j() {
                return this.B
            }
            get length() {
                return this.v - this.A
            }
        },
        xK = class {
            constructor(a) {
                this.j = a;
                this.matches = []
            }
        };
    const yK = ["block", "inline", "inline-block", "list-item", "table-cell"];

    function zK(a, b, c, d, e, f) {
        if (c.Ka(5) >= c.L) return !1;
        for (let ea = 0; ea < b.childNodes.length; ea++) {
            const Z = b.childNodes[ea];
            if (Z.nodeType === Node.TEXT_NODE && "" !== Z.textContent) {
                a: {
                    var g = a;
                    var h = c,
                        k = b,
                        l = Z.textContent,
                        m = d,
                        n = e,
                        q = f;
                    const va = [];b: {
                        var r = l;
                        switch (h.m) {
                            case 1:
                                var t = Array(r.length),
                                    B = 0;
                                for (var z = 0; z < r.length; z++) lK.test(r[z]) || B++, t[z] = B;
                                r = t;
                                break b;
                            default:
                                t = Array(r.length);
                                for (z = B = 0; z < r.length;) {
                                    for (;
                                        /\s/.test(r[z]);) t[z] = B, z++;
                                    for (var A = !1; z < r.length && !/\s/.test(r[z]);) A = !0, t[z] = B, z++;
                                    A && (B++,
                                        t[z - 1] = B)
                                }
                                r = t
                        }
                    }
                    if (l.includes("\u00bb")) n = [];
                    else {
                        t = n.match(l);
                        n = new Map;
                        for (const ja of t) t = ja.l, n.has(t) ? (B = n.get(t), ja.length > B.length && n.set(t, ja)) : n.set(t, ja);
                        n = Array.from(n.values())
                    }
                    B = -1;
                    for (const ja of n) {
                        t = ja.l;
                        n = ja.m;
                        z = q;
                        A = ja.j;
                        var J = z.j,
                            E = z.l + r[t] - V(nq);
                        for (const U of J.j.keys()) {
                            for (var F = J.j.get(U), H = 0; H < F.length && F[H] < E;) H++;
                            J.l -= H;
                            0 < H && J.j.set(U, F.slice(H))
                        }
                        J = z;
                        E = J.j;
                        if ((E.j.has(A) ? E.j.get(A).length : 0) < J.dd && z.j.m < z.yc) {
                            z = g.getComputedStyle(k);
                            A = z.fontSize.match(/\d+/);
                            if (!(A && 12 <= Number(A[0]) &&
                                    22 >= Number(A[0]) && rb(yK, z.display))) {
                                q.l += r[r.length - 1];
                                g = [];
                                break a
                            }
                            B += 1;
                            B < t && va.push(g.document.createTextNode(l.substring(B, t)));
                            B = l.substring(t, n + 1);
                            A = g;
                            z = k;
                            var W = B;
                            H = GJ(l, t, n + 1);
                            F = ja.j;
                            E = r[t];
                            J = z.getBoundingClientRect();
                            var Va = ck(2);
                            W = jd(Va, 2, W);
                            H = jd(W, 3, H);
                            F = jd(H, 4, F);
                            E = Wc(F, 5, E, 0);
                            E = Wc(E, 6, Math.round(J.x), 0);
                            J = Wc(E, 7, Math.round(J.y), 0);
                            A = A.getComputedStyle(z);
                            E = new bk;
                            E = jd(E, 1, A.fontFamily);
                            F = HJ(A.color);
                            E = ad(E, 7, F);
                            F = HJ(A.backgroundColor);
                            E = ad(E, 8, F);
                            F = A.fontSize.match(/^(\d+(\.\d+)?)px$/);
                            E = Wc(E, 4, F ? Math.round(Number(F[1])) : 0, 0);
                            F = Math.round(Number(A.fontWeight));
                            isNaN(F) || 400 === F || Wc(E, 5, F, 0);
                            "none" !== A.textDecorationLine && jd(E, 6, A.textDecorationLine);
                            A = ad(J, 8, E);
                            J = [];
                            for (H = z; H && 20 > J.length;) {
                                z = J;
                                E = z.push;
                                F = H;
                                W = new Zj;
                                W = jd(W, 1, F.tagName);
                                "" !== F.className && Vc(W, 2, F.className.split(" "), Kc);
                                E.call(z, W);
                                if ("BODY" === H.tagName) break;
                                H = H.parentElement
                            }
                            z = J.reverse();
                            z = cd(A, 9, z);
                            z = AK(m, z);
                            va.push(BK(g, h, z, ja.j, B));
                            B = q.j;
                            z = ja.j;
                            t = q.l + r[t];
                            A = [];
                            B.j.has(z) && (A = B.j.get(z));
                            A.push(t);
                            B.l++;
                            B.j.set(z,
                                A);
                            B = n;
                            if (0 < q.eb && q.j.m >= q.eb) break
                        }
                    }
                    h = B + 1;0 !== h && h < l.length && va.push(g.document.createTextNode(l.substring(h)));q.l += r[r.length - 1];g = va
                }
                if (0 < g.length && !T(zq)) {
                    for (const va of g) b.insertBefore(va, Z), CK(va);
                    b.removeChild(Z);
                    ea += g.length - 1
                }
            }
            else if (DK(Z, c) && !zK(a, Z, c, d, e, f)) return !1;
            if (0 < f.eb && f.j.m >= f.eb) break
        }
        return !0
    }

    function CK(a) {
        if (a.nodeType === Node.ELEMENT_NODE) {
            if ("A" === a.tagName) {
                var b = jJ(hJ(getComputedStyle(a.parentElement).color)),
                    c = jJ(hJ(getComputedStyle(a).color));
                var d = iJ(a);
                if (d = b && c && d ? KE(c, d) < Math.min(KE(b, d), 4.5) ? b : null : b) {
                    b = d[0];
                    c = d[1];
                    d = d[2];
                    b = Number(b);
                    c = Number(c);
                    d = Number(d);
                    if (b != (b & 255) || c != (c & 255) || d != (d & 255)) throw Error('"(' + b + "," + c + "," + d + '") is not a valid RGB color');
                    c = b << 16 | c << 8 | d;
                    b = 16 > b ? "#" + (16777216 | c).toString(16).slice(1) : "#" + c.toString(16);
                    M(a, {
                        color: b
                    })
                }
            }
            for (b = 0; b < a.childElementCount; b++) CK(a.children[b])
        }
    }

    function DK(a, b) {
        if (a.nodeType !== Node.ELEMENT_NODE || a.classList ? .contains("google-anno-skip") || !a.offsetHeight) return !1;
        switch (a.tagName ? .toUpperCase ? .()) {
            case "IFRAME":
            case "AUDIO":
            case "BUTTON":
            case "CANVAS":
            case "CITE":
            case "CODE":
            case "EMBED":
            case "FOOTER":
            case "FORM":
            case "KBD":
            case "LABEL":
            case "OBJECT":
            case "PRE":
            case "SAMP":
            case "SCRIPT":
            case "SELECT":
            case "STYLE":
            case "SUB":
            case "SUPER":
            case "SVG":
            case "TEXTAREA":
            case "TIME":
            case "VAR":
            case "VIDEO":
            case null:
                return !1;
            case "A":
                return !T(lq) &&
                    !!b.A;
            default:
                return !T(lq) && !!b.A || !(a.className.toUpperCase ? .() ? .includes("CRUMB") || a.id.toUpperCase ? .() ? .includes("CRUMB"))
        }
    }
    class EK {
        constructor() {
            this.j = null
        }
        get l() {
            return this.j
        }
    }

    function BK(a, b, c, d, e) {
        const f = a.document.createElement("SPAN");
        FK(f);
        f.appendChild(a.document.createTextNode(e));
        e = a.document.createElement("A");
        mJ(e);
        M(e, {
            "text-decoration": "none"
        });
        hf(e);
        e.className = "google-anno";
        e.appendChild(PJ(a, {
            bottom: "-1px",
            "font-family": '"Google Material Icons", "goog-matfb"',
            "font-size": "90%",
            position: "relative"
        }));
        e.appendChild(a.document.createTextNode("\u00a0"));
        e.appendChild(f);
        const g = GK(b, c, e);
        XJ(b, 999, e, h => {
            try {
                const k = nJ(c, g.l, null, d, b);
                yJ(a, b, k, d, !0);
                return !1
            } finally {
                h.preventDefault(),
                    h.stopImmediatePropagation()
            }
        });
        return e
    }

    function GK(a, b, c) {
        const d = new EK;
        HK(a, e => {
            for (const k of e)
                if (k.isIntersecting) {
                    var f = b;
                    e = a.v;
                    var g = new pk;
                    f = id(g, 1, f);
                    g = oJ(e, 5);
                    f = bd(g, 4, vk, f);
                    e = pJ(e, f);
                    d.j = e
                } else if (e = d, e.j) {
                f = a.v;
                g = new ok;
                g = id(g, 1, e.j);
                var h = oJ(f, 6);
                g = bd(h, 5, vk, g);
                pJ(f, g);
                e.j = null
            }
        }).observe(c);
        return d
    }

    function FK(a) {
        mJ(a);
        M(a, {
            "text-decoration": "underline"
        });
        M(a, {
            "text-decoration-style": "dotted"
        });
        M(a, {
            "-webkit-text-decoration-line": "underline",
            "-webkit-text-decoration-style": "dotted"
        })
    };

    function AK(a, b) {
        a.entries.push(zd(b, !1));
        return a.entries.length - 1
    }

    function IK(a) {
        if (T(Lq)) {
            a = Uf(a);
            let d = 0;
            for (var b of a) d += (I(b, 3) ? 1 : 0) + (I(b, 4) ? 1 : 0) + Tc(b, 5, Lc, !1).length;
            return ik(hk(new jk, a.length), d)
        }
        b = hk(new jk, Tf(a).length);
        let c = 0;
        Tf(a).forEach(d => {
            c += D(d, Qf, 2).length
        });
        return ik(b, c)
    }

    function JK(a, b, c, d) {
        const e = new Uj;
        switch (a) {
            case "se":
                return b = new Tj, bd(e, 1, Vj, b);
            case "sw":
                return b = new Tj, bd(e, 2, Vj, b);
            case "si":
                return b = new Tj, bd(e, 3, Vj, b);
            case "sl":
                return b = new Tj, bd(e, 5, Vj, b);
            case "l":
                return b = new Tj, bd(e, 6, Vj, b)
        }
        if (c && b) {
            if (b.l) return a = new Sj, b = id(a, 1, b.l), bd(e, 7, Vj, b);
            if (c.j && b.v && (!d || !b.A)) return b = new Tj, bd(e, 8, Vj, b)
        }
        return null
    }
    var KK = class {
        constructor() {
            this.entries = [];
            this.j = 0;
            this.l = this.m = null
        }
    };
    var LK = class {
        constructor(a, b, c) {
            this.win = a;
            this.l = b;
            this.m = c
        }
        get window() {
            return this.win
        }
        get j() {
            return this.l
        }
        get C() {
            return this.m
        }
    };
    var MK = class {
        constructor(a) {
            this.j = a
        }
    };

    function wJ(a, b) {
        var c = oJ(a, 9);
        b = bd(c, 9, vk, b);
        pJ(a, b)
    }

    function pJ(a, b) {
        for (const c of a.j) c(b);
        return fd(b, 1)
    }

    function oJ(a, b) {
        var c = new uk;
        var d = a.A++;
        c = id(c, 1, d);
        b = id(c, 2, Math.round(a.l.Ka(b) - a.m));
        return ad(b, 10, a.v)
    }
    var NK = class {
        constructor(a, b, c, d) {
            this.l = a;
            this.m = b;
            this.v = c;
            this.A = 1;
            this.j = [...d]
        }
    };

    function OK(a) {
        return a ? (a = a.match(/^[a-z]{2,3}/i)) ? a[0].toLowerCase() : "" : ""
    }

    function PK(a) {
        return new Set(a.map(OK).filter(b => b.length))
    };
    var QK = class {
        constructor(a, b) {
            this.l = a;
            this.m = b
        }
        get j() {
            return this.l
        }
        get v() {
            return this.m
        }
    };
    class RK extends NJ {
        constructor(a, b, c, d, e) {
            super([b], [c], d);
            this.K = a;
            this.v = e || null
        }
        C() {
            const a = {};
            a.left = this.m[0] + "px";
            Oh(this.K, a)
        }
        D() {}
    };
    var SK = class {
        constructor(a) {
            this.kb = a.kb;
            this.xc = a.xc ? ? 300
        }
    };

    function vJ(a, b, c, d, e) {
        return c.setTimeout(TK(a, b, d), e)
    }

    function DJ(a) {
        return 2 === ld(a.l, 12)
    }

    function FJ(a, b, c) {
        return b.setInterval(TK(a, 1066, c), 1E3)
    }

    function XJ(a, b, c, d) {
        c.addEventListener("click", TK(a, b, d))
    }

    function YJ(a, b, c, d, e) {
        return new RK(b, c, d, a.G, e)
    }

    function HK(a, b) {
        return new IntersectionObserver(TK(a, 1065, b), {
            threshold: .98
        })
    }

    function TK(a, b, c) {
        return a.G.ta(b, c, void 0, d => void UK(a, d))
    }

    function UK(a, b) {
        b.e = T(Iq) ? `${a.H.kb}` : `${V(pq)}`;
        b.c = `${a.N}`
    }
    var WK = class {
        constructor(a, b, c, d, e, f, g, h, k, l, m, n, q, r = !1) {
            this.C = a;
            this.j = b;
            this.l = c;
            this.N = d;
            this.L = e;
            this.A = f;
            this.G = g;
            this.v = h;
            this.sa = k;
            this.T = l;
            this.B = m;
            this.K = n;
            this.I = r;
            this.H = new SK(q);
            this.m = rb(VK, G(c, 7)) ? 1 : 0;
            this.D = new Map;
            if (T(Cq))
                if (T(Lq))
                    for (const t of Uf(this.l)) null != w(t, 2) && this.D.set(G(t, 1), G(t, 2));
                else Tf(this.l).forEach(t => {
                    null != w(t, 3) && this.D.set(G(t, 1), G(t, 3));
                    D(t, Qf, 2).forEach(B => {
                        null != w(B, 2) && this.D.set(G(B, 1), G(B, 2))
                    })
                })
        }
        Aa(a, b) {
            this.G.Aa(a, b, c => void UK(this, c))
        }
        Ka(a) {
            return this.T.Ka(a)
        }
    };
    const VK = ["ja", "zh_CN", "zh_TW"];

    function XK(a, b, c, d, e, f) {
        var g = Nk,
            h = Mk;
        try {
            Cb(a.document)
        } catch (k) {
            return
        }
        f = (f = rF(new vF(a), "__gads", f)) ? (f = Ug(f + "t2Z7mVic")) ? f % 20 : null : null;
        f || (f = Wg() ? null : Math.floor(20 * Rg()));
        null != f && YK(a, b, c, new MK(f), g, d, h, e)
    }

    function ZK(a, b, c, d, e, f, g, h) {
        T(fq) && b && !b.j && (a = zy(a)) && sh(a, () => {
            YK(c.window, c.j, c.C, new MK(d.j), e, f, g, h)
        })
    }

    function YK(a, b, c, d, e, f, g, h) {
        const k = b.j;
        if (k) {
            var l = h.Ka(1),
                m = l + (T(Iq) ? b.l.xc : V(mq));
            if (!T(zq) && 0 < (T(Lq) ? Uf(k) : Tf(k)).length) {
                var n = a.document;
                const Gb = n.createElement("LINK"),
                    Ka = N `https://fonts.googleapis.com/css2?family=Google+Material+Icons:wght@400;500;700`;
                pf(Gb, Ka, "stylesheet");
                n.head.appendChild(Gb)
            }
            var q = 488 > O(a).clientWidth;
            if (T(fq) || bK(a)) {
                var r = (T(Lq) ? Uf(b.j) : Tf(b.j)).length;
                var t = new QK(b.A, r)
            } else t = null;
            var B = new LK(a, b, c);
            if (T(fq) || bK(a)) {
                var z = t;
                if (bK(a)) var A = new OJ(!0, !1, !1, 0);
                else {
                    var J = ry({
                        J: a,
                        Rc: 3E3,
                        Tc: V(kq),
                        sa: g,
                        Ze: !0
                    });
                    var E = TJ(a, 2, g),
                        F = TJ(a, 1, g);
                    A = new OJ(0 < J || 0 === z.v ? !1 : !z.j || 0 < F || q && 0 === E, 0 === E, 0 === F, J)
                }
            } else A = null;
            var H = A,
                W = b.l,
                Va = new nk,
                ea = T(Iq) ? W.kb : V(pq);
            var Z = id(Va, 1, ea);
            var va = Wc(Z, 2, d.j, 0);
            var ja = new NK(h, l, va, f);
            T(rq) && ZK(a, H, B, d, e, f, g, h);
            var U = new WK(c, q, k, d.j, m, H, e, ja, g, h, b.B, b.v, b.l, b.m),
                Q = new KK; {
                const Gb = a.document.body;
                if (Gb && $K(Gb)) {
                    var qb = Gb.textContent || "";
                    b: switch (U.m) {
                        case 1:
                            let Ka = 0;
                            for (let Ha = qb.length - 1; 0 <= Ha; Ha--) lK.test(qb[Ha]) || Ka++;
                            var dl =
                                Ka;
                            break b;
                        default:
                            const za = qb.trim();
                            dl = "" === za ? 0 : za.split(/\s+/).length
                    }
                    Q.j = dl;
                    var Rt = OK(G(U.l, 7)); {
                        const Ka = a.document.documentElement,
                            za = OK(Ka.lang) || OK(Ka.getAttribute("xml:lang"));
                        if ("" !== za) var el = new Set([za]);
                        else {
                            var St = a.location;
                            const Ha = St.host.match(/^[a-z]{2}\./i),
                                Pa = Ha ? [Ha[0]] : [];
                            for (const Ia of St.pathname.split("/")) 2 === Ia.length && Pa.push(Ia);
                            var Tt = PK(Pa);
                            if (Tt.size) var Ut = Tt;
                            else {
                                const Ia = a.navigator;
                                Ut = PK(Ia.languages ? .length ? Ia.languages : [Ia.language])
                            }
                            el = Ut
                        }
                    }
                    Q.m = Rt;
                    Q.l = new Set(el);
                    var zL = T(lq) && T(eq) ? Math.min(U.B ? .Bb ? ? Number.MAX_SAFE_INTEGER, U.K ? .Bb ? ? Number.MAX_SAFE_INTEGER) : V(wq);
                    if (dl < zL) var Vt = "sw";
                    else {
                        if (a.document.querySelector('script[src*="www.google.com/adsense/search/ads.js"]')) var Wt = "si";
                        else {
                            if (el.has(Rt)) {
                                if (U.Ka(5) >= U.L) var Xt = "l";
                                else {
                                    b: {
                                        const Ka = U.l;
                                        if (0 === (T(Lq) ? Uf(Ka) : Tf(Ka)).length || !T(lq) && U.A && !U.A.j) var fl = !0;
                                        else {
                                            if (T(lq) || !U.A) {
                                                var Yt = a.document;
                                                const za = Yt.createElement("style");
                                                var AL = T(Bq) ? Nh `@font-face{font-family:"goog-matfb";size-adjust:39.13%;src:local("Times New Roman"),local("Tinos");}` :
                                                    Nh `@font-face{font-family:"goog-matfb";size-adjust:17.16%;src:local("Times New Roman");}`;
                                                za.textContent = Qe(AL);
                                                Yt.head.appendChild(za)
                                            }
                                            if (T(Lq))
                                                if (T(lq)) {
                                                    var nf = oK(Uf(Ka), 2, U.m);
                                                    var of = oK(Uf(Ka), 1, U.m)
                                                } else {
                                                    var BL = Uf(Ka);
                                                    const za = new pK(U.m);
                                                    for (const Ha of BL) {
                                                        const Pa = G(Ha, 1);
                                                        qK(za, Pa, Pa);
                                                        for (const Ia of Tc(Ha, 5, Lc, !1)) qK(za, Ia, Pa)
                                                    }
                                                    rK(za);
                                                    nf = of = new sK(za)
                                                }
                                            else if (T(lq)) nf = tK(Tf(Ka), 2, U.m), of = tK(Tf(Ka), 1, U.m);
                                            else {
                                                var CL = Tf(Ka);
                                                const za = new pK(U.m);
                                                for (const Ha of CL)
                                                    for (const Pa of D(Ha, Qf, 2)) qK(za,
                                                        G(Pa, 1), G(Ha, 1));
                                                rK(za);
                                                nf = of = new sK(za)
                                            }
                                            var gl;
                                            if (gl = U.A && U.A.j) {
                                                var DL = Q.j;
                                                gl = !T(lq) || !T(eq) || DL >= (U.K ? .Bb ? ? Number.MAX_SAFE_INTEGER)
                                            }
                                            if (gl) {
                                                if (vK(nf.j, qb)) {
                                                    var EL = new jK(V(Hq), a, U),
                                                        FL = U.m;
                                                    const za = nf.match(qb),
                                                        Ha = new Map;
                                                    for (const Pa of za) {
                                                        const Ia = Pa.j;
                                                        if (Ha.has(Ia)) Ha.get(Ia).matches.push(Pa);
                                                        else {
                                                            const yh = new xK(Ia);
                                                            yh.matches.push(Pa);
                                                            Ha.set(Ia, yh)
                                                        }
                                                    }
                                                    var GL = Array.from(Ha.values());
                                                    for (const Pa of GL) {
                                                        let Ia = null;
                                                        for (const yh of Pa.matches) {
                                                            c: {
                                                                var hl = qb,
                                                                    kd = yh,
                                                                    HL = Q;
                                                                if (!nK(hl, kd.l, kd.m, FL)) {
                                                                    var Zt =
                                                                        null;
                                                                    break c
                                                                }
                                                                const $t = hl.substring(kd.l, kd.m + 1);
                                                                var IL = HL,
                                                                    JL = $t,
                                                                    KL = GJ(hl, kd.l, kd.m + 1),
                                                                    LL = kd.j,
                                                                    ML = ck(1);
                                                                var NL = jd(ML, 2, JL);
                                                                var OL = jd(NL, 3, KL);
                                                                var PL = jd(OL, 4, LL);
                                                                var QL = Wc(PL, 5, null, 0);AK(IL, QL);Zt = $t
                                                            }
                                                            const au = Zt;null != au && (Ia = au)
                                                        }
                                                        if (null != Ia) {
                                                            var il = EL;
                                                            il.m.push(new kK(Pa.j, Ia));
                                                            il.l && iK(il)
                                                        }
                                                    }
                                                }
                                                if (!T(lq)) {
                                                    fl = !0;
                                                    break b
                                                }
                                            }
                                            var RL = Q.j;
                                            fl = !(!T(lq) || !T(eq) || RL >= (U.B ? .Bb ? ? Number.MAX_SAFE_INTEGER)) || !vK( of .j, qb) || zK(a, a.document.body, U, Q, of , new lJ((U.B ? .dd ? ? null) || 0, (U.B ? .yc ? ? null) || 0, (U.B ? .eb ? ? null) || -1))
                                        }
                                    }
                                    Xt =
                                    fl ? "a" : "p"
                                }
                                var bu = Xt
                            } else bu = "sl";
                            Wt = bu
                        }
                        Vt = Wt
                    }
                    var cu = Vt
                } else cu = "se"
            }
            var SL = h.Ka(3) - l;
            if (!T(zq) && Q.entries.length && !I(k, 13)) {
                var du = a.document;
                const Gb = du.createElement("LINK");
                pf(Gb, N `https://www.google.com/adsense/search/ads.js`, "prefetch");
                Gb.as = "script";
                Gb.fetchPriority = "low";
                du.head.appendChild(Gb)
            }
            var TL = b.C,
                UL = a.location.hostname,
                VL = b.D,
                WL = t,
                eu = cu,
                XL = new kk,
                YL = new Pj;
            var ZL = jd(YL, 1, TL);
            var $L = jd(ZL, 2, UL);
            var aM = nd($L, 3, q);
            var bM = x(aM, 4, Q.j);
            var cM = ad(XL, 1, bM);
            var dM = new Rj,
                eM = Array.from(Q.l ? ? []).sort();
            var fM = Vc(dM, 1, eM, Kc);
            var gM = jd(fM, 2, Q.m);
            var hM = jd(gM, 3, VL);
            var iM = ad(cM, 2, hM);
            var jM = id(iM, 3, Math.round(SL));
            var kM = IK(k);
            var jl = ad(jM, 6, kM);
            const fu = JK(eu, H, WL, q);
            if (fu) {
                var lM = new Xj;
                var mM = dd(lM, 1, Uj, fu);
                bd(jl, 5, lk, mM)
            } else {
                var nM = new gk;
                var oM = nd(nM, 1, "p" === eu);
                var pM = cd(oM, 2, Q.entries);
                var qM = (T(Lq) ? Uf(k) : Tf(k)).length;
                var rM = id(pM, 3, qM);
                bd(jl, 4, lk, rM)
            }
            var sM = oJ(ja, 3);
            var tM = bd(sM, 3, vk, jl);
            pJ(ja, tM)
        }
    }

    function $K(a) {
        try {
            Cb(new ResizeObserver(() => {})), Cb(new MutationObserver(() => {}))
        } catch {
            return !1
        }
        return a.classList && void 0 !== a.classList.contains && void 0 !== a.attachShadow
    };

    function aL(a, b, c, d, e) {
        if (!TC(OC(), 29, !1)) {
            UC(OC(), 29, !0);
            var f = a.performance;
            f ? .now && XK(a, c, d, [g => {
                var h = b.sa;
                var k = hD(b);
                k = id(k, 3, 1);
                g = bd(k, 6, xk, g);
                yk(h, g)
            }], new fJ(f), e)
        }
    };
    var bL = class {
        constructor(a, b, c, d, e, f) {
            this.j = a;
            this.C = b;
            this.A = c;
            this.D = d;
            this.B = {
                Bb: 300,
                dd: 2,
                yc: 5,
                eb: -1
            };
            this.v = {
                Bb: 50
            };
            this.l = e;
            this.m = f
        }
    };

    function cL(a) {
        Nk.ed(b => {
            b.shv = String(a);
            b.mjsv = "m202302060101";
            b.eid = qF(u)
        })
    }

    function dL(a) {
        cL(G(a, 2));
        a = I(a, 6);
        Fd(gF, Ui);
        gF = a
    };

    function eL({
        df: a,
        gg: b
    }) {
        return a || ("dev" === b ? "dev" : "")
    };
    var fL = "undefined" === typeof sttc ? void 0 : sttc;

    function gL(a) {
        var b = Nk;
        try {
            return Fd(a, Ti), new bF(JSON.parse(a))
        } catch (c) {
            b.ka(838, c instanceof Error ? c : Error(String(c)), void 0, d => {
                d.jspb = String(a)
            })
        }
        return new bF
    };

    function hL(a) {
        if (a.l) return a.l;
        a.K && a.K(a.m) ? a.l = a.m : a.l = hh(a.m, a.L);
        return a.l ? ? null
    }

    function iL(a) {
        a.v || (a.v = b => {
            try {
                var c = a.I ? a.I(b) : void 0;
                if (c) {
                    var d = c.Zc,
                        e = a.G.get(d);
                    if (e) {
                        a.G.delete(d);
                        var f = a.C.get(c.Zc);
                        a.C.delete(d);
                        e(f, c.payload)
                    }
                }
            } catch (g) {}
        }, L(a.m, "message", a.v))
    }

    function jL(a, b) {
        if (hL(a))
            if (a.l === a.m) {
                var c = a.H.get("getDataWithCallback");
                c && c(a.l, b)
            } else if ((c = a.A.get("getDataWithCallback")) && c.Qc) {
            iL(a);
            var d = ++a.N;
            a.G.set(d, c.je);
            a.C.set(d, c.Zd(b));
            a.l.postMessage(c.Qc(b, d), "*")
        }
    }
    var kL = class extends Dk {
        constructor(a, b, c, d) {
            super();
            this.L = b;
            this.K = c;
            this.I = d;
            this.H = new Map;
            this.N = 0;
            this.A = new Map;
            this.G = new Map;
            this.C = new Map;
            this.v = void 0;
            this.m = a
        }
        j() {
            delete this.l;
            this.H.clear();
            this.A.clear();
            this.G.clear();
            this.C.clear();
            this.v && (Yd(this.m, "message", this.v), delete this.v);
            delete this.m;
            delete this.I;
            super.j()
        }
    };
    const lL = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.callback({
                    consentData: c ? ? void 0,
                    Ld: d ? void 0 : 2
                })
            })
        },
        mL = {
            Zd: a => a.callback,
            Qc: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            je: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    consentData: b.returnValue ? ? void 0,
                    Ld: b.success ? void 0 : 2
                })
            }
        };

    function nL(a) {
        let b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Zc: b.__uspapiReturn.callId
        }
    }
    var oL = class extends Dk {
        constructor(a) {
            super();
            this.caller = new kL(a, "__uspapiLocator", b => "function" === typeof b.__uspapi, nL);
            this.caller.H.set("getDataWithCallback", lL);
            this.caller.A.set("getDataWithCallback", mL)
        }
        j() {
            this.caller.xa();
            super.j()
        }
        C(a) {
            let b = {};
            if (hL(this.caller)) {
                var c = Sd(() => {
                    a(b)
                });
                jL(this.caller, {
                    callback: d => {
                        d.Ld || (b = d.consentData);
                        c()
                    }
                });
                setTimeout(c, 500)
            } else a(b)
        }
    };
    var pL = Gd(class extends K {
        constructor(a) {
            super(a)
        }
    });
    const qL = (a, b) => {
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c => {
                c = pL(c);
                b.callback({
                    consentData: c
                })
            })
        },
        rL = {
            Zd: a => a.callback,
            Qc: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command
                }
            }),
            je: (a, b) => {
                a({
                    consentData: b
                })
            }
        };

    function sL(a) {
        a = pL(a.data.__fciReturn);
        return {
            payload: a,
            Zc: w(a, 1)
        }
    }
    var tL = class extends Dk {
        constructor(a) {
            super();
            this.l = null;
            this.v = !1;
            this.caller = new kL(a, "googlefcPresent", void 0, sL);
            this.caller.H.set("getDataWithCallback", qL);
            this.caller.A.set("getDataWithCallback", rL)
        }
        j() {
            this.caller.xa();
            super.j()
        }
        m() {
            this.v || (this.l = hL(this.caller), this.v = !0);
            return !!this.l
        }
        H(a) {
            return new Promise(b => {
                this.m() && jL(this.caller, {
                    command: a,
                    callback: c => {
                        b(c.consentData)
                    }
                })
            })
        }
    };

    function uL(a, b) {
        b = b && b[0];
        if (!b) return null;
        b = b.target;
        const c = b.getBoundingClientRect(),
            d = tg(a.j.R() || window);
        if (0 >= c.bottom || c.bottom > d.height || 0 >= c.right || c.left >= d.width) return null;
        var e = vL(a, b, c, a.j.j.elementsFromPoint(dg(c.left + c.width / 2, c.left, c.right - 1), dg(c.bottom - 1 - 2, c.top, c.bottom - 1)), 1, []),
            f = vL(a, b, c, a.j.j.elementsFromPoint(dg(c.left + c.width / 2, c.left, c.right - 1), dg(c.top + 2, c.top, c.bottom - 1)), 2, e.Ha),
            g = vL(a, b, c, a.j.j.elementsFromPoint(dg(c.left + 2, c.left, c.right - 1), dg(c.top + c.height / 2,
                c.top, c.bottom - 1)), 3, [...e.Ha, ...f.Ha]);
        const h = vL(a, b, c, a.j.j.elementsFromPoint(dg(c.right - 1 - 2, c.left, c.right - 1), dg(c.top + c.height / 2, c.top, c.bottom - 1)), 4, [...e.Ha, ...f.Ha, ...g.Ha]);
        var k = wL(a, b, c),
            l = n => rb(a.m, n.overlapType) && rb(a.v, n.overlapDepth) && rb(a.l, n.overlapDetectionPoint);
        e = mb([...e.entries, ...f.entries, ...g.entries, ...h.entries], l);
        l = mb(k, l);
        k = [...e, ...l];
        f = -2 > c.left || c.right > d.width + 2;
        f = 0 < k.length || f;
        g = ug(a.j.j);
        const m = new Ah(c.left, c.top, c.width, c.height);
        e = [...nb(e, n => new Ah(n.elementRect.left,
            n.elementRect.top, n.elementRect.width, n.elementRect.height)), ...Ab(nb(l, n => Ch(m, n.elementRect))), ...mb(Ch(m, new Ah(0, 0, d.width, d.height)), n => 0 <= n.top && n.top + n.height <= d.height)];
        return {
            entries: k,
            isOverlappingOrOutsideViewport: f,
            scrollPosition: {
                scrollX: g.x,
                scrollY: g.y
            },
            target: b,
            targetRect: c,
            viewportSize: {
                width: d.width,
                height: d.height
            },
            overlappedArea: 20 > e.length ? xL(m, e) : yL(c, e)
        }
    }

    function uM(a, b) {
        const c = a.j.R(),
            d = a.j.j;
        return new Promise((e, f) => {
            const g = c.IntersectionObserver;
            if (g)
                if (d.elementsFromPoint)
                    if (d.createNodeIterator)
                        if (d.createRange)
                            if (c.Range.prototype.getBoundingClientRect) {
                                var h = new g(k => {
                                    const l = new Pi,
                                        m = Oi(l, () => uL(a, k));
                                    m && (l.l.length && (m.executionTime = Math.round(Number(l.l[0].duration))), h.disconnect(), e(m))
                                }, vM);
                                h.observe(b)
                            } else f(Error("5"));
            else f(Error("4"));
            else f(Error("3"));
            else f(Error("2"));
            else f(Error("1"))
        })
    }

    function vL(a, b, c, d, e, f) {
        if (0 === c.width || 0 === c.height) return {
            entries: [],
            Ha: []
        };
        const g = [],
            h = [];
        for (let n = 0; n < d.length; n++) {
            const q = d[n];
            if (q === b) continue;
            if (rb(f, q)) continue;
            h.push(q);
            const r = q.getBoundingClientRect();
            if (a.j.contains(q, b)) {
                g.push(wM(a, c, q, r, 1, e));
                continue
            }
            if (a.j.contains(b, q)) {
                g.push(wM(a, c, q, r, 2, e));
                continue
            }
            a: {
                var k = a;
                var l = b,
                    m = q;
                const z = k.j.qf(l, m);
                if (!z) {
                    k = null;
                    break a
                }
                const {
                    suspectAncestor: A,
                    Ta: J
                } = xM(k, l, z, m) || {},
                {
                    suspectAncestor: E,
                    Ta: F
                } = xM(k, m, z, l) || {};k = A && J && E && F ? J <= F ? {
                    suspectAncestor: A,
                    overlapType: yM[J]
                } : {
                    suspectAncestor: E,
                    overlapType: zM[F]
                } : A && J ? {
                    suspectAncestor: A,
                    overlapType: yM[J]
                } : E && F ? {
                    suspectAncestor: E,
                    overlapType: zM[F]
                } : null
            }
            const {
                suspectAncestor: t,
                overlapType: B
            } = k || {};
            t && B ? g.push(wM(a, c, q, r, B, e, t)) : g.push(wM(a, c, q, r, 9, e))
        }
        return {
            entries: g,
            Ha: h
        }
    }

    function wL(a, b, c) {
        const d = [];
        for (b = b.parentElement; b; b = b.parentElement) {
            const f = b.getBoundingClientRect();
            if (f) {
                var e = Qg(b, a.j.R());
                e && "visible" !== e.overflow && ("auto" !== e.overflowY && "scroll" !== e.overflowY && c.bottom > f.bottom + 2 ? d.push(wM(a, c, b, f, 5, 1)) : (e = "auto" === e.overflowX || "scroll" === e.overflowX, !e && c.left < f.left - 2 ? d.push(wM(a, c, b, f, 5, 3)) : !e && c.right > f.right + 2 && d.push(wM(a, c, b, f, 5, 4))))
            }
        }
        return d
    }

    function xL(a, b) {
        if (0 === a.width || 0 === a.height || 0 === b.length) return 0;
        let c = 0;
        for (let d = 1; d < 1 << b.length; d++) {
            let e = a,
                f = 0;
            for (let g = 0; g < b.length && (!(d & 1 << g) || (f++, e = Bh(e, b[g]), e)); g++);
            e && (c = 1 === f % 2 ? c + (e.width + 1) * (e.height + 1) : c - (e.width + 1) * (e.height + 1))
        }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function yL(a, b) {
        if (0 === a.width || 0 === a.height || 0 === b.length) return 0;
        let c = 0;
        for (let d = a.left; d <= a.right; d++)
            for (let e = a.top; e <= a.bottom; e++)
                for (let f = 0; f < b.length; f++)
                    if (d >= b[f].left && d <= b[f].left + b[f].width && e >= b[f].top && e <= b[f].top + b[f].height) {
                        c++;
                        break
                    }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function wM(a, b, c, d, e, f, g) {
        const h = {
            element: c,
            elementRect: d,
            overlapType: e,
            overlapDetectionPoint: f
        };
        if (rb(a.m, e) && rb(a.l, f)) {
            b = new wh(b.top, b.right - 1, b.bottom - 1, b.left);
            if ((a = AM(a, c)) && zh(b, a)) c = 4;
            else {
                a = BM(c, d);
                if (Fb) {
                    e = Yh(c, "paddingLeft");
                    f = Yh(c, "paddingRight");
                    var k = Yh(c, "paddingTop"),
                        l = Yh(c, "paddingBottom");
                    e = new wh(k, f, l, e)
                } else e = Rh(c, "paddingLeft"), f = Rh(c, "paddingRight"), k = Rh(c, "paddingTop"), l = Rh(c, "paddingBottom"), e = new wh(parseFloat(k), parseFloat(f), parseFloat(l), parseFloat(e));
                zh(b, new wh(a.top +
                    e.top, a.right - e.right, a.bottom - e.bottom, a.left + e.left)) ? c = 3 : (c = BM(c, d), c = zh(b, c) ? 2 : 1)
            }
            h.overlapDepth = c
        }
        g && (h.suspectAncestor = g);
        return h
    }

    function xM(a, b, c, d) {
        const e = [];
        for (var f = b; f && f !== c; f = f.parentElement) e.unshift(f);
        c = a.j.R();
        for (f = 0; f < e.length; f++) {
            const h = e[f];
            var g = Qg(h, c);
            if (g) {
                if ("fixed" === g.position) return {
                    suspectAncestor: h,
                    Ta: 1
                };
                if ("sticky" === g.position && a.j.contains(h.parentElement, d)) return {
                    suspectAncestor: h,
                    Ta: 2
                };
                if ("absolute" === g.position) return {
                    suspectAncestor: h,
                    Ta: 3
                };
                if ("none" !== g.cssFloat) {
                    g = h === e[0];
                    const k = CM(a, e.slice(0, f), h);
                    if (g || k) return {
                        suspectAncestor: h,
                        Ta: 4
                    }
                }
            }
        }
        return (a = CM(a, e, b)) ? {
                suspectAncestor: a,
                Ta: 5
            } :
            null
    }

    function CM(a, b, c) {
        const d = c.getBoundingClientRect();
        if (!d) return null;
        for (let e = 0; e < b.length; e++) {
            const f = b[e];
            if (!a.j.contains(f, c)) continue;
            const g = f.getBoundingClientRect();
            if (!g) continue;
            const h = Qg(f, a.j.R());
            if (h && d.bottom > g.bottom + 2 && "visible" === h.overflowY) return f
        }
        return null
    }

    function AM(a, b) {
        var c = a.j.j;
        a = c.createRange();
        if (!a) return null;
        c = c.createNodeIterator(b, NodeFilter.SHOW_TEXT, {
            acceptNode: d => /^[\s\xa0]*$/.test(d.nodeValue) ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT
        });
        for (b = c.nextNode(); c.nextNode(););
        c = c.previousNode();
        if (!b || !c) return null;
        a.setStartBefore(b);
        a.setEndAfter(c);
        a = a.getBoundingClientRect();
        return 0 === a.width || 0 === a.height ? null : new wh(a.top, a.right, a.bottom, a.left)
    }

    function BM(a, b) {
        if (!Fb || 9 <= Number(Tb)) {
            var c = Rh(a, "borderLeftWidth");
            d = Rh(a, "borderRightWidth");
            e = Rh(a, "borderTopWidth");
            a = Rh(a, "borderBottomWidth");
            c = new wh(parseFloat(e), parseFloat(d), parseFloat(a), parseFloat(c))
        } else {
            c = $h(a, "borderLeft");
            var d = $h(a, "borderRight"),
                e = $h(a, "borderTop");
            a = $h(a, "borderBottom");
            c = new wh(e, d, a, c)
        }
        return new wh(b.top + c.top, b.right - 1 - c.right, b.bottom - 1 - c.bottom, b.left + c.left)
    }
    class DM {
        constructor(a) {
            var b = EM;
            this.j = og(a);
            this.m = [5, 8, 9];
            this.v = [3, 4];
            this.l = b
        }
    }
    const yM = {
            [1]: 3,
            [4]: 10,
            [3]: 12,
            [2]: 4,
            [5]: 5
        },
        zM = {
            [1]: 6,
            [4]: 11,
            [3]: 13,
            [2]: 7,
            [5]: 8
        };
    mb(Tg({
        bi: 1,
        ci: 2,
        Mj: 3,
        Nj: 4,
        Pj: 5,
        Xh: 6,
        Yh: 7,
        ai: 8,
        bj: 9,
        Oj: 10,
        Zh: 11,
        Lj: 12,
        Wh: 13
    }), a => !rb([1, 2], a));
    Tg({
        oh: 1,
        cj: 2,
        Bh: 3,
        Qj: 4
    });
    const EM = Tg({
            qh: 1,
            Tj: 2,
            Pi: 3,
            zj: 4
        }),
        vM = {
            threshold: [0, .25, .5, .75, .95, .96, .97, .98, .99, 1]
        };

    function FM(a, b, c, d) {
        const e = new Xu;
        let f = "";
        const g = k => {
            try {
                const l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                f === l.paw_id && (Yd(a, "message", g), l.error ? e.j(Error(l.error)) : e.resolve(d(l)))
            } catch (l) {}
        };
        var h = "function" === typeof a.gmaSdk ? .getQueryInfo ? a.gmaSdk : void 0;
        if (h) return L(a, "message", g), f = c(h), e.promise;
        c = "function" === typeof a.webkit ? .messageHandlers ? .getGmaQueryInfo ? .postMessage || "function" === typeof a.webkit ? .messageHandlers ? .getGmaSig ? .postMessage ? a.webkit.messageHandlers : void 0;
        return c ? (f = String(Math.floor(2147483647 * Rg())), L(a, "message", g), b(c, f), e.promise) : null
    }

    function GM(a) {
        return FM(a, (b, c) => void(b.getGmaQueryInfo ? ? b.getGmaSig) ? .postMessage(c), b => b.getQueryInfo(), b => b.signal)
    };

    function HM(a) {
        if (a.m) return a.m;
        a.m = hh(a.l, "__uspapiLocator");
        return a.m
    }

    function IM(a, b) {
        if ("function" === typeof a.l ? .__uspapi) a = a.l.__uspapi, a("getUSPData", 1, b);
        else if (HM(a)) {
            JM(a);
            const c = ++a.G;
            a.A[c] = b;
            a.m && a.m.postMessage({
                __uspapiCall: {
                    command: "getUSPData",
                    version: 1,
                    callId: c
                }
            }, "*")
        }
    }

    function JM(a) {
        a.v || (a.v = b => {
            try {
                let d = {};
                "string" === typeof b.data ? d = JSON.parse(b.data) : d = b.data;
                var c = d.__uspapiReturn;
                a.A ? .[c.callId](c.returnValue, c.success)
            } catch {}
        }, L(a.l, "message", a.v))
    }
    var KM = class extends Dk {
        constructor(a) {
            super();
            this.l = a;
            this.m = null;
            this.A = {};
            this.G = 0;
            this.v = null
        }
        j() {
            this.v && Yd(this.l, "message", this.v);
            super.j()
        }
        C(a) {
            let b = {};
            if ("function" === typeof this.l ? .__uspapi || null != HM(this)) {
                var c = Sd(() => a(b));
                IM(this, (d, e) => {
                    e && (b = d);
                    c()
                });
                setTimeout(c, 500)
            } else a(b)
        }
    };

    function LM(a) {
        a.v || (a.v = b => {
            try {
                const c = pL(b.data.__fciReturn);
                (0, a.G[w(c, 1)])(c)
            } catch (c) {}
        }, L(a.A, "message", a.v))
    }
    var MM = class extends Dk {
        constructor(a) {
            super();
            this.A = a;
            this.v = this.l = null;
            this.G = {};
            this.I = 0;
            this.C = !1
        }
        m() {
            if (!this.C) {
                if (!this.l) {
                    var a = hh(this.A, "googlefcPresent");
                    this.l = a ? a : null
                }
                this.C = !0
            }
            return !!this.l
        }
        H(a) {
            return new Promise(b => {
                if (this.m())
                    if (this.l === this.A) {
                        var c = this.l.googlefc || (this.l.googlefc = {});
                        c.__fci = c.__fci || [];
                        c.__fci.push(a, d => {
                            b(pL(d))
                        })
                    } else LM(this), c = this.I++, this.G[c] = b, this.l.postMessage({
                        __fciCall: {
                            command: a,
                            callId: c
                        }
                    }, "*")
            })
        }
    };
    const NM = (a, b) => {
        try {
            const g = void 0 === I(b, 6) ? !0 : I(b, 6);
            a: switch (ld(b, 4)) {
                case 1:
                    var c = "pt";
                    break a;
                case 2:
                    c = "cr";
                    break a;
                default:
                    c = ""
            }
            var d = new Ff(Df(ld(b, 2)), G(b, 3), c),
                e = C(b, zf, 5) ? .j() ? ? "";
            d.zb = e;
            d.j = g;
            d.win = a;
            var f = d.build();
            xf(f)
        } catch {}
    };

    function OM(a, b) {
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? NM(a, b) : L(a, "load", () => void NM(a, b)))
    };

    function PM(a) {
        const b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    }

    function QM(a) {
        if (a === a.top || Kg(a.top)) return Promise.resolve({
            status: 4
        });
        a: {
            try {
                var b = (a.top ? .frames ? ? {}).google_ads_top_frame;
                break a
            } catch (d) {}
            b = null
        }
        if (!b) return Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && PM(a.document.referrer)) return Promise.resolve({
            status: 3
        });
        const c = new Xu;
        a = new MessageChannel;
        a.port1.onmessage = d => {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                tb: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    var RM = class extends K {
            constructor(a) {
                super(a)
            }
        },
        SM = Gd(RM),
        TM = [1, 3];
    const UM = N `https://securepubads.g.doubleclick.net/static/topics/topics_frame.html`;

    function VM(a) {
        const b = a.google_tag_topics_state ? ? (a.google_tag_topics_state = {});
        return b.messageChannelSendRequestFn ? Promise.resolve(b.messageChannelSendRequestFn) : new Promise(c => {
            function d(h) {
                return g.j(h).then(({
                    data: k
                }) => k)
            }
            const e = Pg("IFRAME");
            e.style.display = "none";
            e.name = "goog_topics_frame";
            e.src = qe(UM).toString();
            const f = (new URL(UM.toString())).origin,
                g = TE({
                    destination: a,
                    Ca: e,
                    origin: f,
                    Sa: "goog:gRpYw:doubleclick"
                });
            g.j("goog:topics:frame:handshake:ack").then(({
                data: h
            }) => {
                "goog:topics:frame:handshake:ack" ===
                h && c(d)
            });
            b.messageChannelSendRequestFn = d;
            a.document.documentElement.appendChild(e)
        })
    }

    function WM(a, b, c) {
        var d = Nk;
        const {
            Ob: e,
            Nb: f
        } = XM(c);
        b = b.google_tag_topics_state ? ? (b.google_tag_topics_state = {});
        b.getTopicsPromise || (a = a({
                message: "goog:topics:frame:get:topics",
                skipTopicsObservation: !1
            }).then(g => {
                let h = f;
                if (g instanceof Uint8Array) h || (h = !(e instanceof Uint8Array && yb(g, e)));
                else if (Vi()(g)) h || (h = g !== e);
                else return d.ka(989, Error(JSON.stringify(g))), 7;
                if (h && c) try {
                    var k = new RM;
                    var l = x(k, 2, Gi());
                    g instanceof Uint8Array ? Xc(l, 1, TM, Bc(g, !1)) : Xc(l, 3, TM, g);
                    c.setItem("goog:cached:topics", Ad(l))
                } catch {}
                return g
            }),
            b.getTopicsPromise = a);
        return e && !f ? Promise.resolve(e) : b.getTopicsPromise
    }

    function XM(a) {
        if (!a) return {
            Ob: null,
            Nb: !0
        };
        try {
            const n = a.getItem("goog:cached:topics");
            if (!n) return {
                Ob: null,
                Nb: !0
            };
            const q = SM(n);
            let r;
            const t = Yc(q, TM);
            switch (t) {
                case 0:
                    r = null;
                    break;
                case 1:
                    var b, c = 1 === Yc(q, TM) ? 1 : -1;
                    a = q;
                    const z = w(a, c),
                        A = Bc(z, !0);
                    null != A && A !== z && Nc(a, c, A);
                    var d = A;
                    var e = null == d ? lc() : d;
                    kc(ic);
                    var f = e.M;
                    if (null == f || gc(f)) var g = f;
                    else {
                        if ("string" === typeof f)
                            if (cc) {
                                c = f;
                                ec.test(c) && (c = c.replace(ec, fc));
                                var h = atob(c);
                                var k = new Uint8Array(h.length);
                                for (c = 0; c < h.length; c++) k[c] = h.charCodeAt(c);
                                var l = k
                            } else l = ac(f);
                        else l = null;
                        g = l
                    }
                    var m = g;
                    r = (b = null == m ? m : e.M = m) ? new Uint8Array(b) : hc || (hc = new Uint8Array(0));
                    break;
                case 3:
                    r = ld(q, 3 === Yc(q, TM) ? 3 : -1);
                    break;
                default:
                    lf(t, void 0)
            }
            const B = fd(q, 2) + 6048E5 < Gi();
            return {
                Ob: r,
                Nb: B
            }
        } catch {
            return {
                Ob: null,
                Nb: !0
            }
        }
    };

    function YM(a) {
        a = a.innerInsElement;
        if (!a) throw Error("no_wrapper_element_in_loader_provided_slot");
        return a
    }
    async function ZM({
        ea: a,
        da: b,
        Za: c,
        slot: d
    }) {
        const e = d.vars,
            f = Ng(d.pubWin),
            g = YM(d),
            h = new AG({
                J: f,
                pubWin: d.pubWin,
                F: e,
                ea: a,
                da: b,
                Za: c,
                X: g
            });
        h.G = Date.now();
        nl(1, [h.F]);
        Pk(1032, () => {
            if (f && T(aq)) {
                var k = h.F;
                TC(OC(), 32, !1) || (UC(OC(), 32, !0), lI(f, "sa" === k.google_loader_used ? 5 : 9))
            }
        });
        try {
            await $M(h)
        } catch (k) {
            if (!Sk(159, k)) throw k;
        }
        Pk(639, () => {
            {
                var k = h.F;
                const m = h.J;
                if (m && 1 === k.google_responsive_auto_format && !0 === k.google_full_width_responsive_allowed) {
                    var l;
                    (l = (l = m.document.getElementById(k.google_async_iframe_id +
                        (T(Hp) ? "_host" : ""))) ? Eg(l, "INS", "adsbygoogle") : null) ? (k = new zG(m, l, k), k.j = u.setInterval(Ba(k.v, k), 500), k.v(), k = !0) : k = !1
                } else k = !1
            }
            return k
        });
        Uk(h.pubWin, "affa", k => {
            Pk(1008, () => {
                e.google_ad_client && f && !eb() && aN(f, e, eJ(k.config), h.l, G(a, 8))
            }, bN)
        });
        e.google_ad_client && f && !eb() && f ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/) && aN(f, e, cN(), h.l, G(a, 8));
        return h
    }

    function bN(a) {
        a.e = `${V(pq)}`
    }

    function aN(a, b, c, d, e) {
        if (C(c, Wf, 1) || T(Dq)) {
            var f = Ik(lD);
            var g = b.google_page_url;
            g = "string" === typeof g ? g : "";
            var h = "on" === b.google_adtest;
            const m = C(c, YE, 2);
            try {
                const n = a ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/);
                if (n) {
                    var k = decodeURIComponent(n[1]);
                    var l = Xf(k)
                } else l = null
            } catch (n) {
                l = null
            }
            l || (l = T(gq) ? C(c, Wf, 1) ? ? null : null);
            c = new bL(l, g, !(!m ? .j() || !(488 > O(a).clientWidth) && m ? .v()), e, new SK({
                kb: T(Iq) ? V(Jp) : V(pq),
                xc: V(Ip)
            }), h);
            aL(a, f, c, b.google_ad_client, d)
        }
    }

    function cN() {
        const a = new dJ;
        if (T(fq)) {
            var b = new YE;
            b = nd(b, 5, !0);
            b = nd(b, 8, !0);
            ad(a, 2, b)
        }
        return a
    }

    function $M(a) {
        if (/_sdo/.test(a.F.google_ad_format)) return Promise.resolve();
        pF(13);
        pF(11);
        var b = Ik(Wq).v(Qp.j, Qp.defaultValue);
        if (b.length) {
            var c = document;
            if (b.length && c.head)
                for (var d of b)
                    if ((b = d) && c.head) {
                        var e = Pg("META");
                        c.head.appendChild(e);
                        e.httpEquiv = "origin-trial";
                        e.content = b
                    }
        }
        c = OC();
        (d = TC(c, 23, !1)) || UC(c, 23, !0);
        if (!d) {
            c = a.F.google_ad_client;
            d = a.ea;
            c = void 0 !== Pc(d, YE, 13 === Yc(d, cF) ? 13 : -1) ? C(md(d, YE, 13, cF), VD, 2) : yb(md(d, $E, 14, cF) ? .j() ? ? [], [c]) ? C(C(md(d, $E, 14, cF), YE, 2), VD, 2) : new VD;
            c = new WD(a.pubWin,
                a.F.google_ad_client, c, I(a.ea, 6));
            c.l = !0;
            b = C(c.A, zo, 1);
            if (c.l && (d = c.j, c.v && !hz(b) ? (e = new JD, e = x(e, 1, 1)) : e = null, e)) {
                e = Ad(e);
                try {
                    d.localStorage.setItem("google_auto_fc_cmp_setting", e)
                } catch (f) {}
            }
            b && iz(new jz(c.j, new Az(c.j, c.m), b, new cw(c.j)))
        }
        c = !Eh() && !db();
        return !c || c && !dN(a) ? eN(a) : Promise.resolve()
    }

    function fN(a, b, c = !1) {
        b = XE(a.J, b);
        const d = Ih() || fr(a.pubWin.top);
        if (!b || -12245933 === b.y || -12245933 === d.width || -12245933 === d.height || !d.height) return 0;
        let e = 0;
        try {
            const f = a.pubWin.top;
            e = hr(f.document, f).y
        } catch (f) {
            return 0
        }
        a = e + d.height;
        return b.y < e ? c ? 0 : (e - b.y) / d.height : b.y > a ? (b.y - a) / d.height : 0
    }

    function dN(a) {
        return gN(a) || hN(a)
    }

    function gN(a) {
        const b = a.F;
        if (!b.google_pause_ad_requests) return !1;
        const c = u.setTimeout(() => {
                Rk("abg:cmppar", {
                    client: a.F.google_ad_client,
                    url: a.F.google_page_url
                })
            }, 1E4),
            d = Qk(450, () => {
                b.google_pause_ad_requests = !1;
                u.clearTimeout(c);
                a.pubWin.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
                dN(a) || eN(a)
            });
        a.pubWin.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
        return !0
    }

    function hN(a) {
        const b = a.pubWin.document,
            c = iN();
        if (0 > c.hidden && 0 > c.visible) return !1;
        const d = a.X,
            e = TG(b);
        if (!e) return !1;
        if (!UG(b)) return jN(a, c.visible, d);
        const f = 3 === SG(b);
        if (fN(a, d) <= c.hidden && !f) return !1;
        let g = Qk(332, () => {
            !UG(b) && g && (Yd(b, e, g), jN(a, c.visible, d) || eN(a), g = null)
        });
        return L(b, e, g)
    }

    function iN() {
        const a = {
            hidden: 0,
            visible: 3
        };
        u.IntersectionObserver || (a.visible = -1);
        Hg() && (a.visible *= 2);
        return a
    }

    function jN(a, b, c) {
        if (!c || 0 > b) return !1;
        var d = a.F;
        if (!Il(d.google_reactive_ad_format) && (VF(d) || d.google_reactive_ads_config) || !ir(c) || fN(a, c) <= b) return !1;
        var e = OC(),
            f = TC(e, 8, {});
        e = TC(e, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        const g = !!a.pubWin.google_apltlad;
        if (!f[d] && !e[d] && !g) return !1;
        f = new Promise(h => {
            const k = new u.IntersectionObserver((l, m) => {
                lb(l, n => {
                    0 >= n.intersectionRatio || (m.unobserve(n.target), h(void 0))
                })
            }, {
                rootMargin: `${100*b}%`
            });
            a.H = k;
            k.observe(c)
        });
        e = new Promise(h => {
            c.addEventListener("adsbygoogle-close-to-visible-event",
                () => {
                    h(void 0)
                })
        });
        ia(Promise, "any").call(Promise, [f, e]).then(() => {
            Pk(294, () => {
                eN(a)
            })
        });
        return !0
    }

    function eN(a) {
        Pk(326, () => {
            if (1 === gi(a.F)) {
                var c = T(bq),
                    d = c || T($p),
                    e = a.pubWin;
                if (d && e === a.J) {
                    var f = new al;
                    d = new bl;
                    f.setCorrelator(qh(a.pubWin));
                    var g = qF(a.pubWin);
                    jd(f, 5, g);
                    od(f, 2, 1);
                    g = ad(d, 1, f);
                    f = new $k;
                    f = nd(f, 10, !0);
                    var h = T(Tp);
                    f = nd(f, 8, h);
                    h = T(Up);
                    f = nd(f, 12, h);
                    h = T(Xp);
                    f = nd(f, 7, h);
                    h = T(Wp);
                    f = nd(f, 13, h);
                    ad(g, 2, f);
                    e.google_rum_config = d.toJSON();
                    Og(e.document, I(a.ea, 9) && c ? a.da.Sf : a.da.Tf)
                } else Ni(Ok)
            }
        });
        a.F.google_ad_channel = kN(a, a.F.google_ad_channel);
        a.F.google_tag_partner = lN(a, a.F.google_tag_partner);
        mN(a);
        const b = a.F.google_start_time;
        "number" === typeof b && (rl = b, a.F.google_start_time = null);
        WE(a);
        nN(a);
        XC() && YD({
            win: a.pubWin,
            webPropertyCode: a.F.google_ad_client,
            vb: a.da.vb
        });
        VF(a.F) && (dy() && (a.F.google_adtest = a.F.google_adtest || "on"), a.F.google_pgb_reactive = a.F.google_pgb_reactive || 3);
        oN(a.J);
        if ("function" === typeof a.pubWin.document.browsingTopics && kF(a.pubWin.document) || T(Kp)) try {
            a.B = VM(a.pubWin)
        } catch (c) {
            Sk(984, c)
        }
        return pN(a)
    }

    function nN(a) {
        a.J && (ZF(a.J, a.da.gf), XF(a.J.location) && hG(a.J, {
            enable_page_level_ads: {
                pltais: !0
            },
            google_ad_client: a.F.google_ad_client
        }))
    }

    function kN(a, b) {
        return (b ? [b] : []).concat(MC(a.F).ad_channels || []).join("+")
    }

    function lN(a, b) {
        return (b ? [b] : []).concat(MC(a.F).tag_partners || []).join("+")
    }

    function qN(a) {
        const b = Pg("IFRAME");
        Sg(a, (c, d) => {
            null != c && b.setAttribute(d, c)
        });
        return b
    }

    function rN(a, b, c) {
        return 9 === a.F.google_reactive_ad_format && Eg(a.X, null, "fsi_container") ? (a.X.appendChild(b), Promise.resolve(b)) : fG(a.da.re, 525, d => {
            a.X.appendChild(b);
            d.createAdSlot(a.J, a.F, b, a.X.parentElement, ND(c, a.pubWin));
            return b
        })
    }

    function sN(a, b, c) {
        OM(a.pubWin, nd(Bf(od(od(Af(new Cf, yf(new zf, String(qh(a.pubWin)))), 4, 1), 2, 1), G(a.ea, 2)), 6, !0));
        const d = a.J;
        a.F.google_acr && a.F.google_acr(b);
        L(b, "load", () => {
            b && b.setAttribute("data-load-complete", !0);
            const f = d ? MC(d).enable_overlap_observer || !1 : !1;
            (a.F.ovlp || f) && d && d === a.pubWin && tN(d, a, a.X, b)
        });
        var e = f => {
            f && a.m.push(() => {
                f.xa()
            })
        };
        uN(a, b);
        vN(a, b);
        !d || VF(a.F) && !jG(a.F) || (a.X || Rk("shadowroot_nullcheck", {
            "var": "sth_init",
            ctxSize: Object.keys(a).length,
            isExp: T(Hp) ? 1 : 0
        }, .05), e(new FH(d,
            b, a.F)), e(new PG(a, b)), e(d.IntersectionObserver ? null : new RG(d, b, a.X)));
        d && (e(new JG(d, b)), a.m.push(tG(d, a.F)), Ik(yG).init(d), a.m.push(FG(d, a.X, b)));
        b && b.setAttribute("data-google-container-id", c);
        c = a.F.iaaso;
        if (null != c) {
            e = a.X;
            const f = e.parentElement;
            (f && vr.test(f.className) ? f : e).setAttribute("data-auto-ad-size", c)
        }
        c = a.X;
        c.setAttribute("tabindex", "0");
        c.setAttribute("title", "Advertisement");
        c.setAttribute("aria-label", "Advertisement");
        wN(a)
    }

    function uN(a, b) {
        const c = a.pubWin,
            d = a.F.google_ad_client,
            e = WC();
        let f = null;
        const g = Uk(c, "pvt", (h, k) => {
            "string" === typeof h.token && k.source === b.contentWindow && (f = h.token, g(), e[d] = e[d] || [], e[d].push(f), 100 < e[d].length && e[d].shift())
        });
        a.m.push(g)
    }

    function xN(a, b) {
        var c = rF(a, "__gpi_opt_out", b.l);
        c && (c = Lf(Kf(Jf(If(new Mf, c), 2147483647), "/"), b.pubWin.location.hostname), sF(a, "__gpi_opt_out", c, b.l))
    }

    function vN(a, b) {
        const c = Uk(a.pubWin, "gpi-uoo", (d, e) => {
            if (e.source === b.contentWindow) {
                e = Lf(Kf(Jf(If(new Mf, d.userOptOut ? "1" : "0"), 2147483647), "/"), a.pubWin.location.hostname);
                var f = new vF(a.pubWin);
                sF(f, "__gpi_opt_out", e, a.l);
                if (d.userOptOut || d.clearAdsData) tF(f, "__gads", a.l), tF(f, "__gpi", a.l)
            }
        });
        a.m.push(c)
    }

    function wN(a) {
        const b = Eh(a.pubWin);
        if (b)
            if ("AMP-STICKY-AD" === b.container) {
                const c = d => {
                    "fill_sticky" === d.data && b.renderStart && b.renderStart()
                };
                L(a.pubWin, "message", Nk.ta(616, c));
                a.m.push(() => {
                    Yd(a.pubWin, "message", c)
                })
            } else b.renderStart && b.renderStart()
    }

    function tN(a, b, c, d) {
        uM(new DM(a), c).then(e => {
            nl(8, [e]);
            return e
        }).then(e => {
            const f = c.parentElement;
            (f && vr.test(f.className) ? f : c).setAttribute("data-overlap-observer-io", e.isOverlappingOrOutsideViewport);
            return e
        }).then(e => {
            const f = b.F.armr || "",
                g = e.executionTime || "",
                h = null == b.F.iaaso ? "" : Number(b.F.iaaso),
                k = Number(e.isOverlappingOrOutsideViewport),
                l = nb(e.entries, z => `${z.overlapType}:${z.overlapDepth}:${z.overlapDetectionPoint}`),
                m = Number(e.overlappedArea.toFixed(2)),
                n = d.dataset.googleQueryId || "",
                q =
                m * e.targetRect.width * e.targetRect.height,
                r = e.scrollPosition.scrollX + "," + e.scrollPosition.scrollY,
                t = ii(e.target),
                B = [e.targetRect.left, e.targetRect.top, e.targetRect.right, e.targetRect.bottom].join();
            e = e.viewportSize.width + "x" + e.viewportSize.height;
            Rk("ovlp", {
                adf: b.F.google_ad_dom_fingerprint,
                armr: f,
                client: b.F.google_ad_client,
                eid: qF(b.F),
                et: g,
                fwrattr: b.F.google_full_width_responsive,
                iaaso: h,
                io: k,
                saldr: b.F.google_loader_used,
                oa: m,
                oe: l.join(","),
                qid: n,
                rafmt: b.F.google_responsive_auto_format,
                roa: q,
                slot: b.F.google_ad_slot,
                sp: r,
                tgt: t,
                tr: B,
                url: b.F.google_page_url,
                vp: e,
                pvc: qh(a)
            }, 1)
        }).catch(e => {
            nl(8, ["Error:", e.message, c]);
            Rk("ovlp-err", {
                err: e.message
            }, 1)
        })
    }

    function yN(a, b) {
        b.allow = b.allow && 0 < b.allow.length ? b.allow + ("; " + a) : a
    }

    function zN(a, b, c, d) {
        var e = a.F;
        const f = e.google_async_iframe_id,
            g = e.google_ad_width,
            h = e.google_ad_height;
        var k = kG(e),
            l = {
                id: f,
                name: f
            };
        l.style = k ? [`width:${g}px !IMPORTANT`, `height:${h}px !IMPORTANT`].join(";") : "left:0;position:absolute;top:0;border:0;" + `width:${g}px;` + `height:${h}px;`;
        var m = fh();
        if (m["allow-top-navigation-by-user-activation"] && m["allow-popups-to-escape-sandbox"]) {
            m = b;
            if (b = "fsb=" + encodeURIComponent("1")) {
                var n = m.indexOf("#");
                0 > n && (n = m.length);
                var q = m.indexOf("?");
                if (0 > q || q > n) {
                    q = n;
                    var r =
                        ""
                } else r = m.substring(q + 1, n);
                m = [m.slice(0, q), r, m.slice(n)];
                n = m[1];
                m[1] = b ? n ? n + "&" + b : b : n;
                b = m[0] + (m[1] ? "?" + m[1] : "") + m[2]
            } else b = m;
            l.sandbox = eh().join(" ")
        }
        T(kp) && !1 === e.google_video_play_muted && yN("autoplay", l);
        n = b;
        b = AN(b);
        q = c ? b.replace(/&ea=[^&]*/, "") + "&ea=0" : b;
        null != g && (l.width = String(g));
        null != h && (l.height = String(h));
        l.frameborder = "0";
        l.marginwidth = "0";
        l.marginheight = "0";
        l.vspace = "0";
        l.hspace = "0";
        l.allowtransparency = "true";
        l.scrolling = "no";
        m = "";
        if (c) {
            m = 10;
            for (q = ""; 0 < m--;) q += "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(Math.floor(62 *
                Math.random()));
            m = q;
            b = Tk(b, m);
            Tk(n, m)
        } else b = q;
        e.dash && (l.srcdoc = e.dash);
        n = T(rI(window) ? Oq : Nq);
        q = T(Qq);
        n = sI(a.pubWin, n, q);
        q = e.google_trust_token_additional_signing_data;
        n && tI(n) && (n = vI(n, q)) && (l.trustToken = JSON.stringify(n));
        a.pubWin.document.featurePolicy ? .features().includes("attribution-reporting") && yN("attribution-reporting", l);
        T(Rp) && (n = a.pubWin, void 0 !== n.credentialless && (T(Sp) || n.crossOriginIsolated) && (l.credentialless = "true"));
        if (k) {
            l.src = b;
            var t = qN(l);
            t = rN(a, t, d)
        } else {
            d = {};
            d.dtd = DG((new Date).getTime(),
                rl);
            d = ci(d, b);
            l.src = d;
            d = a.pubWin;
            d = d == d.top;
            l = qN(l);
            d && a.m.push(Kh(a.pubWin, l));
            d = (d = a.F.google_shadow_mode) && "string" === typeof d && "open" === d ? "open" : "closed";
            a: {
                k = a.X;
                try {
                    if (T(Hp) && k) {
                        t = k.attachShadow({
                            mode: d
                        });
                        break a
                    }
                } catch (B) {}
                t = void 0
            }
            a.X.style.visibility = "visible";
            t = t || a.X;
            for (d = l; k = t.firstChild;) t.removeChild(k);
            t.appendChild(d);
            t = Promise.resolve(l)
        }
        c && (c = a.da.mg, e = {
                id: f,
                url: b,
                width: g,
                height: h,
                Sa: m,
                Rf: a.pubWin,
                Oe: f,
                lk: "google_expandable_ad_slot" + gi(e),
                Bf: c.toString(),
                Mc: a.pubWin
            }, e = !e.id || !e.url ||
            0 >= e.width || 0 >= e.height || !e.Sa || !e.Mc ? void 0 : Uk(e.Mc, "ct", Ca(Xk, e, c)), e && a.m.push(e));
        return t
    }

    function AN(a) {
        var b = V(v("Edge") ? yp : Cp);
        var c = a;
        c.length > b && (c = c.substring(0, b - 8), c = c.replace(/%\w?$/, ""), c = c.replace(/&[^=]*=?$/, ""), c += "&trunc=1");
        if (c !== a) {
            b -= 8;
            let d = a.lastIndexOf("&", b); - 1 === d && (d = a.lastIndexOf("?", b));
            Rk("trn", {
                ol: a.length,
                tr: -1 === d ? "" : a.substring(d + 1),
                url: a
            }, .01)
        }
        return c
    }
    async function BN(a) {
        var b = a.F,
            c = a.pubWin,
            d = a.l;
        y(d, 5) && xN(new vF(a.pubWin), a);
        var e = ND(d, a.pubWin);
        if (!y(d, 5)) return Rk("afc_noc_req", {}, V(ip)), Promise.resolve();
        y(d, 5) && zF(d, a.pubWin, a.F.google_ad_client);
        var f = a.F.google_reactive_ads_config;
        f && (eG(a.J, f), lG(f, a, ND(d)), f = f.page_level_pubvars, ta(f) && fe(a.F, f));
        y(d, 5) && await CN();
        T(Kp) && a.B && y(d, 5) && !TC(OC(), 34, !1) && (UC(OC(), 34, !0), f = a.B.then(g => {
            g({
                message: "goog:spam:client_age",
                pvsid: qh(a.pubWin)
            })
        }), Nk.Aa(1069, f));
        if (T(Op) && a.B)
            if (DN(a)) {
                a.v = 1;
                const g = ND(a.l, a.pubWin);
                f = a.B.then(async k => {
                    await WM(k, a.pubWin, g).then(l => {
                        a.v = l
                    })
                });
                const h = V(Np);
                0 < h ? await Promise.race([f, uh(h)]) : await f
            } else a.v = 5;
        if (!uI(a.pubWin, hF(), G(a.ea, 8))) {
            const g = V(Uq);
            f = c.google_trust_token_operation_promise;
            0 < g && f && await Promise.race([f, new Promise(h => void setTimeout(() => {
                h(void 0)
            }, g))])
        }
        f = "";
        kG(b) ? (f = a.da.ng.toString() + "#" + II(b), QI(b, OC()), EN(b)) : (5 === b.google_pgb_reactive && b.google_reactive_ads_config || !WF(b) || UF(c, b, e)) && EN(b) && (f = FI(a, d));
        nl(2, [b, f]);
        if (!f) return Promise.resolve();
        b.google_async_iframe_id || fi(c);
        e = gi(b);
        b = a.pubWin === a.J ? "a!" + e.toString(36) : `${e.toString(36)}.${Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Da()).toString(36)}`;
        c = 0 < fN(a, a.X, !0);
        e = {
            ifi: e,
            uci: b
        };
        c && (c = OC(), e.btvi = TC(c, 21, 1), VC(c, 21));
        f = ci(e, f);
        d = zN(a, f, 0 === a.A, d);
        f = AN(f);
        a.F.rpe && zH(a.pubWin, a.X, {
            height: a.F.google_ad_height,
            md: "force",
            wd: !0,
            Zf: !0,
            uc: a.F.google_ad_client
        });
        d = await d;
        try {
            sN(a, d, b)
        } catch (g) {
            Sk(223, g)
        }
    }

    function CN() {
        return (gb() ? 0 <= $a(11) : fb() && 0 <= $a(65)) ? new Promise(a => {
            hI(a.bind(null, !0))
        }) : (hI(null), Promise.resolve(!1))
    }

    function FN(a) {
        const b = T(dq) ? new oL(a) : new KM(a);
        return new Promise(c => {
            b.C(d => {
                d && "string" === typeof d.uspString ? c(d.uspString) : c(null)
            })
        })
    }

    function GN(a) {
        var b = gh(u.top, "googlefcPresent");
        u.googlefc && !b && Rk("adsense_fc_has_namespace_but_no_iframes", {
            publisherId: a
        }, 1)
    }

    function HN(a) {
        return a.m() ? a.H("loaded") : Promise.resolve(null)
    }

    function IN(a, b) {
        const c = b.ig;
        b = b.uspString;
        c ? BG(a, c) : QD(a, !0);
        b && x(a, 1, b)
    }

    function JN(a) {
        const b = V(gp);
        if (0 >= b) return null;
        const c = Gi(),
            d = GM(a.pubWin);
        if (!d) return null;
        a.C = "0";
        return Promise.race([d, uh(b, "0")]).then(e => {
            Rk("adsense_paw", {
                time: Gi() - c
            });
            e ? .length > V(fp) ? Sk(809, Error(`ML:${e.length}`)) : a.C = e
        }).catch(e => {
            Sk(809, e)
        })
    }

    function KN(a) {
        const b = Gi();
        return Promise.race([Pk(832, () => QM(a)), uh(200)]).then(c => {
            Rk("afc_etu", {
                etus: c ? .status ? ? 100,
                sig: Gi() - b,
                tms: 200
            });
            return c ? .tb
        })
    }

    function LN(a) {
        var b = V(jp);
        return Promise.race([Qk(779, () => {
            const c = T(rI(window) ? Oq : Nq),
                d = T(Qq);
            return BI(new CI(a, c, d))
        })(), uh(b)])
    }
    async function MN(a) {
        const b = JN(a),
            c = Pk(868, () => KN(a.pubWin));
        dI(G(a.ea, 8));
        CE(a.pubWin);
        GN(a.F.google_ad_client);
        var d = T(cq) ? new tL(a.pubWin) : new MM(a.pubWin);
        await HN(d);
        a.l = new RD;
        d = [CG(a), FN(a.pubWin)];
        d = await Promise.all(d);
        IN(a.l, {
            ig: d[0],
            uspString: d[1]
        });
        uI(a.pubWin, hF(), G(a.ea, 8)) && (d = LN(!!y(a.l, 5)), T(Tq) ? Nk.Aa(962, d) : await d);
        await b;
        a.tb = await c || "";
        await BN(a)
    }

    function DN(a) {
        const b = a.l;
        a = a.F;
        return !a.google_restrict_data_processing && 1 !== a.google_tag_for_under_age_of_consent && 1 !== a.google_tag_for_child_directed_treatment && !!y(b, 5) && !b.j() && !YC() && !y(b, 9)
    }

    function pN(a) {
        var b = a.pubWin.document,
            c = a.F;
        const d = c.google_ad_width,
            e = c.google_ad_height;
        let f = 0;
        try {
            !1 === c.google_allow_expandable_ads && (f |= 1);
            if (!b.body || isNaN(c.google_ad_height) || isNaN(c.google_ad_width) || !/^http/.test(b.location.protocol)) f |= 2; {
                c = navigator;
                const l = c.userAgent,
                    m = c.platform,
                    n = c.product;
                if (!/Win|Mac|Linux|iPad|iPod|iPhone/.test(m) && /^Opera/.test(l)) var g = !1;
                else if (/Win/.test(m) && /Trident/.test(l) && 11 <= b.documentMode) g = !0;
                else {
                    var h = (/WebKit\/(\d+)/.exec(l) || [0, 0])[1],
                        k = (/rv:(\d+\.\d+)/.exec(l) || [0, 0])[1];
                    g = !h && "Gecko" === n && 27 <= k && !/ rv: 1\.8([^.] |\.0) /.test(l) || 536 <= h ? !0 : !1
                }
            }
            g || (f |= 4);
            lr(a.pubWin, d, e) && (f |= 2)
        } catch (l) {
            f |= 8
        }
        a.A = f;
        0 === a.A || (a.F.google_allow_expandable_ads = !1);
        vh(a.pubWin) !== a.pubWin && (a.j |= 4);
        3 === SG(a.pubWin.document) && (a.j |= 32);
        if (b = a.J) b = a.J, b = !(O(b).scrollWidth <= O(b).clientWidth);
        b && (a.j |= 1024);
        a.pubWin.Prototype ? .Version && (a.j |= 16384);
        a.F.google_loader_features_used && (a.j |= a.F.google_loader_features_used);
        a.D = 2;
        return MN(a)
    }

    function EN(a) {
        const b = OC(),
            c = a.google_ad_section;
        VF(a) && VC(b, 15);
        if (li(a)) {
            if (100 < VC(b, 5)) return !1
        } else if (100 < VC(b, 6) - TC(b, 15, 0) && "" === c) return !1;
        return !0
    }

    function mN(a) {
        const b = a.J;
        if (b && !MC(b).ads_density_stats_processed && !Eh(b) && (MC(b).ads_density_stats_processed = !0, T(Dp) || .01 > Rg())) {
            const c = () => {
                if (b) {
                    var d = OB(JB(b), a.F.google_ad_client, b.location.hostname, qF(a.F).split(","));
                    Rk("ama_stats", d, 1)
                }
            };
            th(b, () => {
                u.setTimeout(c, 1E3)
            })
        }
    }

    function oN(a) {
        a && !MC(a).host_pinged_back && (MC(a).host_pinged_back = !0, Rk("abg_host", {
            host: a.location.host
        }, .01))
    };
    (function(a, b, c) {
        Pk(843, () => {
            if (!u.google_sa_impl) {
                var d = gL(a);
                dL(d);
                nl(16, [3, d.toJSON()]);
                var e = eL({
                        df: b,
                        gg: G(d, 2)
                    }),
                    f = c(e, d);
                u.google_sa_impl = h => ZM({
                    ea: d,
                    da: f,
                    Za: e,
                    slot: h
                });
                nF(jF(u));
                u.google_process_slots ? .();
                var g = (u.Prototype || {}).Version;
                null != g && Rk("prtpjs", {
                    version: g
                })
            }
        })
    })(fL, "m202302060101", function(a, b) {
        const c = 2012 < ed(b, 1) ? `_fy${ed(b,1)}` : "",
            d = G(b, 3);
        b = G(b, 2);
        return {
            Tf: N `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/rum${c}.js`,
            Sf: N `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/rum_debug${c}.js`,
            re: N `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/reactive_library${c}.js`,
            gf: N `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/debug_card_library${c}.js`,
            mg: N `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/creativetoolset/xpc_expansion_embed.js`,
            ng: N `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup.html`,
            Gb: N `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${c}.js`,
            vb: N `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/gallerify${c}.js`
        }
    });
}).call(this, "[2021,\"r20230207\",\"r20110914\",null,null,null,null,\".google.co.in\",null,null,null,null,[null,[]],null,null,null,null,-1,[44759837,44759875,44759926]]");