(function(sttc) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    'use strict';
    var aa = {},
        n = this || self;

    function ba(a) {
        a = a.split(".");
        for (var b = n, c = 0; c < a.length; c++)
            if (b = b[a[c]], null == b) return null;
        return b
    }

    function ca(a) {
        var b = typeof a;
        b = "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null";
        return "array" == b || "object" == b && "number" == typeof a.length
    }

    function da(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function ea(a) {
        return Object.prototype.hasOwnProperty.call(a, fa) && a[fa] || (a[fa] = ++ha)
    }
    var fa = "closure_uid_" + (1E9 * Math.random() >>> 0),
        ha = 0;

    function ia(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function ja(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function ka(a, b, c) {
        Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ka = ia : ka = ja;
        return ka.apply(null, arguments)
    }

    function la(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function ma(a, b) {
        a = a.split(".");
        var c = n;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function na(a) {
        return a
    };
    let oa = (new Date).getTime();

    function pa(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function qa(a, b) {
        let c = 0;
        a = pa(String(a)).split(".");
        b = pa(String(b)).split(".");
        const d = Math.max(a.length, b.length);
        for (let g = 0; 0 == c && g < d; g++) {
            var e = a[g] || "",
                f = b[g] || "";
            do {
                e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                if (0 == e[0].length && 0 == f[0].length) break;
                c = ra(0 == e[1].length ? 0 : parseInt(e[1], 10), 0 == f[1].length ? 0 : parseInt(f[1], 10)) || ra(0 == e[2].length, 0 == f[2].length) || ra(e[2], f[2]);
                e = e[3];
                f = f[3]
            } while (0 == c)
        }
        return c
    }

    function ra(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };

    function ta() {
        var a = n.navigator;
        return a && (a = a.userAgent) ? a : ""
    }

    function p(a) {
        return -1 != ta().indexOf(a)
    };

    function ua() {
        return p("Trident") || p("MSIE")
    }

    function va() {
        return (p("Chrome") || p("CriOS")) && !p("Edge") || p("Silk")
    }

    function wa(a) {
        const b = {};
        a.forEach(c => {
            b[c[0]] = c[1]
        });
        return c => b[c.find(d => d in b)] || ""
    }

    function xa() {
        var a = ta();
        if (ua()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        let d;
        for (; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
        a = wa(b);
        return p("Opera") ? a(["Version", "Opera"]) :
            p("Edge") ? a(["Edge"]) : p("Edg/") ? a(["Edg"]) : p("Silk") ? a(["Silk"]) : va() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    };

    function ya(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function za(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Aa(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = "string" === typeof a ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Da(a, b) {
        const c = a.length,
            d = Array(c),
            e = "string" === typeof a ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Ea(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Fa(a, b) {
        a: {
            const c = a.length,
                d = "string" === typeof a ? a.split("") : a;
            for (let e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function Ga(a, b) {
        a: {
            var c = a.length;
            const d = "string" === typeof a ? a.split("") : a;
            for (--c; 0 <= c; c--)
                if (c in d && b.call(void 0, d[c], c, a)) {
                    b = c;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function Ha(a, b) {
        return 0 <= ya(a, b)
    }

    function Ia(a) {
        const b = a.length;
        if (0 < b) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Ka(a) {
        Ka[" "](a);
        return a
    }
    Ka[" "] = function() {};
    var La = ua();
    !p("Android") || va();
    va();
    !p("Safari") || va();
    var Ma = {},
        Na = null;

    function Oa(a) {
        var b = [];
        Pa(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Pa(a, b) {
        function c(l) {
            for (; d < a.length;) {
                var k = a.charAt(d++),
                    m = Na[k];
                if (null != m) return m;
                if (!/^[\s\xa0]*$/.test(k)) throw Error("Unknown base64 encoding at char: " + k);
            }
            return l
        }
        Qa();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (64 === h && -1 === e) break;
            b(e << 2 | f >> 4);
            64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
        }
    }

    function Qa() {
        if (!Na) {
            Na = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                var d = a.concat(b[c].split(""));
                Ma[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e];
                    void 0 === Na[f] && (Na[f] = e)
                }
            }
        }
    };
    var Ra = "undefined" !== typeof Uint8Array;
    const Sa = !La && "function" === typeof n.btoa;

    function Ta(a) {
        if (!Sa) {
            var b;
            void 0 === b && (b = 0);
            Qa();
            b = Ma[b];
            const g = Array(Math.floor(a.length / 3)),
                h = b[64] || "";
            let l = 0,
                k = 0;
            for (; l < a.length - 2; l += 3) {
                var c = a[l],
                    d = a[l + 1],
                    e = a[l + 2],
                    f = b[c >> 2];
                c = b[(c & 3) << 4 | d >> 4];
                d = b[(d & 15) << 2 | e >> 6];
                e = b[e & 63];
                g[k++] = f + c + d + e
            }
            f = 0;
            e = h;
            switch (a.length - l) {
                case 2:
                    f = a[l + 1], e = b[(f & 15) << 2] || h;
                case 1:
                    a = a[l], g[k] = b[a >> 2] + b[(a & 3) << 4 | f >> 4] + e + h
            }
            return g.join("")
        }
        for (b = ""; 10240 < a.length;) b += String.fromCharCode.apply(null, a.subarray(0, 10240)), a = a.subarray(10240);
        b += String.fromCharCode.apply(null,
            a);
        return btoa(b)
    }
    var Va = {};
    let Wa;
    var Xa = class {
        constructor(a) {
            if (Va !== Va) throw Error("illegal external caller");
            this.xa = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        }
        isEmpty() {
            return null == this.xa
        }
    };
    const Ya = Symbol();

    function Za(a, b) {
        if (Ya) return a[Ya] |= b;
        if (void 0 !== a.L) return a.L |= b;
        Object.defineProperties(a, {
            L: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        });
        return b
    }

    function $a(a, b) {
        const c = q(a);
        (c & b) !== b && (Object.isFrozen(a) && (a = Array.prototype.slice.call(a)), ab(a, c | b));
        return a
    }

    function bb(a, b) {
        Ya ? a[Ya] && (a[Ya] &= ~b) : void 0 !== a.L && (a.L &= ~b)
    }

    function q(a) {
        let b;
        Ya ? b = a[Ya] : b = a.L;
        return null == b ? 0 : b
    }

    function ab(a, b) {
        Ya ? a[Ya] = b : void 0 !== a.L ? a.L = b : Object.defineProperties(a, {
            L: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    }

    function cb(a) {
        Za(a, 1);
        return a
    }

    function db(a) {
        return !!(q(a) & 2)
    }

    function eb(a) {
        Za(a, 16);
        return a
    }

    function fb(a, b) {
        ab(b, (a | 0) & -51)
    }

    function gb(a, b) {
        ab(b, (a | 18) & -41)
    };
    var hb = {};

    function ib(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let jb;
    var kb;
    const lb = [];
    ab(lb, 23);
    kb = Object.freeze(lb);

    function mb(a) {
        if (db(a.u)) throw Error("Cannot mutate an immutable Message");
    }

    function nb(a) {
        var b = a.length;
        (b = b ? a[b - 1] : void 0) && ib(b) ? b.g = 1 : a.push({
            g: 1
        })
    };

    function ob(a) {
        const b = a.j + a.W;
        return a.H || (a.H = a.u[b] = {})
    }

    function r(a, b, c) {
        return -1 === b ? null : b >= a.j ? a.H ? a.H[b] : void 0 : c && a.H && (c = a.H[b], null != c) ? c : a.u[b + a.W]
    }

    function t(a, b, c, d) {
        mb(a);
        return x(a, b, c, d)
    }

    function x(a, b, c, d) {
        a.v && (a.v = void 0);
        if (b >= a.j || d) return ob(a)[b] = c, a;
        a.u[b + a.W] = c;
        (c = a.H) && b in c && delete c[b];
        return a
    }

    function pb(a, b, c, d, e) {
        let f = r(a, b, d);
        Array.isArray(f) || (f = kb);
        const g = q(f);
        g & 1 || cb(f);
        if (e) g & 2 || Za(f, 2), c & 1 || Object.freeze(f);
        else {
            e = !(c & 2);
            const h = g & 2;
            c & 1 || !h ? e && g & 16 && !h && bb(f, 16) : (f = cb(Array.prototype.slice.call(f)), x(a, b, f, d))
        }
        return f
    }

    function qb(a, b, c = !1) {
        return pb(a, b, 0, c, db(a.u))
    }

    function rb(a, b) {
        a = r(a, b);
        return null == a ? a : !!a
    }

    function sb(a, b) {
        const c = db(a.u);
        let d = pb(a, b, 1, !1, c);
        const e = q(d);
        if (!(e & 4)) {
            Object.isFrozen(d) && (d = cb(d.slice()), x(a, b, d, !1));
            let f = 0,
                g = 0;
            for (; f < d.length; f++) {
                const h = d[f];
                null != h && (d[g++] = h)
            }
            g < f && (d.length = g);
            Za(d, 5);
            c && (Za(d, 2), Object.freeze(d))
        }!c && (e & 2 || Object.isFrozen(d)) && (d = Array.prototype.slice.call(d), Za(d, 5), tb(a, b, d, !1));
        return d
    }

    function tb(a, b, c, d) {
        c = null == c ? kb : $a(c, 1);
        return t(a, b, c, d)
    }

    function z(a, b, c, d) {
        mb(a);
        c !== d ? x(a, b, c) : x(a, b, void 0, !1);
        return a
    }

    function ub(a, b, c, d) {
        mb(a);
        (c = vb(a, c)) && c !== b && null != d && x(a, c, void 0, !1);
        return x(a, b, d)
    }

    function wb(a, b, c) {
        return vb(a, b) === c ? c : -1
    }

    function vb(a, b) {
        let c = 0;
        for (let d = 0; d < b.length; d++) {
            const e = b[d];
            null != r(a, e) && (0 !== c && x(a, c, void 0, !1), c = e)
        }
        return c
    }

    function xb(a, b, c, d) {
        const e = r(a, c, d); {
            let g = !1;
            var f = null == e || "object" !== typeof e || (g = Array.isArray(e)) || e.ua !== hb ? g ? new b(e) : void 0 : e
        }
        f !== e && null != f && (x(a, c, f, d), Za(f.u, q(a.u) & 18));
        return f
    }

    function A(a, b, c) {
        b = xb(a, b, c, !1);
        if (null == b) return b;
        if (!db(a.u)) {
            const d = yb(b);
            d !== b && (b = d, x(a, c, b, !1))
        }
        return b
    }

    function zb(a, b, c, d, e) {
        a.h || (a.h = {});
        var f = a.h[c],
            g = pb(a, c, 3, void 0, e);
        if (!f) {
            var h = g;
            f = [];
            var l = !!(q(a.u) & 16);
            g = db(h);
            const v = h;
            !e && g && (h = Array.prototype.slice.call(h));
            var k = g;
            let y = 0;
            for (; y < h.length; y++) {
                var m = h[y];
                m = Array.isArray(m) ? new b(m) : void 0;
                if (void 0 === m) continue;
                var u = m.u;
                const w = q(u);
                let C = w;
                g && (C |= 2);
                l && (C |= 16);
                C != w && ab(u, C);
                u = C;
                k = k || !!(2 & u);
                f.push(m)
            }
            a.h[c] = f;
            l = q(h);
            b = l | 33;
            b = k ? b & -9 : b | 8;
            l != b && (k = h, Object.isFrozen(k) && (k = Array.prototype.slice.call(k)), ab(k, b), h = k);
            v !== h && x(a, c, h);
            (e ||
                d && g) && Za(f, 2);
            d && Object.freeze(f);
            return f
        }
        e || (e = Object.isFrozen(f), d && !e ? Object.freeze(f) : !d && e && (f = Array.prototype.slice.call(f), a.h[c] = f));
        return f
    }

    function B(a, b, c) {
        var d = db(a.u);
        b = zb(a, b, c, d, d);
        a = pb(a, c, 3, void 0, d);
        if (!(d || q(a) & 8)) {
            for (d = 0; d < b.length; d++) {
                c = b[d];
                const e = yb(c);
                c !== e && (b[d] = e, a[d] = e.u)
            }
            Za(a, 8)
        }
        return b
    }

    function Ab(a, b, c) {
        mb(a);
        null == c && (c = void 0);
        return x(a, b, c)
    }

    function Bb(a, b, c, d) {
        mb(a);
        null == d && (d = void 0);
        return ub(a, b, c, d)
    }

    function Cb(a, b, c, d) {
        mb(a);
        let e = null == c ? kb : cb([]);
        if (null != c) {
            let f = !!c.length;
            for (let g = 0; g < c.length; g++) {
                const h = c[g];
                f = f && !db(h.u);
                e[g] = h.u
            }
            e = $a(e, (f ? 8 : 0) | 1);
            a.h || (a.h = {});
            a.h[b] = c
        } else a.h && (a.h[b] = void 0);
        return x(a, b, e, d)
    }

    function Db(a, b) {
        a = r(a, b);
        return null == a ? 0 : a
    }

    function Eb(a, b) {
        a = r(a, b);
        return null == a ? 0 : a
    }

    function Fb(a, b) {
        return null == a ? b : a
    }

    function D(a, b) {
        return Fb(r(a, b), "")
    }

    function E(a, b, c = !1) {
        return Fb(rb(a, b), c)
    }

    function Gb(a, b) {
        const c = r(a, b);
        var d = null == c ? c : "number" === typeof c || "NaN" === c || "Infinity" === c || "-Infinity" === c ? Number(c) : void 0;
        null != d && d !== c && x(a, b, d);
        return Fb(d, 0)
    }

    function F(a, b) {
        return Fb(r(a, b), 0)
    }

    function Hb(a, b, c, d) {
        return A(a, b, wb(a, d, c))
    };
    let Ib;

    function Jb(a, b) {
        Ib = b;
        a = new a(b);
        Ib = void 0;
        return a
    };

    function Kb(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "object":
                if (a)
                    if (Array.isArray(a)) {
                        if (0 !== (q(a) & 128)) return a = Array.prototype.slice.call(a), nb(a), a
                    } else {
                        if (Ra && null != a && a instanceof Uint8Array) return Ta(a);
                        if (a instanceof Xa) {
                            const b = a.xa;
                            return null == b ? "" : "string" === typeof b ? b : a.xa = Ta(b)
                        }
                    }
        }
        return a
    };

    function Lb(a, b, c, d) {
        if (null != a) {
            if (Array.isArray(a)) a = Mb(a, b, c, void 0 !== d);
            else if (ib(a)) {
                const e = {};
                for (let f in a) Object.prototype.hasOwnProperty.call(a, f) && (e[f] = Lb(a[f], b, c, d));
                a = e
            } else a = b(a, d);
            return a
        }
    }

    function Mb(a, b, c, d) {
        const e = q(a);
        d = d ? !!(e & 16) : void 0;
        a = Array.prototype.slice.call(a);
        for (let f = 0; f < a.length; f++) a[f] = Lb(a[f], b, c, d);
        c(e, a);
        return a
    }

    function Nb(a) {
        return a.ua === hb ? a.toJSON() : Kb(a)
    }

    function Ob(a, b) {
        a & 128 && nb(b)
    };

    function Pb(a, b, c = gb) {
        if (null != a) {
            if (Ra && a instanceof Uint8Array) return a.length ? new Xa(new Uint8Array(a)) : Wa || (Wa = new Xa(null));
            if (Array.isArray(a)) {
                const d = q(a);
                if (d & 2) return a;
                if (b && !(d & 32) && (d & 16 || 0 === d)) return ab(a, d | 2), a;
                a = Mb(a, Pb, d & 4 ? gb : c, !0);
                b = q(a);
                b & 4 && b & 2 && Object.freeze(a);
                return a
            }
            return a.ua === hb ? Qb(a) : a
        }
    }

    function Rb(a, b, c, d, e, f, g) {
        (a = a.h && a.h[c]) ? (d = q(a), d & 2 ? d = a : (f = Da(a, Qb), gb(d, f), Object.freeze(f), d = f), Cb(b, c, d, e)) : t(b, c, Pb(d, f, g), e)
    }

    function Qb(a) {
        if (db(a.u)) return a;
        a = Sb(a, !0);
        Za(a.u, 2);
        return a
    }

    function Sb(a, b) {
        const c = a.u;
        var d = eb([]),
            e = a.constructor.messageId;
        e && d.push(e);
        e = a.H;
        if (e) {
            d.length = c.length;
            d.fill(void 0, d.length, c.length);
            var f = {};
            d[d.length - 1] = f
        }
        0 !== (q(c) & 128) && nb(d);
        b = b || db(a.u) ? gb : fb;
        d = Jb(a.constructor, d);
        a.Na && (d.Na = a.Na.slice());
        f = !!(q(c) & 16);
        const g = e ? c.length - 1 : c.length;
        for (let h = 0; h < g; h++) Rb(a, d, h - a.W, c[h], !1, f, b);
        if (e)
            for (const h in e) Rb(a, d, +h, e[h], !0, f, b);
        return d
    }

    function yb(a) {
        if (!db(a.u)) return a;
        const b = Sb(a, !1);
        b.v = a;
        return b
    };
    var G = class {
        constructor(a, b, c) {
            null == a && (a = Ib);
            Ib = void 0;
            var d = this.constructor.h || 0,
                e = 0 < d,
                f = this.constructor.messageId,
                g = !1;
            if (null == a) {
                a = f ? [f] : [];
                var h = 48;
                var l = !0;
                e && (d = 0, h |= 128);
                ab(a, h)
            } else {
                if (!Array.isArray(a)) throw Error();
                if (f && f !== a[0]) throw Error();
                let k = h = Za(a, 0);
                if (l = 0 !== (16 & k))(g = 0 !== (32 & k)) || (k |= 32);
                if (e)
                    if (128 & k) d = 0;
                    else {
                        if (0 < a.length) {
                            const m = a[a.length - 1];
                            if (ib(m) && "g" in m) {
                                d = 0;
                                k |= 128;
                                delete m.g;
                                let u = !0;
                                for (let v in m) {
                                    u = !1;
                                    break
                                }
                                u && a.pop()
                            }
                        }
                    }
                else if (128 & k) throw Error();
                h !== k && ab(a,
                    k)
            }
            this.W = (f ? 0 : -1) - d;
            this.h = void 0;
            this.u = a;
            a: {
                f = this.u.length;d = f - 1;
                if (f && (f = this.u[d], ib(f))) {
                    this.H = f;
                    this.j = d - this.W;
                    break a
                }
                void 0 !== b && -1 < b ? (this.j = Math.max(b, d + 1 - this.W), this.H = void 0) : this.j = Number.MAX_VALUE
            }
            if (!e && this.H && "g" in this.H) throw Error('Unexpected "g" flag in sparse object of message that is not a group type.');
            if (c) {
                b = l && !g && !0;
                e = this.j;
                let k;
                for (l = 0; l < c.length; l++) g = c[l], g < e ? (g += this.W, (d = a[g]) ? Tb(d, b) : a[g] = kb) : (k || (k = ob(this)), (d = k[g]) ? Tb(d, b) : k[g] = kb)
            }
        }
        toJSON() {
            const a = this.u;
            return jb ? a : Mb(a, Nb, Ob)
        }
    };

    function Tb(a, b) {
        if (Array.isArray(a)) {
            var c = q(a),
                d = 1;
            !b || c & 2 || (d |= 16);
            (c & d) !== d && ab(a, c | d)
        }
    }
    G.prototype.ua = hb;

    function Ub(a, b) {
        return Kb(b)
    };
    const Vb = a => null !== a && void 0 !== a;
    let Wb = void 0;

    function Xb(a, b) {
        const c = Wb;
        Wb = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    };

    function Yb(a) {
        return b => {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = Jb(a, eb(b))
            }
            return b
        }
    };
    var Zb = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var ac = class extends G {
            constructor(a) {
                super(a, -1, $b)
            }
        },
        $b = [2, 3];

    function bc(a, b) {
        this.i = a === cc && b || "";
        this.h = dc
    }
    var dc = {},
        cc = {};

    function ec(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function fc(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function hc(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    };

    function ic(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    }

    function jc(a, b, c) {
        return a.removeEventListener ? (a.removeEventListener(b, c, !1), !0) : !1
    };

    function kc(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function lc(a, b) {
        for (const c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function mc(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function nc(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    };
    var oc;

    function pc() {
        if (void 0 === oc) {
            var a = null,
                b = n.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: na,
                        createScript: na,
                        createScriptURL: na
                    })
                } catch (c) {
                    n.console && n.console.error(c.message)
                }
                oc = a
            } else oc = a
        }
        return oc
    };
    const qc = {};
    class rc {
        constructor(a, b) {
            this.h = b === qc ? a : ""
        }
        toString() {
            return this.h.toString()
        }
    };
    var tc = class {
        constructor(a, b) {
            this.h = b === sc ? a : ""
        }
        toString() {
            return this.h + ""
        }
    };

    function uc(a, b) {
        a = vc.exec(wc(a).toString());
        var c = a[3] || "";
        return xc(a[1] + yc("?", a[2] || "", b) + yc("#", c))
    }

    function wc(a) {
        return a instanceof tc && a.constructor === tc ? a.h : "type_error:TrustedResourceUrl"
    }
    var vc = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        sc = {};

    function xc(a) {
        const b = pc();
        a = b ? b.createScriptURL(a) : a;
        return new tc(a, sc)
    }

    function yc(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };

    function zc(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };

    function Ac(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!ca(f) || da(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (da(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                za(g ? Ia(f) : f, d)
            }
        }
    }

    function Bc(a) {
        this.h = a || n.document || document
    }
    Bc.prototype.getElementsByTagName = function(a, b) {
        return (b || this.h).getElementsByTagName(String(a))
    };
    Bc.prototype.createElement = function(a) {
        var b = this.h;
        a = String(a);
        "application/xhtml+xml" === b.contentType && (a = a.toLowerCase());
        return b.createElement(a)
    };
    Bc.prototype.createTextNode = function(a) {
        return this.h.createTextNode(String(a))
    };
    Bc.prototype.append = function(a, b) {
        Ac(9 == a.nodeType ? a : a.ownerDocument || a.document, a, arguments)
    };
    Bc.prototype.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function Cc() {
        return !Dc() && (p("iPod") || p("iPhone") || p("Android") || p("IEMobile"))
    }

    function Dc() {
        return p("iPad") || p("Android") && !p("Mobile") || p("Silk")
    };
    var Ec = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Fc = /#|$/;

    function Gc(a, b) {
        var c = a.search(Fc);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function Hc(a) {
        try {
            var b;
            if (b = !!a && null != a.location.href) a: {
                try {
                    Ka(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch {
            return !1
        }
    }

    function Ic(a) {
        return Hc(a.top) ? a.top : null
    }

    function Jc(a, b) {
        const c = Kc("SCRIPT", a);
        c.src = wc(b);
        (b = (b = (c.ownerDocument && c.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && c.setAttribute("nonce", b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    }

    function Lc(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function Mc(a, b) {
        if (!Nc() && !Oc()) {
            let c = Math.random();
            if (c < b) return c = Pc(), a[Math.floor(c * a.length)]
        }
        return null
    }

    function Pc() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function H(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Qc(a) {
        const b = a.length;
        if (0 == b) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    }
    var Oc = fc(() => Ea(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], Rc) || 1E-4 > Math.random()),
        Nc = fc(() => -1 != ta().indexOf("MSIE"));
    const Rc = a => -1 != ta().indexOf(a);
    var Sc = /^([0-9.]+)px$/,
        Tc = /^(-?[0-9.]{1,30})$/;

    function Uc(a) {
        if (!Tc.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function I(a) {
        return (a = Sc.exec(a)) ? +a[1] : null
    }
    var Vc = (a, b) => {
            for (let e = 0; 50 > e; ++e) {
                try {
                    var c = !(!a.frames || !a.frames[b])
                } catch {
                    c = !1
                }
                if (c) return a;
                a: {
                    try {
                        const f = a.parent;
                        if (f && f != a) {
                            var d = f;
                            break a
                        }
                    } catch {}
                    d = null
                }
                if (!(a = d)) break
            }
            return null
        },
        Wc = fc(() => Cc() ? 2 : Dc() ? 1 : 0),
        Xc = (a, b) => {
            H(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        };
    let Yc = [];
    const Zc = () => {
        const a = Yc;
        Yc = [];
        for (const b of a) try {
            b()
        } catch {}
    };

    function $c(a, b) {
        if (a.length && b.head)
            for (const c of a) a: {
                a = c;
                if (!a || !b.head) break a;
                const d = Kc("META");b.head.appendChild(d);d.httpEquiv = "origin-trial";d.content = a
            }
    }
    var ad = a => {
            if ("number" !== typeof a.goog_pvsid) try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: Math.floor(Math.random() * 2 ** 52),
                    configurable: !1
                })
            } catch (b) {}
            return Number(a.goog_pvsid) || -1
        },
        cd = a => {
            var b = bd;
            "complete" === b.readyState || "interactive" === b.readyState ? (Yc.push(a), 1 == Yc.length && (window.Promise ? Promise.resolve().then(Zc) : window.setImmediate ? setImmediate(Zc) : setTimeout(Zc, 0))) : b.addEventListener("DOMContentLoaded", a)
        };

    function Kc(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function dd(a, b, c = null, d = !1, e = !1) {
        fd(a, b, c, d, e)
    }

    function fd(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = Kc("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    const l = ya(h, f);
                    0 <= l && Array.prototype.splice.call(h, l, 1)
                }
                jc(f, "load", g);
                jc(f, "error", g)
            };
            ic(f, "load", g);
            ic(f, "error", g)
        }
        e && (f.attributionsrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var hd = (a, b) => {
            let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
            H(a, (d, e) => {
                d && (c += `&${e}=${encodeURIComponent(d)}`)
            });
            gd(c)
        },
        gd = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : dd(b, a, void 0, !1, !1)
        };
    let id = null;
    var bd = document,
        J = window;
    let jd = null;
    var kd = (a, b = []) => {
        let c = !1;
        n.google_logging_queue || (c = !0, n.google_logging_queue = []);
        n.google_logging_queue.push([a, b]);
        if (a = c) {
            if (null == jd) {
                jd = !1;
                try {
                    var d = Ic(n);
                    d && -1 !== d.location.hash.indexOf("google_logging") && (jd = !0);
                    n.localStorage.getItem("google_logging") && (jd = !0)
                } catch (e) {}
            }
            a = jd
        }
        a && (d = n.document, a = new bc(cc, "https://pagead2.googlesyndication.com/pagead/js/logging_library.js"), a = xc(a instanceof bc && a.constructor === bc && a.h === dc ? a.i : "type_error:Const"), Jc(d, a))
    };

    function ld(a = n) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function md(a = ld()) {
        return a ? Hc(a.master) ? a.master : null : null
    };

    function nd(a, ...b) {
        if (0 === b.length) return xc(a[0]);
        const c = [a[0]];
        for (let d = 0; d < b.length; d++) c.push(encodeURIComponent(b[d])), c.push(a[d + 1]);
        return xc(c.join(""))
    };

    function od(a) {
        a = a[0];
        const b = pc();
        a = b ? b.createScript(a) : a;
        return new rc(a, qc)
    };
    var pd = a => {
            a = md(ld(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1;
            return a.google_unique_id
        },
        qd = a => {
            a = a.google_unique_id;
            return "number" === typeof a ? a : 0
        },
        rd = () => {
            if (!J) return !1;
            try {
                return !(!J.navigator.standalone && !J.top.navigator.standalone)
            } catch (a) {
                return !1
            }
        },
        sd = a => {
            if (!a) return "";
            a = a.toLowerCase();
            "ca-" != a.substring(0, 3) && (a = "ca-" + a);
            return a
        };
    class td {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    }
    var ud = a => !!(a.error && a.meta && a.id);
    const vd = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var wd = class {
            constructor(a, b) {
                this.h = a;
                this.i = b
            }
        },
        xd = class {
            constructor(a, b, c) {
                this.url = a;
                this.s = b;
                this.Oa = !!c;
                this.depth = null
            }
        };

    function yd(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function zd(a, b, c, d, e) {
        const f = [];
        H(a, function(g, h) {
            (g = Ad(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function Ad(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(Ad(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(zd(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Bd(a) {
        let b = 1;
        for (const c in a.i) b = c.length > b ? c.length : b;
        return 3997 - b - a.j.length - 1
    }

    function Cd(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = Bd(a) - b.length;
        if (0 > d) return "";
        a.h.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.h.length; f++) {
            const g = a.h[f],
                h = a.i[g];
            for (let l = 0; l < h.length; l++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let k = zd(h[l], a.j, ",$");
                if (k) {
                    k = e + k;
                    if (d >= k.length) {
                        d -= k.length;
                        c += k;
                        e = a.j;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class Dd {
        constructor() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.h = []
        }
    };

    function Ed(a, b) {
        0 <= b && 1 >= b && (a.h = b)
    }

    function Fd(a, b, c, d = !1, e) {
        if ((d ? a.h : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Dd ? f = c : (f = new Dd, H(c, (h, l) => {
                var k = f;
                const m = k.l++;
                h = yd(l, h);
                k.h.push(m);
                k.i[m] = h
            }));
            const g = Cd(f, "/pagead/gen_204?id=" + b + "&");
            g && dd(n, g)
        } catch (f) {}
    }
    class Gd {
        constructor() {
            this.h = Math.random()
        }
    };
    let Hd = null;

    function Id() {
        if (null === Hd) {
            Hd = "";
            try {
                let a = "";
                try {
                    a = n.top.location.hash
                } catch (b) {
                    a = n.location.hash
                }
                if (a) {
                    const b = a.match(/\bdeid=([\d,]+)/);
                    Hd = b ? b[1] : ""
                }
            } catch (a) {}
        }
        return Hd
    };

    function Jd() {
        const a = n.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Kd() {
        const a = n.performance;
        return a && a.now ? a.now() : null
    };
    class Ld {
        constructor(a, b) {
            var c = Kd() || Jd();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.uniqueId = Math.random();
            this.taskId = this.slotId = void 0
        }
    };
    const Md = n.performance,
        Nd = !!(Md && Md.mark && Md.measure && Md.clearMarks),
        Od = fc(() => {
            var a;
            if (a = Nd) a = Id(), a = !!a.indexOf && 0 <= a.indexOf("1337");
            return a
        });

    function Pd(a) {
        a && Md && Od() && (Md.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Md.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Qd(a) {
        a.h = !1;
        a.i != a.j.google_js_reporting_queue && (Od() && za(a.i, Pd), a.i.length = 0)
    }
    class Rd {
        constructor(a) {
            this.i = [];
            this.j = a || n;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.h = Od() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.h) return null;
            a = new Ld(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Md && Od() && Md.mark(b);
            return a
        }
        end(a) {
            if (this.h && "number" === typeof a.value) {
                a.duration = (Kd() || Jd()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Md && Od() && Md.mark(b);
                !this.h || 2048 < this.i.length ||
                    this.i.push(a)
            }
        }
    };

    function Sd(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        if (a.stack) {
            a = a.stack;
            var c = b;
            try {
                -1 == a.indexOf(c) && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n")
            } catch (d) {
                b = c
            }
        }
        return b
    }
    class Td {
        constructor(a, b = null) {
            this.A = a;
            this.h = null;
            this.m = this.I;
            this.i = b;
            this.j = !1
        }
        Sa(a) {
            this.m = a
        }
        wa(a) {
            this.h = a
        }
        l(a) {
            this.j = a
        }
        ia(a, b, c) {
            let d, e;
            try {
                this.i && this.i.h ? (e = this.i.start(a.toString(), 3), d = b(), this.i.end(e)) : d = b()
            } catch (f) {
                b = !0;
                try {
                    Pd(e), b = this.m(a, new td(f, {
                        message: Sd(f)
                    }), void 0, c)
                } catch (g) {
                    this.I(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        va(a, b) {
            return (...c) => this.ia(a, () => b.apply(void 0, c))
        }
        I(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const Ja = new Dd;
                var g = Ja;
                g.h.push(1);
                g.i[1] = yd("context", a);
                ud(b) || (b = new td(b, {
                    message: Sd(b)
                }));
                if (b.msg) {
                    g = Ja;
                    var h = b.msg.substring(0, 512);
                    g.h.push(2);
                    g.i[2] = yd("msg", h)
                }
                var l = b.meta || {};
                b = l;
                if (this.h) try {
                    this.h(b)
                } catch (Ua) {}
                if (d) try {
                    d(b)
                } catch (Ua) {}
                d = Ja;
                l = [l];
                d.h.push(3);
                d.i[3] = l;
                d = n;
                l = [];
                b = null;
                do {
                    var k = d;
                    if (Hc(k)) {
                        var m = k.location.href;
                        b = k.document && k.document.referrer || null
                    } else m = b, b = null;
                    l.push(new xd(m || "", k));
                    try {
                        d = k.parent
                    } catch (Ua) {
                        d = null
                    }
                } while (d && k != d);
                for (let Ua = 0, of = l.length - 1; Ua <= of ; ++Ua) l[Ua].depth = of -Ua;
                k = n;
                if (k.location &&
                    k.location.ancestorOrigins && k.location.ancestorOrigins.length == l.length - 1)
                    for (m = 1; m < l.length; ++m) {
                        var u = l[m];
                        u.url || (u.url = k.location.ancestorOrigins[m - 1] || "", u.Oa = !0)
                    }
                var v = l;
                let gc = new xd(n.location.href, n, !1);
                k = null;
                const ed = v.length - 1;
                for (u = ed; 0 <= u; --u) {
                    var y = v[u];
                    !k && vd.test(y.url) && (k = y);
                    if (y.url && !y.Oa) {
                        gc = y;
                        break
                    }
                }
                y = null;
                const Zi = v.length && v[ed].url;
                0 != gc.depth && Zi && (y = v[ed]);
                f = new wd(gc, y);
                if (f.i) {
                    v = Ja;
                    var w = f.i.url || "";
                    v.h.push(4);
                    v.i[4] = yd("top", w)
                }
                var C = {
                    url: f.h.url || ""
                };
                if (f.h.url) {
                    var Ba =
                        f.h.url.match(Ec),
                        T = Ba[1],
                        Ca = Ba[3],
                        sa = Ba[4];
                    w = "";
                    T && (w += T + ":");
                    Ca && (w += "//", w += Ca, sa && (w += ":" + sa));
                    var pf = w
                } else pf = "";
                T = Ja;
                C = [C, {
                    url: pf
                }];
                T.h.push(5);
                T.i[5] = C;
                Fd(this.A, e, Ja, this.j, c)
            } catch (Ja) {
                try {
                    Fd(this.A, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Sd(Ja),
                        url: f && f.h.url
                    }, this.j, c)
                } catch (gc) {}
            }
            return !0
        }
        ca(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.I(a, c instanceof Error ? c : Error(c), void 0, this.h || void 0)
            })
        }
    };
    var Ud = a => "string" === typeof a,
        Vd = a => void 0 === a;
    var Xd = class extends G {
            constructor(a) {
                super(a, -1, Wd)
            }
        },
        Wd = [2, 8],
        Yd = [3, 4, 5],
        Zd = [6, 7];

    function $d(a) {
        return null != a ? !a : a
    }

    function ae(a, b) {
        let c = !1;
        for (let d = 0; d < a.length; d++) {
            const e = a[d]();
            if (e === b) return e;
            null == e && (c = !0)
        }
        if (!c) return !b
    }

    function be(a, b) {
        var c = B(a, Xd, 2);
        if (!c.length) return ce(a, b);
        a = F(a, 1);
        if (1 === a) return $d(be(c[0], b));
        c = Da(c, d => () => be(d, b));
        switch (a) {
            case 2:
                return ae(c, !1);
            case 3:
                return ae(c, !0)
        }
    }

    function ce(a, b) {
        const c = vb(a, Yd);
        a: {
            switch (c) {
                case 3:
                    var d = F(a, wb(a, Yd, 3));
                    break a;
                case 4:
                    d = F(a, wb(a, Yd, 4));
                    break a;
                case 5:
                    d = F(a, wb(a, Yd, 5));
                    break a
            }
            d = void 0
        }
        if (d && (b = (b = b[c]) && b[d])) {
            try {
                var e = b(...sb(a, 8))
            } catch (f) {
                return
            }
            b = F(a, 1);
            if (4 === b) return !!e;
            if (5 === b) return null != e;
            if (12 === b) a = D(a, wb(a, Zd, 7));
            else a: {
                switch (c) {
                    case 4:
                        a = Gb(a, wb(a, Zd, 6));
                        break a;
                    case 5:
                        a = D(a, wb(a, Zd, 7));
                        break a
                }
                a = void 0
            }
            if (null != a) {
                if (6 === b) return e === a;
                if (9 === b) return null != e && 0 === qa(String(e), a);
                if (null != e) switch (b) {
                    case 7:
                        return e <
                            a;
                    case 8:
                        return e > a;
                    case 12:
                        return Ud(a) && Ud(e) && (new RegExp(a)).test(e);
                    case 10:
                        return null != e && -1 === qa(String(e), a);
                    case 11:
                        return null != e && 1 === qa(String(e), a)
                }
            }
        }
    }

    function de(a, b) {
        return !a || !(!b || !be(a, b))
    };
    var fe = class extends G {
            constructor(a) {
                super(a, -1, ee)
            }
        },
        ee = [4];
    var ge = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var ie = class extends G {
            constructor(a) {
                super(a, -1, he)
            }
        },
        je = Yb(ie),
        he = [5],
        ke = [1, 2, 3, 6, 7];
    var me = class extends G {
            constructor() {
                super(void 0, -1, le)
            }
        },
        le = [2];

    function ne(a, b) {
        return t(a, 1, b)
    }
    var oe = class extends G {
        constructor() {
            super()
        }
    };

    function pe(a, b) {
        return z(a, 1, b, 0)
    }

    function qe(a, b) {
        return z(a, 2, b, 0)
    }
    var re = class extends G {
        constructor() {
            super()
        }
        getWidth() {
            return Fb(r(this, 1), 0)
        }
        getHeight() {
            return Fb(r(this, 2), 0)
        }
    };

    function se(a, b) {
        return Ab(a, 1, b)
    }

    function te(a, b) {
        return Ab(a, 2, b)
    }

    function ue(a, b) {
        Ab(a, 3, b)
    }
    var ve = class extends G {
        constructor() {
            super()
        }
    };
    var we = class extends G {
        constructor() {
            super()
        }
    };

    function xe(a, b) {
        return Bb(a, 4, ye, b)
    }
    var ze = class extends G {
            constructor() {
                super()
            }
        },
        ye = [4, 5, 6, 8, 9, 10];

    function Ae(a, b) {
        return z(a, 1, b, 0)
    }

    function Be(a, b) {
        return z(a, 2, b, 0)
    }
    var Ce = class extends G {
        constructor() {
            super()
        }
    };
    var De = class extends G {
            constructor() {
                super()
            }
        },
        Ee = [1, 2];

    function Fe(a, b) {
        return Ab(a, 1, b)
    }

    function Ge(a, b) {
        return Cb(a, 2, b)
    }

    function He(a, b) {
        return tb(a, 4, b)
    }

    function Ie(a, b) {
        return Cb(a, 5, b)
    }

    function Je(a, b) {
        return z(a, 6, b, 0)
    }
    var Le = class extends G {
            constructor() {
                super(void 0, -1, Ke)
            }
        },
        Ke = [2, 4, 5];
    var Ne = class extends G {
            constructor() {
                super(void 0, -1, Me)
            }
        },
        Me = [5],
        Oe = [1, 2, 3, 4];
    var Qe = class extends G {
            constructor() {
                super(void 0, -1, Pe)
            }
        },
        Pe = [2, 3];

    function Re(a, b) {
        return Bb(a, 4, Se, b)
    }
    var Te = class extends G {
            constructor() {
                super()
            }
            getTagSessionCorrelator() {
                return Fb(r(this, 2), 0)
            }
        },
        Se = [4, 5, 7];

    function Ue(a, ...b) {
        Ve(a, ...b.map(c => ({
            Va: 4,
            message: c
        })))
    }

    function We(a, ...b) {
        Ve(a, ...b.map(c => ({
            Va: 7,
            message: c
        })))
    };

    function Xe(a) {
        return JSON.stringify([a.map(b => [{
            [b.Va]: b.message.toJSON()
        }])])
    };
    var Ye = (a, b) => {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function Ze() {
        this.A = this.A;
        this.j = this.j
    }
    Ze.prototype.A = !1;

    function $e(a) {
        a.A || (a.A = !0, a.h())
    }

    function af(a, b) {
        a.A ? b() : (a.j || (a.j = []), a.j.push(b))
    }
    Ze.prototype.h = function() {
        if (this.j)
            for (; this.j.length;) this.j.shift()()
    };

    function bf(a, b, c, d) {
        ic(b, c, d);
        af(a, () => jc(b, c, d))
    }

    function cf(a, b) {
        1 !== a.state && (a.state = 1, a.callback && a.callback(b))
    }

    function df(a) {
        a.s.document.visibilityState ? bf(a, a.s.document, "visibilitychange", b => {
            "hidden" === a.s.document.visibilityState && cf(a, b);
            "visible" === a.s.document.visibilityState && (a.state = 0)
        }) : "onpagehide" in a.s ? (bf(a, a.s, "pagehide", b => {
            cf(a, b)
        }), bf(a, a.s, "pageshow", () => {
            a.state = 0
        })) : bf(a, a.s, "beforeunload", b => {
            cf(a, b)
        })
    }

    function ef(a, b) {
        a.callback || df(a);
        a.callback = b
    }
    var ff = class extends Ze {
        constructor(a) {
            super();
            this.s = a;
            this.state = 0;
            this.callback = null
        }
    };

    function Ve(a, ...b) {
        a.A && 65536 <= Xe(a.h.concat(b)).length && gf(a);
        a.h.push(...b);
        a.h.length >= a.m && gf(a);
        a.h.length && null === a.i && (a.i = setTimeout(() => {
            gf(a)
        }, a.B))
    }

    function hf(a, b, c, d) {
        a.j || (a.j = new ff(b), ef(a.j, () => {
            for (const e of a.l) e();
            c()
        }));
        d && 1 !== a.j.state && a.l.push(d)
    }

    function gf(a) {
        null !== a.i && (clearTimeout(a.i), a.i = null);
        if (a.h.length) {
            var b = Xe(a.h);
            a.v("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.h = []
        }
    }

    function jf(a, b, c) {
        hf(a, b, () => {
            gf(a)
        }, c)
    }
    var kf = class {
            constructor(a, b, c) {
                this.v = Ye;
                this.B = a;
                this.m = b;
                this.A = c;
                this.l = [];
                this.h = [];
                this.i = null
            }
        },
        lf = class extends kf {
            constructor(a = 1E3, b = 100, c = !1) {
                super(a, b, c && !0)
            }
        };

    function mf(a, b) {
        b = z(b, 1, Date.now(), 0);
        var c = ad(window);
        b = z(b, 2, c, 0);
        return z(b, 6, a.m, 0)
    }

    function nf(a, b, c, d, e, f) {
        if (a.j) {
            var g = Be(Ae(new Ce, b), c);
            b = Je(Ge(Fe(Ie(He(new Le, d), e), g), a.h.slice()), f);
            b = Re(new Te, b);
            Ue(a.i, mf(a, b));
            if (1 === f || 3 === f || 4 === f && !a.h.some(h => F(h, 1) === F(g, 1) && F(h, 2) === c)) a.h.push(g), 100 < a.h.length && a.h.shift()
        }
    }

    function qf(a, b, c, d) {
        if (a.j && a.l) {
            var e = new Qe;
            b = Cb(e, 2, b);
            c = Cb(b, 3, c);
            d && z(c, 1, d, 0);
            d = new Te;
            d = Bb(d, 7, Se, c);
            Ue(a.i, mf(a, d))
        }
    }
    var rf = class {
        constructor(a, b, c, d = new lf(b)) {
            this.m = a;
            this.l = c;
            this.i = d;
            this.h = [];
            this.j = 0 < a && Pc() < 1 / a
        }
    };
    var K = a => {
        var b = "ta";
        if (a.ta && a.hasOwnProperty(b)) return a.ta;
        b = new a;
        return a.ta = b
    };
    var sf = class {
        constructor() {
            this.G = {
                [3]: {},
                [4]: {},
                [5]: {}
            }
        }
    };
    var tf = /^true$/.test("false");

    function uf(a, b) {
        switch (b) {
            case 1:
                return F(a, wb(a, ke, 1));
            case 2:
                return F(a, wb(a, ke, 2));
            case 3:
                return F(a, wb(a, ke, 3));
            case 6:
                return F(a, wb(a, ke, 6));
            default:
                return null
        }
    }

    function vf(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return E(a, 1);
            case 7:
                return D(a, 3);
            case 2:
                return Gb(a, 2);
            case 3:
                return D(a, 3);
            case 6:
                return sb(a, 4);
            default:
                return null
        }
    }
    const wf = fc(() => {
        if (!tf) return {};
        try {
            const a = window.sessionStorage && window.sessionStorage.getItem("GGDFSSK");
            if (a) return JSON.parse(a)
        } catch {}
        return {}
    });

    function xf(a, b, c, d = 0) {
        K(yf).j[d] = K(yf).j[d] ? .add(b) ? ? (new Set).add(b);
        const e = wf();
        if (null != e[b]) return e[b];
        b = zf(d)[b];
        if (!b) return c;
        b = je(JSON.stringify(b));
        b = Af(b);
        a = vf(b, a);
        return null != a ? a : c
    }

    function Af(a) {
        const b = K(sf).G;
        if (b) {
            const c = Ga(B(a, ge, 5), d => de(A(d, Xd, 1), b));
            if (c) return A(c, fe, 2) ? ? null
        }
        return A(a, fe, 4) ? ? null
    }
    class yf {
        constructor() {
            this.i = {};
            this.l = [];
            this.j = {};
            this.h = new Map
        }
    }

    function Bf(a, b = !1, c) {
        return !!xf(1, a, b, c)
    }

    function Cf(a, b = 0, c) {
        a = Number(xf(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function Df(a, b = "", c) {
        a = xf(3, a, b, c);
        return "string" === typeof a ? a : b
    }

    function Ef(a, b = [], c) {
        a = xf(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function zf(a) {
        return K(yf).i[a] || (K(yf).i[a] = {})
    }

    function Ff(a, b) {
        const c = zf(b);
        H(a, (d, e) => c[e] = d)
    }

    function Gf(a, b, c, d, e = !1) {
        const f = [],
            g = [];
        za(b, h => {
            const l = zf(h);
            za(a, k => {
                var m = vb(k, ke);
                const u = uf(k, m);
                if (u) {
                    var v = K(yf).h.get(h) ? .get(u) ? .slice(0) ? ? [];
                    a: {
                        const y = new Ne;
                        switch (m) {
                            case 1:
                                ub(y, 1, Oe, u);
                                break;
                            case 2:
                                ub(y, 2, Oe, u);
                                break;
                            case 3:
                                ub(y, 3, Oe, u);
                                break;
                            case 6:
                                ub(y, 4, Oe, u);
                                break;
                            default:
                                m = void 0;
                                break a
                        }
                        tb(y, 5, v);m = y
                    }
                    if (v = m) v = !!K(yf).j[h] ? .has(u);
                    v && f.push(m);
                    if (v = m) v = !!K(yf).h.get(h) ? .has(u);
                    v && g.push(m);
                    e || (m = K(yf), m.h.has(h) || m.h.set(h, new Map), m.h.get(h).has(u) || m.h.get(h).set(u, []), d &&
                        m.h.get(h).get(u).push(d));
                    l[u] = k.toJSON()
                }
            })
        });
        (f.length || g.length) && qf(c, f, g, d ? ? void 0)
    }

    function Hf(a, b) {
        const c = zf(b);
        za(a, d => {
            var e = je(JSON.stringify(d));
            const f = vb(e, ke);
            (e = uf(e, f)) && (c[e] || (c[e] = d))
        })
    }

    function If() {
        return Da(Object.keys(K(yf).i), a => Number(a))
    }

    function Jf(a) {
        Ha(K(yf).l, a) || Ff(zf(4), a)
    };

    function L(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function Kf(a, b, c) {
        return b[a] || c
    }

    function Lf(a) {
        L(5, Bf, a);
        L(6, Cf, a);
        L(7, Df, a);
        L(8, Ef, a);
        L(13, Hf, a);
        L(15, Jf, a)
    }

    function Mf(a) {
        L(4, b => {
            K(sf).G = b
        }, a);
        L(9, (b, c) => {
            var d = K(sf);
            null == d.G[3][b] && (d.G[3][b] = c)
        }, a);
        L(10, (b, c) => {
            var d = K(sf);
            null == d.G[4][b] && (d.G[4][b] = c)
        }, a);
        L(11, (b, c) => {
            var d = K(sf);
            null == d.G[5][b] && (d.G[5][b] = c)
        }, a);
        L(14, b => {
            var c = K(sf);
            for (const d of [3, 4, 5]) Object.assign(c.G[d], b[d])
        }, a)
    }

    function Nf(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };

    function Of(a, b, c) {
        a.j = Kf(1, b, () => {});
        a.l = d => Kf(2, b, () => [])(d, c);
        a.i = () => Kf(3, b, () => [])(c);
        a.h = d => {
            Kf(16, b, () => {})(d, c)
        }
    }
    class Pf {
        j() {}
        h() {}
        l() {
            return []
        }
        i() {
            return []
        }
    };
    let Qf, Rf;
    const Sf = new Rd(window);
    (a => {
        Qf = a ? ? new Gd;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        Ed(Qf, window.google_srt);
        Rf = new Td(Qf, Sf);
        Rf.wa(() => {});
        Rf.l(!0);
        "complete" == window.document.readyState ? window.google_measure_js_timing || Qd(Sf) : Sf.h && ic(window, "load", () => {
            window.google_measure_js_timing || Qd(Sf)
        })
    })();
    var Tf = {
        Lb: 0,
        Kb: 1,
        Hb: 2,
        Cb: 3,
        Ib: 4,
        Db: 5,
        Jb: 6,
        Fb: 7,
        Gb: 8,
        Bb: 9,
        Eb: 10
    };
    var Uf = {
        Nb: 0,
        Ob: 1,
        Mb: 2
    };

    function Vf(a) {
        if (0 != a.h) throw Error("Already resolved/rejected.");
    }
    var Yf = class {
        constructor() {
            this.i = new Wf(this);
            this.h = 0
        }
        resolve(a) {
            Vf(this);
            this.h = 1;
            this.l = a;
            Xf(this.i)
        }
    };

    function Xf(a) {
        switch (a.h.h) {
            case 0:
                break;
            case 1:
                a.i && a.i(a.h.l);
                break;
            case 2:
                a.j && a.j(a.h.j);
                break;
            default:
                throw Error("Unhandled deferred state.");
        }
    }
    var Wf = class {
        constructor(a) {
            this.h = a
        }
        then(a, b) {
            if (this.i) throw Error("Then functions already set.");
            this.i = a;
            this.j = b;
            Xf(this)
        }
    };
    const Zf = class {
        constructor(a) {
            this.h = a.slice(0)
        }
        forEach(a) {
            this.h.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new Zf(Aa(this.h, a))
        }
        apply(a) {
            return new Zf(a(this.h.slice(0)))
        }
        sort(a) {
            return new Zf(this.h.slice(0).sort(a))
        }
        get(a) {
            return this.h[a]
        }
        add(a) {
            const b = this.h.slice(0);
            b.push(a);
            return new Zf(b)
        }
    };

    function $f(a, b) {
        for (var c = [], d = a.length, e = 0; e < d; e++) c.push(a[e]);
        c.forEach(b, void 0)
    };
    const bg = class {
        constructor() {
            this.h = {};
            this.i = {}
        }
        set(a, b) {
            const c = ag(a);
            this.h[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = ag(a);
            return void 0 !== this.h[a] ? this.h[a] : b
        }
        clear() {
            this.h = {};
            this.i = {}
        }
    };

    function ag(a) {
        return a instanceof Object ? String(ea(a)) : a + ""
    };

    function cg(a) {
        return new dg({
            value: a
        }, null)
    }

    function eg(a) {
        return new dg(null, a)
    }

    function fg(a) {
        try {
            return cg(a())
        } catch (b) {
            return eg(b)
        }
    }

    function gg(a) {
        return null != a.h ? a.h.value : null
    }

    function hg(a, b) {
        null != a.h && b(a.h.value);
        return a
    }

    function ig(a, b) {
        null != a.h || b(a.i);
        return a
    }
    class dg {
        constructor(a, b) {
            this.h = a;
            this.i = b
        }
        map(a) {
            return null != this.h ? (a = a(this.h.value), a instanceof dg ? a : cg(a)) : this
        }
    };
    const jg = class {
        constructor(a) {
            this.h = new bg;
            if (a)
                for (var b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.h.set(a, !0)
        }
        contains(a) {
            return void 0 !== this.h.h[ag(a)]
        }
    };
    class kg {
        constructor() {
            this.h = new bg
        }
        set(a, b) {
            let c = this.h.get(a);
            c || (c = new jg, this.h.set(a, c));
            c.add(b)
        }
    };
    var M = class extends G {
            constructor(a) {
                super(a, -1, lg)
            }
            getId() {
                return r(this, 3)
            }
        },
        lg = [4];
    class mg {
        constructor({
            Xa: a,
            Pb: b,
            Xb: c,
            rb: d
        }) {
            this.h = b;
            this.l = new Zf(a || []);
            this.j = d;
            this.i = c
        }
    };
    const og = a => {
            const b = [],
                c = a.l;
            c && c.h.length && b.push({
                aa: "a",
                ga: ng(c)
            });
            null != a.h && b.push({
                aa: "as",
                ga: a.h
            });
            null != a.i && b.push({
                aa: "i",
                ga: String(a.i)
            });
            null != a.j && b.push({
                aa: "rp",
                ga: String(a.j)
            });
            b.sort(function(d, e) {
                return d.aa.localeCompare(e.aa)
            });
            b.unshift({
                aa: "t",
                ga: "aa"
            });
            return b
        },
        ng = a => {
            a = a.h.slice(0).map(pg);
            a = JSON.stringify(a);
            return Qc(a)
        },
        pg = a => {
            const b = {};
            null != r(a, 7) && (b.q = r(a, 7));
            null != r(a, 2) && (b.o = r(a, 2));
            null != r(a, 5) && (b.p = r(a, 5));
            return b
        };
    var qg = class extends G {
        constructor(a) {
            super(a)
        }
        setLocation(a) {
            return t(this, 1, a)
        }
    };

    function rg(a) {
        const b = [].slice.call(arguments).filter(ec(e => null === e));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Ma || []);
            d = Object.assign(d, e.Ra)
        });
        return new sg(c, d)
    }

    function tg(a) {
        switch (a) {
            case 1:
                return new sg(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new sg(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new sg(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new sg(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function ug(a) {
        if (null == a) var b = null;
        else {
            var c = og(a);
            a = [];
            for (b of c) c = String(b.ga), a.push(b.aa + "." + (20 >= c.length ? c : c.slice(0, 19) + "_"));
            b = new sg(null, {
                google_placement_id: a.join("~")
            })
        }
        return b
    }
    class sg {
        constructor(a, b) {
            this.Ma = a;
            this.Ra = b
        }
    };
    const vg = new sg(["google-auto-placed"], {
        google_reactive_ad_format: 40,
        google_tag_origin: "qs"
    });
    var wg = {
        overlays: 1,
        interstitials: 2,
        vignettes: 2,
        inserts: 3,
        immersives: 4,
        list_view: 5,
        full_page: 6,
        side_rails: 7
    };

    function xg(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map)) : a.google_reactive_ads_global_state = new yg;
        return a.google_reactive_ads_global_state
    }
    class yg {
        constructor() {
            this.wasPlaTagProcessed = !1;
            this.wasReactiveAdConfigReceived = {};
            this.adCount = {};
            this.wasReactiveAdVisible = {};
            this.stateForType = {};
            this.reactiveTypeEnabledInAsfe = {};
            this.wasReactiveTagRequestSent = !1;
            this.reactiveTypeDisabledByPublisher = {};
            this.tagSpecificState = {};
            this.messageValidationEnabled = !1;
            this.floatingAdsStacking = new zg;
            this.sideRailProcessedFixedElements = new Set;
            this.sideRailAvailableSpace = new Map
        }
    }
    var zg = class {
        constructor() {
            this.maxZIndexRestrictions = {};
            this.nextRestrictionId = 0;
            this.maxZIndexListeners = []
        }
    };
    var N = a => {
        a = a.document;
        let b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    };
    var Ag = a => {
            a = a.getBoundingClientRect();
            return 0 < a.width && 0 < a.height
        },
        Bg = a => {
            let b = 0;
            a.forEach(c => b = Math.max(b, c.getBoundingClientRect().width));
            return c => c.getBoundingClientRect().width > .5 * b
        },
        Cg = a => {
            const b = N(a).clientHeight || 0;
            return c => c.getBoundingClientRect().height >= .75 * b
        },
        Dg = (a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top;
    var Eg = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Fg = class extends G {
        constructor() {
            super()
        }
    };
    var Hg = class extends G {
            constructor() {
                super(void 0, -1, Gg)
            }
        },
        Gg = [1];
    var Ig = class extends G {
        constructor(a) {
            super(a)
        }
        i() {
            return E(this, 2)
        }
    };
    var Jg = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Kg = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Mg = class extends G {
            constructor(a) {
                super(a, -1, Lg)
            }
            i() {
                return B(this, Kg, 1)
            }
        },
        Lg = [1];
    var Ng = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Og = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Qg = class extends G {
            constructor(a) {
                super(a, -1, Pg)
            }
        },
        Pg = [6, 7, 9, 10, 11];

    function Rg(a) {
        var b = [];
        $f(a.getElementsByTagName("p"), function(c) {
            100 <= Sg(c) && b.push(c)
        });
        return b
    }

    function Sg(a) {
        if (3 == a.nodeType) return a.length;
        if (1 != a.nodeType || "SCRIPT" == a.tagName) return 0;
        var b = 0;
        $f(a.childNodes, function(c) {
            b += Sg(c)
        });
        return b
    }

    function Tg(a) {
        return 0 == a.length || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Ug(a, b) {
        if (null == a.h) return b;
        switch (a.h) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.h);
        }
    }
    const Vg = class {
        constructor(a, b, c, d) {
            this.l = a;
            this.i = b;
            this.j = c;
            this.h = d
        }
        query(a) {
            var b = [];
            try {
                b = a.querySelectorAll(this.l)
            } catch (f) {}
            if (!b.length) return [];
            a = Ia(b);
            a = Ug(this, a);
            "number" === typeof this.i && (b = this.i, 0 > b && (b += a.length), a = 0 <= b && b < a.length ? [a[b]] : []);
            if ("number" === typeof this.j) {
                b = [];
                for (var c = 0; c < a.length; c++) {
                    var d = Rg(a[c]),
                        e = this.j;
                    0 > e && (e += d.length);
                    0 <= e && e < d.length && b.push(d[e])
                }
                a = b
            }
            return a
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.l,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.h
            })
        }
    };

    function Wg(a) {
        if (1 != a.nodeType) var b = !1;
        else if (b = "INS" == a.tagName) a: {
            b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
            for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
            for (d = 0; d < b.length; ++d)
                if (!c[b[d]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    };
    var O = class {
            constructor(a, b = !1) {
                this.h = a;
                this.defaultValue = b
            }
        },
        Xg = class {
            constructor(a, b = 0) {
                this.h = a;
                this.defaultValue = b
            }
        },
        Yg = class {
            constructor(a, b = []) {
                this.h = a;
                this.defaultValue = b
            }
        };
    var Zg = new O(1082, !0),
        $g = new O(1214, !0),
        ah = new Xg(1130, 100),
        bh = new class {
            constructor(a, b = "") {
                this.h = a;
                this.defaultValue = b
            }
        }(14),
        ch = new O(316),
        dh = new O(1207, !0),
        eh = new O(313),
        fh = new O(369),
        gh = new O(1230),
        hh = new O(1229),
        ih = new O(1231),
        jh = new O(1171, !0),
        kh = new O(1201, !0),
        lh = new O(217),
        mh = new O(1228),
        nh = new O(1216),
        oh = new O(1215),
        ph = new O(1086, !0),
        qh = new Xg(1079, 5),
        rh = new Yg(1934, ["Az6AfRvI8mo7yiW5fLfj04W21t0ig6aMsGYpIqMTaX60H+b0DkO1uDr+7BrzMcimWzv/X7SXR8jI+uvbV0IJlwYAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==",
            "A+USTya+tNvDPaxUgJooz+LaVk5hPoAxpLvSxjogX4Mk8awCTQ9iop6zJ9d5ldgU7WmHqBlnQB41LHHRFxoaBwoAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", "A7FovoGr67TUBYbnY+Z0IKoJbbmRmB8fCyirUGHavNDtD91CiGyHHSA2hDG9r9T3NjUKFi6egL3RbgTwhhcVDwUAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="
        ]),
        sh = new O(203),
        th = new O(84),
        uh = new O(1975),
        vh = new O(1974),
        wh = new O(1162),
        xh = new O(1120),
        yh = new Xg(501545963, 1),
        zh = new O(501545960),
        Ah = new O(501545961),
        Bh = new O(45388034),
        Ch = new Xg(501545962, 1),
        Dh = new Xg(45388309, -1),
        Eh = new Xg(1114, 1),
        Fh = new Xg(1108, 1E3),
        Gh = new O(491815314),
        Hh = new O(1121),
        Ih = new O(501545959, !0),
        Jh = new O(504834127),
        Kh = new O(502896280),
        Lh = new O(1928),
        Mh = new O(1941),
        Nh = new O(370946349),
        Oh = new O(392736476),
        Ph = new Xg(406149835),
        Qh = new Yg(1932),
        Rh = new Xg(1935);
    var Sh = class {
        constructor() {
            const a = {};
            this.i = (b, c) => null != a[b] ? a[b] : c;
            this.j = (b, c) => null != a[b] ? a[b] : c;
            this.l = (b, c) => null != a[b] ? a[b] : c;
            this.h = (b, c) => null != a[b] ? a[b] : c;
            this.m = () => {}
        }
    };

    function P(a) {
        return K(Sh).i(a.h, a.defaultValue)
    }

    function Th(a) {
        return K(Sh).j(a.h, a.defaultValue)
    }

    function Uh() {
        return K(Sh).l(bh.h, bh.defaultValue)
    };

    function Vh(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && 8 == d.nodeType;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        Wg(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    };

    function Wh(a, b) {
        const c = e => {
                e = Xh(e);
                return null == e ? !1 : 0 < e
            },
            d = e => {
                e = Xh(e);
                return null == e ? !1 : 0 > e
            };
        switch (b) {
            case 0:
                return {
                    init: Yh(a.previousSibling, c),
                    ma: e => Yh(e.previousSibling, c),
                    pa: 0
                };
            case 2:
                return {
                    init: Yh(a.lastChild, c),
                    ma: e => Yh(e.previousSibling, c),
                    pa: 0
                };
            case 3:
                return {
                    init: Yh(a.nextSibling, d),
                    ma: e => Yh(e.nextSibling, d),
                    pa: 3
                };
            case 1:
                return {
                    init: Yh(a.firstChild, d),
                    ma: e => Yh(e.nextSibling, d),
                    pa: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function Xh(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function Yh(a, b) {
        return a && b(a) ? a : null
    };
    var Zh = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };
    var $h = a => {
        if (a == a.top) return 0;
        for (; a && a != a.top && Hc(a); a = a.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };
    var ai = (a, b) => {
        do {
            const c = Lc(a, b);
            if (c && "fixed" == c.position) return !1
        } while (a = a.parentElement);
        return !0
    };

    function bi(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            const f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = I(a[c[e]]);
                d = null === d ? null : Math.round(d);
                null != d && (b[f] = d)
            }
        }
    }
    var ci = (a, b) => !((Tc.test(b.google_ad_width) || Sc.test(a.style.width)) && (Tc.test(b.google_ad_height) || Sc.test(a.style.height))),
        ei = (a, b) => (a = di(a, b)) ? a.y : 0,
        di = (a, b) => {
            try {
                const c = b.document.documentElement.getBoundingClientRect(),
                    d = a.getBoundingClientRect();
                return {
                    x: d.left - c.left,
                    y: d.top - c.top
                }
            } catch (c) {
                return null
            }
        },
        fi = a => {
            let b = 0;
            for (let c in Zh) - 1 != a.indexOf(c) && (b |= Zh[c]);
            return b
        },
        gi = (a, b, c, d, e) => {
            if (a !== a.top) return Ic(a) ? 3 : 16;
            if (!(488 > N(a).clientWidth)) return 4;
            if (!(a.innerHeight >= a.innerWidth)) return 5;
            const f = N(a).clientWidth;
            if (!f || (f - c) / f > d) a = 6;
            else {
                if (c = "true" != e.google_full_width_responsive) a: {
                    c = b.parentElement;
                    for (b = N(a).clientWidth; c; c = c.parentElement)
                        if ((d = Lc(c, a)) && (e = I(d.width)) && !(e >= b) && "visible" != d.overflow) {
                            c = !0;
                            break a
                        }
                    c = !1
                }
                a = c ? 7 : !0
            }
            return a
        },
        hi = (a, b, c, d) => {
            const e = gi(b, c, a, .3, d);
            !0 !== e ? a = e : "true" == d.google_full_width_responsive || ai(c, b) ? (b = N(b).clientWidth, a = b - a, a = b && 0 <= a ? !0 : b ? -10 > a ? 11 : 0 > a ? 14 : 12 : 10) : a = 9;
            return a
        },
        ii = (a, b, c) => {
            a = a.style;
            "rtl" == b ? a.marginRight = c : a.marginLeft = c
        };
    const ji = (a, b) => {
            if (3 == b.nodeType) return /\S/.test(b.data);
            if (1 == b.nodeType) {
                if (/^(script|style)$/i.test(b.nodeName)) return !1;
                let c;
                try {
                    c = Lc(b, a)
                } catch (d) {}
                return !c || "none" != c.display && !("absolute" == c.position && ("hidden" == c.visibility || "collapse" == c.visibility))
            }
            return !1
        },
        ki = (a, b, c) => {
            a = di(b, a);
            return "rtl" == c ? -a.x : a.x
        };
    var li = (a, b) => {
        var c;
        c = (c = b.parentElement) ? (c = Lc(c, a)) ? c.direction : "" : "";
        if (c) {
            b.style.border = b.style.borderStyle = b.style.outline = b.style.outlineStyle = b.style.transition = "none";
            b.style.borderSpacing = b.style.padding = "0";
            ii(b, c, "0px");
            b.style.width = N(a).clientWidth + "px";
            if (0 !== ki(a, b, c)) {
                ii(b, c, "0px");
                var d = ki(a, b, c);
                ii(b, c, -1 * d + "px");
                a = ki(a, b, c);
                0 !== a && a !== d && ii(b, c, d / (a - d) * d + "px")
            }
            b.style.zIndex = 30
        }
    };
    var mi = class {
        constructor(a, b) {
            this.M = a;
            this.j = b
        }
        height() {
            return this.j
        }
        h(a) {
            return 300 < a && 300 < this.j ? this.M : Math.min(1200, Math.round(a))
        }
        i() {}
    };
    var ni = (a, b, c, d = e => e) => {
            let e;
            return a.style && a.style[c] && d(a.style[c]) || (e = Lc(a, b)) && e[c] && d(e[c]) || null
        },
        oi = a => b => b.M <= a,
        ri = (a, b, c, d) => {
            const e = a && pi(c, b),
                f = qi(b, d);
            return g => !(e && g.height() >= f)
        },
        si = a => b => b.height() <= a,
        pi = (a, b) => ei(a, b) < N(b).clientHeight - 100,
        ti = (a, b) => {
            var c = ni(b, a, "height", I);
            if (c) return c;
            var d = b.style.height;
            b.style.height = "inherit";
            c = ni(b, a, "height", I);
            b.style.height = d;
            if (c) return c;
            c = Infinity;
            do(d = b.style && I(b.style.height)) && (c = Math.min(c, d)), (d = ni(b, a, "maxHeight", I)) && (c =
                Math.min(c, d)); while ((b = b.parentElement) && "HTML" != b.tagName);
            return c
        };
    const qi = (a, b) => {
        const c = 0 == qd(a);
        return b && c ? Math.max(250, 2 * N(a).clientHeight / 3) : 250
    };
    var ui = {
        google_ad_channel: !0,
        google_ad_client: !0,
        google_ad_host: !0,
        google_ad_host_channel: !0,
        google_adtest: !0,
        google_tag_for_child_directed_treatment: !0,
        google_tag_for_under_age_of_consent: !0,
        google_tag_partner: !0,
        google_restrict_data_processing: !0,
        google_page_url: !0,
        google_debug_params: !0,
        google_shadow_mode: !0,
        google_adbreak_test: !0,
        google_ad_frequency_hint: !0,
        google_admob_interstitial_slot: !0,
        google_admob_rewarded_slot: !0,
        google_admob_ads_only: !0,
        google_max_ad_content_rating: !0,
        google_traffic_source: !0
    };
    const vi = RegExp("(^| )adsbygoogle($| )");

    function wi(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = zc(d.Yb);
            a[e] = d.value
        }
    };
    class xi {
        constructor() {
            var a = nd `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
            this.h = null;
            this.j = !1;
            this.m = Math.random();
            this.i = this.I;
            this.A = a
        }
        wa(a) {
            this.h = a
        }
        l(a) {
            this.j = a
        }
        Sa(a) {
            this.i = a
        }
        I(a, b, c = .01, d, e = "jserror") {
            if ((this.j ? this.m : Math.random()) > c) return !1;
            ud(b) || (b = new td(b, {
                context: a,
                id: e
            }));
            if (d || this.h) b.meta = {}, this.h && this.h(b.meta), d && d(b.meta);
            n.google_js_errors = n.google_js_errors || [];
            n.google_js_errors.push(b);
            n.error_rep_loaded || (Jc(n.document, this.A), n.error_rep_loaded = !0);
            return !1
        }
        ia(a, b, c) {
            try {
                return b()
            } catch (d) {
                if (!this.i(a, d, .01, c, "jserror")) throw d;
            }
        }
        va(a, b) {
            return (...c) => this.ia(a, () => b.apply(void 0, c))
        }
        ca(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.I(a, c instanceof Error ? c : Error(c), void 0, this.h || void 0)
            })
        }
    };
    const yi = (a, b) => {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    var zi = (a, b, c, d, e = !1) => {
            const f = d || window,
                g = "undefined" !== typeof queueMicrotask;
            return function() {
                e && g && queueMicrotask(() => {
                    f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                    f.google_rum_task_id_counter += 1
                });
                const h = Kd();
                let l, k = 3;
                try {
                    l = b.apply(this, arguments)
                } catch (m) {
                    k = 13;
                    if (!c) throw m;
                    c(a, m)
                } finally {
                    f.google_measure_js_timing && h && yi({
                        label: a.toString(),
                        value: h,
                        duration: (Kd() || 0) - h,
                        type: k,
                        ...(e && g && {
                            taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                        })
                    }, f)
                }
                return l
            }
        },
        Ai = (a, b) => zi(a, b, (c, d) => {
            (new xi).I(c, d)
        }, void 0, !1);

    function Bi(a, b, c) {
        return zi(a, b, void 0, c, !0).apply()
    }

    function Ci(a) {
        if (!a) return null;
        var b = r(a, 7);
        if (r(a, 1) || a.getId() || 0 < sb(a, 4).length) {
            b = sb(a, 4);
            var c = r(a, 3),
                d = r(a, 1),
                e = "";
            d && (e += d);
            c && (e += "#" + Tg(c));
            if (b)
                for (c = 0; c < b.length; c++) e += "." + Tg(b[c]);
            a = (b = e) ? new Vg(b, r(a, 2), r(a, 5), Di(r(a, 6))) : null
        } else a = b ? new Vg(b, r(a, 2), r(a, 5), Di(r(a, 6))) : null;
        return a
    }
    var Ei = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Di(a) {
        return null == a ? a : Ei[a]
    }
    var Fi = {
        1: 0,
        2: 1,
        3: 2,
        4: 3
    };

    function Gi(a) {
        return a.google_ama_state = a.google_ama_state || {}
    }

    function Hi(a) {
        a = Gi(a);
        return a.optimization = a.optimization || {}
    };
    var Ii = Yb(class extends G {
        constructor(a) {
            super(a)
        }
    });
    var Ji = a => {
        switch (r(a, 8)) {
            case 1:
            case 2:
                if (null == a) var b = null;
                else b = A(a, M, 1), null == b ? b = null : (a = r(a, 2), b = null == a ? null : new mg({
                    Xa: [b],
                    rb: a
                }));
                return null != b ? cg(b) : eg(Error("Missing dimension when creating placement id"));
            case 3:
                return eg(Error("Missing dimension when creating placement id"));
            default:
                return eg(Error("Invalid type: " + r(a, 8)))
        }
    };
    var Ki = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Li = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Mi = class extends G {
        constructor(a) {
            super(a)
        }
        i() {
            return rb(this, 23)
        }
    };
    var Ni = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Oi = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Pi = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Qi = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Ri = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Si = class extends G {
            constructor(a) {
                super(a)
            }
            getName() {
                return r(this, 4)
            }
        },
        Ti = [1, 2, 3];
    var Vi = class extends G {
            constructor(a) {
                super(a, -1, Ui)
            }
        },
        Ui = [2, 5, 6, 11];
    var Wi = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Yi = class extends G {
            constructor(a) {
                super(a)
            }
            i() {
                return Hb(this, Wi, 2, Xi)
            }
        },
        Xi = [1, 2];
    var aj = class extends G {
            constructor(a) {
                super(a, -1, $i)
            }
            i() {
                return A(this, Yi, 3)
            }
        },
        $i = [1, 4];
    var cj = class extends G {
            constructor(a) {
                super(a, -1, bj)
            }
        },
        dj = Yb(cj),
        bj = [1, 2, 5, 7];
    var ej = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function fj(a, b) {
        const c = new kg,
            d = new jg;
        b.forEach(e => {
            if (Hb(e, Qi, 1, Ti)) {
                e = Hb(e, Qi, 1, Ti);
                if (A(e, Ng, 1) && A(A(e, Ng, 1), M, 1) && A(e, Ng, 2) && A(A(e, Ng, 2), M, 1)) {
                    const g = gj(a, A(A(e, Ng, 1), M, 1)),
                        h = gj(a, A(A(e, Ng, 2), M, 1));
                    if (g && h)
                        for (var f of ej({
                                anchor: g,
                                position: r(A(e, Ng, 1), 2)
                            }, {
                                anchor: h,
                                position: r(A(e, Ng, 2), 2)
                            })) c.set(ea(f.anchor), f.position)
                }
                A(e, Ng, 3) && A(A(e, Ng, 3), M, 1) && (f = gj(a, A(A(e, Ng, 3), M, 1))) && c.set(ea(f), r(A(e, Ng, 3), 2))
            } else Hb(e, Ri, 2, Ti) ? hj(a, Hb(e, Ri, 2, Ti), c) : Hb(e, Pi, 3, Ti) && ij(a, Hb(e, Pi, 3, Ti), d)
        });
        return new jj(c,
            d)
    }
    class jj {
        constructor(a, b) {
            this.i = a;
            this.h = b
        }
    }
    const hj = (a, b, c) => {
            A(b, Ng, 2) ? (b = A(b, Ng, 2), (a = gj(a, A(b, M, 1))) && c.set(ea(a), r(b, 2))) : A(b, M, 1) && (a = kj(a, A(b, M, 1))) && a.forEach(d => {
                d = ea(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        ij = (a, b, c) => {
            A(b, M, 1) && (a = kj(a, A(b, M, 1))) && a.forEach(d => {
                c.add(ea(d))
            })
        },
        gj = (a, b) => (a = kj(a, b)) && 0 < a.length ? a[0] : null,
        kj = (a, b) => (b = Ci(b)) ? b.query(a) : null;

    function lj(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (mj(b)) return !0;
            if (a.h.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.h.add(d));
        return !1
    }

    function nj(a) {
        a = oj(a);
        return a.has("all") || a.has("after")
    }

    function pj(a) {
        a = oj(a);
        return a.has("all") || a.has("before")
    }

    function oj(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function mj(a) {
        const b = oj(a);
        return a && ("AUTO-ADS-EXCLUSION-AREA" === a.tagName || b.has("inside") || b.has("all"))
    }
    var qj = class {
        constructor() {
            this.h = new Set
        }
    };

    function rj(a, b) {
        if (!a) return !1;
        a = Lc(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return "left" == a || "right" == a
    }

    function sj(a) {
        for (a = a.previousSibling; a && 1 != a.nodeType;) a = a.previousSibling;
        return a ? a : null
    }

    function tj(a) {
        return !!a.nextSibling || !!a.parentNode && tj(a.parentNode)
    };

    function uj(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (-1 != a.indexOf(b)) return !0;
        b = vj(b);
        return "go" != b && -1 != a.indexOf(b) ? !0 : !1
    }

    function vj(a) {
        let b = "";
        H(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    };

    function wj(a = window) {
        a = a.googletag;
        return a ? .apiReady ? a : void 0
    };
    const xj = a => {
        const b = wj(a);
        return b ? Aa(Da(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => null != c) : null
    };
    var yj = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function zj(a, b) {
        if (a.l) return !0;
        a.l = !0;
        const c = B(a.i, Qg, 1);
        a.j = 0;
        const d = Aj(a.B);
        if (uj(a.h.location, "google_audio_sense")) {
            var e = new Jg;
            e = t(e, 1, 1);
            var f = new Ig;
            f = t(f, 2, !0);
            e = Ab(e, 2, f);
            f = new Hg;
            var g = new Eg;
            var h = t(g, 1, 1);
            mb(f);
            g = zb(f, Eg, 1, !1, !1);
            h = null != h ? h : new Eg;
            var l = pb(f, 1, 2, void 0, !1);
            g.push(h);
            l.push(h.u);
            db(h.u) && bb(l, 8);
            g = new Fg;
            g = t(g, 1, !0);
            f = Ab(f, 2, g);
            e = Ab(e, 3, f)
        } else e = A(a.i, Jg, 27);
        if (f = e)
            if (g = A(a.i, Mg, 6) ? .i() || [], e = a.h, 1 == F(f, 1) && A(f, Ig, 2) ? .i() && 0 != g.length) {
                var k;
                f = [];
                for (k of g)
                    if (g =
                        Ci(A(k, M, 1) || null)) g = g.query(e.document), 0 < g.length && f.push(g[0]);
                f = f.filter(Ag).filter(Bg(f)).filter(Cg(e));
                f.sort(Dg);
                if (k = f[0] || null) f = e.document.createElement("div"), f.id = "google-auto-placed-read-aloud-player-reserved", Xc(f, {
                    width: "100%",
                    height: "65px"
                }), k.insertBefore(f, k.firstChild), Gi(e).audioSenseSpaceReserved = !0
            }
        k = a.h;
        var m;
        try {
            var u = (m = k.localStorage.getItem("google_ama_settings")) ? Ii(m) : null
        } catch (y) {
            u = null
        }
        m = null !== u && E(u, 2, !1);
        u = Gi(k);
        m && (u.eatf = !0, kd(7, [!0, 0, !1]));
        b: {
            f = {
                hb: !1,
                ib: !1
            };
            h = Ia(k.document.querySelectorAll(".google-auto-placed"));l = Ia(k.document.querySelectorAll("ins.adsbygoogle[data-anchor-shown],ins.adsbygoogle[data-anchor-status]"));
            const y = Ia(k.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]"));g = (xj(k) || Ia(k.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(Ia(k.document.querySelectorAll("iframe[id^=google_ads_iframe]")));
            const w = Ia(k.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")),
                C = Ia(k.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
                Ba = Ia(k.document.querySelectorAll("div.googlepublisherpluginad")),
                T = Ia(k.document.querySelectorAll("html > ins.adsbygoogle"));e = [].concat(Ia(k.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), Ia(k.document.querySelectorAll("body ins.adsbygoogle")));m = [];
            for (const [Ca, sa] of [
                    [f.Sb, h],
                    [f.hb, l],
                    [f.Vb, y],
                    [f.Tb, g],
                    [f.Wb, w],
                    [f.Rb, C],
                    [f.Ub, Ba],
                    [f.ib, T]
                ]) f = sa,
            !1 === Ca ? m = m.concat(f) : e = e.concat(f);e = yj(e);m = yj(m);
            e = e.slice(0);
            for (v of m)
                for (m = 0; m < e.length; m++)(v.contains(e[m]) || e[m].contains(v)) && e.splice(m, 1);
            var v = e;m = N(k).clientHeight;
            for (k = 0; k < v.length; k++)
                if (!(v[k].getBoundingClientRect().top > m)) {
                    v = !0;
                    break b
                }
            v = !1
        }
        v = v ? u.eatfAbg = !0 : !1;
        if (v) return !0;
        v = new jg([2]);
        for (u = 0; u < c.length; u++) {
            m = a;
            e = c[u];
            k = u;
            f = b;
            g = d;
            h = v;
            if (A(e, qg, 4) && h.contains(r(A(e, qg, 4), 1)) && 1 === r(e, 8) && Bj(e, g)) {
                m.j++;
                if (f = Cj(m, e, f, g)) g = Gi(m.h), g.numAutoAdsPlaced || (g.numAutoAdsPlaced = 0), A(e, M, 1) && null != r(A(e, M, 1), 5) && (g.numPostPlacementsPlaced ?
                    g.numPostPlacementsPlaced++ : g.numPostPlacementsPlaced = 1), null == g.placed && (g.placed = []), g.numAutoAdsPlaced++, g.placed.push({
                    index: k,
                    element: f.ka
                }), kd(7, [!1, m.j, !0]);
                m = f
            } else m = null;
            if (m) return !0
        }
        kd(7, [!1, a.j, !1]);
        return !1
    }

    function Cj(a, b, c, d) {
        if (!Bj(b, d) || 1 != r(b, 8)) return null;
        d = A(b, M, 1);
        if (!d) return null;
        d = Ci(d);
        if (!d) return null;
        d = d.query(a.h.document);
        if (0 == d.length) return null;
        d = d[0];
        var e = Fi[r(b, 2)];
        e = void 0 === e ? null : e;
        var f;
        if (!(f = null == e)) {
            a: {
                f = a.h;
                switch (e) {
                    case 0:
                        f = rj(sj(d), f);
                        break a;
                    case 3:
                        f = rj(d, f);
                        break a;
                    case 2:
                        var g = d.lastChild;
                        f = rj(g ? 1 == g.nodeType ? g : sj(g) : null, f);
                        break a
                }
                f = !1
            }
            if (c = !f && !(!c && 2 == e && !tj(d))) c = 1 == e || 2 == e ? d : d.parentNode,
            c = !(c && !Wg(c) && 0 >= c.offsetWidth);f = !c
        }
        if (!(c = f)) {
            c = a.A;
            f = r(b, 2);
            g = ea(d);
            g = c.i.h.get(g);
            if (!(g = g ? g.contains(f) : !1)) a: {
                if (c.h.contains(ea(d))) switch (f) {
                    case 2:
                    case 3:
                        g = !0;
                        break a;
                    default:
                        g = !1;
                        break a
                }
                for (f = d.parentElement; f;) {
                    if (c.h.contains(ea(f))) {
                        g = !0;
                        break a
                    }
                    f = f.parentElement
                }
                g = !1
            }
            c = g
        }
        if (!c) {
            c = a.v;
            f = r(b, 2);
            a: switch (f) {
                case 1:
                    g = nj(d.previousElementSibling) || pj(d);
                    break a;
                case 4:
                    g = nj(d) || pj(d.nextElementSibling);
                    break a;
                case 2:
                    g = pj(d.firstElementChild);
                    break a;
                case 3:
                    g = nj(d.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + f);
            }
            c = g || lj(c, d, f)
        }
        if (c) return null;
        f = A(b, Og, 3);
        c = {};
        f && (c.Ua = r(f, 1), c.La = r(f, 2), c.ab = !!rb(f, 3));
        f = A(b, qg, 4) && r(A(b, qg, 4), 2) ? r(A(b, qg, 4), 2) : null;
        f = tg(f);
        g = null != r(b, 12) ? r(b, 12) : null;
        g = null == g ? null : new sg(null, {
            google_ml_rank: g
        });
        b = Dj(a, b);
        b = rg(a.m, f, g, b);
        f = a.h;
        a = a.C;
        var h = f.document,
            l = c.ab || !1;
        g = (new Bc(h)).createElement("DIV");
        const k = g.style;
        k.width = "100%";
        k.height = "auto";
        k.clear = l ? "both" : "none";
        l = g.style;
        l.textAlign = "center";
        c.pb && wi(l, c.pb);
        h = (new Bc(h)).createElement("INS");
        l = h.style;
        l.display = "block";
        l.margin = "auto";
        l.backgroundColor =
            "transparent";
        c.Ua && (l.marginTop = c.Ua);
        c.La && (l.marginBottom = c.La);
        c.Wa && wi(l, c.Wa);
        g.appendChild(h);
        c = {
            sa: g,
            ka: h
        };
        c.ka.setAttribute("data-ad-format", "auto");
        g = [];
        if (h = b && b.Ma) c.sa.className = h.join(" ");
        h = c.ka;
        h.className = "adsbygoogle";
        h.setAttribute("data-ad-client", a);
        g.length && h.setAttribute("data-ad-channel", g.join("+"));
        a: {
            try {
                var m = c.sa;
                if (P(eh)) {
                    {
                        const C = Wh(d, e);
                        if (C.init) {
                            var u = C.init;
                            for (d = u; d = C.ma(d);) u = d;
                            var v = {
                                anchor: u,
                                position: C.pa
                            }
                        } else v = {
                            anchor: d,
                            position: e
                        }
                    }
                    m["google-ama-order-assurance"] =
                        0;
                    Vh(m, v.anchor, v.position)
                } else Vh(m, d, e);
                b: {
                    var y = c.ka;y.dataset.adsbygoogleStatus = "reserved";y.className += " adsbygoogle-noablate";m = {
                        element: y
                    };
                    var w = b && b.Ra;
                    if (y.hasAttribute("data-pub-vars")) {
                        try {
                            w = JSON.parse(y.getAttribute("data-pub-vars"))
                        } catch (C) {
                            break b
                        }
                        y.removeAttribute("data-pub-vars")
                    }
                    w && (m.params = w);
                    (f.adsbygoogle = f.adsbygoogle || []).push(m)
                }
            } catch (C) {
                (y = c.sa) && y.parentNode && (w = y.parentNode, w.removeChild(y), Wg(w) && (w.style.display = w.getAttribute("data-init-display") || "none"));
                y = !1;
                break a
            }
            y = !0
        }
        return y ? c : null
    }

    function Dj(a, b) {
        return gg(ig(Ji(b).map(ug), c => {
            Gi(a.h).exception = c
        }))
    }
    const Ej = class {
        constructor(a, b, c, d, e) {
            this.h = a;
            this.C = b;
            this.i = c;
            this.m = e || null;
            this.A = (this.B = d) ? fj(a.document, B(d, Si, 5)) : fj(a.document, []);
            this.v = new qj;
            this.j = 0;
            this.l = !1
        }
    };

    function Aj(a) {
        const b = {};
        a && qb(a, 6, !1).forEach(c => {
            b[c] = !0
        });
        return b
    }

    function Bj(a, b) {
        return a && void 0 !== xb(a, qg, 4, !1) && b[r(A(a, qg, 4), 2)] ? !1 : !0
    };
    var Fj = Yb(class extends G {
        constructor(a) {
            super(a)
        }
    });
    class Q extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, Q) : this.stack = Error().stack || ""
        }
    };
    let Gj, R;
    const Hj = new Rd(n);
    var Ij = a => {
        null != a && (n.google_measure_js_timing = a);
        n.google_measure_js_timing || Qd(Hj)
    };
    (a => {
        Gj = a || new Gd;
        "number" !== typeof n.google_srt && (n.google_srt = Math.random());
        Ed(Gj, n.google_srt);
        R = new Td(Gj, Hj);
        R.l(!0);
        "complete" == n.document.readyState ? Ij() : Hj.h && ic(n, "load", () => {
            Ij()
        })
    })();
    var Jj = (a, b, c) => R.ia(a, b, c),
        Kj = (a, b) => R.va(a, b),
        Lj = (a, b, c) => {
            const d = K(Pf).i();
            !b.eid && d.length && (b.eid = d.toString());
            Fd(Gj, a, b, !0, c)
        },
        Mj = (a, b) => {
            R.ca(a, b)
        },
        Nj = (a, b, c, d) => {
            let e;
            ud(b) ? e = b.msg || Sd(b.error) : e = Sd(b);
            return 0 == e.indexOf("TagError") ? (c = b instanceof td ? b.error : b, c.pbr || (c.pbr = !0, R.I(a, b, .1, d, "puberror")), !1) : R.I(a, b, c, d)
        };

    function Oj(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? fg(() => Fj(c)) : cg(null)
    };

    function Pj() {
        if (Qj) return Qj;
        const a = md() || window,
            b = a.google_persistent_state_async;
        return null != b && "object" == typeof b && null != b.S && "object" == typeof b.S ? Qj = b : a.google_persistent_state_async = Qj = new Rj
    }

    function Sj(a) {
        return Tj[a] || "google_ps_" + a
    }

    function Uj(a, b, c) {
        b = Sj(b);
        a = a.S;
        const d = a[b];
        return void 0 === d ? (a[b] = c(), a[b]) : d
    }

    function Vj(a, b, c) {
        return Uj(a, b, () => c)
    }

    function Wj(a) {
        return !!Vj(Pj(), 30, a)
    }
    class Rj {
        constructor() {
            this.S = {}
        }
    }
    var Qj = null;
    const Tj = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function Xj(a) {
        this.h = a || {
            cookie: ""
        }
    }
    Xj.prototype.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        "object" === typeof c && (h = c.Zb, g = c.ac || !1, f = c.domain || void 0, e = c.path || void 0, d = c.nb);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === d && (d = -1);
        this.h.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (0 > d ? "" : 0 == d ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * d)).toUTCString()) + (g ? ";secure" : "") + (null != h ? ";samesite=" + h : "")
    };
    Xj.prototype.get = function(a, b) {
        const c = a + "=",
            d = (this.h.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = pa(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    Xj.prototype.isEmpty = function() {
        return !this.h.cookie
    };
    Xj.prototype.clear = function() {
        var a = (this.h.cookie || "").split(";");
        const b = [];
        var c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = pa(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (c = b.length - 1; 0 <= c; c--) a = b[c], this.get(a), this.set(a, "", {
            nb: 0,
            path: void 0,
            domain: void 0
        })
    };

    function Yj(a, b = window) {
        if (rb(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    };

    function Zj(a) {
        var b = new ak;
        return t(b, 5, a)
    }
    var ak = class extends G {
        constructor() {
            super()
        }
    };
    const bk = a => {
        void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
        void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
        return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
    };

    function ck(a) {
        if (!1 === a.gdprApplies) return !0;
        void 0 === a.internalErrorState && (a.internalErrorState = bk(a));
        return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (hd({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
    }

    function dk(a) {
        if (a.i) return a.i;
        a.i = Vc(a.l, "__tcfapiLocator");
        return a.i
    }

    function ek(a) {
        return "function" === typeof a.l.__tcfapi || null != dk(a)
    }

    function fk(a, b, c, d) {
        c || (c = () => {});
        if ("function" === typeof a.l.__tcfapi) a = a.l.__tcfapi, a(b, 2, c, d);
        else if (dk(a)) {
            gk(a);
            const e = ++a.K;
            a.v[e] = c;
            a.i && a.i.postMessage({
                __tcfapiCall: {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }
            }, "*")
        } else c({}, !1)
    }

    function gk(a) {
        a.m || (a.m = b => {
            try {
                var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                a.v[c.callId](c.returnValue, c.success)
            } catch (d) {}
        }, ic(a.l, "message", a.m))
    }
    class hk extends Ze {
        constructor(a) {
            var b = {};
            super();
            this.l = a;
            this.i = null;
            this.v = {};
            this.K = 0;
            this.C = b.Ta ? ? 500;
            this.B = b.Qb ? ? !1;
            this.m = null
        }
        h() {
            this.v = {};
            this.m && (jc(this.l, "message", this.m), delete this.m);
            delete this.v;
            delete this.l;
            delete this.i;
            super.h()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.B
            };
            const c = hc(() => a(b));
            let d = 0; - 1 !== this.C && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.C));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = bk(b),
                    b.internalBlockOnErrors = this.B, g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                fk(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && fk(this, "removeEventListener", null, a.listenerId)
        }
    };
    var mk = ({
            s: a,
            X: b,
            Ta: c,
            callback: d,
            na: e = !1,
            oa: f = !1
        }) => {
            b = ik({
                s: a,
                X: b,
                na: e,
                oa: f
            });
            null != b.h || "tcunav" != b.i.message ? d(b) : jk(a, c).then(g => g.map(kk)).then(g => g.map(h => lk(a, h))).then(d)
        },
        ik = ({
            s: a,
            X: b,
            na: c = !1,
            oa: d = !1
        }) => {
            if (!nk({
                    s: a,
                    X: b,
                    na: c,
                    oa: d
                })) return lk(a, Zj(!0));
            b = Pj();
            return (b = Vj(b, 24)) ? lk(a, kk(b)) : eg(Error("tcunav"))
        };

    function nk({
        s: a,
        X: b,
        na: c,
        oa: d
    }) {
        if (!(d = !d && ek(new hk(a)))) {
            if (c = !c) {
                if (b) {
                    a = Oj(a);
                    if (null != a.h)
                        if ((a = a.h.value) && null != r(a, 1)) b: switch (a = r(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else R.I(806, a.i, void 0, void 0), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function jk(a, b) {
        return Promise.race([ok(), pk(a, b)])
    }

    function ok() {
        return (new Promise(a => {
            var b = Pj();
            a = {
                resolve: a
            };
            const c = Vj(b, 25, []);
            c.push(a);
            b.S[Sj(25)] = c
        })).then(qk)
    }

    function pk(a, b) {
        return new Promise(c => {
            a.setTimeout(c, b, eg(Error("tcto")))
        })
    }

    function qk(a) {
        return a ? cg(a) : eg(Error("tcnull"))
    }

    function kk(a) {
        if (ck(a))
            if (!1 !== a.gdprApplies && "tcunavailable" !== a.tcString && void 0 !== a.gdprApplies && "string" === typeof a.tcString && a.tcString.length) {
                b: {
                    if (a.publisher && a.publisher.restrictions) {
                        var b = a.publisher.restrictions["1"];
                        if (void 0 !== b) {
                            b = b["755"];
                            break b
                        }
                    }
                    b = void 0
                }
                0 === b ? a = !1 : a.purpose && a.vendor ? (b = a.vendor.consents, (b = !(!b || !b["755"])) && a.purposeOneTreatment && "CH" === a.publisherCC ? a = !0 : (b && (a = a.purpose.consents, b = !(!a || !a["1"])), a = b)) : a = !0
            }
        else a = !0;
        else a = !1;
        return Zj(a)
    }

    function lk(a, b) {
        return (a = Yj(b, a)) ? cg(a) : eg(Error("unav"))
    };
    var sk = class extends G {
            constructor(a) {
                super(a, -1, rk)
            }
        },
        rk = [1, 2, 3];
    var tk = class extends G {
        constructor(a) {
            super(a)
        }
        i() {
            return A(this, sk, 2)
        }
    };
    const uk = class {
        constructor(a) {
            this.exception = a
        }
    };

    function vk(a, b) {
        try {
            var c = a.i,
                d = c.resolve,
                e = a.h;
            Gi(e.h);
            B(e.i, Qg, 1);
            d.call(c, new uk(b))
        } catch (f) {
            a = a.i, b = f, Vf(a), a.h = 2, a.j = b, Xf(a.i)
        }
    }
    var wk = class {
        constructor(a, b, c) {
            this.j = a;
            this.h = b;
            this.i = c
        }
        start() {
            this.l()
        }
        l() {
            try {
                switch (this.j.document.readyState) {
                    case "complete":
                    case "interactive":
                        zj(this.h, !0);
                        vk(this);
                        break;
                    default:
                        zj(this.h, !1) ? vk(this) : this.j.setTimeout(ka(this.l, this), 100)
                }
            } catch (a) {
                vk(this, a)
            }
        }
    };
    var xk = "a".charCodeAt(),
        yk = mc(Tf),
        zk = mc(Uf);

    function S(a, b) {
        if (a.h + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.i.substring(a.h, a.h + b);
        a.h += b;
        return parseInt(c, 2)
    }

    function Ak(a) {
        return String.fromCharCode(xk + S(a, 6)) + String.fromCharCode(xk + S(a, 6))
    }

    function Bk(a) {
        let b = S(a, 12);
        const c = [];
        for (; b--;) {
            var d = !0 === !!S(a, 1),
                e = S(a, 16);
            if (d)
                for (d = S(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function Ck(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (S(a, 1)) {
                const f = e + 1;
                if (c && -1 === c.indexOf(f)) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function Dk(a) {
        const b = S(a, 16);
        return !0 === !!S(a, 1) ? (a = Bk(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : Ck(a, b)
    }
    class Ek {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.i = a;
            this.h = 0
        }
    };
    var Gk = (a, b) => {
        try {
            var c = Oa(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new Ek(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = !0;
            d.h += 78;
            c.cmpId = S(d, 12);
            c.cmpVersion = S(d, 12);
            d.h += 30;
            c.tcfPolicyVersion = S(d, 6);
            c.isServiceSpecific = !!S(d, 1);
            c.useNonStandardStacks = !!S(d, 1);
            c.specialFeatureOptins = Fk(Ck(d, 12, zk), zk);
            c.purpose = {
                consents: Fk(Ck(d, 24, yk), yk),
                legitimateInterests: Fk(Ck(d, 24, yk), yk)
            };
            c.purposeOneTreatment = !!S(d, 1);
            c.publisherCC = Ak(d);
            c.vendor = {
                consents: Fk(Dk(d), b),
                legitimateInterests: Fk(Dk(d),
                    b)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const Fk = (a, b) => {
        const c = {};
        if (Array.isArray(b) && 0 !== b.length)
            for (const d of b) c[d] = -1 !== a.indexOf(d);
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var Hk = class {
        constructor() {
            this.h = {}
        }
    };
    var Ik = class extends G {
        constructor() {
            super()
        }
    };
    var Jk = class extends G {
        constructor() {
            super()
        }
    };
    var Kk = class extends G {
            constructor() {
                super()
            }
        },
        Lk = [8, 11, 12, 13, 15, 17, 18, 19, 20, 21, 22, 25, 26, 27];
    var Mk = class {};
    var Nk = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Ok = class extends G {
        constructor(a) {
            super(a)
        }
    };
    var Qk = Yb(class extends G {
            constructor(a) {
                super(a, -1, Pk)
            }
        }),
        Pk = [7];
    var Rk = new class {
        constructor() {
            this.key = "45369554";
            this.defaultValue = !1;
            this.valueType = "boolean"
        }
    };
    var Sk = class extends Hk {
            constructor() {
                super();
                var a = n.__fcexpdef || "";
                try {
                    const b = JSON.parse(a)[0];
                    a = "";
                    for (let c = 0; c < b.length; c++) a += String.fromCharCode(b.charCodeAt(c) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(c % 10));
                    this.h = JSON.parse(a)
                } catch (b) {}
            }
        },
        Tk;

    function Uk(a) {
        return (a = Vk(a)) ? A(a, Ok, 4) : null
    }

    function Vk(a) {
        if (a = (new Xj(a)).get("FCCDCF", ""))
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                Wk(1), b = null
            } else b = a;
            else b = null;
        try {
            return b ? Qk(b) : null
        } catch (c) {
            return Wk(2), null
        }
    }

    function Wk(a) {
        new Mk;
        var b = new Ik;
        a = t(b, 7, a);
        b = new Jk;
        a = Ab(b, 1, a);
        b = new Kk;
        Bb(b, 22, Lk, a);
        Tk || (Tk = new Sk);
        a = Tk.h[Rk.key];
        if ("proto" === Rk.valueType) try {
            JSON.parse(a)
        } catch (c) {}
    };
    mc(Tf).map(a => Number(a));
    mc(Uf).map(a => Number(a));

    function Xk(a) {
        a.__tcfapiPostMessageReady || Yk(new Zk(a))
    }

    function Yk(a) {
        a.i = b => {
            const c = "string" == typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.h.__tcfapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = "removeEventListener" === e.command ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.h.addEventListener("message", a.i);
        a.h.__tcfapiPostMessageReady = !0
    }
    var Zk = class {
        constructor(a) {
            this.h = a;
            this.i = null
        }
    };
    var $k = (a, b) => {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = Kc("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };

    function al() {
        var a = window,
            b = P(jh);
        a.__uspapi || a.frames.__uspapiLocator || (a = new bl(a), cl(a), b && dl(a))
    }

    function cl(a) {
        !a.m || a.h.__uspapi || a.h.frames.__uspapiLocator || (a.h.__uspapiManager = "fc", $k(a.h, "__uspapiLocator"), ma("__uspapi", (...b) => el(a, ...b)))
    }

    function dl(a) {
        !a.j || a.h.__tcfapi || a.h.frames.__tcfapiLocator || (a.h.__tcfapiManager = "fc", $k(a.h, "__tcfapiLocator"), a.h.__tcfapiEventListeners = a.h.__tcfapiEventListeners || [], ma("__tcfapi", (...b) => fl(a, ...b)), Xk(a.h))
    }

    function el(a, b, c, d) {
        "function" === typeof d && "getUSPData" === b && d({
            version: 1,
            uspString: a.m
        }, !0)
    }

    function fl(a, b, c, d, e = null) {
        if ("function" === typeof d)
            if (c && 2 !== c) d(null, !1);
            else switch (c = a.h.__tcfapiEventListeners, b) {
                case "getTCData":
                    !e || Array.isArray(e) && e.every(f => "number" === typeof f) ? d(gl(a, e, null), !0) : d(null, !1);
                    break;
                case "ping":
                    d({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.0",
                        cmpVersion: 1,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    b = c.push(d);
                    d(gl(a, null, b - 1), !0);
                    break;
                case "removeEventListener":
                    c[e] ? (c[e] = null, d(!0)) : d(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    d(null, !1)
            }
    }

    function gl(a, b, c) {
        if (!a.j) return null;
        b = Gk(a.j, b);
        b.addtlConsent = null != a.l ? a.l : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    }
    class bl {
        constructor(a) {
            this.h = a;
            this.i = a.document;
            this.m = (a = (a = Vk(this.i)) ? A(a, Nk, 5) || null : null) ? r(a, 2) : null;
            this.j = (a = Uk(this.i)) && null != r(a, 1) ? r(a, 1) : null;
            this.l = (a = Uk(this.i)) && null != r(a, 2) ? r(a, 2) : null
        }
    };
    const hl = a => {
            const b = /[a-zA-Z0-9._~-]/,
                c = /%[89a-zA-Z]./;
            return a.replace(/(%[a-zA-Z0-9]{2})/g, function(d) {
                if (!d.match(c)) {
                    const e = decodeURIComponent(d);
                    if (e.match(b)) return e
                }
                return d.toUpperCase()
            })
        },
        il = a => {
            let b = "";
            const c = /[/%?&=]/;
            for (let d = 0; d < a.length; ++d) {
                const e = a[d];
                b = e.match(c) ? b + e : b + encodeURIComponent(e)
            }
            return b
        };
    var jl = a => {
        a = qb(a, 2, !1);
        if (!a) return !1;
        for (let b = 0; b < a.length; b++)
            if (1 == a[b]) return !0;
        return !1
    };
    const ll = (a, b) => {
            a = il(hl(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
            const c = Qc(a),
                d = kl(a);
            return b.find(e => {
                const f = void 0 !== xb(e, Oi, 7, !1) ? r(A(e, Oi, 7), 1) : r(e, 1);
                e = void 0 !== xb(e, Oi, 7, !1) ? r(A(e, Oi, 7), 2) : 2;
                if ("number" !== typeof f) return !1;
                switch (e) {
                    case 1:
                        return f == c;
                    case 2:
                        return d[f] || !1
                }
                return !1
            }) || null
        },
        kl = a => {
            const b = {};
            for (;;) {
                b[Qc(a)] = !0;
                if (!a) return b;
                a = a.substring(0, a.lastIndexOf("/"))
            }
        };
    const ml = {
        google_ad_channel: !0,
        google_ad_host: !0
    };
    var nl = (a, b) => {
            a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
            Lj("ama", b, .01)
        },
        ol = a => {
            const b = {};
            H(ml, (c, d) => {
                d in a && (b[d] = a[d])
            });
            return b
        };
    var pl = a => {
        a = A(a, Ni, 3);
        return !a || r(a, 1) <= Date.now() ? !1 : !0
    };

    function ql(a) {
        if (P(ch)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? dj(b) : null
        } catch (d) {
            c = null
        }
        return c
    };
    var rl = class extends G {
        constructor(a) {
            super(a)
        }
        i() {
            return A(this, tk, 2)
        }
        l() {
            return E(this, 3)
        }
    };
    var tl = class extends G {
            constructor(a) {
                super(a, -1, sl)
            }
            i() {
                return sb(this, 1)
            }
            l() {
                return A(this, rl, 2)
            }
        },
        sl = [1];
    var vl = class extends G {
            constructor(a) {
                super(a, -1, ul)
            }
            getId() {
                return Db(this, 1)
            }
        },
        ul = [2];
    var xl = class extends G {
            constructor(a) {
                super(a, -1, wl)
            }
        },
        wl = [2];
    var zl = class extends G {
            constructor(a) {
                super(a, -1, yl)
            }
        },
        yl = [2];
    var Al = class extends G {
        constructor(a) {
            super(a)
        }
        i() {
            return Fb(r(this, 2), 0)
        }
        l() {
            return Fb(r(this, 4), 0)
        }
        m() {
            return E(this, 3)
        }
    };
    var Cl = class extends G {
            constructor(a) {
                super(a, -1, Bl)
            }
        },
        Bl = [1, 4, 2, 3];
    var Fl = class extends G {
            constructor(a) {
                super(a, -1, Dl)
            }
            l() {
                return Hb(this, rl, 13, El)
            }
            A() {
                return void 0 !== xb(this, rl, wb(this, El, 13))
            }
            i() {
                return Hb(this, tl, 14, El)
            }
            m() {
                return void 0 !== xb(this, tl, wb(this, El, 14))
            }
        },
        Dl = [19],
        El = [13, 14];
    let Gl = void 0;

    function Hl() {
        Xb(Gl, Vb);
        return Gl
    };
    var Kl = (a, b, c = "", d = null) => 1 === b && Il(c, d) ? !0 : Jl(a, c, e => Ea(B(e, Zb, 2), f => r(f, 1) === b)),
        Il = (a, b) => !b || E(b, 22) && !P(oh) ? !1 : b.A() ? E(b.l(), 1) : b.m() && "" !== a && 1 === b.i().i().length && b.i().i()[0] === a ? E(b.i().l(), 1) : !1,
        Ll = (a, b) => {
            b = Db(b, 18); - 1 !== b && (a.tmod = b)
        },
        Nl = a => {
            const b = Ic(J) || J;
            return Ml(b, a) ? !0 : Jl(J, "", c => Ea(qb(c, 3, !1), d => d === a))
        };

    function Ml(a, b) {
        a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
        return !!a && Ha(a.split(","), b.toString())
    }

    function Jl(a, b, c) {
        a = Ic(a) || a;
        const d = Ol(a);
        b && (b = sd(String(b)));
        return lc(d, (e, f) => Object.prototype.hasOwnProperty.call(d, f) && (!b || b === f) && c(e))
    }

    function Ol(a) {
        a = Pl(a);
        const b = {};
        H(a, (c, d) => {
            try {
                const e = new ac(c);
                b[d] = e
            } catch (e) {}
        });
        return b
    }
    var Pl = a => P(Zg) ? (a = ik({
        s: a,
        X: Hl()
    }), null != a.h ? Ql(a.h.value) : {}) : Ql(a.localStorage);

    function Ql(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : kc(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && "string" === typeof e && Array.isArray(d))
        } catch (b) {
            return {}
        }
    }

    function Rl(a) {
        P(kh) && Lj("atf_ad_settings_from_ppabg", {
            p_s: a
        }, .01)
    }
    const Sl = a => !!a && (0 < B(a, Qg, 1).length || P(dh) && 0 < B(a, Kg, 3).length);
    var Tl = () => {
        const a = [];
        P(hh) && a.push(1);
        P(gh) && a.push(2);
        P(ih) && a.push(7);
        return a
    };

    function U(a) {
        a.google_ad_modifications || (a.google_ad_modifications = {});
        return a.google_ad_modifications
    }

    function Ul(a) {
        a = U(a);
        const b = a.space_collapsing || "none";
        return a.remove_ads_by_default ? {
            Ka: !0,
            xb: b,
            ra: a.ablation_viewport_offset
        } : null
    }

    function Vl(a, b) {
        a = U(a);
        a.had_ads_ablation = !0;
        a.remove_ads_by_default = !0;
        a.space_collapsing = "slot";
        a.ablation_viewport_offset = b
    }

    function Wl(a) {
        U(J).allow_second_reactive_tag = a
    }

    function Xl() {
        const a = U(window);
        a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
        return a.afg_slotcar_vars
    };

    function Yl(a) {
        return a.document.querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };

    function Zl(a, b, c, d) {
        $l(new am(a, b, c, d))
    }

    function $l(a) {
        ig(hg(ik({
            s: a.s,
            X: E(a.i, 6)
        }), b => {
            bm(a, b, !0)
        }), () => {
            cm(a)
        })
    }

    function bm(a, b, c) {
        ig(hg(dm(b), d => {
            em("ok");
            a.h(d, {
                fromLocalStorage: !0
            })
        }), () => {
            var d = a.s;
            try {
                b.removeItem("google_ama_config")
            } catch (e) {
                nl(d, {
                    lserr: 1
                })
            }
            c ? cm(a) : a.h(null, null)
        })
    }

    function cm(a) {
        ig(hg(fm(a), b => {
            a.h(b, {
                fromPABGSettings: !0
            })
        }), () => {
            gm(a)
        })
    }

    function dm(a) {
        return (a = (a = ql(a)) ? pl(a) ? a : null : null) ? cg(a) : eg(Error("invlocst"))
    }

    function fm(a) {
        var b = a.s;
        if ((U(b) ? .head_tag_slot_vars ? .google_ad_host ? ? Yl(b)) && (!E(a.i, 22) || !P(nh))) return eg(Error("invtag"));
        a: {
            b = a.s;
            var c = a.j;a = a.i;
            if (a ? .A()) b = a ? .l() ? .i() ? .i(),
            Sl(b) ? Rl(!1) : b = null;
            else {
                if (a ? .m()) {
                    const d = a ? .i() ? .i(),
                        e = a ? .i() ? .l() ? .i() ? .i();
                    if (d && 1 === d.length && d[0] === c && Sl(e) && D(a, 17) === b.location.host) {
                        Rl(!0);
                        b = e;
                        break a
                    }
                }
                b = null
            }
        }
        b ? (c = new cj, a = B(b, Qg, 1), c = Cb(c, 1, a), a = B(b, Vi, 2), c = Cb(c, 7, a), P(dh) && 0 < B(b, Kg, 3).length && (a = new Mg, b = B(b, Kg, 3), b = Cb(a, 1, b), Ab(c, 6, b)), b = cg(c)) : b = eg(Error("invtag"));
        return b
    }

    function gm(a) {
        mk({
            s: a.s,
            X: E(a.i, 6),
            Ta: 50,
            callback: b => {
                hm(a, b)
            }
        })
    }

    function hm(a, b) {
        ig(hg(b, c => {
            bm(a, c, !1)
        }), c => {
            em(c.message);
            a.h(null, null)
        })
    }

    function em(a) {
        Lj("abg::amalserr", {
            status: a,
            guarding: "true",
            timeout: 50,
            rate: .01
        }, .01)
    }
    class am {
        constructor(a, b, c, d) {
            this.s = a;
            this.i = b;
            this.j = c;
            this.h = d
        }
    };
    var km = (a, b, c, d) => {
        try {
            const e = ll(a, B(c, Vi, 7));
            if (e && jl(e)) {
                r(e, 4) && (d = rg(d, new sg(null, {
                    google_package: r(e, 4)
                })));
                const f = new Ej(a, b, c, e, d);
                Bi(1E3, () => {
                    var g = new Yf;
                    (new wk(a, f, g)).start();
                    return g.i
                }, a).then(la(im, a), la(jm, a))
            }
        } catch (e) {
            nl(a, {
                atf: -1
            })
        }
    };
    const im = a => {
            nl(a, {
                atf: 1
            })
        },
        jm = (a, b) => {
            (a.google_ama_state = a.google_ama_state || {}).exception = b;
            nl(a, {
                atf: 0
            })
        };

    function lm(a) {
        if (P(xh)) {
            a.easpi = P(xh);
            P(wh) && (a.easpa = !0);
            a.asntp = 0;
            a.asntpv = 0;
            a.asntpl = 0;
            a.asntpm = 0;
            a.asntpc = Th(Fh);
            a.asna = 5;
            a.asnd = 5;
            a.asnp = 5;
            a.asns = 5;
            a.asmat = Th(Eh);
            a.asptt = -1;
            P(Jh) || (a.aspe = !0);
            a.asro = P(Hh);
            P(Gh) && (a.ascet = !0);
            P(Bh) && (a.asgr = !0);
            P(Ih) || (a.asrc = !1);
            P(zh) && (a.asbu = !0);
            P(Ah) && (a.aseb = !0);
            1 > Th(Ch) && (a.asla = Th(Ch));
            1 > Th(yh) && (a.asaa = Th(yh));
            P(Kh) && (a.asupm = !0);
            var b = Th(Dh);
            0 < b && (a.asmrc = b)
        }
    };
    La || !p("Safari") || va();
    class mm {
        constructor() {
            this.promise = new Promise(a => {
                this.resolve = a
            })
        }
    };

    function nm() {
        const {
            promise: a,
            resolve: b
        } = new mm;
        return {
            promise: a,
            resolve: b
        }
    };

    function om(a = () => {}) {
        n.google_llp || (n.google_llp = {});
        const b = n.google_llp;
        let c = b[7];
        if (c) return c;
        c = nm();
        b[7] = c;
        a();
        return c
    }

    function pm(a) {
        return om(() => {
            Jc(n.document, a)
        }).promise
    };
    var qm = a => {
        if (n.google_apltlad || n !== n.top || !a.google_ad_client) return null;
        n.google_apltlad = !0;
        const b = {
                enable_page_level_ads: {
                    pltais: !0
                },
                google_ad_client: a.google_ad_client
            },
            c = b.enable_page_level_ads;
        H(a, (d, e) => {
            ui[e] && "google_ad_client" !== e && (c[e] = d)
        });
        c.google_pgb_reactive = 7;
        lm(c);
        if ("google_ad_section" in a || "google_ad_region" in a) c.google_ad_section = a.google_ad_section || a.google_ad_region;
        return b
    };

    function rm(a) {
        return da(a.enable_page_level_ads) && 7 === a.enable_page_level_ads.google_pgb_reactive
    };
    var um = (a, b) => {
        U(J).ama_ran_on_page || Bi(1001, () => sm(new tm(a, b)), n)
    };

    function sm(a) {
        Zl(a.h, a.j, a.i.google_ad_client || "", (b, c) => {
            var d = a.h,
                e = a.i;
            U(J).ama_ran_on_page || b && vm(d, e, b, c)
        })
    }
    class tm {
        constructor(a, b) {
            this.h = n;
            this.i = a;
            this.j = b
        }
    }

    function vm(a, b, c, d) {
        d && (Gi(a).configSourceInAbg = d);
        void 0 !== xb(c, aj, 24, !1) && (d = Hi(a), d.availableAbg = !0, d.ablationFromStorage = !!A(c, aj, 24) ? .i() ? .i());
        if (rm(b) && (d = ll(a, B(c, Vi, 7)), !d || !rb(d, 8))) return;
        U(J).ama_ran_on_page = !0;
        A(c, Mi, 15) ? .i() && (U(a).enable_overlap_observer = !0);
        var e = A(c, Li, 13);
        e && 1 === r(e, 1) ? (d = 0, (e = A(e, Ki, 6)) && r(e, 3) && (d = r(e, 3) || 0), Vl(a, d)) : A(c, aj, 24) ? .i() ? .i() && (Hi(a).ablatingThisPageview = !0, Vl(a, 1));
        kd(3, [c.toJSON()]);
        const f = b.google_ad_client || "";
        b = ol(da(b.enable_page_level_ads) ?
            b.enable_page_level_ads : {});
        const g = rg(vg, new sg(null, b));
        Jj(782, () => {
            km(a, f, c, g)
        })
    };
    var wm = {
            google_ad_modifications: !0,
            google_analytics_domain_name: !0,
            google_analytics_uacct: !0,
            google_pause_ad_requests: !0,
            google_user_agent_client_hint: !0
        },
        xm = a => (a = a.innerText || a.innerHTML) && (a = a.replace(/^\s+/, "").split(/\r?\n/, 1)[0].match(/^\x3c!--+(.*?)(?:--+>)?\s*$/)) && RegExp("google_ad_client").test(a[1]) ? a[1] : null,
        ym = a => {
            if (a = a.innerText || a.innerHTML)
                if (a = a.replace(/^\s+|\s+$/g, "").replace(/\s*(\r?\n)+\s*/g, ";"), (a = a.match(/^\x3c!--+(.*?)(?:--+>)?$/) || a.match(/^\/*\s*<!\[CDATA\[(.*?)(?:\/*\s*\]\]>)?$/i)) &&
                    RegExp("google_ad_client").test(a[1])) return a[1];
            return null
        },
        zm = a => {
            switch (a) {
                case "true":
                    return !0;
                case "false":
                    return !1;
                case "null":
                    return null;
                case "undefined":
                    break;
                default:
                    try {
                        const b = a.match(/^(?:'(.*)'|"(.*)")$/);
                        if (b) return b[1] || b[2] || "";
                        if (/^[-+]?\d*(\.\d+)?$/.test(a)) {
                            const c = parseFloat(a);
                            return c === c ? c : void 0
                        }
                    } catch (b) {}
            }
        };

    function Am(a) {
        if (a.google_ad_client) var b = String(a.google_ad_client);
        else {
            if (null == (b = U(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client"))) {
                b: {
                    b = a.document.getElementsByTagName("script");a = a.navigator && a.navigator.userAgent || "";a = RegExp("appbankapppuzdradb|daumapps|fban|fbios|fbav|fb_iab|gsa/|messengerforios|naver|niftyappmobile|nonavigation|pinterest|twitter|ucbrowser|yjnewsapp|youtube", "i").test(a) || /i(phone|pad|pod)/i.test(a) &&
                    /applewebkit/i.test(a) && !/version|safari/i.test(a) && !rd() ? xm : ym;
                    for (var c = b.length - 1; 0 <= c; c--) {
                        var d = b[c];
                        if (!d.google_parsed_script_for_pub_code && (d.google_parsed_script_for_pub_code = !0, d = a(d))) {
                            b = d;
                            break b
                        }
                    }
                    b = null
                }
                if (b) {
                    a = /(google_\w+) *= *(['"]?[\w.-]+['"]?) *(?:;|$)/gm;
                    for (c = {}; d = a.exec(b);) c[d[1]] = zm(d[2]);
                    b = c;
                    b = b.google_ad_client ? b.google_ad_client : ""
                } else b = ""
            }
            b = b ? ? ""
        }
        return b
    };
    async function Bm(a, b) {
        var c = 10;
        return 0 >= c ? Promise.reject() : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e())
            }, 200)
        })
    };

    function Cm(a) {
        const b = a.state.pc;
        return null !== b && 0 !== b ? b : a.state.pc = ad(a.s)
    }

    function Dm(a) {
        const b = a.state.wpc;
        return null !== b && "" !== b ? b : a.state.wpc = Am(a.s)
    }

    function Em(a, b) {
        var c = new ze;
        var d = Cm(a);
        c = z(c, 1, d, 0);
        d = Dm(a);
        c = z(c, 2, d, "");
        c = z(c, 3, a.state.sd, 0);
        return z(c, 7, Math.round(b || a.s.performance.now()), 0)
    }
    async function Fm(a) {
        await Bm(a.s, () => !(!Cm(a) || !Dm(a)))
    }
    async function Gm() {
        var a = K(Hm);
        if (a.i && !a.state.le.includes(1)) {
            a.state.le.push(1);
            var b = a.s.performance.now();
            await Fm(a);
            var c = se(te(new ve, qe(pe(new re, N(a.s).scrollWidth), N(a.s).scrollHeight)), qe(pe(new re, N(a.s).clientWidth), N(a.s).clientHeight)),
                d = $h(a.s);
            0 !== d && ue(c, ne(new oe, d));
            We(a.h, xe(Em(a, b), c));
            jf(a.h, a.s, () => {
                var e = a.h;
                var f = Em(a);
                var g = new we;
                f = Bb(f, 8, ye, g);
                We(e, f)
            })
        }
    }
    async function Im(a, b, c) {
        if (a.i && c.length && !a.state.lgdp.includes(Number(b))) {
            a.state.lgdp.push(Number(b));
            var d = a.s.performance.now();
            await Fm(a);
            var e = a.h;
            a = Em(a, d);
            d = new me;
            b = z(d, 1, b, 0);
            c = tb(b, 2, c);
            c = Bb(a, 9, ye, c);
            We(e, c)
        }
    }
    var Hm = class {
        constructor(a) {
            this.s = md() || window;
            this.h = a ? ? new lf(100, 100, !0);
            if (P($g)) this.state = Uj(Pj(), 33, () => {
                const b = Th(ah);
                return {
                    sd: b,
                    ssp: 0 < b && Pc() < 1 / b,
                    pc: null,
                    wpc: null,
                    le: [],
                    lgdp: []
                }
            });
            else {
                a = Th(ah);
                const b = Wj(0 < a && Pc() < 1 / a);
                this.state = {
                    sd: a,
                    ssp: b,
                    pc: null,
                    wpc: null,
                    le: [],
                    lgdp: []
                }
            }
        }
        get i() {
            return this.state.ssp
        }
    };

    function Jm(a, b) {
        return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1
    }

    function Km(a) {
        var b = J.document;
        if (b.currentScript) return Jm(b.currentScript, a);
        for (const c of b.scripts)
            if (0 === Jm(c, a)) return 0;
        return 1
    };

    function Lm(a, b) {
        return {
            [3]: {
                [55]: () => 0 === a,
                [23]: c => Kl(J, Number(c)),
                [24]: c => Nl(Number(c)),
                [61]: () => E(b, 6),
                [63]: () => E(b, 6) || ".google.ch" === D(b, 8)
            },
            [4]: {
                [7]: c => {
                    try {
                        var d = window.localStorage
                    } catch (g) {
                        d = null
                    }
                    c = Number(c);
                    c = 0 !== c ? `${"google_experiment_mod"}${c}` : "google_experiment_mod";
                    a: {
                        var e = -1;
                        try {
                            d && (e = parseInt(d.getItem(c), 10))
                        } catch {
                            e = null;
                            break a
                        }
                        e = 0 <= e && 1E3 > e ? e : null
                    }
                    if (null === e) {
                        const g = Oc() ? null : Math.floor(1E3 * Pc());
                        if (e = null != g && d) a: {
                            var f = String(g);
                            try {
                                if (d) {
                                    d.setItem(c, f);
                                    e = f;
                                    break a
                                }
                            } catch {}
                            e =
                            null
                        }
                        d = e ? g : null
                    } else d = e;
                    return d ? ? void 0
                }
            },
            [5]: {
                [6]: () => D(b, 15)
            }
        }
    };

    function Mm(a = n) {
        return a.ggeac || (a.ggeac = {})
    };

    function Nm() {
        var a = K(Sh).h(rh.h, rh.defaultValue);
        $c(a, J.document)
    }

    function Om(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function Pm(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    };

    function Qm(a, b) {
        try {
            const d = a.split(".");
            a = n;
            let e = 0,
                f;
            for (; null != a && e < d.length; e++) f = a, a = a[d[e]], "function" === typeof a && (a = f[d[e]]());
            var c = a;
            if (typeof c === b) return c
        } catch {}
    }
    var Rm = {
        [3]: {
            [8]: a => {
                try {
                    return null != ba(a)
                } catch {}
            },
            [9]: a => {
                try {
                    var b = ba(a)
                } catch {
                    return
                }
                if (a = "function" === typeof b) b = b && b.toString && b.toString(), a = "string" === typeof b && -1 != b.indexOf("[native code]");
                return a
            },
            [10]: () => window === window.top,
            [6]: a => Ha(K(Pf).i(), Number(a)),
            [27]: a => {
                a = Qm(a, "boolean");
                return void 0 !== a ? a : void 0
            },
            [60]: a => {
                try {
                    return !!n.document.querySelector(a)
                } catch {}
            },
            [69]: a => Om(a, n.document),
            [70]: a => Pm(a, n.document)
        },
        [4]: {
            [3]: () => Wc(),
            [6]: a => {
                a = Qm(a, "number");
                return void 0 !== a ? a : void 0
            }
        },
        [5]: {
            [2]: () => window.location.href,
            [3]: () => {
                try {
                    return window.top.location.hash
                } catch {
                    return ""
                }
            },
            [4]: a => {
                a = Qm(a, "string");
                return void 0 !== a ? a : void 0
            }
        }
    };
    const Sm = [12, 13, 20];

    function Tm(a, b, c, d) {
        const e = K(sf).G;
        if (!de(A(b, Xd, 3), e)) return null;
        var f = B(b, vl, 2),
            g = F(b, 6);
        if (g) {
            ub(d, 1, Ee, g);
            f = e[4];
            switch (c) {
                case 2:
                    var h = f[8];
                    break;
                case 1:
                    h = f[7]
            }
            c = void 0;
            if (h) try {
                c = h(g), z(d, 3, c, 0)
            } catch (l) {}
            return (b = Um(b, c)) ? Vm(a, [b], 1) : null
        }
        if (g = F(b, 10)) {
            ub(d, 2, Ee, g);
            h = null;
            switch (c) {
                case 1:
                    h = e[4][9];
                    break;
                case 2:
                    h = e[4][10];
                    break;
                default:
                    return null
            }
            c = h ? h(String(g)) : void 0;
            if (void 0 === c && 1 === F(b, 11)) return null;
            void 0 !== c && z(d, 3, c, 0);
            return (b = Um(b, c)) ? Vm(a, [b], 1) : null
        }
        d = e ? Aa(f, l => de(A(l, Xd,
            3), e)) : f;
        if (!d.length) return null;
        c = d.length * Eb(b, 1);
        return (b = F(b, 4)) ? Wm(a, b, c, d) : Vm(a, d, c / 1E3)
    }

    function Xm(a, b, c) {
        a.Z[c] || (a.Z[c] = []);
        a = a.Z[c];
        Ha(a, b) || a.push(b)
    }

    function Ym(a, b, c) {
        const d = [],
            e = Zm(a.i, b);
        var f;
        if (f = 9 !== b) a.j[b] ? f = !0 : (a.j[b] = !0, f = !1);
        if (f) return nf(a.J, b, c, d, [], 4), d;
        if (!e.length) return nf(a.J, b, c, d, [], 3), d;
        const g = Ha(Sm, b),
            h = [];
        za(e, l => {
            var k = new De;
            if (l = Tm(a, l, c, k)) 0 !== vb(k, Ee) && h.push(k), k = l.getId(), d.push(k), Xm(a, k, g ? 4 : c), (l = B(l, ie, 2)) && (g ? Gf(l, If(), a.J, k) : Gf(l, [c], a.J, k))
        });
        nf(a.J, b, c, d, h, 1);
        return d
    }

    function $m(a, b) {
        a.i.push(...Aa(Da(b, c => new zl(c)), c => !Ha(Sm, F(c, 1))))
    }

    function Vm(a, b, c) {
        const d = a.h,
            e = Fa(b, f => !!d[f.getId()]);
        return e ? e : a.la ? null : Mc(b, c)
    }

    function Wm(a, b, c, d) {
        const e = null != a.ha[b] ? a.ha[b] : 1E3;
        if (0 >= e) return null;
        d = Vm(a, d, c / e);
        a.ha[b] = d ? 0 : e - c;
        return d
    }

    function an(a, b) {
        L(1, c => {
            a.h[c] = !0
        }, b);
        L(2, (c, d) => Ym(a, c, d), b);
        L(3, c => (a.Z[c] || []).concat(a.Z[4]), b);
        L(12, c => void $m(a, c), b);
        L(16, (c, d) => void Xm(a, c, d), b)
    }
    var bn = class {
        constructor() {
            this.i = [];
            this.J = null;
            this.j = {};
            this.la = !1;
            this.ha = {};
            this.Z = {};
            this.h = {}
        }
        init(a, b, c, {
            la: d = !1,
            Z: e = [],
            ha: f = {}
        } = {}) {
            this.i = a.slice();
            this.J = c;
            this.j = {};
            this.la = d;
            this.ha = f;
            this.Z = {
                [b]: [],
                [4]: []
            };
            this.h = {};
            (a = Id()) && za(a.split(",") || [], g => {
                (g = Number(g)) && (this.h[g] = !0)
            });
            za(e, g => {
                this.h[g] = !0
            });
            return this
        }
    };

    function Zm(a, b) {
        return (a = Fa(a, c => F(c, 1) === b)) && B(a, xl, 2) || []
    }

    function Um(a, b) {
        var c = B(a, vl, 2),
            d = c.length,
            e = Eb(a, 8);
        a = d * Eb(a, 1) - 1;
        b = void 0 !== b ? b : Math.floor(1E3 * Pc());
        d = (b - e) % d;
        if (b < e || b - e - d >= a) return null;
        c = c[d];
        e = K(sf).G;
        return !c || e && !de(A(c, Xd, 3), e) ? null : c
    };

    function cn(a, b) {
        a.h = Kf(14, b, () => {})
    }
    class dn {
        constructor() {
            this.h = () => {}
        }
    }

    function en(a) {
        K(dn).h(a)
    };

    function fn({
        fb: a,
        G: b,
        cb: c,
        Ya: d = Mm(),
        Za: e = 0,
        J: f = new rf(A(a, Al, 5) ? .i() ? ? 0, A(a, Al, 5) ? .l() ? ? 0, A(a, Al, 5) ? .m() ? ? !1)
    }) {
        d.hasOwnProperty("init-done") ? (Kf(12, d, () => {})(Da(B(a, zl, 2), g => g.toJSON())), Kf(13, d, () => {})(Da(B(a, ie, 1), g => g.toJSON()), e), b && Kf(14, d, () => {})(b), gn(e, d)) : (an(K(bn).init(B(a, zl, 2), e, f, c), d), Lf(d), Mf(d), Nf(d), gn(e, d), Gf(B(a, ie, 1), [e], f, void 0, !0), tf = tf || !(!c || !c.jb), en(Rm), b && en(b))
    }

    function gn(a, b = Mm()) {
        Of(K(Pf), b, a);
        hn(b, a);
        cn(K(dn), b);
        K(Sh).m()
    }

    function hn(a, b) {
        const c = K(Sh);
        c.i = (d, e) => Kf(5, a, () => !1)(d, e, b);
        c.j = (d, e) => Kf(6, a, () => 0)(d, e, b);
        c.l = (d, e) => Kf(7, a, () => "")(d, e, b);
        c.h = (d, e) => Kf(8, a, () => [])(d, e, b);
        c.m = () => {
            Kf(15, a, () => {})(b)
        }
    };

    function jn(a) {
        var b = K(Pf).l(a);
        a = Im(K(Hm), a, b);
        Rf.ca(1085, a)
    }
    var kn = (a, b, c) => {
        var d = U(a);
        if (d.plle) gn(1, Mm(a));
        else {
            d.plle = !0;
            d = A(b, Cl, 12);
            var e = E(b, 9);
            fn({
                fb: d,
                G: Lm(c, b),
                cb: {
                    la: e && !!a.google_disable_experiments,
                    jb: e
                },
                Ya: Mm(a),
                Za: 1
            });
            if (c = D(b, 15)) c = Number(c), K(Pf).j(c);
            for (const f of qb(b, 19)) b = f, K(Pf).h(b);
            jn(12);
            jn(10);
            a = Ic(a) || a;
            uj(a.location, "google_mc_lab") && K(Pf).h(44738307);
            uj(a.location, "google_auto_storify_swipeable") && K(Pf).h(44773747);
            uj(a.location, "google_auto_storify_scrollable") && K(Pf).h(44773746);
            uj(a.location, "google_pga_monetization") && K(Pf).h(44779794)
        }
    };
    var ln = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function mn(a, b) {
        if (15 == b) {
            if (728 <= a) return 728;
            if (468 <= a) return 468
        } else if (90 == b) {
            if (200 <= a) return 200;
            if (180 <= a) return 180;
            if (160 <= a) return 160;
            if (120 <= a) return 120
        }
        return null
    };

    function nn(a) {
        return b => !!(b.ja & a)
    }
    class V extends mi {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.ja = c;
            this.kb = d
        }
        qa() {
            return this.ja
        }
        i(a, b, c) {
            b.google_ad_resize || (c.style.height = this.height() + "px", b.rpe = !0)
        }
    };
    const on = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        pn = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        qn = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function rn(a) {
        var b = 0;
        a.V && b++;
        a.N && b++;
        a.O && b++;
        if (3 > b) return {
            P: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.V.split(",");
        const c = a.O.split(",");
        a = a.N.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            P: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (2 < b.length) return {
            P: "The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while " + `you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        const d = [],
            e = [];
        for (let g = 0; g <
            b.length; g++) {
            var f = Number(c[g]);
            if (Number.isNaN(f) || 0 === f) return {
                P: `Wrong value '${c[g]}' for ${"data-matched-content-rows-num"}.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || 0 === f) return {
                P: `Wrong value '${a[g]}' for ${"data-matched-content-columns-num"}.`
            };
            e.push(f)
        }
        return {
            O: d,
            N: e,
            Qa: b
        }
    }

    function sn(a) {
        return 1200 <= a ? {
            width: 1200,
            height: 600
        } : 850 <= a ? {
            width: a,
            height: Math.floor(.5 * a)
        } : 550 <= a ? {
            width: a,
            height: Math.floor(.6 * a)
        } : 468 <= a ? {
            width: a,
            height: Math.floor(.7 * a)
        } : {
            width: a,
            height: Math.floor(3.44 * a)
        }
    };
    const tn = Ka("script");

    function un(a, b, c) {
        null != a.ja && (c.google_responsive_formats = a.ja);
        null != a.T && (c.google_safe_for_responsive_override = a.T);
        null != a.i && (!0 === a.i ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = a.i));
        null != a.j && !0 !== a.j && (c.gfwrnher = a.j);
        var d = a.m || c.google_ad_width;
        null != d && (c.google_resizing_width = d);
        d = a.l || c.google_ad_height;
        null != d && (c.google_resizing_height = d);
        d = a.size().h(b);
        const e = a.size().height();
        if (!c.google_ad_resize) {
            c.google_ad_width = d;
            c.google_ad_height =
                e;
            var f = a.size();
            b = f.h(b) + "x" + f.height();
            c.google_ad_format = b;
            c.google_responsive_auto_format = a.A;
            null != a.h && (c.armr = a.h);
            c.google_ad_resizable = !0;
            c.google_override_format = 1;
            c.google_loader_features_used = 128;
            !0 === a.i && (c.gfwrnh = a.size().height() + "px")
        }
        null != a.C && (c.gfwroml = a.C);
        null != a.K && (c.gfwromr = a.K);
        null != a.l && (c.gfwroh = a.l);
        null != a.m && (c.gfwrow = a.m);
        null != a.R && (c.gfwroz = a.R);
        null != a.v && (c.gml = a.v);
        null != a.B && (c.gmr = a.B);
        null != a.U && (c.gzi = a.U);
        b = Ic(window) || window;
        uj(b.location, "google_responsive_dummy_ad") &&
            (Ha([1, 2, 3, 4, 5, 6, 7, 8], a.A) || 1 === a.h) && 2 !== a.h && (a = JSON.stringify({
                googMsgType: "adpnt",
                key_value: [{
                    key: "qid",
                    value: "DUMMY_AD"
                }]
            }), c.dash = `<${tn}>window.top.postMessage('${a}', '*'); 
          </${tn}> 
          <div id="dummyAd" style="width:${d}px;height:${e}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${e}</p> 
            <p>Rendered size:${d}x${e}</p> 
          </div>`)
    }
    class vn {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, l = null, k = null, m = null, u = null) {
            this.A = a;
            this.fa = b;
            this.ja = c;
            this.h = d;
            this.T = e;
            this.i = f;
            this.j = g;
            this.C = h;
            this.K = l;
            this.l = k;
            this.m = m;
            this.R = u;
            this.U = this.B = this.v = null
        }
        size() {
            return this.fa
        }
    };
    const wn = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var xn = class extends mi {
            h(a) {
                return Math.min(1200, Math.max(this.M, Math.round(a)))
            }
        },
        An = (a, b) => {
            yn(a, b);
            if ("pedestal" == b.google_content_recommendation_ui_type) return new vn(9, new xn(a, Math.floor(a * b.google_phwr)));
            var c = Cc();
            468 > a ? c ? (c = a - 8 - 8, c = Math.floor(c / 1.91 + 70) + Math.floor(11 * (c * on.mobile_banner_image_sidebyside + pn.mobile_banner_image_sidebyside) + 96), a = {
                ea: a,
                da: c,
                N: 1,
                O: 12,
                V: "mobile_banner_image_sidebyside"
            }) : (a = sn(a), a = {
                ea: a.width,
                da: a.height,
                N: 1,
                O: 13,
                V: "image_sidebyside"
            }) : (a = sn(a), a = {
                ea: a.width,
                da: a.height,
                N: 4,
                O: 2,
                V: "image_stacked"
            });
            zn(b, a);
            return new vn(9, new xn(a.ea, a.da))
        },
        Bn = (a, b) => {
            yn(a, b);
            var c = rn({
                O: b.google_content_recommendation_rows_num,
                N: b.google_content_recommendation_columns_num,
                V: b.google_content_recommendation_ui_type
            });
            if (c.P) a = {
                ea: 0,
                da: 0,
                N: 0,
                O: 0,
                V: "image_stacked",
                P: c.P
            };
            else {
                var d = 2 === c.Qa.length && 468 <= a ? 1 : 0;
                var e = c.Qa[d];
                e = 0 === e.indexOf("pub_control_") ? e : "pub_control_" + e;
                var f = qn[e];
                let g = c.N[d];
                for (; a / g < f && 1 < g;) g--;
                f = g;
                d = c.O[d];
                c = Math.floor(((a - 8 * f - 8) / f * on[e] + pn[e]) *
                    d + 8 * d + 8);
                a = 1500 < a ? {
                    width: 0,
                    height: 0,
                    vb: "Calculated slot width is too large: " + a
                } : 1500 < c ? {
                    width: 0,
                    height: 0,
                    vb: "Calculated slot height is too large: " + c
                } : {
                    width: a,
                    height: c
                };
                a = {
                    ea: a.width,
                    da: a.height,
                    N: f,
                    O: d,
                    V: e
                }
            }
            if (a.P) throw new Q(a.P);
            zn(b, a);
            return new vn(9, new xn(a.ea, a.da))
        };

    function yn(a, b) {
        if (0 >= a) throw new Q("Invalid responsive width from Matched Content slot " + b.google_ad_slot + ": " + a + ". Please ensure to put this Matched Content slot into a non-zero width div container.");
    }

    function zn(a, b) {
        a.google_content_recommendation_ui_type = b.V;
        a.google_content_recommendation_columns_num = b.N;
        a.google_content_recommendation_rows_num = b.O
    };
    class Cn extends mi {
        h() {
            return this.M
        }
        i(a, b, c) {
            li(a, c);
            b.google_ad_resize || (c.style.height = this.height() + "px", b.rpe = !0)
        }
    };
    const Dn = {
        "image-top": a => 600 >= a ? 284 + .414 * (a - 250) : 429,
        "image-middle": a => 500 >= a ? 196 - .13 * (a - 250) : 164 + .2 * (a - 500),
        "image-side": a => 500 >= a ? 205 - .28 * (a - 250) : 134 + .21 * (a - 500),
        "text-only": a => 500 >= a ? 187 - .228 * (a - 250) : 130,
        "in-article": a => 420 >= a ? a / 1.2 : 460 >= a ? a / 1.91 + 130 : 800 >= a ? a / 4 : 200
    };
    var En = class extends mi {
            h() {
                return Math.min(1200, this.M)
            }
        },
        Fn = (a, b, c, d, e) => {
            var f = e.google_ad_layout || "image-top";
            if ("in-article" == f) {
                var g = a;
                if ("false" == e.google_full_width_responsive) a = g;
                else if (a = gi(b, c, g, .2, e), !0 !== a) e.gfwrnwer = a, a = g;
                else if (a = N(b).clientWidth)
                    if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                        b: {
                            g = c;
                            for (let h = 0; 100 > h && g.parentElement; ++h) {
                                const l = g.parentElement.childNodes;
                                for (let k = 0; k < l.length; ++k) {
                                    const m = l[k];
                                    if (m != g && ji(b, m)) break b
                                }
                                g = g.parentElement;
                                g.style.width =
                                    "100%";
                                g.style.height = "auto"
                            }
                        }
                        li(b, c)
                    }
                else a = g;
                else a = g
            }
            if (250 > a) throw new Q("Fluid responsive ads must be at least 250px wide: availableWidth=" + a);
            a = Math.min(1200, Math.floor(a));
            if (d && "in-article" != f) {
                f = Math.ceil(d);
                if (50 > f) throw new Q("Fluid responsive ads must be at least 50px tall: height=" + f);
                return new vn(11, new mi(a, f))
            }
            if ("in-article" != f && (d = e.google_ad_layout_key)) {
                f = "" + d;
                c = Math.pow(10, 3);
                if (e = (d = f.match(/([+-][0-9a-z]+)/g)) && d.length)
                    for (b = [], g = 0; g < e; g++) b.push(parseInt(d[g], 36) / c);
                else b =
                    null;
                if (!b) throw new Q("Invalid data-ad-layout-key value: " + f);
                f = (a + -725) / 1E3;
                c = 0;
                d = 1;
                e = b.length;
                for (g = 0; g < e; g++) c += b[g] * d, d *= f;
                f = Math.ceil(1E3 * c - -725 + 10);
                if (isNaN(f)) throw new Q("Invalid height: height=" + f);
                if (50 > f) throw new Q("Fluid responsive ads must be at least 50px tall: height=" + f);
                if (1200 < f) throw new Q("Fluid responsive ads must be at most 1200px tall: height=" + f);
                return new vn(11, new mi(a, f))
            }
            d = Dn[f];
            if (!d) throw new Q("Invalid data-ad-layout value: " + f);
            c = pi(c, b);
            b = N(b).clientWidth;
            b = "in-article" !==
                f || c || a !== b ? Math.ceil(d(a)) : Math.ceil(1.25 * d(a));
            return new vn(11, "in-article" == f ? new En(a, b) : new mi(a, b))
        };
    var Gn = a => b => {
            for (let c = a.length - 1; 0 <= c; --c)
                if (!a[c](b)) return !1;
            return !0
        },
        In = (a, b) => {
            var c = Hn.slice(0);
            const d = c.length;
            let e = null;
            for (let f = 0; f < d; ++f) {
                const g = c[f];
                if (a(g)) {
                    if (!b || b(g)) return g;
                    null === e && (e = g)
                }
            }
            return e
        };
    var W = [new V(970, 90, 2), new V(728, 90, 2), new V(468, 60, 2), new V(336, 280, 1), new V(320, 100, 2), new V(320, 50, 2), new V(300, 600, 4), new V(300, 250, 1), new V(250, 250, 1), new V(234, 60, 2), new V(200, 200, 1), new V(180, 150, 1), new V(160, 600, 4), new V(125, 125, 1), new V(120, 600, 4), new V(120, 240, 4), new V(120, 120, 1, !0)],
        Hn = [W[6], W[12], W[3], W[0], W[7], W[14], W[1], W[8], W[10], W[4], W[15], W[2], W[11], W[5], W[13], W[9], W[16]];
    var Kn = (a, b, c, d, e) => {
            "false" == e.google_full_width_responsive ? c = {
                D: a,
                F: 1
            } : "autorelaxed" == b && e.google_full_width_responsive || Jn(b) || e.google_ad_resize ? (b = hi(a, c, d, e), c = !0 !== b ? {
                D: a,
                F: b
            } : {
                D: N(c).clientWidth || a,
                F: !0
            }) : c = {
                D: a,
                F: 2
            };
            const {
                D: f,
                F: g
            } = c;
            return !0 !== g ? {
                D: a,
                F: g
            } : d.parentElement ? {
                D: f,
                F: g
            } : {
                D: a,
                F: g
            }
        },
        Nn = (a, b, c, d, e) => {
            const {
                D: f,
                F: g
            } = Jj(247, () => Kn(a, b, c, d, e));
            var h = !0 === g;
            const l = I(d.style.width),
                k = I(d.style.height),
                {
                    ba: m,
                    Y: u,
                    qa: v,
                    Pa: y
                } = Ln(f, b, c, d, e, h);
            h = Mn(b, v);
            var w;
            const C = (w = ni(d, c, "marginLeft",
                    I)) ? w + "px" : "",
                Ba = (w = ni(d, c, "marginRight", I)) ? w + "px" : "";
            w = ni(d, c, "zIndex") || "";
            return new vn(h, m, v, null, y, g, u, C, Ba, k, l, w)
        },
        Jn = a => "auto" == a || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a),
        Ln = (a, b, c, d, e, f) => {
            b = "auto" == b ? .25 >= a / Math.min(1200, N(c).clientWidth) ? 4 : 3 : fi(b);
            let g;
            var h = !1;
            let l = !1;
            var k = 488 > N(c).clientWidth;
            if (k) {
                g = ai(d, c);
                var m = pi(d, c);
                h = !m && g;
                l = m && g
            }
            m = [oi(a), nn(b)];
            m.push(ri(k, c, d, l));
            null != e.google_max_responsive_height && m.push(si(e.google_max_responsive_height));
            k = [w => !w.kb];
            if (h || l) h = ti(c, d), k.push(si(h));
            let u = In(Gn(m), Gn(k));
            if (!u) throw new Q("No slot size for availableWidth=" + a);
            const {
                ba: v,
                Y: y
            } = Jj(248, () => {
                var w;
                a: if (f) {
                    if (e.gfwrnh && (w = I(e.gfwrnh))) {
                        w = {
                            ba: new Cn(a, w),
                            Y: !0
                        };
                        break a
                    }
                    w = a / 1.2;
                    var C = Math;
                    var Ba = C.min;
                    if (e.google_resizing_allowed || "true" == e.google_full_width_responsive) var T = Infinity;
                    else {
                        T = d;
                        let sa = Infinity;
                        do {
                            var Ca = ni(T, c, "height", I);
                            Ca && (sa = Math.min(sa, Ca));
                            (Ca = ni(T, c, "maxHeight", I)) && (sa = Math.min(sa, Ca))
                        } while ((T = T.parentElement) && "HTML" != T.tagName);
                        T = sa
                    }
                    C = Ba.call(C, w, T);
                    if (C < .5 * w || 100 > C) C = w;
                    w = {
                        ba: new Cn(a, Math.floor(C)),
                        Y: C < w ? 102 : !0
                    }
                } else w = {
                    ba: u,
                    Y: 100
                };
                return w
            });
            return "in-article" === e.google_ad_layout && c.location && "#hffwroe2etoq" == c.location.hash ? {
                ba: On(a, c, d, v, e),
                Y: !1,
                qa: b,
                Pa: g
            } : {
                ba: v,
                Y: y,
                qa: b,
                Pa: g
            }
        };
    const Mn = (a, b) => {
            if ("auto" == a) return 1;
            switch (b) {
                case 2:
                    return 2;
                case 1:
                    return 3;
                case 4:
                    return 4;
                case 3:
                    return 5;
                case 6:
                    return 6;
                case 5:
                    return 7;
                case 7:
                    return 8
            }
            throw Error("bad mask");
        },
        On = (a, b, c, d, e) => {
            const f = e.google_ad_height || ni(c, b, "height", I);
            b = Fn(a, b, c, f, e).size();
            return b.M * b.height() > a * d.height() ? new V(b.M, b.height(), 1) : d
        };
    var Pn = (a, b, c, d, e) => {
        var f;
        (f = N(b).clientWidth) ? 488 > N(b).clientWidth ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, li(b, c), f = {
            D: f,
            F: !0
        }) : f = {
            D: a,
            F: 5
        } : f = {
            D: a,
            F: 4
        }: f = {
            D: a,
            F: 10
        };
        const {
            D: g,
            F: h
        } = f;
        if (!0 !== h || a == g) return new vn(12, new mi(a, d), null, null, !0, h, 100);
        const {
            ba: l,
            Y: k,
            qa: m
        } = Ln(g, "auto", b, c, e, !0);
        return new vn(1, l, m, 2, !0, h, k)
    };
    var Rn = (a, b) => {
            const c = b.google_ad_format;
            if ("autorelaxed" == c) {
                a: {
                    if ("pedestal" != b.google_content_recommendation_ui_type)
                        for (const d of wn)
                            if (null != b[d]) {
                                a = !0;
                                break a
                            }
                    a = !1
                }
                return a ? 9 : 5
            }
            if (Jn(c)) return 1;
            if ("link" === c) return 4;
            if ("fluid" == c) return "in-article" !== b.google_ad_layout || !a.location || "#hffwroe2etop" != a.location.hash && "#hffwroe2etoq" != a.location.hash ? 8 : (Qn(b), 1);
            if (27 === b.google_reactive_ad_format) return Qn(b), 1
        },
        Tn = (a, b, c, d, e = !1) => {
            e = b.offsetWidth || (c.google_ad_resize || e) && ni(b, d, "width",
                I) || c.google_ad_width || 0;
            4 === a && (c.google_ad_format = "auto", a = 1);
            var f = (f = Sn(a, e, b, c, d)) ? f : Nn(e, c.google_ad_format, d, b, c);
            f.size().i(d, c, b);
            un(f, e, c);
            1 != a && (a = f.size().height(), b.style.height = a + "px")
        };
    const Sn = (a, b, c, d, e) => {
            const f = d.google_ad_height || ni(c, e, "height", I);
            switch (a) {
                case 5:
                    const {
                        D: g,
                        F: h
                    } = Jj(247, () => Kn(b, d.google_ad_format, e, c, d));
                    !0 === h && b != g && li(e, c);
                    !0 === h ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                    return An(g, d);
                case 9:
                    return Bn(b, d);
                case 8:
                    return Fn(b, e, c, f, d);
                case 10:
                    return Pn(b, e, c, f, d)
            }
        },
        Qn = a => {
            a.google_ad_format = "auto";
            a.armr = 3
        };

    function Un(a, b) {
        var c = Ic(b);
        if (c) {
            c = N(c).clientWidth;
            const d = Lc(a, b) || {},
                e = d.direction;
            if ("0px" === d.width && "none" !== d.cssFloat) return -1;
            if ("ltr" === e && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if ("rtl" === e && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function Vn(a) {
        R.wa(b => {
            b.shv = String(a);
            b.mjsv = "m202302060101";
            const c = K(Pf).i(),
                d = U(n);
            d.eids || (d.eids = []);
            b.eid = c.concat(d.eids).join(",")
        })
    }

    function Wn(a) {
        Vn(D(a, 2));
        a = E(a, 6);
        Xb(Gl, Vd);
        Gl = a
    };

    function Xn({
        bb: a,
        sb: b
    }) {
        return a || ("dev" === b ? "dev" : "")
    };

    function Yn(a) {
        var b = R;
        try {
            return Xb(a, Ud), new Fl(JSON.parse(a))
        } catch (c) {
            b.I(838, c instanceof Error ? c : Error(String(c)), void 0, d => {
                d.jspb = String(a)
            })
        }
        return new Fl
    };

    function Zn(a, b) {
        return null == b ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function $n(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function ao() {
        const a = new Set,
            b = wj();
        try {
            if (!b) return a;
            const c = b.pubads();
            for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch (c) {}
        return a
    }

    function bo(a) {
        a = a.id;
        return null != a && (ao().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function co(a, b, c) {
        if (!a.sources) return !1;
        switch (eo(a)) {
            case 2:
                const d = fo(a);
                if (d) return c.some(f => go(d, f));
            case 1:
                const e = ho(a);
                if (e) return b.some(f => go(e, f))
        }
        return !1
    }

    function eo(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function ho(a) {
        return io(a, b => b.currentRect)
    }

    function fo(a) {
        return io(a, b => b.previousRect)
    }

    function io(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function go(a, b) {
        const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
    }

    function jo() {
        const a = [...document.getElementsByTagName("iframe")].filter(bo),
            b = [...ao()].map(c => document.getElementById(c)).filter(c => null !== c);
        ko = window.scrollX;
        lo = window.scrollY;
        return mo = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function no() {
        var a = new oo;
        if (P(sh)) {
            var b = window;
            if (!b.google_plmetrics && window.PerformanceObserver) {
                b.google_plmetrics = !0;
                b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                for (const c of b) a.J().observe({
                    type: c,
                    buffered: !0
                });
                po(a)
            }
        }
    }

    function po(a) {
        const b = Ai(641, () => {
                var d = document;
                2 == (d.prerendering ? 3 : {
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5
                }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) && qo(a)
            }),
            c = Ai(641, () => void qo(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.ya = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            a.J().disconnect()
        }
    }

    function qo(a) {
        if (!a.Fa) {
            a.Fa = !0;
            a.J().takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += $n("cls", a.B), b += $n("mls", a.K), b += Zn("nls", a.R), window.LayoutShiftAttribution && (b += $n("cas", a.m), b += Zn("nas", a.Ea)), b += $n("wls", a.fa), b += $n("tls", a.Ia), window.LayoutShiftAttribution && (b += $n("was", a.Ja)));
            window.LargestContentfulPaint && (b += Zn("lcp", a.Ca), b += Zn("lcps", a.Ba));
            window.PerformanceEventTiming && a.Aa && (b += Zn("fid", a.za));
            window.PerformanceLongTaskTiming &&
                (b += Zn("cbt", a.v), b += Zn("mbt", a.C), b += Zn("nlt", a.T));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) bo(c) && d++;
            b += Zn("nif", d);
            b += Zn("ifi", qd(window));
            c = K(Pf).i();
            b += `&${"eid"}=${encodeURIComponent(c.join())}`;
            b += `&${"top"}=${n===n.top?1:0}`;
            b += a.Ha ? `&${"qqid"}=${encodeURIComponent(a.Ha)}` : Zn("pvsid", ad(n));
            window.googletag && (b += "&gpt=1");
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            $e(a)
        }
    }
    class oo extends Ze {
        constructor() {
            super();
            this.l = this.i = this.R = this.K = this.B = 0;
            this.Ga = this.Da = Number.NEGATIVE_INFINITY;
            this.za = this.Ba = this.Ca = this.Ea = this.Ja = this.m = this.Ia = this.fa = 0;
            this.Aa = !1;
            this.T = this.C = this.v = 0;
            const a = document.querySelector("[data-google-query-id]");
            this.Ha = a ? a.getAttribute("data-google-query-id") : null;
            this.U = null;
            this.Fa = !1;
            this.ya = () => {}
        }
        J() {
            this.U || (this.U = new PerformanceObserver(Ai(640, a => {
                const b = ko !== window.scrollX || lo !== window.scrollY ? [] : mo,
                    c = jo();
                for (const f of a.getEntries()) switch (f.entryType) {
                    case "layout-shift":
                        a =
                            f;
                        var d = b,
                            e = c;
                        if (!a.hadRecentInput) {
                            this.B += Number(a.value);
                            Number(a.value) > this.K && (this.K = Number(a.value));
                            this.R += 1;
                            if (d = co(a, d, e)) this.m += a.value, this.Ea++;
                            if (5E3 < a.startTime - this.Da || 1E3 < a.startTime - this.Ga) this.Da = a.startTime, this.l = this.i = 0;
                            this.Ga = a.startTime;
                            this.i += a.value;
                            d && (this.l += a.value);
                            this.i > this.fa && (this.fa = this.i, this.Ja = this.l, this.Ia = a.startTime + a.duration)
                        }
                        break;
                    case "largest-contentful-paint":
                        a = f;
                        this.Ca = Math.floor(a.renderTime || a.loadTime);
                        this.Ba = a.size;
                        break;
                    case "first-input":
                        a =
                            f;
                        this.za = Number((a.processingStart - a.startTime).toFixed(3));
                        this.Aa = !0;
                        break;
                    case "longtask":
                        a = Math.max(0, f.duration - 50), this.v += a, this.C = Math.max(this.C, a), this.T += 1
                }
            })));
            return this.U
        }
        h() {
            super.h();
            this.ya()
        }
    }
    var ko = void 0,
        lo = void 0,
        mo = [];
    var X = {
            issuerOrigin: "https://attestation.android.com",
            issuancePath: "/att/i",
            redemptionPath: "/att/r"
        },
        Y = {
            issuerOrigin: "https://pagead2.googlesyndication.com",
            issuancePath: "/dtt/i",
            redemptionPath: "/dtt/r",
            getStatePath: "/dtt/s"
        };

    function ro() {
        const a = window.navigator.userAgent,
            b = /Chrome/.test(a);
        return /Android/.test(a) && b
    }

    function so(a = window) {
        return !a.PeriodicSyncManager
    }

    function to() {
        var a = window.document;
        const b = K(Sh).h(Qh.h, Qh.defaultValue);
        $c(b, a)
    }

    function uo(a, b) {
        return a || ".google.ch" === b || "function" === typeof J.__tcfapi
    }

    function Z(a, b, c) {
        if (a = window.goog_tt_state_map ? .get(a)) a.state = b, void 0 != c && (a.hasRedemptionRecord = c)
    }

    function vo() {
        const a = `${X.issuerOrigin}${X.redemptionPath}`,
            b = {
                keepalive: !0,
                trustToken: {
                    type: "token-redemption",
                    issuer: X.issuerOrigin,
                    refreshPolicy: "none"
                }
            };
        Z(X.issuerOrigin, 2);
        return window.fetch(a, b).then(c => {
            if (!c.ok) throw Error(`${c.status}: Network response was not ok!`);
            Z(X.issuerOrigin, 6, !0)
        }).catch(c => {
            c && "NoModificationAllowedError" === c.name ? Z(X.issuerOrigin, 6, !0) : Z(X.issuerOrigin, 5)
        })
    }

    function wo() {
        const a = `${X.issuerOrigin}${X.issuancePath}`;
        Z(X.issuerOrigin, 8);
        return window.fetch(a, {
            keepalive: !0,
            trustToken: {
                type: "token-request"
            }
        }).then(b => {
            if (!b.ok) throw Error(`${b.status}: Network response was not ok!`);
            Z(X.issuerOrigin, 10);
            return vo()
        }).catch(b => {
            if (b && "NoModificationAllowedError" === b.name) return Z(X.issuerOrigin, 10), vo();
            Z(X.issuerOrigin, 9)
        })
    }

    function xo() {
        Z(X.issuerOrigin, 13);
        return document.hasTrustToken(X.issuerOrigin).then(a => a ? vo() : wo())
    }

    function yo() {
        Z(Y.issuerOrigin, 13);
        if (window.Promise) {
            var a = document.hasTrustToken(Y.issuerOrigin).then(e => e).catch(e => window.Promise.reject({
                state: 19,
                error: e
            }));
            const b = `${Y.issuerOrigin}${Y.redemptionPath}`,
                c = {
                    keepalive: !0,
                    trustToken: {
                        type: "token-redemption",
                        refreshPolicy: "none"
                    }
                };
            Z(Y.issuerOrigin, 16);
            a = a.then(e => window.fetch(b, c).then(f => {
                if (!f.ok) throw Error(`${f.status}: Network response was not ok!`);
                Z(Y.issuerOrigin, 18, !0)
            }).catch(f => {
                if (f && "NoModificationAllowedError" === f.name) Z(Y.issuerOrigin,
                    18, !0);
                else {
                    if (e) return window.Promise.reject({
                        state: 17,
                        error: f
                    });
                    Z(Y.issuerOrigin, 17)
                }
            })).then(() => document.hasTrustToken(Y.issuerOrigin).then(e => e).catch(e => window.Promise.reject({
                state: 19,
                error: e
            }))).then(e => {
                const f = `${Y.issuerOrigin}${Y.getStatePath}`;
                Z(Y.issuerOrigin, 20);
                return window.fetch(`${f}?ht=${e}`, {
                    trustToken: {
                        type: "send-redemption-record",
                        issuers: [Y.issuerOrigin]
                    }
                }).then(g => {
                    if (!g.ok) throw Error(`${g.status}: Network response was not ok!`);
                    Z(Y.issuerOrigin, 22);
                    return g.text().then(h =>
                        JSON.parse(h))
                }).catch(g => window.Promise.reject({
                    state: 21,
                    error: g
                }))
            });
            const d = ad(window);
            return a.then(e => {
                const f = `${Y.issuerOrigin}${Y.issuancePath}`;
                return e && e.srqt && e.cs ? (Z(Y.issuerOrigin, 23), window.fetch(`${f}?cs=${e.cs}&correlator=${d}`, {
                    keepalive: !0,
                    trustToken: {
                        type: "token-request"
                    }
                }).then(g => {
                    if (!g.ok) throw Error(`${g.status}: Network response was not ok!`);
                    Z(Y.issuerOrigin, 25);
                    return e
                }).catch(g => window.Promise.reject({
                    state: 24,
                    error: g
                }))) : e
            }).then(e => {
                if (e && e.srdt && e.cs) return Z(Y.issuerOrigin,
                    26), window.fetch(`${b}?cs=${e.cs}&correlator=${d}`, {
                    keepalive: !0,
                    trustToken: {
                        type: "token-redemption",
                        refreshPolicy: "refresh"
                    }
                }).then(f => {
                    if (!f.ok) throw Error(`${f.status}: Network response was not ok!`);
                    Z(Y.issuerOrigin, 28, !0)
                }).catch(f => window.Promise.reject({
                    state: 27,
                    error: f
                }))
            }).then(() => {
                Z(Y.issuerOrigin, 29)
            }).catch(e => {
                if (e instanceof Object && e.hasOwnProperty("state") && e.hasOwnProperty("error"))
                    if ("number" === typeof e.state && e.error instanceof Error) {
                        Z(Y.issuerOrigin, e.state);
                        const f = Th(Ph);
                        Math.random() <=
                            f && hd({
                                state: e.state,
                                err: e.error.toString()
                            }, "dtt_err")
                    } else throw Error(e);
                else throw e;
            })
        }
    }

    function zo(a) {
        if (document.hasTrustToken && !P(Nh)) {
            var b = window.goog_tt_promise_map;
            if (b && b instanceof Map) {
                var c = [];
                if (a.i.some(d => d.issuerOrigin === X.issuerOrigin)) {
                    let d = b.get(X.issuerOrigin);
                    d || (d = xo(), b.set(X.issuerOrigin, d));
                    c.push(d)
                }
                a.i.some(d => d.issuerOrigin === Y.issuerOrigin) && (a = b.get(Y.issuerOrigin), a || (a = yo(), b.set(Y.issuerOrigin, a)), c.push(a));
                if (0 < c.length && window.Promise && window.Promise.all) return window.Promise.all(c)
            }
        }
    }
    var Ao = class extends Ze {
        constructor(a, b) {
            super();
            this.i = [];
            a && ro() && this.i.push(X);
            b && this.i.push(Y);
            if (document.hasTrustToken && !P(Nh)) {
                const c = new Map;
                this.i.forEach(d => {
                    c.set(d.issuerOrigin, {
                        issuerOrigin: d.issuerOrigin,
                        state: 1,
                        hasRedemptionRecord: !1
                    })
                });
                window.goog_tt_state_map = window.goog_tt_state_map && window.goog_tt_state_map instanceof Map ? new Map([...c, ...window.goog_tt_state_map]) : c;
                window.goog_tt_promise_map && window.goog_tt_promise_map instanceof Map || (window.goog_tt_promise_map = new Map)
            }
        }
    };
    var Bo = class extends G {
        constructor() {
            super()
        }
        getVersion() {
            return D(this, 2)
        }
    };

    function Co(a, b) {
        return t(a, 2, b)
    }

    function Do(a, b) {
        return t(a, 3, b)
    }

    function Eo(a, b) {
        return t(a, 4, b)
    }

    function Fo(a, b) {
        return t(a, 5, b)
    }

    function Go(a, b) {
        return t(a, 9, b)
    }

    function Ho(a, b) {
        return Cb(a, 10, b)
    }

    function Io(a, b) {
        return t(a, 11, b)
    }

    function Jo(a, b) {
        return t(a, 1, b)
    }

    function Ko(a, b) {
        return t(a, 7, b)
    }
    var Mo = class extends G {
            constructor() {
                super(void 0, -1, Lo)
            }
        },
        Lo = [10, 6];
    const No = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Oo() {
        if ("function" !== typeof J.navigator ? .userAgentData ? .getHighEntropyValues) return null;
        const a = J.google_tag_data ? ? (J.google_tag_data = {});
        if (a.uach_promise) return a.uach_promise;
        const b = J.navigator.userAgentData.getHighEntropyValues(No).then(c => {
            a.uach ? ? (a.uach = c);
            return c
        });
        return a.uach_promise = b
    }

    function Po(a) {
        return Io(Ho(Fo(Co(Jo(Eo(Ko(Go(Do(new Mo, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), a.fullVersionList ? .map(b => {
            var c = new Bo;
            c = t(c, 1, b.brand);
            return t(c, 2, b.version)
        }) || []), a.wow64 || !1)
    }

    function Qo() {
        return Oo() ? .then(a => Po(a)) ? ? null
    };

    function Ro(a, b) {
        b.google_ad_host || (a = Yl(a)) && (b.google_ad_host = a)
    }

    function So(a, b, c = "") {
        J.google_sa_impl && !J.document.getElementById("google_shimpl") && (delete J.google_sa_queue, delete J.google_sa_impl);
        J.google_sa_queue || (J.google_sa_queue = [], J.google_process_slots = Kj(215, () => To(J.google_sa_queue)), a = Uo(c, a, b), Jc(J.document, a).id = "google_shimpl")
    }

    function To(a) {
        const b = a.shift();
        "function" === typeof b && R.ia(216, b);
        a.length && n.setTimeout(Kj(215, () => To(a)), 0)
    }

    function Vo(a, b, c) {
        a.google_sa_queue = a.google_sa_queue || [];
        a.google_sa_impl ? c(b) : a.google_sa_queue.push(b)
    }

    function Uo(a, b, c) {
        b = E(c, 4) ? b.tb : b.ub;
        const d = {};
        a: {
            if (E(c, 4)) {
                if (a = a || Am(J)) {
                    a = {
                        client: a,
                        plah: J.location.host
                    };
                    break a
                }
                throw Error("PublisherCodeNotFoundForAma");
            }
            a = {}
        }
        Wo(a, d);
        Wo(Uh() ? {
            bust: Uh()
        } : {}, d);
        return uc(b, d)
    }

    function Wo(a, b) {
        H(a, (c, d) => {
            void 0 === b[d] && (b[d] = c)
        })
    }

    function Xo(a) {
        a: {
            var b = [n.top];
            var c = [];
            let e = 0,
                f;
            for (; f = b[e++];) {
                c.push(f);
                try {
                    if (f.frames)
                        for (let g = 0; g < f.frames.length && 1024 > b.length; ++g) b.push(f.frames[g])
                } catch {}
            }
            b = c;
            for (c = 0; c < b.length; c++) try {
                var d = b[c].frames.google_esf;
                if (d) {
                    id = d;
                    break a
                }
            } catch (g) {}
            id = null
        }
        if (id) return null;d = Kc("IFRAME");d.id = "google_esf";d.name = "google_esf";d.src = wc(a.Ab).toString();d.style.display = "none";
        return d
    }

    function Yo(a, b, c, d) {
        Zo(a, b, c, d, (e, f) => {
            e = e.document;
            for (var g = void 0, h = 0; !g || e.getElementById(g + "_host");) g = "aswift_" + h++;
            e = g;
            g = Number(f.google_ad_width || 0);
            f = Number(f.google_ad_height || 0);
            h = Kc("DIV");
            h.id = e + "_host";
            const l = h.style;
            l.border = "none";
            l.height = `${f}px`;
            l.width = `${g}px`;
            l.margin = "0px";
            l.padding = "0px";
            l.position = "relative";
            l.visibility = "visible";
            l.backgroundColor = "transparent";
            h.style.display = "inline-block";
            c.appendChild(h);
            return {
                gb: e,
                zb: h
            }
        })
    }

    function Zo(a, b, c, d, e) {
        const f = e(a, b);
        e = f.gb;
        $o(a, c, b);
        c = oa;
        const g = (new Date).getTime();
        b.google_lrv = D(d, 2);
        b.google_async_iframe_id = e;
        b.google_start_time = c;
        b.google_bpp = g > c ? g - c : 1;
        a.google_sv_map = a.google_sv_map || {};
        a.google_sv_map[e] = b;
        d = a.document.getElementById(e + "_host") ? h => h() : h => window.setTimeout(h, 0);
        Vo(a, () => {
            ({
                zb: h
            } = f);
            if (!h || !h.isConnected) {
                var h = a.document.getElementById(String(b.google_async_iframe_id) + "_host");
                if (null == h) throw Error("no_div");
            }
            h = P(mh) ? {
                pubWin: a,
                vars: b,
                innerInsElement: h
            } : {
                pubWin: a,
                vars: b,
                outerInsElement: h,
                innerInsElement: h
            };
            (h = a.google_sa_impl(h)) && R.ca(911, h)
        }, d)
    }

    function $o(a, b, c) {
        var d = c.google_ad_output,
            e = c.google_ad_format,
            f = c.google_ad_width || 0,
            g = c.google_ad_height || 0;
        e || "html" !== d && null != d || (e = f + "x" + g);
        d = !c.google_ad_slot || c.google_override_format || !ln[c.google_ad_width + "x" + c.google_ad_height] && "aa" === c.google_loader_used;
        e && d ? e = e.toLowerCase() : e = "";
        c.google_ad_format = e;
        if ("number" !== typeof c.google_reactive_sra_index || !c.google_ad_unit_key) {
            e = [c.google_ad_slot, c.google_orig_ad_format || c.google_ad_format, c.google_ad_type, c.google_orig_ad_width || c.google_ad_width,
                c.google_orig_ad_height || c.google_ad_height
            ];
            d = [];
            f = 0;
            for (g = b; g && 25 > f; g = g.parentNode, ++f) 9 === g.nodeType ? d.push("") : d.push(g.id);
            (d = d.join()) && e.push(d);
            c.google_ad_unit_key = Qc(e.join(":")).toString();
            e = [];
            for (d = 0; b && 25 > d; ++d) {
                f = (f = 9 !== b.nodeType && b.id) ? "/" + f : "";
                a: {
                    if (b && b.nodeName && b.parentElement) {
                        g = b.nodeName.toString().toLowerCase();
                        const h = b.parentElement.childNodes;
                        let l = 0;
                        for (let k = 0; k < h.length; ++k) {
                            const m = h[k];
                            if (m.nodeName && m.nodeName.toString().toLowerCase() === g) {
                                if (b === m) {
                                    g = "." + l;
                                    break a
                                }++l
                            }
                        }
                    }
                    g =
                    ""
                }
                e.push((b.nodeName && b.nodeName.toString().toLowerCase()) + f + g);
                b = b.parentElement
            }
            b = e.join() + ":";
            e = [];
            if (a) try {
                let h = a.parent;
                for (d = 0; h && h !== a && 25 > d; ++d) {
                    const l = h.frames;
                    for (f = 0; f < l.length; ++f)
                        if (a === l[f]) {
                            e.push(f);
                            break
                        }
                    a = h;
                    h = a.parent
                }
            } catch (h) {}
            c.google_ad_dom_fingerprint = Qc(b + e.join()).toString()
        }
    }

    function ap() {
        var a = Ic(n);
        a && (a = xg(a), a.tagSpecificState[1] || (a.tagSpecificState[1] = {
            debugCard: null,
            debugCardRequested: !1
        }))
    }

    function bp(a) {
        to();
        uo(Hl(), D(a, 8)) || Kj(779, () => {
            var b = P(so(window) ? Mh : Lh);
            const c = P(Oh);
            b = new Ao(b, c);
            0 < Th(Rh) ? J.google_trust_token_operation_promise = zo(b) : zo(b)
        })();
        a = Qo();
        null != a && a.then(b => {
            a: {
                jb = !0;
                try {
                    var c = JSON.stringify(b.toJSON(), Ub);
                    break a
                } finally {
                    jb = !1
                }
                c = void 0
            }
            J.google_user_agent_client_hint = c
        });
        Nm()
    };

    function cp(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            case "google_allow_expandable_ads":
                return /^true$/.test(b);
            default:
                return b
        }
    }

    function dp(a, b) {
        if (a.getAttribute("src")) {
            var c = a.getAttribute("src") || "",
                d = Gc(c, "client");
            d && (b.google_ad_client = cp("google_ad_client", d));
            (c = Gc(c, "host")) && (b.google_ad_host = cp("google_ad_host", c))
        }
        a = a.attributes;
        c = a.length;
        for (d = 0; d < c; d++) {
            var e = a[d];
            if (/data-/.test(e.name)) {
                const f = pa(e.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_"));
                b.hasOwnProperty(f) || (e = cp(f, e.value), null !== e && (b[f] = e))
            }
        }
    }

    function ep(a) {
        if (a = ld(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else return 12
    }

    function fp(a, b, c, d) {
        dp(a, b);
        if (c.document && c.document.body && !Rn(c, b) && !b.google_reactive_ad_format) {
            var e = parseInt(a.style.width, 10),
                f = Un(a, c);
            if (0 < f && e > f) {
                var g = parseInt(a.style.height, 10);
                e = !!ln[e + "x" + g];
                var h = f;
                if (e) {
                    const l = mn(f, g);
                    if (l) h = l, b.google_ad_format = l + "x" + g + "_0ads_al";
                    else throw new Q("No slot size for availableWidth=" + f);
                }
                b.google_ad_resize = !0;
                b.google_ad_width = h;
                e || (b.google_ad_format = null, b.google_override_format = !0);
                f = h;
                a.style.width = `${f}px`;
                g = Nn(f, "auto", c, a, b);
                h = f;
                g.size().i(c,
                    b, a);
                un(g, h, b);
                g = g.size();
                b.google_responsive_formats = null;
                g.M > f && !e && (b.google_ad_width = g.M, a.style.width = `${g.M}px`)
            }
        }(e = a.offsetWidth) || (e = ni(a, c, "width", I));
        e = e || b.google_ad_width || 0;
        if (488 > N(c).clientWidth) {
            f = Ic(c) || c;
            g = b.google_ad_client;
            if (d = uj(f.location, "google_responsive_slot_preview") || P(lh) || Kl(f, 1, g, d)) b: if (b.google_reactive_ad_format || b.google_ad_resize || Rn(c, b) || ci(a, b)) d = !1;
                else {
                    for (d = a; d; d = d.parentElement) {
                        f = Lc(d, c);
                        if (!f) {
                            b.gfwrnwer = 18;
                            d = !1;
                            break b
                        }
                        if (!Ha(["static", "relative"], f.position)) {
                            b.gfwrnwer =
                                17;
                            d = !1;
                            break b
                        }
                    }
                    d = gi(c, a, e, .3, b);
                    !0 !== d ? (b.gfwrnwer = d, d = !1) : d = c === c.top ? !0 : !1
                }
            d ? (b.google_resizing_allowed = !0, b.ovlp = !0, b.google_ad_format = "auto", b.iaaso = !0, b.armr = 1, d = !0) : d = !1
        } else d = !1;
        if (e = Rn(c, b)) Tn(e, a, b, c, d);
        else {
            if (ci(a, b)) {
                if (d = Lc(a, c)) a.style.width = d.width, a.style.height = d.height, bi(d, b);
                b.google_ad_width || (b.google_ad_width = a.offsetWidth);
                b.google_ad_height || (b.google_ad_height = a.offsetHeight);
                b.google_loader_features_used = 256;
                b.google_responsive_auto_format = ep(c)
            } else bi(a.style, b);
            c.location &&
                "#gfwmrp" == c.location.hash || 12 == b.google_responsive_auto_format && "true" == b.google_full_width_responsive ? Tn(10, a, b, c, !1) : .01 > Math.random() && 12 === b.google_responsive_auto_format && (a = hi(a.offsetWidth || parseInt(a.style.width, 10) || b.google_ad_width, c, a, b), !0 !== a ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
        }
    };

    function gp(a) {
        if (a.i) return a.i;
        a.C && a.C(a.l) ? a.i = a.l : a.i = Vc(a.l, a.K);
        return a.i ? ? null
    }
    var hp = class extends Ze {
        constructor(a, b, c) {
            super();
            this.K = a;
            this.C = b;
            this.R = c;
            this.B = new Map;
            this.v = new Map;
            this.U = new Map;
            this.T = new Map;
            this.m = void 0;
            this.l = J
        }
        h() {
            delete this.i;
            this.B.clear();
            this.v.clear();
            this.U.clear();
            this.T.clear();
            this.m && (jc(this.l, "message", this.m), delete this.m);
            delete this.l;
            delete this.R;
            super.h()
        }
    };
    const ip = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.callback({
                    consentData: c ? ? void 0,
                    eb: d ? void 0 : 2
                })
            })
        },
        jp = {
            lb: a => a.callback,
            mb: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            ob: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    consentData: b.returnValue ? ? void 0,
                    eb: b.success ? void 0 : 2
                })
            }
        };

    function kp(a) {
        let b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            qb: b.__uspapiReturn.callId
        }
    }
    var lp = class extends Ze {
        constructor() {
            super();
            this.caller = new hp("__uspapiLocator", a => "function" === typeof a.__uspapi, kp);
            this.caller.B.set("getDataWithCallback", ip);
            this.caller.v.set("getDataWithCallback", jp)
        }
        h() {
            $e(this.caller);
            super.h()
        }
        m() {
            return !!gp(this.caller)
        }
    };
    var mp = Yb(class extends G {
        constructor(a) {
            super(a)
        }
    });
    const np = (a, b) => {
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c => {
                c = mp(c);
                b.callback({
                    consentData: c
                })
            })
        },
        op = {
            lb: a => a.callback,
            mb: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command
                }
            }),
            ob: (a, b) => {
                a({
                    consentData: b
                })
            }
        };

    function pp(a) {
        a = mp(a.data.__fciReturn);
        return {
            payload: a,
            qb: r(a, 1)
        }
    }
    var qp = class extends Ze {
        constructor() {
            super();
            this.i = null;
            this.l = !1;
            this.caller = new hp("googlefcPresent", void 0, pp);
            this.caller.B.set("getDataWithCallback", np);
            this.caller.v.set("getDataWithCallback", op)
        }
        h() {
            $e(this.caller);
            super.h()
        }
        m() {
            this.l || (this.i = gp(this.caller), this.l = !0);
            return !!this.i
        }
    };

    function rp() {
        const a = od `(a=0)=>{let b;const c=class{};}`;
        try {
            var b = window;
            const c = a instanceof rc && a.constructor === rc ? a.h : "type_error:SafeScript";
            b.eval(c) === c && b.eval(c.toString());
            return {
                supports: !0,
                error: ""
            }
        } catch (c) {
            return {
                supports: !1,
                error: String(c)
            }
        }
    };
    var sp = a => {
        ic(window, "message", b => {
            let c;
            try {
                c = JSON.parse(b.data)
            } catch (d) {
                return
            }!c || "sc-cnf" !== c.googMsgType || a(c, b)
        })
    };
    var tp = class extends Ze {
        constructor() {
            super();
            this.l = J;
            this.i = null
        }
        h() {
            super.h()
        }
        m() {
            var a;
            (a = "function" === typeof this.l ? .__uspapi) || (a = this.i ? this.i : this.i = Vc(this.l, "__uspapiLocator"), a = null != a);
            return a
        }
    };
    var up = class extends Ze {
        constructor() {
            super();
            this.v = J;
            this.i = null;
            this.l = !1
        }
        m() {
            if (!this.l) {
                if (!this.i) {
                    var a = Vc(this.v, "googlefcPresent");
                    this.i = a ? a : null
                }
                this.l = !0
            }
            return !!this.i
        }
    };
    let vp = null;
    const wp = [],
        xp = new Map;
    let yp = -1;

    function zp(a) {
        return vi.test(a.className) && "done" !== a.dataset.adsbygoogleStatus
    }
    var Bp = (a, b, c) => {
        a.dataset.adsbygoogleStatus = "done";
        Ap(a, b, c)
    };

    function Ap(a, b, c) {
        var d = window;
        d.google_spfd || (d.google_spfd = fp);
        var e = b.google_reactive_ads_config;
        e || fp(a, b, d, c);
        Ro(d, b);
        if (!Cp(a, b, d)) {
            e || (d.google_lpabyc = ei(a, d) + ni(a, d, "height", I));
            if (e) {
                e = e.page_level_pubvars || {};
                if (U(J).page_contains_reactive_tag && !U(J).allow_second_reactive_tag) {
                    if (e.pltais) {
                        Wl(!1);
                        return
                    }
                    throw new Q("Only one 'enable_page_level_ads' allowed per page.");
                }
                U(J).page_contains_reactive_tag = !0;
                Wl(7 === e.google_pgb_reactive)
            }
            b.google_unique_id = pd(d);
            H(wm, (f, g) => {
                b[g] = b[g] || d[g]
            });
            b.google_loader_used = "aa";
            b.google_reactive_tag_first = 1 === (U(J).first_tag_on_page || 0);
            Jj(164, () => {
                Yo(d, b, a, c)
            })
        }
    }

    function Cp(a, b, c) {
        var d = b.google_reactive_ads_config,
            e = "string" === typeof a.className && RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className),
            f = Ul(c);
        if (f && f.Ka && "on" !== b.google_adtest && !e) {
            e = ei(a, c);
            const g = N(c).clientHeight;
            e = 0 == g ? null : e / g;
            if (!f.ra || f.ra && (e || 0) >= f.ra) return a.className += " adsbygoogle-ablated-ad-slot", c = c.google_sv_map = c.google_sv_map || {}, d = ea(a), b.google_element_uid = d, c[b.google_element_uid] = b, a.setAttribute("google_element_uid", String(d)), "slot" === f.xb && (null !== Uc(a.getAttribute("width")) &&
                a.setAttribute("width", 0), null !== Uc(a.getAttribute("height")) && a.setAttribute("height", 0), a.style.width = "0px", a.style.height = "0px"), !0
        }
        if ((f = Lc(a, c)) && "none" === f.display && !("on" === b.google_adtest || 0 < b.google_reactive_ad_format || d)) return c.document.createComment && a.appendChild(c.document.createComment("No ad requested because of display:none on the adsbygoogle tag")), !0;
        a = null == b.google_pgb_reactive || 3 === b.google_pgb_reactive;
        return 1 !== b.google_reactive_ad_format && 8 !== b.google_reactive_ad_format ||
            !a ? !1 : (n.console && n.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + String(b.google_reactive_ad_format) + " is deprecated. Check out page-level ads at https://www.google.com/adsense"), !0)
    }

    function Dp(a) {
        var b = document.getElementsByTagName("INS");
        for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
            var c = e;
            if (zp(c) && "reserved" !== c.dataset.adsbygoogleStatus && (!a || e.id === a)) return e
        }
        return null
    }
    var Fp = (a, b, c) => {
        if (a && a.shift) {
            let d = 20;
            for (; 0 < a.length && 0 < d;) {
                try {
                    Ep(a.shift(), b, c)
                } catch (e) {
                    setTimeout(() => {
                        throw e;
                    })
                }--d
            }
        }
    };

    function Gp() {
        const a = Kc("INS");
        a.className = "adsbygoogle";
        a.className += " adsbygoogle-noablate";
        Xc(a, {
            display: "none"
        });
        return a
    }
    var Hp = (a, b) => {
            const c = {},
                d = Tl();
            H(wg, (g, h) => {
                !1 === a.enable_page_level_ads ? c[h] = !1 : a.hasOwnProperty(h) ? c[h] = a[h] : d.includes(g) && (c[h] = !1)
            });
            da(a.enable_page_level_ads) && (c.page_level_pubvars = a.enable_page_level_ads);
            const e = Gp();
            bd.body.appendChild(e);
            const f = {
                google_reactive_ads_config: c,
                google_ad_client: a.google_ad_client
            };
            f.google_pause_ad_requests = !!U(J).pause_ad_requests;
            Bp(e, f, b)
        },
        Ip = (a, b) => {
            xg(n).wasPlaTagProcessed = !0;
            const c = () => Hp(a, b),
                d = n.document;
            if (d.body || "complete" === d.readyState || "interactive" ===
                d.readyState) Hp(a, b);
            else {
                const e = hc(R.va(191, c));
                ic(d, "DOMContentLoaded", e);
                (new n.MutationObserver((f, g) => {
                    d.body && (e(), g.disconnect())
                })).observe(d, {
                    childList: !0,
                    subtree: !0
                })
            }
        };

    function Ep(a, b, c) {
        const d = {};
        Jj(165, () => Jp(a, d, b, c), e => {
            e.client = e.client || d.google_ad_client || a.google_ad_client;
            e.slotname = e.slotname || d.google_ad_slot;
            e.tag_origin = e.tag_origin || d.google_tag_origin
        })
    }

    function Kp(a) {
        delete a.google_checked_head;
        H(a, (b, c) => {
            ui[c] || (delete a[c], n.console.warn(`AdSense head tag doesn't support ${c.replace("google","data").replace(/_/g,"-")} attribute.`))
        })
    }
    var Np = (a, b) => {
        var c = J.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || J.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])');
        if (c) {
            c.setAttribute("data-checked-head", "true");
            var d = U(window);
            if (d.head_tag_slot_vars) Lp(c);
            else {
                var e = {};
                dp(c, e);
                Kp(e);
                var f = nc(e);
                d.head_tag_slot_vars = f;
                c = {
                    google_ad_client: e.google_ad_client,
                    enable_page_level_ads: e
                };
                J.adsbygoogle || (J.adsbygoogle = []);
                d = J.adsbygoogle;
                d.loaded ? d.push(c) : d.splice && d.splice(0, 0, c);
                e.google_adbreak_test || b.l() ? .l() && P(ph) ? Mp(f, a) : sp(() => {
                    Mp(f, a)
                })
            }
        }
    };
    const Lp = a => {
        const b = U(window).head_tag_slot_vars,
            c = a.getAttribute("src") || "";
        if ((a = Gc(c, "client") || a.getAttribute("data-ad-client") || "") && a !== b.google_ad_client) throw new Q("Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page " + a + ", " + b.google_ad_client);
    };

    function Op(a) {
        if ("object" === typeof a && null != a) {
            if ("string" === typeof a.type) return 2;
            if ("string" === typeof a.sound || "string" === typeof a.preloadAdBreaks) return 3
        }
        return 0
    }
    var Jp = (a, b, c, d) => {
        if (null == a) throw new Q("push() called with no parameters.");
        d.m() && Pp(a, d.i().i(), D(d, 2));
        var e = Op(a);
        if (0 !== e) d = Xl(), d.first_slotcar_request_processing_time || (d.first_slotcar_request_processing_time = Date.now(), d.adsbygoogle_execution_start_time = oa), null == vp ? (Qp(a), wp.push(a)) : 3 === e ? Jj(787, () => {
            vp.handleAdConfig(a)
        }) : Mj(730, vp.handleAdBreak(a));
        else {
            oa = (new Date).getTime();
            So(c, d, Rp(a));
            Sp();
            a: {
                if (void 0 != a.enable_page_level_ads) {
                    if ("string" === typeof a.google_ad_client) {
                        e = !0;
                        break a
                    }
                    throw new Q("'google_ad_client' is missing from the tag config.");
                }
                e = !1
            }
            if (e) Tp(a, d);
            else if ((e = a.params) && H(e, (g, h) => {
                    b[h] = g
                }), "js" === b.google_ad_output) console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
            else {
                e = Up(a.element);
                dp(e, b);
                c = U(n).head_tag_slot_vars || {};
                H(c, (g, h) => {
                    b.hasOwnProperty(h) || (b[h] = g)
                });
                if (e.hasAttribute("data-require-head") && !U(n).head_tag_slot_vars) throw new Q("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
                if (!b.google_ad_client) throw new Q("Ad client is missing from the slot.");
                var f = (c = 0 === (U(J).first_tag_on_page || 0) && qm(b)) && rm(c);
                c && (f || (Tp(c, d), U(J).skip_next_reactive_tag = !0), f && Vp(c));
                0 === (U(J).first_tag_on_page || 0) && (U(J).first_tag_on_page = 2);
                b.google_pause_ad_requests = !!U(J).pause_ad_requests;
                Bp(e, b, d)
            }
        }
    };
    let Wp = !1;

    function Pp(a, b, c) {
        Wp || (Wp = !0, a = Rp(a) || Am(J), Lj("predictive_abg", {
            a_c: a,
            p_c: b.join(),
            b_v: c
        }, .01))
    }

    function Rp(a) {
        return a.google_ad_client ? a.google_ad_client : (a = a.params) && a.google_ad_client ? a.google_ad_client : ""
    }
    const Sp = () => {
            if (P(fh)) {
                var a = Ul(J);
                if (!(a = a && a.Ka)) {
                    try {
                        var b = J.localStorage
                    } catch (c) {
                        b = null
                    }
                    b = b ? ql(b) : null;
                    a = !(b && pl(b) && b)
                }
                a || Vl(J, 1)
            }
        },
        Vp = a => {
            cd(() => {
                xg(n).wasPlaTagProcessed || n.adsbygoogle && n.adsbygoogle.push(a)
            })
        };

    function Tp(a, b) {
        if (U(J).skip_next_reactive_tag) U(J).skip_next_reactive_tag = !1;
        else {
            0 === (U(J).first_tag_on_page || 0) && (U(J).first_tag_on_page = 1);
            if (a.tag_partner) {
                var c = a.tag_partner;
                const d = U(n);
                d.tag_partners = d.tag_partners || [];
                d.tag_partners.push(c)
            }
            um(a, b);
            Ip(a, b)
        }
    }
    const Up = a => {
            if (a) {
                if (!zp(a) && (a.id ? a = Dp(a.id) : a = null, !a)) throw new Q("'element' has already been filled.");
                if (!("innerHTML" in a)) throw new Q("'element' is not a good DOM element.");
            } else if (a = Dp(), !a) throw new Q("All ins elements in the DOM with class=adsbygoogle already have ads in them.");
            return a
        },
        Xp = () => {
            const a = new hk(J),
                b = P(vh) ? new lp : new tp,
                c = P(uh) ? new qp : new up;
            Lj("cmpMet", {
                tcfv1: J.__cmp ? 1 : 0,
                tcfv2: ek(a) ? 1 : 0,
                usp: b.m() ? 1 : 0,
                fc: c.m() ? 1 : 0,
                ptt: 9
            }, .001)
        },
        Yp = a => {
            Pj().S[Sj(26)] = !!Number(a)
        },
        Zp = a => {
            Number(a) ? U(J).pause_ad_requests = !0 : (U(J).pause_ad_requests = !1, a = () => {
                if (!U(J).pause_ad_requests) {
                    var b = {};
                    let c;
                    "function" === typeof window.CustomEvent ? c = new CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", b) : (c = document.createEvent("CustomEvent"), c.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !!b.bubbles, !!b.cancelable, b.detail));
                    J.dispatchEvent(c)
                }
            }, n.setTimeout(a, 0), n.setTimeout(a, 1E3))
        },
        $p = a => {
            Lj("adsenseGfpKnob", {
                value: a,
                ptt: 9
            }, .1);
            switch (a) {
                case 0:
                case 2:
                    a = !0;
                    break;
                case 1:
                    a = !1;
                    break;
                default:
                    throw Error(`Illegal value of ${"cookieOptions"}: ${a}`);
            }
            J._gfp_a_ = a
        },
        bq = a => {
            try {
                Object.defineProperty(a, "requestNonPersonalizedAds", {
                    set: Yp
                }), Object.defineProperty(a, "pauseAdRequests", {
                    set: Zp
                }), Object.defineProperty(a, "cookieOptions", {
                    set: $p
                }), Object.defineProperty(a, "onload", {
                    set: aq
                })
            } catch {}
        };

    function aq(a) {
        a && a.call && "function" === typeof a && window.setTimeout(a, 0)
    }

    function Mp(a, b) {
        b = pm(uc(b.wb, Uh() ? {
            bust: Uh()
        } : {})).then(c => {
            null == vp && (c.init(a), vp = c, cq())
        });
        R.ca(723, b);
        b.finally(() => {
            wp.length = 0;
            Lj("slotcar", {
                event: "api_ld",
                time: Date.now() - oa,
                time_pr: Date.now() - yp
            })
        })
    }
    const cq = () => {
        for (const [a, b] of xp) - 1 !== b && (n.clearTimeout(b), xp.delete(a));
        for (let a = 0; a < wp.length; a++) {
            if (xp.has(a)) continue;
            const b = wp[a],
                c = Op(b);
            Jj(723, () => {
                if (3 === c) vp.handleAdConfig(b);
                else if (2 === c) {
                    var d = vp.handleAdBreakBeforeReady(b);
                    R.ca(730, d)
                }
            })
        }
    };

    function Qp(a) {
        var b = wp.length;
        if (2 === Op(a) && "preroll" === a.type && null != a.adBreakDone) {
            -1 === yp && (yp = Date.now());
            var c = n.setTimeout(() => {
                try {
                    (0, a.adBreakDone)({
                        breakType: "preroll",
                        breakName: a.name,
                        breakFormat: "preroll",
                        breakStatus: "timeout"
                    }), xp.set(b, -1), Lj("slotcar", {
                        event: "pr_to",
                        source: "adsbygoogle"
                    })
                } catch (d) {
                    console.error("[Ad Placement API] adBreakDone callback threw an error:", d instanceof Error ? d : Error(String(d)))
                }
            }, 1E3 * Th(qh));
            xp.set(b, c)
        }
    };
    (function(a, b, c, d = () => {}) {
        R.Sa(Nj);
        Jj(166, () => {
            const e = Yn(b);
            Wn(e);
            d();
            kd(16, [1, e.toJSON()]);
            var f = md(ld(J)) || J;
            const g = c(Xn({
                bb: a,
                sb: D(e, 2)
            }), e);
            Ll(f, e);
            kn(f, e, null === J.document.currentScript ? 1 : Km(g.yb));
            Mj(1086, Gm());
            if (!ua() || 0 <= qa(xa(), 11)) {
                Ij(P(th));
                bp(e);
                al();
                try {
                    no()
                } catch {}
                ap();
                Np(g, e);
                f = window;
                var h = f.adsbygoogle;
                if (!h || !h.loaded) {
                    Lj("new_abg_tag", {
                        value: `${E(e,16)}`,
                        host_v: `${E(e,22)}`,
                        frequency: .01
                    }, .01);
                    Xp();
                    var l = {
                        push: v => {
                            Ep(v, g, e)
                        },
                        loaded: !0
                    };
                    bq(l);
                    if (h)
                        for (var k of ["requestNonPersonalizedAds",
                                "pauseAdRequests", "cookieOptions"
                            ]) void 0 !== h[k] && (l[k] = h[k]);
                    "_gfp_a_" in window || (window._gfp_a_ = !0);
                    Fp(h, g, e);
                    f.adsbygoogle = l;
                    h && (l.onload = h.onload);
                    (k = Xo(g)) && document.documentElement.appendChild(k);
                    var {
                        supports: m,
                        error: u
                    } = rp();
                    Lj("modern_js", {
                        fy: Db(e, 1),
                        supports: String(m),
                        c: 2021,
                        e: u
                    }, .01)
                }
            }
        })
    })("m202302060101", "undefined" === typeof sttc ? void 0 : sttc, function(a, b) {
        const c = 2012 < Db(b, 1) ? `_fy${Db(b,1)}` : "";
        var d = D(b, 3);
        const e = D(b, 2);
        b = nd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${c}.js`;
        d = nd `https://googleads.g.doubleclick.net/pagead/html/${e}/${d}/zrt_lookup.html`;
        return {
            wb: b,
            ub: nd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl${c}.js`,
            tb: nd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_with_ama${c}.js`,
            bc: nd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_instrumented${c}.js`,
            Ab: d,
            yb: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle)\.js(?:[?#].*)?$/
        }
    });
}).call(this, "[2021,\"r20230207\",\"r20190131\",null,null,null,null,\".google.co.in\",null,null,null,[[[1082,null,null,[1]],[1214,null,null,[1]],[null,1130,null,[null,100]],[null,1126,null,[null,10000]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,500]]]],[null,1224,null,[null,0.01]],[null,1159,null,[null,500]],[1217,null,null,[1]],[1122,null,null,[1]],[1218,null,null,[1]],[1207,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[1205,null,null,[1]],[1167,null,null,[1]],[1129,null,null,[1]],[null,1169,null,[null,61440]],[1171,null,null,[1]],[1201,null,null,[1]],[1199,null,null,[1]],[1161,null,null,[1]],[null,1072,null,[null,0.75]],[1101,null,null,[1]],[null,1168,null,[null,61440]],[1198,null,null,[1]],[1206,null,null,[1]],[1219,null,null,[1]],[1190,null,null,[1]],[null,508040914,null,[null,100]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1080,null,[null,5]],[null,null,null,[null,null,null,[\"2\"]],null,10003],[1086,null,null,[1]],[63682,null,null,[]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[null,1079,null,[null,5]],[null,1050,null,[null,30]],[null,58,null,[null,120]],[1033,null,null,[1]],[10002,null,null,[1]],[null,null,null,[null,null,null,[\"Az6AfRvI8mo7yiW5fLfj04W21t0ig6aMsGYpIqMTaX60H+b0DkO1uDr+7BrzMcimWzv\/X7SXR8jI+uvbV0IJlwYAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"A+USTya+tNvDPaxUgJooz+LaVk5hPoAxpLvSxjogX4Mk8awCTQ9iop6zJ9d5ldgU7WmHqBlnQB41LHHRFxoaBwoAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"A7FovoGr67TUBYbnY+Z0IKoJbbmRmB8fCyirUGHavNDtD91CiGyHHSA2hDG9r9T3NjUKFi6egL3RbgTwhhcVDwUAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\"]],null,1934],[1957,null,null,[1]],[1971,null,null,[1]],[null,1972,null,[]],[null,1142,null,[null,8]],[null,501545963,null,[null,1]],[null,1195,null,[null,1]],[null,1119,null,[null,300]],[null,1193,null,[null,100]],[505942137,null,null,[1]],[500657056,null,null,[1]],[null,501545962,null,[null,1]],[null,495583959,null,[null,-1]],[null,45388309,null,[null,-1]],[null,1114,null,[null,1]],[null,1116,null,[null,300]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1108,null,[null,1000]],[1203,null,null,[1]],[45388146,null,null,[1]],[null,1115,null,[null,-1]],[501545959,null,null,[1]],[null,1194,null,[null,1]],[469675169,null,null,[1]],[null,469675170,null,[null,30000]],[392736476,null,null,[]],[null,null,null,[],null,1932],[432938498,null,null,[]],[485990406,null,null,[]]],[[10,[[null,[[31071642],[31071643,[[1216,null,null,[1]]]]],null,72],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[10,[[42531705],[42531706]]],[1,[[44719338],[44719339,[[334,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]]],[10,[[44767166],[44767167]]],[10,[[44782466],[44782467,[[1160,null,null,[1]]]],[44782468,[[1226,null,null,[1]],[1160,null,null,[1]]]]]],[null,[[44755592],[44755593],[44755594],[44755653],[44777509,[[1200,null,null,[1]]]]],null,51],[null,[[31071869],[31071870,[[1215,null,null,[1]]]]],null,72],[10,[[31071258],[31071259]]],[100,[[31071755],[31071756,[[1222,null,null,[1]]]]]],[100,[[31072224],[31072225,[[472491850,null,null,[1]]]]]],[100,[[31072226],[31072227,[[1227,null,null,[1]]]]]],[100,[[31072254],[31072255,[[10004,null,null,[1]]]]]],[100,[[31072258],[31072259,[[500169372,null,null,[1]]]]]],[1000,[[31072271,[[null,null,14,[null,null,\"31072271\"]]],[6,null,null,null,6,null,\"31072271\"]],[31072272,[[null,null,14,[null,null,\"31072272\"]]],[6,null,null,null,6,null,\"31072272\"]]],[4,null,55],63],[100,[[31072287],[31072288,[[null,1158,null,[null,45]]]]]],[1000,[[31072323,[[null,null,14,[null,null,\"31072323\"]]],[6,null,null,null,6,null,\"31072323\"]],[31072324,[[null,null,14,[null,null,\"31072324\"]]],[6,null,null,null,6,null,\"31072324\"]]],[4,null,55],63],[10,[[31072348],[31072349,[[1228,null,null,[1]]]]]],[1000,[[31072372,[[null,null,14,[null,null,\"31072372\"]]],[6,null,null,null,6,null,\"31072372\"]],[31072373,[[null,null,14,[null,null,\"31072373\"]]],[6,null,null,null,6,null,\"31072373\"]]],[4,null,55],63],[10,[[44772268],[44772269,[[1185,null,null,[1]]]]]],[50,[[44774292],[44774606,[[1147,null,null,[1]]]]],null,54],[1,[[44774293,[[1147,null,null,[1]]]],[44774605,[[1147,null,null,[1]]]],[44776415]],null,54],[1,[[44779343],[44779344,[[1147,null,null,[1]]]]],null,54],[200,[[44779793],[44779794,[[63682,null,null,[1]]]]],null,51],[50,[[31067422],[31067423,[[null,1032,null,[]]]],[44776074],[44776369],[44777421],[44779109],[44779906]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[10,[[44776368],[44779257]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69]]],[17,[[null,[[44773745],[44773746],[44773747]],null,null,null,null,31,null,null,113],[10,[[31071260]]],[10,[[31071261],[31071262],[31071263],[31071264]],null,null,null,44,22],[10,[[31071265],[31071266]],null,null,null,44,null,500],[10,[[31071267]],null,null,null,44,null,900],[10,[[31071268],[31071269]],null,null,null,null,null,null,null,101]]],[11,[[500,[[31072315,[[483374575,null,null,[]]]],[31072316,[[483374575,null,null,[1]]]]],[4,null,8,null,null,null,null,[\"sharedStorage\"]]]]],[12,[[20,[[21065724],[21065725,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71],[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61],[50,[[31071662],[31071663,[[1974,null,null,[1]]]]]],[10,[[31071975],[31071976,[[1975,null,null,[1]]]]]],[100,[[31072228],[31072229,[[501411886,null,null,[1]]]]]],[10,[[44769661],[44769662,[[1973,null,null,[1]]]]]]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]],[1000,[[31067146,null,[4,null,9,null,null,null,null,[\"document.browsingTopics\"]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067147,null,[2,[[4,null,9,null,null,null,null,[\"navigator.runAdAuction\"]],[4,null,9,null,null,null,null,[\"navigator.joinAdInterestGroup\"]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067148,null,[4,null,69,null,null,null,null,[\"attribution-reporting\"]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067672,null,[2,[[4,null,69,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,70,null,null,null,null,[\"browsing-topics\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067673,null,[2,[[4,null,69,null,null,null,null,[\"join-ad-interest-group\"]],[1,[[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067674,null,[2,[[4,null,69,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067675,null,[2,[[4,null,69,null,null,null,null,[\"attribution-reporting\"]],[1,[[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31068556,null,[4,null,8,null,null,null,null,[\"sharedStorage\"]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31068557,null,[2,[[4,null,69,null,null,null,null,[\"shared-storage\"]],[1,[[4,null,70,null,null,null,null,[\"shared-storage\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[null,[[31070383,null,[4,null,27,null,null,null,null,[\"crossOriginIsolated\"]]],[31070384,[[null,null,null,[null,null,null,[\"A\/6fvn8\/Gtanoa1JImBxbvhuYBg6saTOvUwnxxrjfqYKVr6FhYuq735gNAS9yiA9eZCfxy6DNpj7b5RvVydt3AAAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQW5vbnltb3VzSWZyYW1lT3JpZ2luVHJpYWwiLCJleHBpcnkiOjE2NzU4MTQzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A+U9qN2zW5GTLxw8s2+dVNTkJno6E+N\/ccDejxXyQWvhjPxM7ZW2kkup3QdRQA3PNcdJmf7fmSYjbhYI9IfoTwwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQW5vbnltb3VzSWZyYW1lT3JpZ2luVHJpYWwiLCJleHBpcnkiOjE2NzU4MTQzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A\/nrjb\/iPi\/6otfK9jaRrKeitC60ZEvSBV2LdZ9fK9wYY6avQ4BArkhirmauwsEv8oXTREo3giK6JoHNOyETTwsAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQW5vbnltb3VzSWZyYW1lT3JpZ2luVHJpYWwiLCJleHBpcnkiOjE2NzU4MTQzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,472572701],[439828594,null,null,[1]]],[4,null,27,null,null,null,null,[\"crossOriginIsolated\"]]]],[2,[[6,null,null,3,null,0],[12,null,null,null,4,null,\"Chrome\/((?!10[012345])\\\\d{3,})\",[\"navigator.userAgent\"]]]],70],[null,[[31070594],[31070595,[[null,null,null,[null,null,null,[\"A\/6fvn8\/Gtanoa1JImBxbvhuYBg6saTOvUwnxxrjfqYKVr6FhYuq735gNAS9yiA9eZCfxy6DNpj7b5RvVydt3AAAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQW5vbnltb3VzSWZyYW1lT3JpZ2luVHJpYWwiLCJleHBpcnkiOjE2NzU4MTQzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A+U9qN2zW5GTLxw8s2+dVNTkJno6E+N\/ccDejxXyQWvhjPxM7ZW2kkup3QdRQA3PNcdJmf7fmSYjbhYI9IfoTwwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQW5vbnltb3VzSWZyYW1lT3JpZ2luVHJpYWwiLCJleHBpcnkiOjE2NzU4MTQzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A\/nrjb\/iPi\/6otfK9jaRrKeitC60ZEvSBV2LdZ9fK9wYY6avQ4BArkhirmauwsEv8oXTREo3giK6JoHNOyETTwsAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQW5vbnltb3VzSWZyYW1lT3JpZ2luVHJpYWwiLCJleHBpcnkiOjE2NzU4MTQzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,472572701],[439828594,null,null,[1]],[483962503,null,null,[1]]]]],[2,[[6,null,null,3,null,0],[12,null,null,null,4,null,\"Chrome\/((?!10[012345])\\\\d{3,})\",[\"navigator.userAgent\"]]]],70],[null,[[44768158,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44768159,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[50,[[44776500,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44776501,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[50,[[44776502,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44776503,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[null,[[44783616,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44783617,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]],[20,[[1000,[[31070530,null,[4,null,27,null,null,null,null,[\"crossOriginIsolated\"]]]],[2,[[6,null,null,3,null,0],[12,null,null,null,4,null,\"Chrome\/((?!10[012345])\\\\d{3,})\",[\"navigator.userAgent\"]]]]],[1000,[[31070531,null,[2,[[4,null,27,null,null,null,null,[\"crossOriginIsolated\"]],[4,null,8,null,null,null,null,[\"credentialless\"]]]]]],[2,[[6,null,null,3,null,0],[12,null,null,null,4,null,\"Chrome\/((?!10[012345])\\\\d{3,})\",[\"navigator.userAgent\"]]]]],[1000,[[31070532,null,[4,null,9,null,null,null,null,[\"SharedArrayBuffer\"]]]],[2,[[6,null,null,3,null,0],[12,null,null,null,4,null,\"Chrome\/((?!10[012345])\\\\d{3,})\",[\"navigator.userAgent\"]]]]]]]],null,null,[null,\"1000\",1,\"1000\"]],[1,[]],null,null,1,\"playtictactoe.org\",853427758,[44759875,44759926,44759837]]");