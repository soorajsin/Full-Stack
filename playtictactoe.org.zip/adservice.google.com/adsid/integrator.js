processGoogleToken({
    "newToken": "ChAIgNynnwYQ8se30fXL1plaEjkAxziOsR4gXHOzL0Dk6ZMOx30IyDs0F_qYb5l3l6NOV8mtaEHoiWtJ-bDKlbbWmwf0d3hPVTAFNU0",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2023-02-13-20",
    "pucrd": ""
});